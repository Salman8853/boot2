package com.gigflex.prototype.microservices.department.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.department.dtob.Permissions;
import com.gigflex.prototype.microservices.department.dtob.PermissionsRequest;
import com.gigflex.prototype.microservices.department.repository.PermissionsRepository;
import com.gigflex.prototype.microservices.department.service.PermissionsService;
import com.gigflex.prototype.microservices.util.GigflexResponse;


@Service
public class PermissionsServiceImpl implements PermissionsService{
	
	@Autowired
	PermissionsRepository permissionsRepository;

	@Override
	public String getAllPermissions() {
		String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            List<Permissions> perlst = permissionsRepository.findAll();
            jsonobj.put("responsecode", 200);
            jsonobj.put("message", "Success");
            jsonobj.put("timestamp", new Date());
            if (perlst != null && perlst.size() > 0) {
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(perlst);
                jsonobj.put("data", new JSONArray(Detail));
            }
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        }
        return res;
	}

	@Override
	public String getAllPermissionsById(long id) {
		 String res = "";
	        try {
	            JSONObject jsonobj = new JSONObject();
	            Optional<Permissions> perlst = permissionsRepository.findById(id);
	            jsonobj.put("responsecode", 200);
	            jsonobj.put("message", "Success");
	            jsonobj.put("timestamp", new Date());
	            if (perlst!=null &&  perlst.get() != null ) {
	                ObjectMapper mapperObj = new ObjectMapper();
	                String Detail = mapperObj.writeValueAsString(perlst.get());
	                jsonobj.put("data", new JSONObject(Detail));
	            }
	            res = jsonobj.toString();
	        } catch (JSONException | JsonProcessingException ex) {
	            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
	            res = derr.toString();
	        }
	        return res;
	}

	@Override
	public String savePermissions(PermissionsRequest perrqst, String ip) {
		 String res = "";
	        try {
	            JSONObject jsonobj = new JSONObject();
	            Permissions per=new Permissions();
	            per.setPermissionsName(perrqst.getPermissionsName());
	            per.setIpAddress(ip);
	            Permissions perRes = permissionsRepository.save(per);
	            jsonobj.put("responsecode", 200);
	            jsonobj.put("timestamp", new Date());
	            if (perRes!=null && perRes.getId()>0 ) {
//	                kafkaService.sendDepartment(deptRes);
	                jsonobj.put("message", "Permission has been added successfully.");
	                ObjectMapper mapperObj = new ObjectMapper();
	                String Detail = mapperObj.writeValueAsString(perRes);
	                jsonobj.put("data", new JSONObject(Detail));
	            }
	            else
	                {
	            jsonobj.put("message", "Failed");
	            }
	            res = jsonobj.toString();
	        } catch (JSONException | JsonProcessingException ex) {
	            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
	            res = derr.toString();
	        }
	        return res;
	}

	@Override
	public String deletePermissionsById(long id) {
		String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            permissionsRepository.deleteById(id);
            jsonobj.put("responsecode", 200);
            jsonobj.put("message", "Permission has been deleted.");
            jsonobj.put("timestamp", new Date());
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        }
        return res;
	}
	
	

//	@Override
//	public List<Permissions> getAllPermissions() {
//	   List<Permissions> per = 	permissionsRepository.findAll();
//	   return per;
//	}
//
//	@Override
//	public Optional<Permissions> getAllPermissionsById(long id) {
//		return permissionsRepository.findById(id);
//	}
//
//	@Override
//	public Permissions savePermissions(Permissions per) {
//	return permissionsRepository.save(per);
//	}
//
//	@Override
//	public void deletePermissionsById(long id) {
//		permissionsRepository.deleteById(id);
//		
//	}

//	@Override
//	public Permissions getPermissionByName(String name) {
//		if(permissionsRepository.getPermissionByName(name).equals("name")){
//			Permissions permission = new Permissions();
//			per.setPermissionsName(true);
//			permission.setPermissionsName(name);
//		    
//			}
//	}

}
