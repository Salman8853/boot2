
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.organization.api;


import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.service.OrganizationService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
/**
 * 
 * @author ajit.p
 *
 */

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/organizationservice/")
public class OrganizationController {

	@Autowired
	OrganizationService organizationService;

	@GetMapping("/allOrganizations")
	public ResponseEntity<Object> getAllOrganizations() {
		Object response = null;
		Iterable<Organization> orgs = organizationService.findAllOrganizations();
		if (orgs == null || orgs.toString().equals("[]")) {
			response = "No Organizations Found.";
		} else {
			response = orgs;
		}
		return ResponseEntity.ok(response);
	}

	@PostMapping("/saveOrganization")
	public ResponseEntity<Object> createOrganization(@Valid @RequestBody Organization organization, Errors errors) {
		Object response = null;
		if (errors.hasErrors()) {
			response = errors.getAllErrors();
			return ResponseEntity.badRequest().body(response);
		} else {
			organization = organizationService.registerFromOrganization(organization);
			response = "Organization Saved with :" + organization.getId();
			return ResponseEntity.ok(response);
		}
	}

	@GetMapping("/getOrganization/{id}")
	public ResponseEntity<Object> getOrganization(@PathVariable Long id) {
		Object response = null;
		Optional<Organization> org = organizationService.getOrganizationById(id);
		if (org == null) {
			response = "Organization with Id : (" + id + ") Not found";
		} else {
			response = org;
		}
		return ResponseEntity.ok(response);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteEmployee(@PathVariable Long id) {
		Object response = null;
		Optional<Organization> org = organizationService.getOrganizationById(id);
		if (org == null) {
			response = "Organization with Id : (" + id + ") Not found";
		} else {
			organizationService.deleteOrganization(id);
			response = "Organization with Id : (" + id + ") Deleted";
		}

		return ResponseEntity.ok(response);
	}
/**
 * 
 * @param id
 * @param organization
 * @param errors
 * @return
 */
	@PutMapping("/update/{id}")
	public ResponseEntity<Object> updateOrganization(@PathVariable Long id, @Valid @RequestBody Organization organization,
			Errors errors, HttpServletRequest httpRequest) {
		Object response = null;
		if (errors.hasErrors()) {
			response = errors.getAllErrors();
			return ResponseEntity.badRequest().body(response);
		}
		Organization org = organizationService.getOrgById(id);
		if (org == null) {
			response = "Organization with Id : (" + id + ") Not found";
		} else {
		
			org.setId(organization.getId());
			org.setOrganizationName(organization.getOrganizationName());
			org.setOrganizationCode(organization.getOrganizationCode());
			org.setPhoneNumber(organization.getPhoneNumber());
			org.setAddress(organization.getAddress());
			org.setAddress1(organization.getAddress1());
			org.setCity(organization.getCity());
			org.setStateProvince(organization.getStateProvince());
			org.setCountry(organization.getCountry());
			org.setZipCode(organization.getZipCode());
			org.setTaxId(organization.getTaxId());
			org.setRegNo(organization.getRegNo());
			org.setWorkFrom(organization.getWorkFrom());
			org.setWorkTo(organization.getWorkTo());
			
			org.setLat(organization.getLat());
			org.setLang(organization.getLang());
			org.setIsActive(organization.getIsActive());
			org.setIpAddress(httpRequest.getRemoteAddr());
			org.setIsVerified(organization.getIsVerified());
			
			org.setUpdatedAt(organization.getUpdatedAt());
			org.setCreatedAt(organization.getCreatedAt());
			/*org.setApproved(organization.isApproved());
			org.setApprovedDate(organization.getApprovedDate());
			org.setApprovedBy(organization.getApprovedBy());*/
	
			id = organizationService.registerFromOrganization(org).getId();
			response = "Organization with Id : (" + id + ") is Updated";
		}
		return ResponseEntity.ok(response);
	}
}

