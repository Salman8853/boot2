/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.department.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.department.dtob.DepartmentMaster;
import com.gigflex.prototype.microservices.department.dtob.DepartmentMasterRequest;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.department.repository.DepartmentMasterRepository;
import com.gigflex.prototype.microservices.department.service.DepartmentMasterService;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author nirbhay.p
 */

@Service
public class DepartmentMasterServiceImpl implements DepartmentMasterService {

    @Autowired
    DepartmentMasterRepository departmentMasterRepository;
    @Autowired
    KafkaService kafkaService;
    
    @Override
    public String getAllDepartment() {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            List<DepartmentMaster> deptlst = departmentMasterRepository.findAll();
            List<DepartmentMaster> deptlstRes=new ArrayList<DepartmentMaster>();
            for(DepartmentMaster dept:deptlst)
            {
                dept.setParentid();
                deptlstRes.add(dept);
            }
            jsonobj.put("responsecode", 200);
            jsonobj.put("message", "Success");
            jsonobj.put("timestamp", new Date());
            if (deptlstRes != null && deptlstRes.size() > 0) {
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(deptlstRes);
                jsonobj.put("data", new JSONArray(Detail));
            }
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        }
        return res;
    }

    @Override
    public String getAllDepartmentByID(long id) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            Optional<DepartmentMaster> deptlst = departmentMasterRepository.findById(id);
            DepartmentMaster dept=deptlst.get();
            jsonobj.put("responsecode", 200);
            jsonobj.put("message", "Success");
            jsonobj.put("timestamp", new Date());
            if ( dept!= null ) {
                dept.setParentid();
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(dept);
                jsonobj.put("data", new JSONObject(Detail));
            }
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        }
        return res;
    }

    @Override
    public String saveNewDepartment(DepartmentMasterRequest deptReq, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            DepartmentMaster dept=new DepartmentMaster();
            dept.setDepartmentName(deptReq.getDepartmentName());
            dept.setIpAddress(ip);
            if(deptReq.getParentid()!=null && deptReq.getParentid()>0)
            {
                Optional<DepartmentMaster> deptlst = departmentMasterRepository.findById(deptReq.getParentid());
                if(deptlst!=null && deptlst.get()!=null)
                {
                    dept.setParent(deptlst.get());
                }
            }
            DepartmentMaster deptRes = departmentMasterRepository.save(dept);
            jsonobj.put("responsecode", 200);
            jsonobj.put("timestamp", new Date());
            if (deptRes!=null && deptRes.getId()>0 ) {
               if(deptRes.getParent()!=null && deptRes.getParent().getId()>0)
               {
                   deptRes.setParentid(deptRes.getParent().getId());
               }
                kafkaService.sendDepartment(deptRes);
                jsonobj.put("message", "Department has been added successfully.");
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(deptRes);
                jsonobj.put("data", new JSONObject(Detail));
            }
            else
                {
            jsonobj.put("message", "Failed");
            }
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        }
        return res;
    }

    @Override
    public String deleteDepartmentById(long id) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            departmentMasterRepository.deleteById(id);
            jsonobj.put("responsecode", 200);
            jsonobj.put("message", "Department has been deleted.");
            jsonobj.put("timestamp", new Date());
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        }
        return res;
    }

    @Override
	public DepartmentMaster updateDepartment(DepartmentMaster deptMaster, Long id) {
		DepartmentMaster departmentInDb = departmentMasterRepository.getOne(id);
		if (departmentInDb != null) {
		
			departmentInDb.setDepartmentName(deptMaster.getDepartmentName());
			departmentInDb.setParentid(deptMaster.getParentid());
			departmentInDb = departmentMasterRepository.save(departmentInDb);
		
	  }
	  return departmentInDb;
	}
    
//	@Override
//	public DepartmentMaster getDepartmentById(Long id) {
//		
//		Optional<DepartmentMaster> depMstr = departmentMasterRepository.findById(id);
//		if(depMstr.get()!=null){
//			
//			return depMstr.get();
//		}else{
//			
//			Optional<DepartmentMaster> depMstr1 = departmentMasterRepository.findById(1L);
//			
//			return depMstr1.get();
//
//		}
//	}
}
