package com.gigflex.prototype.microservices.verifyemployee.api;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkingLocation;
import com.gigflex.prototype.microservices.verifyemployee.service.WorkingLocationService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;


/**
 * 
 * @author ajit.p
 *
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/organizationservice/")
public class WorkingLocationController {

	@Autowired
	WorkingLocationService workingLocationService;

	@GetMapping("/allWorkingLocation")
	public ResponseEntity<Object> getAllWorkingLocationss() {
		Object response = null;
		Iterable<WorkingLocation> workingLocation = workingLocationService.getAllWorkingLocations();
		if (workingLocation == null || workingLocation.toString().equals("[]")) {
			response = "No Working Location Found.";
		} else {
			response = workingLocation;
		}
		return ResponseEntity.ok(response);
	}

	@GetMapping("/workingLocationById/{id}")
	public ResponseEntity<Object> getWorkingLocationById(@PathVariable Long id) {
		Object response = null;
		Optional<WorkingLocation> workingLocation = workingLocationService.getWorkingLocationsById(id);
		if (workingLocation == null) {
			response = "Working Location with Id : (" + id + ") Not found.";
		} else {
			response = workingLocation;
		}
		return ResponseEntity.ok(response);
	}

	@PostMapping("/saveWorkingLocation")
	public ResponseEntity<Object> createWorkingLocation(@Valid @RequestBody WorkingLocation workingLocation, Errors errors) {
		Object response = null;
		if (errors.hasErrors()) {
			response = errors.getAllErrors();
			return ResponseEntity.badRequest().body(response);
		} else {
			workingLocation = workingLocationService.saveWorkingLocations(workingLocation);
			response = "Working Location Saved with Id :" + workingLocation.getId();
			return ResponseEntity.ok(response);
		}
	}

	@DeleteMapping("/deleteWorkingLocation/{id}")
	public ResponseEntity<Object> deleteWorkingLocation(@PathVariable Long id) {
		Object response = null;
		Optional<WorkingLocation> workingLocation = workingLocationService.getWorkingLocationsById(id);
		if (workingLocation == null) {
			response = "Working Location with Id : (" + id + ") Not found.";
		} else {
			workingLocationService.deleteWorkingLoccationsById(id);
			response = "Working Location with Id : (" + id + ") Deleted.";
		}

		return ResponseEntity.ok(response);
	}

	/**
	 * 
	 * @param id
	 * @param workingLocation
	 * @param errors
	 * @return
	 */
	@PutMapping("/updateWorkingLocation/{id}")
	public ResponseEntity<Object> updateWorkingLocation(@PathVariable Long id, @Valid @RequestBody WorkingLocation workingLocation,
			Errors errors) {
		Object response = null;
		if (errors.hasErrors()) {
			response = errors.getAllErrors();
			return ResponseEntity.badRequest().body(response);
		}
		Optional<WorkingLocation> workingLoc = workingLocationService.getWorkingLocationsById(id);
		if (workingLoc == null) {
			response = "Working Location with Id : (" + id + ") Not found.";
		} else {
			workingLocation = workingLocationService.saveWorkingLocations(workingLocation);

			id = workingLocationService.saveWorkingLocations(workingLocation).getId();
			response = "Working Location with Id : (" + id + ") is Updated.";
		}
		return ResponseEntity.ok(response);
	}
}