package com.gigflex.prototype.microservices.permissions.dtob;

public class PermissionActivitiesResponse {
	
    private Long id;
	
	private String activitiesCode;
	
	private String url;

	private String permissionsCode;
	
    private String permissionsName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getActivitiesCode() {
		return activitiesCode;
	}

	public void setActivitiesCode(String activitiesCode) {
		this.activitiesCode = activitiesCode;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getPermissionsCode() {
		return permissionsCode;
	}

	public void setPermissionsCode(String permissionsCode) {
		this.permissionsCode = permissionsCode;
	}

	public String getPermissionsName() {
		return permissionsName;
	}

	public void setPermissionsName(String permissionsName) {
		this.permissionsName = permissionsName;
	}
    
    
	
	

}
