package com.gigflex.prototype.microservices.permissions.dtob;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class PermissionsRequest {
	
	@NotNull
	@NotEmpty
	private String permissionsName;

	public String getPermissionsName() {
		return permissionsName;
	}

	public void setPermissionsName(String permissionsName) {
		this.permissionsName = permissionsName;
	}
	

}
