package com.gigflex.prototype.microservices.daysmaster.service;

import java.util.List;

import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMasterRequest;

public interface DaysMasterService {
	
	public String getAllDaysMasterByPage(int page, int limit);

	public String findAllDaysMaster();

	

}
