package com.gigflex.prototype.microservices.organizationworkerskill.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.industry.dtob.IndustryMaster;
import com.gigflex.prototype.microservices.industry.repository.IndustryMasterDao;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrgWorkerSkillRequest;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrgWorkerSkillResponse;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkill;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkillRequest;
import com.gigflex.prototype.microservices.organizationworkerskill.repository.OrgWorkerSkillDao;
import com.gigflex.prototype.microservices.organizationworkerskill.search.OrganizationWorkerSkillSpecificationsBuilder;
import com.gigflex.prototype.microservices.organizationworkerskill.service.OrgWorkerSkillService;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.skillmaster.repository.SkillMasterDao;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;

@Service
public class OrgWorkerSkillServiceImpl implements OrgWorkerSkillService {

	@Autowired
	private OrgWorkerSkillDao orgWorkerSkillDao;
	
	@Autowired
	private IndustryMasterDao industryDao;

	@Autowired
	private KafkaService kafkaService;
	
	 @Autowired
		OrganizationRepository orgRep;
	    
	    @Autowired
	    SkillMasterDao skillRep;
	    
	    @Autowired
	    WorkerRepository workRep;

	@Override
	public String updateOrgWorkerSkillById(Long id,
			OrganizationWorkerSkillRequest orgWorkerSkillReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && orgWorkerSkillReq != null) {
				if (orgWorkerSkillReq.getSkillCode() != null
						&& orgWorkerSkillReq.getSkillCode().trim().length() > 0
						&& orgWorkerSkillReq.getOrganizationCode() != null
						&& orgWorkerSkillReq.getOrganizationCode().trim()
								.length() > 0
						&& orgWorkerSkillReq.getWorkerCode() != null
						&& orgWorkerSkillReq.getWorkerCode().trim().length() > 0
						&& orgWorkerSkillReq.getExperienceInDays() != null && orgWorkerSkillReq.getExperienceInDays() >= 0 ) {

					OrganizationWorkerSkill orgWorSkInDb = orgWorkerSkillDao
							.getOrganizationWorkerSkillById(id);
					
					
					OrganizationWorkerSkill orgSkills = orgWorkerSkillDao.getOrgWorkSkillCheckForUpdate(id, orgWorkerSkillReq.getSkillCode(), orgWorkerSkillReq.getOrganizationCode(), orgWorkerSkillReq.getWorkerCode());

					if (orgSkills != null && orgSkills.getId() > 0) {
						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record already exist.");
					} else {
					
					Organization org = orgRep
							.findByOrganizationCode(orgWorkerSkillReq
									.getOrganizationCode());
					if (org != null && org.getId() > 0) {
					Worker worker = workRep.findByWorkerCode(orgWorkerSkillReq.getWorkerCode());
					if(worker != null && worker.getId() > 0){
					SkillMaster skill = skillRep.getSkillCode(orgWorkerSkillReq.getSkillCode());
					if (skill != null && skill.getId() > 0) {
					
					if (orgWorSkInDb != null && orgWorSkInDb.getId() > 0) {

						OrganizationWorkerSkill map = orgWorSkInDb;

						map.setSkillCode(orgWorkerSkillReq.getSkillCode());
						map.setOrganizationCode(orgWorkerSkillReq
								.getOrganizationCode());
						map.setWorkerCode(orgWorkerSkillReq.getWorkerCode());
//						map.setExperienceInYear(orgWorkerSkillReq
//								.getExperienceInYear());
						map.setExperienceInDays(orgWorkerSkillReq.getExperienceInDays());
						if (orgWorkerSkillReq.getIsAssigned() != null) {
							map.setIsAssigned(orgWorkerSkillReq.getIsAssigned());
						} else {
							map.setIsAssigned(false);
						}

						map.setIpAddress(ip);

						OrganizationWorkerSkill mapRes = orgWorkerSkillDao
								.save(map);
						if (mapRes != null && mapRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"OrganizationWorkerSkill updation has been done");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(mapRes);
							jsonobj.put("data", new JSONObject(Detail));
							kafkaService
									.sendUpdateOrganizationWorkerSkill(mapRes);

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"OrganizationWorkerSkill updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message",
								"OrganizationWorkerSkill ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
					
					} else {
						jsonobj.put("message", "Skill Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
					}
					
				} else {
					jsonobj.put("message", "Worker Code Not Found.");
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					}
					
					} else {
					jsonobj.put("message", "Organization Code Not Found.");
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					}
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message",
							"Organization code and Worker Code and Skill Code should not be blank");

					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllOrgWorkerSkill() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = orgWorkerSkillDao
					.getAllOrgWorkerSkillWithNames();
			List<OrgWorkerSkillResponse> maplst = new ArrayList<OrgWorkerSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						OrgWorkerSkillResponse ows = new OrgWorkerSkillResponse();

						OrganizationWorkerSkill data = (OrganizationWorkerSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
						ows.setWorkerCode(data.getWorkerCode());
//						ows.setExperienceInYear(data.getExperienceInYear());
						ows.setExperienceInDays(data.getExperienceInDays());

						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
						ows.setWorkerName((String) arr[3]);

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String findAllOrgWorkerSkill() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<OrganizationWorkerSkill> maplst = orgWorkerSkillDao
					.getAllOrganizationWorkerSkill();
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (maplst != null && maplst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String findOrgWorkerSkillById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			OrganizationWorkerSkill orgWorSklst = orgWorkerSkillDao
					.getOrganizationWorkerSkillById(id);
			if (orgWorSklst != null && orgWorSklst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(orgWorSklst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveOrgWorkerSkill(OrganizationWorkerSkillRequest orgWorkerSkillReq,
			String ip) {
		String res = "";
		try {
//			JSONArray jarr = new JSONArray();

			if (orgWorkerSkillReq != null) {
				if (orgWorkerSkillReq.getSkillCode() != null
						&& orgWorkerSkillReq.getSkillCode().trim().length() > 0
						&& orgWorkerSkillReq.getOrganizationCode() != null
						&& orgWorkerSkillReq.getOrganizationCode().trim()
								.length() > 0
						&& orgWorkerSkillReq.getWorkerCode() != null
						&& orgWorkerSkillReq.getWorkerCode().trim().length() > 0
						&& orgWorkerSkillReq.getExperienceInDays() != null && orgWorkerSkillReq.getExperienceInDays() >= 0) {
			
//					for (String skillcode : orgWorkerSkillReq.getSkillCode()) {
//						if (skillcode != null && skillcode.trim().length() > 0) {
							JSONObject jsonobj = new JSONObject();
							OrganizationWorkerSkill orgSkill = orgWorkerSkillDao.getOrgWorkSkillCheckForSave(orgWorkerSkillReq.getSkillCode(), orgWorkerSkillReq.getOrganizationCode(), orgWorkerSkillReq.getWorkerCode());
							if (orgSkill != null && orgSkill.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record already exist.");
							} else {
							
							Organization org = orgRep
									.findByOrganizationCode(orgWorkerSkillReq
											.getOrganizationCode());
							if (org != null && org.getId() > 0) {
							Worker worker = workRep.findByWorkerCode(orgWorkerSkillReq.getWorkerCode());
							if(worker != null && worker.getId() > 0){
							SkillMaster skill = skillRep.getSkillCode(orgWorkerSkillReq.getSkillCode());
							if (skill != null && skill.getId() > 0) {

							OrganizationWorkerSkill map = new OrganizationWorkerSkill();

							map.setSkillCode(orgWorkerSkillReq.getSkillCode());
							map.setOrganizationCode(orgWorkerSkillReq
									.getOrganizationCode());
							map.setWorkerCode(orgWorkerSkillReq.getWorkerCode());
//							map.setExperienceInYear(orgWorkerSkillReq
//									.getExperienceInYear());
							map.setExperienceInDays(orgWorkerSkillReq.getExperienceInDays());

							if (orgWorkerSkillReq.getIsAssigned() != null) {
								map.setIsAssigned(orgWorkerSkillReq.getIsAssigned());
							} else {
								map.setIsAssigned(false);
							}
							map.setIpAddress(ip);

							OrganizationWorkerSkill mapRes = orgWorkerSkillDao
									.save(map);
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());

							if (mapRes != null && mapRes.getId() > 0) {
								kafkaService
										.sendOrganizationWorkerSkill(mapRes);
								jsonobj.put("message",
										"Organization Code and Skill Code And Worker Code has been added successfully.");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(mapRes);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("message", "Failed");
							}
							
						} else {
							jsonobj.put("message", "Skill Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
						
					} else {
						jsonobj.put("message", "Worker Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						}
						
						} else {
						jsonobj.put("message", "Organization Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						}
							}
//							jarr.add(jsonobj);

//						}
//					}
//					if (jarr.size() > 0) {
//						res = jarr.toString();
//					} else {
//						GigflexResponse derr = new GigflexResponse(400,
//								new Date(), "Multiple add failed.");
//						res = derr.toString();
//					}
//				}
							res = jsonobj.toString();
				} else {
					GigflexResponse derr = new GigflexResponse(400, new Date(),
							"Organization Code and Skill Code And Worker Code should not be blank");
					res = derr.toString();

				}
			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String deleteOrgWorkerSkillById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<OrganizationWorkerSkill> mapData = orgWorkerSkillDao
					.findById(id);
			if (mapData.isPresent() && mapData.get() != null) {

				orgWorkerSkillDao.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message",
						" OrganizationWorkerSkill has been deleted.");
				jsonobj.put("timestamp", new Date());
				kafkaService.sendDeleteOrganizationWorkerSkill(mapData.get());
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softDeleteOrgWorkerSkillById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			OrganizationWorkerSkill orgWorSklst = orgWorkerSkillDao
					.getOrganizationWorkerSkillById(id);

			if (orgWorSklst != null && orgWorSklst.getId() > 0) {
				orgWorSklst.setIsDeleted(true);
				OrganizationWorkerSkill orgwkSkillRes = orgWorkerSkillDao
						.save(orgWorSklst);
				if (orgwkSkillRes != null && orgwkSkillRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());

					jsonobj.put("message",
							"OrganizationWorkerSkill deleted successfully.");

					kafkaService
							.sendUpdateOrganizationWorkerSkill(orgwkSkillRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getSkillsByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (organizationCode != null && organizationCode.length() > 0) {
				List<SkillMaster> skillsRes = new ArrayList<SkillMaster>();

				List<SkillMaster> skills = new ArrayList<SkillMaster>();
				skills = orgWorkerSkillDao
						.getSkillsByOrganizationCode(organizationCode);
				if (skills != null && skills.size() > 0) {
				
				for (SkillMaster sm : skills) {

					IndustryMaster im = industryDao.getIndustryMasterByIndustryCode(sm.getIndustryCode());
					if(im != null && im.getId() > 0){
					sm.setIndustryName(im.getIndustryName());
					
					}
					skillsRes.add(sm);

				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (skillsRes != null && skillsRes.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(skills);
					jsonobj.put("data", new JSONArray(Detail));

				}else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
				}
				}else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
				
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getSkillsByWorkerCode(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (workerCode != null && workerCode.length() > 0) {
				List<SkillMaster> skillsRes = new ArrayList<SkillMaster>();

				List<SkillMaster> skills = new ArrayList<SkillMaster>();
				skills = orgWorkerSkillDao.getSkillsByWorkerCode(workerCode);
				if (skills != null && skills.size() > 0) {
					
					for (SkillMaster sm : skills) {

						IndustryMaster im = industryDao.getIndustryMasterByIndustryCode(sm.getIndustryCode());
						if(im != null && im.getId() > 0){
						sm.setIndustryName(im.getIndustryName());
						
						}
						skillsRes.add(sm);

					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());

					if (skillsRes != null && skillsRes.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(skills);
						jsonobj.put("data", new JSONArray(Detail));

					}else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");

					}
					}
					}else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");

					}
					
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Invalid Input");
				}

				res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteById(List<Long> idList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (Long id : idList) {
				if (id != null && id > 0) {
					JSONObject jsonobj = new JSONObject();

					OrganizationWorkerSkill orgWorSklst = orgWorkerSkillDao
							.getOrganizationWorkerSkillById(id);

					if (orgWorSklst != null && orgWorSklst.getId() > 0) {

						orgWorSklst.setIsDeleted(true);
						OrganizationWorkerSkill orgwkSkillRes = orgWorkerSkillDao
								.save(orgWorSklst);
						if (orgwkSkillRes != null && orgwkSkillRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("Id", id);
							jsonobj.put("message",
									"Organization Worker Skill deleted successfully.");
							kafkaService
									.sendUpdateOrganizationWorkerSkill(orgwkSkillRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("Id", id);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("Id", id);
						jsonobj.put("message", "Record Not Found");
					}

					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getSkillsByOrgCodeByPage(String organizationCode, int page,
			int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (organizationCode != null && organizationCode.length() > 0) {
				List<SkillMaster> skillsRes = new ArrayList<SkillMaster>();

				List<SkillMaster> skills = new ArrayList<SkillMaster>();
				skills = orgWorkerSkillDao.getSkillsByOrganizationCode(
						organizationCode, pageableRequest);
				
				if (skills != null && skills.size() > 0) {
					
					for (SkillMaster sm : skills) {

						IndustryMaster im = industryDao.getIndustryMasterByIndustryCode(sm.getIndustryCode());
						if(im != null && im.getId() > 0){
						sm.setIndustryName(im.getIndustryName());
						
						}
						skillsRes.add(sm);

					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());

					if (skillsRes != null && skillsRes.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(skills);
						jsonobj.put("data", new JSONArray(Detail));

					}else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");

					}
					}
					}else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");

					}
					
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Invalid Input");
				}

				res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getSkillsByWorkerCodeByPage(String workerCode, int page,
			int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);

			if (workerCode != null && workerCode.length() > 0) {
				List<SkillMaster> skillsRes = new ArrayList<SkillMaster>();

				List<SkillMaster> skills = new ArrayList<SkillMaster>();
				skills = orgWorkerSkillDao.getSkillsByWorkerCode(workerCode,
						pageableRequest);
				
				if (skills != null && skills.size() > 0) {
					
					for (SkillMaster sm : skills) {

						IndustryMaster im = industryDao.getIndustryMasterByIndustryCode(sm.getIndustryCode());
						if(im != null && im.getId() > 0){
						sm.setIndustryName(im.getIndustryName());
						
						}
						skillsRes.add(sm);

					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());

					if (skillsRes != null && skillsRes.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(skills);
						jsonobj.put("data", new JSONArray(Detail));

					}else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");

					}
					}
					}else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");

					}
					
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Invalid Input");
				}

				res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getOrgWorkerSkill(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<OrganizationWorkerSkill> org = orgWorkerSkillDao
					.getAllOrganizationWorkerSkill(pageableRequest);
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (org != null && org.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(org);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getOrgWorkerSkillWithNamesByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = orgWorkerSkillDao
					.getAllOrgWorkerSkillWithNames(pageableRequest);
			List<OrgWorkerSkillResponse> maplst = new ArrayList<OrgWorkerSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						OrgWorkerSkillResponse ows = new OrgWorkerSkillResponse();

						OrganizationWorkerSkill data = (OrganizationWorkerSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
						ows.setWorkerCode(data.getWorkerCode());
//						ows.setExperienceInYear(data.getExperienceInYear());
						ows.setExperienceInDays(data.getExperienceInDays());

						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
						ows.setWorkerName((String) arr[3]);

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getSkillsByWorkerCodeAssigned(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (workerCode != null && workerCode.length() > 0) {
				List<SkillMaster> skillsRes = new ArrayList<SkillMaster>();

				List<SkillMaster> skills = new ArrayList<SkillMaster>();
				skills = orgWorkerSkillDao.getSkillsByWorkerCodeAssigned(workerCode);
				if (skills != null && skills.size() > 0) {
					
					for (SkillMaster sm : skills) {

						IndustryMaster im = industryDao.getIndustryMasterByIndustryCode(sm.getIndustryCode());
						if(im != null && im.getId() > 0){
						sm.setIndustryName(im.getIndustryName());
						
						}
						skillsRes.add(sm);

					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());

					if (skillsRes != null && skillsRes.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(skills);
						jsonobj.put("data", new JSONArray(Detail));

					}else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");

					}
					}
					}else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");

					}
					
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Invalid Input");
				}

				res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
            if(search != null && search.trim().length() > 0){
			JSONObject jsonobj = new JSONObject();
			
			OrganizationWorkerSkillSpecificationsBuilder builder = new OrganizationWorkerSkillSpecificationsBuilder();
		        Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
		        java.util.regex.Matcher matcher = pattern.matcher(search + ",");
		        while (matcher.find()) {
		            builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
		        }
		         
		        Specification<OrganizationWorkerSkill> spec = builder.build();
                        if(spec!=null){
		        List<OrganizationWorkerSkill> orglst = orgWorkerSkillDao.findAll(spec);
			if(orglst != null && orglst.size() > 0){
			for(OrganizationWorkerSkill org : orglst){
				if(org.getIsDeleted() != null && org.getIsDeleted() != true){

					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(org);
					JSONObject jsonobjNew = new JSONObject();
					jsonobjNew.put("OrganizationWorkerSkill", new JSONObject(Detail));
					jarr.add(jsonobjNew);

			} 
				
			} 
			if (jarr.size() > 0) {
				
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			jsonobj.put("data", jarr);
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}
			
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}}
                        else{
                           jsonobj.put("responsecode", 400);
			   jsonobj.put("message", "Record Not Found!");
			   jsonobj.put("timestamp", new Date()); 
                        }
			res = jsonobj.toString();
		
            }else{
            	GigflexResponse derr = new GigflexResponse(400, new Date(),
    					"Input data is not valid.");
    			res = derr.toString();

            }
			
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

}
