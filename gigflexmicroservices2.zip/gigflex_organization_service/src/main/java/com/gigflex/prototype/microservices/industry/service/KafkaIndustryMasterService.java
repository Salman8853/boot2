package com.gigflex.prototype.microservices.industry.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.industry.dtob.IndustryMaster;
import com.gigflex.prototype.microservices.industry.repository.IndustryMasterDao;

@Service
public class KafkaIndustryMasterService {
	
	@Autowired
	private IndustryMasterDao industryMasterDao;
	
	 private static final Logger LOG = LoggerFactory.getLogger(KafkaIndustryMasterService.class);

		@KafkaListener(topics = "NewIndustryMaster")
	    public void listen(@Payload String message) {
			ObjectMapper objectMapper = new ObjectMapper();
			LOG.info("received message='{}'", message);
			try {
				IndustryMaster im = objectMapper.readValue(message, IndustryMaster.class);
				industryMasterDao.save(im);
				
			} catch (JsonParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
}
