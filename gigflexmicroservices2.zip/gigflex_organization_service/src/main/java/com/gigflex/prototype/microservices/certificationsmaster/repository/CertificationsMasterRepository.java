package com.gigflex.prototype.microservices.certificationsmaster.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;

public interface CertificationsMasterRepository extends JpaRepository<CertificationsMaster,Long>{
	
	public CertificationsMaster getCertificationsMasterByCertificationCode(String certificationCode);
	
	@Transactional
	public Integer deleteCertificationsMasterByCertificationCode(String certificationCode);
	
   
}
