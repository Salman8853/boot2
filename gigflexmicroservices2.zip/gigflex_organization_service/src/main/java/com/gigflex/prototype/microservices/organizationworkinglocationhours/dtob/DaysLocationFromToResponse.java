package com.gigflex.prototype.microservices.organizationworkinglocationhours.dtob;

import java.util.List;

public class DaysLocationFromToResponse {
	
	private String location;
	
	private List<DaysFromToResponse> daysFromToResponse;

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<DaysFromToResponse> getDaysFromToResponse() {
		return daysFromToResponse;
	}

	public void setDaysFromToResponse(List<DaysFromToResponse> daysFromToResponse) {
		this.daysFromToResponse = daysFromToResponse;
	}
	
	

}
