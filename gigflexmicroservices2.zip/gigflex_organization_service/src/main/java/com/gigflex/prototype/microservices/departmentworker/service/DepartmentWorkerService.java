/**
 * 
 */
package com.gigflex.prototype.microservices.departmentworker.service;

import com.gigflex.prototype.microservices.departmentworker.dtob.DepartmentWorkerRequest;

/**
 * @author ajit.p
 *
 */

public interface DepartmentWorkerService {
	
	public String search(String search);

	public String saveWorkerInDepartment(DepartmentWorkerRequest depWrokerRequest, String ip);

	public String updateWorkerById(Long id, DepartmentWorkerRequest DepartmentWorkerRequest, String ip);
	
	public String getDepartmentWorkerByWorkerCode(String workerCode);
	
	public String getDepartmentWorkerByWorkerCode(String workerCode,int page, int limit);
	
	public String getDepartmentWorkerByWorkerCodeAssigned(String workerCode);

	
}
