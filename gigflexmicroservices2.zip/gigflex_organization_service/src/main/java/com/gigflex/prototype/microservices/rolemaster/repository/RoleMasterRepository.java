package com.gigflex.prototype.microservices.rolemaster.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.rolemaster.dtob.RoleMaster;
import com.gigflex.prototype.microservices.userrolemapping.dtob.UserRolesMapping;

@Repository
public interface RoleMasterRepository extends JpaRepository<RoleMaster, Long>,JpaSpecificationExecutor<RoleMaster> {
	
	@Query("SELECT role FROM RoleMaster role WHERE role.isDeleted != TRUE AND role.roleCode = :roleCode")
    public RoleMaster getRoleMasterByRoleCode(@Param("roleCode") String roleCode);
	
	@Transactional
    public Integer deleteByRoleCode(String roleCode);

	@Query("SELECT role FROM RoleMaster role WHERE role.isDeleted != TRUE")
	public List<RoleMaster> getAllRoleMaster();

	
	@Query("SELECT role FROM RoleMaster role WHERE role.isDeleted != TRUE")
	public List<RoleMaster> getAllRoleMaster(Pageable pageableRequest);


	@Query("SELECT role FROM RoleMaster role WHERE role.isDeleted != TRUE AND role.id = :id")
	public RoleMaster getRoleMasterById(@Param("id") Long id);
	
	@Query("SELECT role FROM RoleMaster role WHERE role.isDeleted != TRUE AND role.organizationCode = :organizationCode AND role.roleName = :roleName")
	public RoleMaster getRoleMasterByOrgCodeRoleName(@Param("organizationCode") String organizationCode,@Param("roleName") String roleName);
	
	@Query("SELECT role FROM RoleMaster role WHERE role.isDeleted != TRUE AND role.id != :id AND role.organizationCode = :organizationCode AND role.roleName = :roleName")
	public RoleMaster getRoleMasterByIdOrgCodeRoleName(@Param("id") Long id,@Param("organizationCode") String organizationCode,@Param("roleName") String roleName);
	
	@Query("SELECT a,o.organizationName FROM RoleMaster a, Organization o WHERE a.isDeleted != TRUE AND o.organizationCode = a.organizationCode AND o.organizationCode = :organizationCode")
	public List<Object> getRoleMasterByOrgCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT a,o.organizationName FROM RoleMaster a, Organization o WHERE a.isDeleted != TRUE AND o.organizationCode = a.organizationCode AND o.organizationCode = :organizationCode")
	public List<Object> getRoleMasterByOrgCodeByPage(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
	
	@Query("SELECT a FROM UserRolesMapping a WHERE a.isDeleted != TRUE AND a.roleCode = :roleCode")
	public List<UserRolesMapping> getUserRolemapByRoleCode(@Param("roleCode") String roleCode);

	
}