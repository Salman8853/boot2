package com.gigflex.prototype.microservices.organization.dtob;

import java.util.List;

public class MassActiveInactiveOrganization {
	
	private List<String> organizationCode;
	
	private Boolean isActive;

	public List<String> getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(List<String> organizationCode) {
		this.organizationCode = organizationCode;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	

}
