package com.gigflex.prototype.microservices.department.dtob;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class DepartmentMasterOrgNameResponse {

	private Long id;

	private String departmentName;

	private Long parentid;

	private String parentName;

	private String organizationCode;

	private String organizationName;

//	@JsonIgnore
//	@ManyToOne
//	@JoinColumn(name = "parentid")
//	private DepartmentMaster parent;

//	@JsonIgnore
//	@OneToMany(mappedBy = "parent", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//	private Set<DepartmentMaster> childDepartment = new HashSet();

//	public void setParentid() {
//		if (parent != null && parent.getId() > 0) {
//			this.parentid = parent.getId();
//		}
//
//	}
//
//	public void setParentName() {
//		if (parent != null && parent.getId() > 0
//				&& parent.getDepartmentName() != null) {
//			this.parentName = parent.getDepartmentName();
//		}
//
//	}

//	public DepartmentMaster getParent() {
//		return parent;
//	}
//
//	public void setParent(DepartmentMaster parent) {
//		this.parent = parent;
//	}
//
//	public Set<DepartmentMaster> getChildDepartment() {
//		return childDepartment;
//	}
//
//	public void setChildDepartment(Set<DepartmentMaster> childDepartment) {
//		this.childDepartment = childDepartment;
//	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public Long getParentid() {
		return parentid;
	}

	public void setParentid(Long parentid) {
		this.parentid = parentid;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

}
