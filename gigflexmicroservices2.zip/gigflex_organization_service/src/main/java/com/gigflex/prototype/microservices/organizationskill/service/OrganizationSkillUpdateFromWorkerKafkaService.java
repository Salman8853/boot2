package com.gigflex.prototype.microservices.organizationskill.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationskill.repository.OrganizationSkillDao;

@Service
public class OrganizationSkillUpdateFromWorkerKafkaService {

	@Autowired
	private OrganizationSkillDao orgSkillDao;

	private static final Logger LOG = LoggerFactory
			.getLogger(OrganizationSkillUpdateFromWorkerKafkaService.class);

	@KafkaListener(topics = "UpdateOrganizationSkillFromWorker")
	public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			OrganizationSkill os = objectMapper.readValue(message,
					OrganizationSkill.class);

			LOG.info("received message='{}'", os.getOrganizationCode());
			LOG.info("received message='{}'", os.getSkillCode());

			OrganizationSkill orgSkillRes = orgSkillDao
					.getSkillByOrgCodeSkillCode(os.getOrganizationCode(),
							os.getSkillCode());

			if (orgSkillRes != null && orgSkillRes.getId() > 0) {
				orgSkillRes.setOrganizationCode(os.getOrganizationCode());
				orgSkillRes.setSkillCode(os.getSkillCode());
				orgSkillRes.setIpAddress(os.getIpAddress());
				orgSkillRes.setIsDeleted(os.getIsDeleted());
				orgSkillDao.save(orgSkillRes);
			}

		} catch (JsonParseException e) {
			LOG.error(
					"In OrganizationSkillUpdateFromWorkerKafkaService >>>>",
					e);
		} catch (JsonMappingException e) {
			LOG.error(
					"In OrganizationSkillUpdateFromWorkerKafkaService >>>>",
					e);
		} catch (IOException e) {
			LOG.error(
					"In OrganizationSkillUpdateFromWorkerKafkaService >>>>",
					e);
		} catch (Exception e) {
			LOG.error(
					"In OrganizationSkillUpdateFromWorkerKafkaService >>>>",
					e);
		}
	}

}
