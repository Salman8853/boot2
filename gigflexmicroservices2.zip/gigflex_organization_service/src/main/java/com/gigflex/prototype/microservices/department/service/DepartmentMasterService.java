
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.department.service;

import java.util.List;
import java.util.Optional;

import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.department.dtob.DepartmentMaster;
import com.gigflex.prototype.microservices.department.dtob.DepartmentMasterRequest;

/**
 *
 * @author nirbhay.p
 */
public interface DepartmentMasterService {
	
	public String search(String search);
    public String getAllDepartment();
    public String getAllDepartmentByPage(int page, int limit);
    public String getAllDepartmentByID(long id);
    public String saveNewDepartment(DepartmentMasterRequest dept, String ip);
    public String deleteDepartmentById(long id);
    public String updateDepartment(DepartmentMaster deptMaster, Long id);
    
    public String getDepartmentMasterByDepartmentCode(String departmentCode);
	
	public String deleteByDepartmentCode(String departmentCode);
	public String softDeleteByDepartmentCode(String departmentCode);
    public String softMultipleDeleteByDepartmentCode(List<String> departmentCodeList);

	public String getDepartmentByParentId(Long parentId);
	public String getDepartmentByParentId(Long parentId,int page, int limit);
	
	public String getDepartmentMasterByOrgCode(String organizationCode);
	public String getDepartmentMasterByOrgCodeByPage(String organizationCode,int page, int limit);
    
//  public DepartmentMaster getDepartmentById(Long id);
    
}
