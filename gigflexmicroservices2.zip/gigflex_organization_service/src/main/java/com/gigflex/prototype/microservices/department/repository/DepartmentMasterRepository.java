/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.department.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.department.dtob.DepartmentMaster;
import com.gigflex.prototype.microservices.departmentworker.dtob.DepartmentWorker;
import com.gigflex.prototype.microservices.worker.dtob.Worker;


/**
 *
 * @author nirbhay.p
 */
@Repository
public interface DepartmentMasterRepository extends JpaRepository<DepartmentMaster, Long>,JpaSpecificationExecutor<DepartmentMaster>{
	
	@Query("SELECT d FROM DepartmentMaster d WHERE d.isDeleted != TRUE AND d.departmentCode = :departmentCode")
	public DepartmentMaster getDepartmentMasterByDepartmentCode(@Param("departmentCode") String departmentCode);
	
	@Transactional
	public Integer deleteByDepartmentCode(String departmentCode);
	
	@Query("SELECT d FROM DepartmentMaster d WHERE d.isDeleted != TRUE")
	public List<DepartmentMaster> getAllDepartmentMaster();
	
	@Query("SELECT d FROM DepartmentMaster d WHERE d.isDeleted != TRUE")
	public List<DepartmentMaster> getAllDepartmentMaster(Pageable pageableRequest);

	@Query("SELECT d FROM DepartmentMaster d WHERE d.isDeleted != TRUE AND d.id = :id")
	public DepartmentMaster getDepartmentMasterById(@Param("id") Long id);
	
	@Query("SELECT a FROM DepartmentMaster a WHERE a.isDeleted != TRUE AND a.parent.id= :parentid")
	public List<DepartmentMaster> getDepartmentByParentId(@Param("parentid") Long parentid);
	
	@Query("SELECT a FROM DepartmentMaster a WHERE a.isDeleted != TRUE AND a.parent.id= :parentid")
	public List<DepartmentMaster> getDepartmentByParentId(@Param("parentid") Long parentid, Pageable pageableRequest);
	
	@Query("SELECT a FROM DepartmentMaster a WHERE a.isDeleted != TRUE AND a.organizationCode = :organizationCode AND a.departmentName = :departmentName")
	public DepartmentMaster getDepartmentMasterByOrgCodeDeptName(@Param("organizationCode") String organizationCode,@Param("departmentName") String departmentName);
	
	@Query("SELECT a FROM DepartmentMaster a WHERE a.isDeleted != TRUE AND a.id != :id AND a.organizationCode = :organizationCode AND a.departmentName = :departmentName")
	public DepartmentMaster getDepartmentMasterByIdOrgCodeDeptName(@Param("id") Long id,@Param("organizationCode") String organizationCode,@Param("departmentName") String departmentName);
	
	@Query("SELECT a,o.organizationName FROM DepartmentMaster a, Organization o WHERE a.isDeleted != TRUE AND o.organizationCode = a.organizationCode AND o.organizationCode = :organizationCode")
	public List<Object> getDepartmentMasterByOrgCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT a,o.organizationName FROM DepartmentMaster a, Organization o WHERE a.isDeleted != TRUE AND o.organizationCode = a.organizationCode AND o.organizationCode = :organizationCode")
	public List<Object> getDepartmentMasterByOrgCodeByPage(@Param("organizationCode") String organizationCode, Pageable pageableRequest);

	@Query("SELECT org FROM DepartmentWorker org WHERE org.isDeleted != TRUE AND org.departmentCode = :departmentCode")
	public List<DepartmentWorker> getOrgDepWorByDepartmentCode(@Param("departmentCode") String departmentCode);
	
	@Query("SELECT org FROM Worker org WHERE org.isDeleted != TRUE AND org.departmentCode = :departmentCode")
	public List<Worker> getWorkerByDepartmentCode(@Param("departmentCode") String departmentCode);


}
