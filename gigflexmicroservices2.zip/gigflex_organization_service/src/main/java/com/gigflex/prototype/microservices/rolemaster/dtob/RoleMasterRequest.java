package com.gigflex.prototype.microservices.rolemaster.dtob;

import javax.persistence.Column;



public class RoleMasterRequest {
	
 
    private String roleName;
    
    private Boolean isActive;
    
	private String organizationCode;

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
    
    

}
