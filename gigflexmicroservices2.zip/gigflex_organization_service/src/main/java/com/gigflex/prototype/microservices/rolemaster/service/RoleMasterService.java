package com.gigflex.prototype.microservices.rolemaster.service;

import java.util.List;

import com.gigflex.prototype.microservices.rolemaster.dtob.RoleMasterRequest;

public interface RoleMasterService {
	
	public String updateRoleMasterById(Long id,RoleMasterRequest roleMaster,String ip);
	public String findAllRoleMaster();
	public String getAllRoleMasterByPage(int page, int limit);
	public String findRoleMasterById(Long id);
	public String saveRoleMaster(RoleMasterRequest roleMasterReq,String ip);
	public String deleteRoleMasterById(Long id);
	public String getRoleMasterByRoleCode(String roleCode);
	public String deleteByRoleCode(String roleCode);
	public String softDeleteByRoleCode(String roleCode);
    public String softMultipleDeleteByRoleCode(List<String> roleCodeList);
	public String search(String search);
	public String getRoleMasterByOrgCode(String organizationCode);
	public String getRoleMasterByOrgCodeByPage(String organizationCode,int page, int limit);


}
