package com.gigflex.prototype.microservices.permissions.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.permissions.dtob.Permissions;
import com.gigflex.prototype.microservices.permissions.repository.PermissionsRepository;

@Service
public class PermissionsDeleteOfRegistrationKafkaService {
	
	@Autowired
	private PermissionsRepository permissionsDao;
	
	private static final Logger LOG = LoggerFactory.getLogger(PermissionsDeleteOfRegistrationKafkaService.class);


	@KafkaListener(topics = "DeletePermissions")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			
			Permissions permissions = objectMapper.readValue(message, Permissions.class);

			LOG.info("received message='{}'", permissions.getPermissionsName());
			LOG.info("received message='{}'", permissions.getPermissionsCode());
			
			Permissions perRes=permissionsDao.getPermissionsByPermissionsCode(permissions.getPermissionsCode());

                        if(perRes!=null && perRes.getId()>0)
                        {
                        	permissionsDao.deleteById(perRes.getId());
                        }
			
		} catch (JsonParseException e) {
			LOG.error("In PermissionsDeleteOfRegistrationKafkaService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In PermissionsDeleteOfRegistrationKafkaService >>>>", e);
		} catch (IOException e) {
			LOG.error("In PermissionsDeleteOfRegistrationKafkaService >>>>", e);
		}catch (Exception e) {
			LOG.error("In PermissionsDeleteOfRegistrationKafkaService >>>>", e);
		}
    }

}
