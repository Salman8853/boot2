
package com.gigflex.prototype.microservices.organizationworkerskill.dtob;

import java.util.List;


public class OrgWorkerSkillResponse {

	private Long id;
	
	private String skillCode;

	private String skillName;


	private String organizationCode;

	private String organizationName;

//	private Double ExperienceInYear;
	
	private Long experienceInDays;


	private String workerCode;

	private String workerName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}



	public String getSkillCode() {
		return skillCode;
	}

	public void setSkillCode(String skillCode) {
		this.skillCode = skillCode;
	}

	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

//	public Double getExperienceInYear() {
//		return ExperienceInYear;
//	}
//
//	public void setExperienceInYear(Double experienceInYear) {
//		ExperienceInYear = experienceInYear;
//	}
	
	

	public String getWorkerCode() {
		return workerCode;
	}

	public Long getExperienceInDays() {
		return experienceInDays;
	}

	public void setExperienceInDays(Long experienceInDays) {
		this.experienceInDays = experienceInDays;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}

	public String getWorkerName() {
		return workerName;
	}

	public void setWorkerName(String workerName) {
		this.workerName = workerName;
	}
	
	

}