package com.gigflex.prototype.microservices.permissions.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name="permissions")
public class Permissions extends CommonAttributes implements Serializable{
	
	
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue
    @Column(name = "id")
	private Long id;
	
	@Column(name="permissions_name")
	private String permissionsName;
	
	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "permissions_code", unique = true)
	private String permissionsCode;
	
    public Permissions(){
    	
    }
    
    @PrePersist
    private void assignUUID() {
    	  if(this.getPermissionsCode()==null || this.getPermissionsCode().length()==0){
      
      this.setPermissionsCode(UUID.randomUUID().toString());
    	  }
        
    }

	public Permissions(Long id, String permissionsName, String permissionsCode) {
		super();
		this.id = id;
		this.permissionsName = permissionsName;
		this.permissionsCode = permissionsCode;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPermissionsName() {
		return permissionsName;
	}

	public void setPermissionsName(String permissionsName) {
		this.permissionsName = permissionsName;
	}

	public String getPermissionsCode() {
		return permissionsCode;
	}

	public void setPermissionsCode(String permissionsCode) {
		this.permissionsCode = permissionsCode;
	}
    
    
    
    
}
