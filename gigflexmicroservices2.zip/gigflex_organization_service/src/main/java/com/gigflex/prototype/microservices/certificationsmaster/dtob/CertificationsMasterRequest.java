package com.gigflex.prototype.microservices.certificationsmaster.dtob;

public class CertificationsMasterRequest {

	private String certificationName;

	public String getCertificationName() {
		return certificationName;
	}

	public void setCertificationName(String certificationName) {
		this.certificationName = certificationName;
	}
	
	
}
