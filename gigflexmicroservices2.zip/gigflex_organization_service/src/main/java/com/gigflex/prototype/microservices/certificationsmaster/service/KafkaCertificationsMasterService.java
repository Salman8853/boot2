package com.gigflex.prototype.microservices.certificationsmaster.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.certificationsmaster.repository.CertificationsMasterRepository;

@Service
public class KafkaCertificationsMasterService {
	
	@Autowired
	private CertificationsMasterRepository certificationsMasterRepository;
	
	 private static final Logger LOG = LoggerFactory.getLogger(KafkaCertificationsMasterService.class);

	 @KafkaListener(topics = "NewCertificationsMaster")
	    public void listen(@Payload String message) {
			ObjectMapper objectMapper = new ObjectMapper();
			LOG.info("received message='{}'", message);
			try {
				CertificationsMaster cm = objectMapper.readValue(message, CertificationsMaster.class);
				certificationsMasterRepository.save(cm);
				
			} catch (JsonParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
}
