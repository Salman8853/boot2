package com.gigflex.prototype.microservices.rolemaster.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.rolemaster.dtob.RoleMasterRequest;
import com.gigflex.prototype.microservices.rolemaster.service.RoleMasterService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationservice/")
public class RoleMasterController {

	@Autowired
	public RoleMasterService roleMasterService;

	@GetMapping("/getAllRoleMaster")
	public String getAllRoleMaster() {
		return roleMasterService.findAllRoleMaster();
	}
	
	@GetMapping("/roleMaster/{search}")
	public String search(@PathVariable("search") String search) {
		return roleMasterService.search(search);
	}
	
	@GetMapping(path="/getAllRoleMasterByPage")
    public String getAllRoleMasterByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String roleMaster = roleMasterService.getAllRoleMasterByPage(page, limit);
      
        return roleMaster;
       
    }

	@GetMapping("/getRoleMaster/{id}")
	public String getRoleMasterById(@PathVariable Long id) {
		return roleMasterService.findRoleMasterById(id);
	}

	@GetMapping("/getRoleMasterByRoleCode/{roleCode}")
	public String getRoleMasterByRoleCode(@PathVariable String roleCode) {
		return roleMasterService.getRoleMasterByRoleCode(roleCode);
	}
	
	@GetMapping("/getRoleMasterByOrgCode/{organizationCode}")
	public String getRoleMasterByOrgCode(@PathVariable String organizationCode) {
		return roleMasterService.getRoleMasterByOrgCode(organizationCode);
	}
	
	@GetMapping(path="/getRoleMasterByOrgCodeByPage/{organizationCode}")
	public String getOrganizationSkillWithNamesByPage(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
	        @RequestParam(value = "limit", defaultValue = "30") int limit) {

	    String roleMast = roleMasterService.getRoleMasterByOrgCodeByPage(organizationCode, page, limit);
	  
	    return roleMast;
	   
	}

	@PostMapping("/saveRoleMaster")
	public String saveNewRoleMaster(
			@Valid @RequestBody RoleMasterRequest roleMasterReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return roleMasterService.saveRoleMaster(roleMasterReq, ip);

	}

	@DeleteMapping("/deleteRoleMaster/{id}")
	public String deleteRoleMasterById(@PathVariable Long id) {
		return roleMasterService.deleteRoleMasterById(id);
	}
	
	@DeleteMapping("/deleteRoleMasterByRoleCode/{roleCode}")
	public String deleteRoleMasterByRoleCode(@PathVariable String roleCode) {
		return roleMasterService.deleteByRoleCode(roleCode);
	}
	
	@DeleteMapping("/softDeleteRoleMasterByRoleCode/{roleCode}")
	public String softDeleteRoleMasterByRoleCode(@PathVariable String roleCode) {
		return roleMasterService.softDeleteByRoleCode(roleCode);
	}
	
	@DeleteMapping("/softMultipleDeleteByRoleCode/{roleCodeList}")
	public String softMultipleDeleteByRoleCode(@PathVariable List<String> roleCodeList) {
		if(roleCodeList != null && roleCodeList.size()>0){
			return roleMasterService.softMultipleDeleteByRoleCode(roleCodeList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
		
	}

	@PutMapping("/updateRoleMaster/{id}")
	public String updateRoleMaster(@PathVariable Long id,
			@Valid @RequestBody RoleMasterRequest roleMaster,
			HttpServletRequest request) {

		if (id == null) {
			return "Role Master with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return roleMasterService.updateRoleMasterById(id, roleMaster, ip);

		}

	}
	
//	@PutMapping("/updateRoleMasterByRoleCode/{roleCode}")
//	public String updateRoleMasterByRoleCode(@PathVariable String roleCode,
//			@Valid @RequestBody RoleMasterRequest roleMaster,
//			HttpServletRequest request) {
//
//		if (roleCode == null) {
//			return "Role Master with Id : (" + roleCode + ") Not found.";
//		} else {
//			String ip = request.getRemoteAddr();
//
//			return roleMasterService.updateRoleMasterByRoleCode(roleCode, roleMaster, ip);
//
//		}
//
//	}
	


	// @GetMapping("/roleMaster")
	// public List<RoleMaster> getAllRoleMaster(){
	// List<RoleMaster> roleMasterList = roleMasterService.findAllRoleMaster();
	// return roleMasterList;
	// }
	//
	// @GetMapping("/roleMaster/{id}")
	// public Optional<RoleMaster> getRoleMasterById(@PathVariable Integer id){
	// return roleMasterService.findRoleMasterById(id) ;
	// }
	//
	// @PostMapping("/roleMaster")
	// public RoleMaster saveNewRoleMaster(@RequestBody RoleMaster roleMaster,
	// HttpServletRequest request){
	// RoleMaster role = roleMaster;
	// role.setIpAddress(request.getRemoteAddr());
	// return roleMasterService.saveRoleMaster(roleMaster);
	//
	// }

}
