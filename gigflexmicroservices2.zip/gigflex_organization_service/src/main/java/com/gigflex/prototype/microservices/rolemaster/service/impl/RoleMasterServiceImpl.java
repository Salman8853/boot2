package com.gigflex.prototype.microservices.rolemaster.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.rolemaster.dtob.RoleMaster;
import com.gigflex.prototype.microservices.rolemaster.dtob.RoleMasterOrgNameResponse;
import com.gigflex.prototype.microservices.rolemaster.dtob.RoleMasterRequest;
import com.gigflex.prototype.microservices.rolemaster.repository.RoleMasterRepository;
import com.gigflex.prototype.microservices.rolemaster.search.RoleMasterSpecificationsBuilder;
import com.gigflex.prototype.microservices.rolemaster.service.RoleMasterService;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@Service
public class RoleMasterServiceImpl implements RoleMasterService {

	private static final Logger LOG = LoggerFactory
			.getLogger(RoleMasterServiceImpl.class);

	@Autowired
	private RoleMasterRepository roleMasterRepository;

	@Autowired
	private KafkaService kafkaService;

	@Autowired
	private OrganizationRepository orgDao;

	@Override
	public String findAllRoleMaster() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<RoleMaster> rolelst = roleMasterRepository.getAllRoleMaster();
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (rolelst != null && rolelst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(rolelst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String findRoleMasterById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			RoleMaster rolelst = roleMasterRepository.getRoleMasterById(id);
			if (rolelst != null && rolelst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(rolelst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveRoleMaster(RoleMasterRequest roleMasterReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (roleMasterReq != null) {

				if (roleMasterReq.getRoleName() != null
						&& roleMasterReq.getRoleName().trim().length() > 0
						&& roleMasterReq.getOrganizationCode() != null
						&& roleMasterReq.getOrganizationCode().trim().length() > 0) {

					Organization org = orgDao
							.findByOrganizationCode(roleMasterReq
									.getOrganizationCode());
					if (org != null && org.getId() > 0) {

						RoleMaster roleMast = roleMasterRepository
								.getRoleMasterByOrgCodeRoleName(
										roleMasterReq.getOrganizationCode(),
										roleMasterReq.getRoleName());

						if (roleMast != null && roleMast.getId() > 0) {
							jsonobj.put("responsecode", 409);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Record already exist.");
						} else {

							RoleMaster role = new RoleMaster();
							role.setIsActive(roleMasterReq.getIsActive());
							role.setRoleName(roleMasterReq.getRoleName());
							role.setOrganizationCode(roleMasterReq
									.getOrganizationCode());
							role.setIpAddress(ip);

							RoleMaster roleRes = roleMasterRepository
									.save(role);

							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());

							if (roleRes != null && roleRes.getId() > 0) {

								kafkaService.sendRoleMaster(roleRes);
								jsonobj.put("message",
										"Role Master has been added successfully.");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(roleRes);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("message", "Failed");
							}
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Organization Code Not Found");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Role Name and Organization Code should not be blank");
				}

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteRoleMasterById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			Optional<RoleMaster> roleData = roleMasterRepository.findById(id);

			if (roleData.isPresent() && roleData.get() != null) {
				roleMasterRepository.deleteById(id);

				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Role Master has been deleted.");
				jsonobj.put("timestamp", new Date());

				// kafkaService.sendRoleMasterDelete(roleData.get());

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String updateRoleMasterById(Long id, RoleMasterRequest roleMaster,
			String ip) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (id > 0 && roleMaster != null) {

				if (roleMaster.getRoleName() != null
						&& roleMaster.getRoleName().trim().length() > 0
						&& roleMaster.getOrganizationCode() != null
						&& roleMaster.getOrganizationCode().trim().length() > 0) {

					Organization org = orgDao.findByOrganizationCode(roleMaster
							.getOrganizationCode());
					if (org != null && org.getId() > 0) {

						RoleMaster rolemasterInDb = roleMasterRepository
								.getRoleMasterById(id);
						// .findById(id);
						if (rolemasterInDb != null
								&& rolemasterInDb.getId() > 0) {

							RoleMaster roleMast = roleMasterRepository
									.getRoleMasterByIdOrgCodeRoleName(id,
											roleMaster.getOrganizationCode(),
											roleMaster.getRoleName());
							if (roleMast != null && roleMast.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record already exist.");
							} else {

								RoleMaster roles = rolemasterInDb;
								roles.setRoleName(roleMaster.getRoleName());
								roles.setIsActive(roleMaster.getIsActive());
								roles.setOrganizationCode(roleMaster
										.getOrganizationCode());
								roles.setIpAddress(ip);
								RoleMaster rolemasterRes = roleMasterRepository
										.save(roles);

								if (rolemasterRes != null
										&& rolemasterRes.getId() > 0) {

									jsonobj.put("responsecode", 200);
									jsonobj.put("message",
											"RoleMaster updation has been done");
									jsonobj.put("timestamp", new Date());
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj
											.writeValueAsString(rolemasterRes);
									jsonobj.put("data", new JSONObject(Detail));

									kafkaService
											.sendRoleMasterUpdate(rolemasterRes);

								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("message",
											"RoleMaster updation has been failed.");
									jsonobj.put("timestamp", new Date());
								}
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"RoleMaster ID is not valid.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Organization Code Not Found");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message",
							"Role Name and Organization Code should not be blank");
					jsonobj.put("timestamp", new Date());
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String getRoleMasterByRoleCode(String roleCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			RoleMaster rolelst = roleMasterRepository
					.getRoleMasterByRoleCode(roleCode);
			if (rolelst != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(rolelst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteByRoleCode(String roleCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			RoleMaster rolelst = roleMasterRepository
					.getRoleMasterByRoleCode(roleCode);

			Integer deleteByRoleCode = roleMasterRepository
					.deleteByRoleCode(roleCode);
			if (deleteByRoleCode != 0 && rolelst != null && rolelst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "RoleMaster has been deleted.");
				jsonobj.put("timestamp", new Date());
				res = jsonobj.toString();

				// kafkaService.sendRoleMasterDelete(rolelst);

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softDeleteByRoleCode(String roleCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			RoleMaster rolelst = roleMasterRepository
					.getRoleMasterByRoleCode(roleCode);

			if (rolelst != null && rolelst.getId() > 0) {

				rolelst.setIsDeleted(true);
				RoleMaster roleRes = roleMasterRepository.save(rolelst);
				if (roleRes != null && roleRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());

					jsonobj.put("message", "Role Master deleted successfully.");

					kafkaService.sendRoleMasterUpdate(roleRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
			LOG.error("Error in softDeleteByRoleCode>>>>>>", ex);
		} catch (org.springframework.orm.jpa.JpaSystemException ex) {
			GigflexResponse derr = new GigflexResponse(401, new Date(),
					GigUtil.getRootException(ex));
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Error in softDeleteByRoleCode>>>>>>", ex);
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByRoleCode(List<String> roleCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String roleCode : roleCodeList) {
				if (roleCode != null && roleCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					roleCode = roleCode.trim();

					RoleMaster rolelst = roleMasterRepository
							.getRoleMasterByRoleCode(roleCode);

					if (rolelst != null && rolelst.getId() > 0) {

						try {

							rolelst.setIsDeleted(true);
							RoleMaster roleRes = roleMasterRepository
									.save(rolelst);
							if (roleRes != null && roleRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", roleCode);
								jsonobj.put("message",
										"RoleMaster deleted successfully.");
								kafkaService.sendRoleMasterUpdate(roleRes);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", roleCode);
								jsonobj.put("message", "Failed");
							}
						} catch (org.springframework.orm.jpa.JpaSystemException ex) {
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", roleCode);
							jsonobj.put("message", GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", roleCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllRoleMasterByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<RoleMaster> rolelst = roleMasterRepository
					.getAllRoleMaster(pageableRequest);
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (rolelst != null && rolelst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(rolelst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				RoleMasterSpecificationsBuilder builder = new RoleMasterSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<RoleMaster> spec = builder.build();
				if (spec != null) {
					List<RoleMaster> rolelst = roleMasterRepository
							.findAll(spec);
					if (rolelst != null && rolelst.size() > 0) {
						for (RoleMaster role : rolelst) {
							if (role.getIsDeleted() != null
									&& role.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(role);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("roleMaster", new JSONObject(
										Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getRoleMasterByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {

				List<Object> objlst = roleMasterRepository
						.getRoleMasterByOrgCode(organizationCode);
				List<RoleMasterOrgNameResponse> maplst = new ArrayList<RoleMasterOrgNameResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							RoleMasterOrgNameResponse wplr = new RoleMasterOrgNameResponse();

							RoleMaster wpl = (RoleMaster) arr[0];

							wplr.setId(wpl.getId());
							wplr.setIsActive(wpl.getIsActive());
							wplr.setRoleName(wpl.getRoleName());
							wplr.setOrganizationCode(wpl.getOrganizationCode());
							wplr.setOrganizationName((String) arr[1]);

							maplst.add(wplr);
						}
					}
					if (maplst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(maplst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getRoleMasterByOrgCodeByPage(String organizationCode,
			int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {

				List<Object> objlst = roleMasterRepository
						.getRoleMasterByOrgCodeByPage(organizationCode,
								pageableRequest);
				List<RoleMasterOrgNameResponse> maplst = new ArrayList<RoleMasterOrgNameResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							RoleMasterOrgNameResponse wplr = new RoleMasterOrgNameResponse();

							RoleMaster wpl = (RoleMaster) arr[0];

							wplr.setId(wpl.getId());
							wplr.setIsActive(wpl.getIsActive());
							wplr.setRoleName(wpl.getRoleName());
							wplr.setOrganizationCode(wpl.getOrganizationCode());
							wplr.setOrganizationName((String) arr[1]);

							maplst.add(wplr);
						}
					}
					if (maplst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(maplst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

}
