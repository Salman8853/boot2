package com.gigflex.prototype.microservices.organizationworkinglocationhours.dtob;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "organization_working_location_hours")
public class OrganizationWorkingLocationHours extends CommonAttributes
		implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "working_location_code", nullable = false)
	private String workingLocationCode;

	@Column(name = "day_code", nullable = false)
	private String dayCode;

	@Column(name = "organization_code", nullable = false)
	private String organizationCode;

	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "working_location_hours_code", unique = true)
	private String workingLocationHoursCode;

	@Column(name = "fromdate", columnDefinition = "DATETIME")
	private Date fromDate;

	@Column(name = "todate", columnDefinition = "DATETIME")
	private Date toDate;
	
	@PrePersist
	private void assignUUID() {
		if (this.getWorkingLocationHoursCode() == null || this.getWorkingLocationHoursCode().length() == 0) {
			this.setWorkingLocationHoursCode(UUID.randomUUID().toString());
		}
	}
	
	public OrganizationWorkingLocationHours(){}

	public OrganizationWorkingLocationHours(Long id,
			String workingLocationCode, String dayCode,
			String organizationCode, String workingLocationHoursCode,
			Date fromDate, Date toDate) {
		super();
		this.id = id;
		this.workingLocationCode = workingLocationCode;
		this.dayCode = dayCode;
		this.organizationCode = organizationCode;
		this.workingLocationHoursCode = workingLocationHoursCode;
		this.fromDate = fromDate;
		this.toDate = toDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getWorkingLocationCode() {
		return workingLocationCode;
	}

	public void setWorkingLocationCode(String workingLocationCode) {
		this.workingLocationCode = workingLocationCode;
	}

	public String getDayCode() {
		return dayCode;
	}

	public void setDayCode(String dayCode) {
		this.dayCode = dayCode;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public String getWorkingLocationHoursCode() {
		return workingLocationHoursCode;
	}

	public void setWorkingLocationHoursCode(String workingLocationHoursCode) {
		this.workingLocationHoursCode = workingLocationHoursCode;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	
	
	
	
	
	

}
