

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.organization.api;





import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.organization.dtob.MassActiveInactiveOrganization;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.dtob.OrganizationLogoRequest;
import com.gigflex.prototype.microservices.organization.service.OrganizationService;
import com.gigflex.prototype.microservices.util.GigflexResponse;


/**
 * 
 * @author ajit.p
 *
 */

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/organizationservice/")
public class OrganizationController {

	@Autowired
	OrganizationService organizationService;
	
	@GetMapping("/organization/{search}")
	public String search(@PathVariable("search") String search) {
		return organizationService.search(search);
	}

	@GetMapping("/getAllOrganizations")
	public String getAllOrganizations() {
		return organizationService.findAllOrganizations();
		
	}
	
	@GetMapping(path="/getOrganizationByPage")
    public String getOrganizationByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String org = organizationService.getOrganization(page, limit);
      
        return org;
       
    }


//	@PostMapping("/saveOrganization")
//	public ResponseEntity<Object> createOrganization(@Valid @RequestBody Organization organization, Errors errors) {
//		Object response = null;
//		if (errors.hasErrors()) {
//			response = errors.getAllErrors();
//			return ResponseEntity.badRequest().body(response);
//		} else {
//			organization = organizationService.registerFromOrganization(organization);
//			response = "Organization Saved with :" + organization.getId();
//			return ResponseEntity.ok(response);
//		}
//	}

	@GetMapping("/getOrganization/{id}")
	public String getOrganization(@PathVariable Long id) {
            return organizationService.fetchOrganizationById(id);
	}
	
	@GetMapping("/getOrganizationByOrgCode/{organizationCode}")
	public String getOrganizationByOrgCode(@PathVariable String organizationCode) {
            return organizationService.findOrganizationByOrgCode(organizationCode);
	}

	@DeleteMapping("/deleteOrganization/{id}")
	public String deleteOrganization(@PathVariable Long id) {
		return organizationService.deleteOrganizationById(id);
	}
	
	@DeleteMapping("/deleteOrganizationByOrgCode/{organizationCode}")
	public String deleteOrganizationByOrgCode(
			@PathVariable String organizationCode) {
		return organizationService.deleteByOrgCode(organizationCode);
	}
	
	@DeleteMapping("/softDeleteOrganizationByOrgCode/{organizationCode}")
	public String softDeleteOrganizationByOrgCode(
			@PathVariable String organizationCode) {
		return organizationService.softDeleteByOrgCode(organizationCode);
	}
	
	@DeleteMapping("/softMultipleDeleteByOrgCode/{organizationCodeList}")
	public String softMultipleDeleteByOrgCode(@PathVariable List<String> organizationCodeList) {
		if(organizationCodeList != null && organizationCodeList.size()>0){
			return organizationService.softMultipleDeleteByOrgCode(organizationCodeList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
		
	}
/**
 * 
 * @param id
 * @param organization
 * @param errors
 * @return
 */
	@PutMapping("/updateOrganization/{id}")
	public String updateOrganization(@PathVariable Long id,  @RequestBody Organization organization,
			HttpServletRequest httpRequest) {
		if(organization!=null)
        {
            organization.setIpAddress(httpRequest.getRemoteAddr());
            return organizationService.updateOrganization(organization, id);
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
            return derr.toString();
        }

	}
	
	@PutMapping("/updateOrganizationLogoByOrganizationCode/{organizationCode}")
	public String updateOrganizationLogoByOrgCode(@PathVariable String organizationCode,  @RequestBody OrganizationLogoRequest orgLogoReq,
			HttpServletRequest httpRequest) {
		if(orgLogoReq!=null)
        {
			String ip = httpRequest.getRemoteAddr();
            return organizationService.updateOrganizationLogoByOrgCode(orgLogoReq, organizationCode,ip);
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
            return derr.toString();
        }
            

	}
	
	@PutMapping("/massActiveInactiveInOrganization")
	public String massActiveInactiveOrganizationByOrgCode(@RequestBody MassActiveInactiveOrganization maassAcInOrgReq, HttpServletRequest httpRequest)
	{
		if(maassAcInOrgReq!=null){
			String ip = httpRequest.getRemoteAddr();
            return organizationService.massActiveInactiveOrganizationByOrgCode(maassAcInOrgReq, ip);
		}
		else{
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
            return derr.toString();
		}
	}
	
	
}


