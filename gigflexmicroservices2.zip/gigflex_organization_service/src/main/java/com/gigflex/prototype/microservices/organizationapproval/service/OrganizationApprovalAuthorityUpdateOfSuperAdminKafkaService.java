package com.gigflex.prototype.microservices.organizationapproval.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organizationapproval.dtob.OrganizationApprovalAuthority;
import com.gigflex.prototype.microservices.organizationapproval.repository.OrganizationApprovalAuthorityRepository;


@Service
public class OrganizationApprovalAuthorityUpdateOfSuperAdminKafkaService {
	
	@Autowired
	private OrganizationApprovalAuthorityRepository oaaDao;
	
    private static final Logger LOG = LoggerFactory.getLogger(OrganizationApprovalAuthorityUpdateOfSuperAdminKafkaService.class);


	@KafkaListener(topics = "UpdateOrganizationApprovalAuthority")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			OrganizationApprovalAuthority oaa = objectMapper.readValue(message, OrganizationApprovalAuthority.class);
			LOG.info("received message='{}'", oaa.getAuthorityCode());
			LOG.info("received message='{}'", oaa.getOrganizationCode());
			LOG.info("received message='{}'", oaa.getIsProcessed());

			
//			OrganizationApprovalAuthority oaaRes=oaaDao.getPermissionsByPermissionsCode(permissions.getPermissionsCode());
			OrganizationApprovalAuthority oaaRes=oaaDao.getOAAByCode(oaa.getOrganizationApprovalAuthorityCode());

                        if(oaaRes!=null && oaaRes.getId()>0)
                        {
                        	oaaRes.setOrganizationCode(oaa.getOrganizationCode());
                        	oaaRes.setAuthorityCode(oaa.getAuthorityCode());
                        	oaaRes.setIsDeleted(oaa.getIsDeleted());
                        	oaaRes.setIsProcessed(oaa.getIsProcessed());
                        	oaaDao.save(oaaRes);
                        }
			
		} catch (JsonParseException e) {
			LOG.error("In OrganizationApprovalAuthorityUpdateOfSuperAdminKafkaService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In OrganizationApprovalAuthorityUpdateOfSuperAdminKafkaService >>>>", e);
		} catch (IOException e) {
			LOG.error("In OrganizationApprovalAuthorityUpdateOfSuperAdminKafkaService >>>>", e);
		}catch (Exception e) {
			LOG.error("In OrganizationApprovalAuthorityUpdateOfSuperAdminKafkaService >>>>", e);
		}
    }

}
