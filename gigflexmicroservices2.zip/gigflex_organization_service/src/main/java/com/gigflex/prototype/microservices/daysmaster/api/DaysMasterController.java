package com.gigflex.prototype.microservices.daysmaster.api;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMasterRequest;
import com.gigflex.prototype.microservices.daysmaster.service.DaysMasterService;
import com.gigflex.prototype.microservices.util.GigflexResponse;



@CrossOrigin(origins="*")
@RestController
@RequestMapping("/organizationservice/")
public class DaysMasterController {
	
	@Autowired
	public DaysMasterService daysMasterService;
	
	
	
	@GetMapping("/getAllDaysMaster")
	public String getAllDaysMaster(){
		return daysMasterService.findAllDaysMaster();
	}
	
	@GetMapping(path="/getAllDaysMasterByPage")
    public String getAllDaysMasterByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String daysMaster = daysMasterService.getAllDaysMasterByPage(page, limit);
      
        return daysMaster;
       
    }
	
	

}
