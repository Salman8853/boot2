package com.gigflex.prototype.microservices.organization.dtob;


import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.Date;



/**
 * @author ajit.p
 *
 */
public class OrganizationConsumeFromDriverOrg extends CommonAttributes {

   
	private Long id;
	
	private String organizationName;
		
	private String organizationCode;
	
	private String phoneNumber;
	
	private String address;
	
	private String address1;

	private String city;

	private String stateProvince;

	private String country;

	private String zipCode;

	private String taxId;

	private String regNo;

	private String workFrom;

	private String workTo;
	
	private String lat;

	private String lang;
	
	private Boolean isActive;

	private Boolean isApproved;

        private Date approvedDate ;

	private String approvedBy;

	private Boolean isVerified;
	  
        private String industryCode;
        
        private String organizationLogo;
    
	private String timezone;
    
        private Integer configureMinutes;
        
        private Integer alertMinutes;
    
        private Boolean isRecursive;
    
        private Integer expiredMinutes;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStateProvince() {
        return stateProvince;
    }

    public void setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getTaxId() {
        return taxId;
    }

    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getWorkFrom() {
        return workFrom;
    }

    public void setWorkFrom(String workFrom) {
        this.workFrom = workFrom;
    }

    public String getWorkTo() {
        return workTo;
    }

    public void setWorkTo(String workTo) {
        this.workTo = workTo;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }

    public Date getApprovedDate() {
        return approvedDate;
    }

    public void setApprovedDate(Date approvedDate) {
        this.approvedDate = approvedDate;
    }

    public String getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(String approvedBy) {
        this.approvedBy = approvedBy;
    }

    public Boolean getIsVerified() {
        return isVerified;
    }

    public void setIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
    }

    public String getIndustryCode() {
        return industryCode;
    }

    public void setIndustryCode(String industryCode) {
        this.industryCode = industryCode;
    }

    public String getOrganizationLogo() {
        return organizationLogo;
    }

    public void setOrganizationLogo(String organizationLogo) {
        this.organizationLogo = organizationLogo;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public Integer getConfigureMinutes() {
        return configureMinutes;
    }

    public void setConfigureMinutes(Integer configureMinutes) {
        this.configureMinutes = configureMinutes;
    }

    public Integer getAlertMinutes() {
        return alertMinutes;
    }

    public void setAlertMinutes(Integer alertMinutes) {
        this.alertMinutes = alertMinutes;
    }

    public Boolean getIsRecursive() {
        return isRecursive;
    }

    public void setIsRecursive(Boolean isRecursive) {
        this.isRecursive = isRecursive;
    }

    public Integer getExpiredMinutes() {
        return expiredMinutes;
    }

    public void setExpiredMinutes(Integer expiredMinutes) {
        this.expiredMinutes = expiredMinutes;
    }
        
        

}
