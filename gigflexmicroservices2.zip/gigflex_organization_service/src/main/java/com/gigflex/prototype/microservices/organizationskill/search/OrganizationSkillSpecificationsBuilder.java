package com.gigflex.prototype.microservices.organizationskill.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.util.SearchCriteria;

public class OrganizationSkillSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public OrganizationSkillSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public OrganizationSkillSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<OrganizationSkill> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<OrganizationSkill>> specs = new ArrayList<Specification<OrganizationSkill>>();
        for (SearchCriteria param : params) {
            specs.add(new OrganizationSkillSpecification(param));
        }
 
        Specification<OrganizationSkill> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
