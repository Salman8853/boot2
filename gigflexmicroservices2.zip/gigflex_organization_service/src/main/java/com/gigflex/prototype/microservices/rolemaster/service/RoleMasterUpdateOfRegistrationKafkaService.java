package com.gigflex.prototype.microservices.rolemaster.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.rolemaster.dtob.RoleMaster;
import com.gigflex.prototype.microservices.rolemaster.repository.RoleMasterRepository;

@Service
public class RoleMasterUpdateOfRegistrationKafkaService {

	@Autowired
	private RoleMasterRepository roleMasterDao;

	private static final Logger LOG = LoggerFactory
			.getLogger(RoleMasterUpdateOfRegistrationKafkaService.class);

	@KafkaListener(topics = "UpdateRoleMaster")
	public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			RoleMaster rm = objectMapper.readValue(message, RoleMaster.class);

			LOG.info("received message='{}'", rm.getRoleName());
			LOG.info("received message='{}'", rm.getRoleCode());
			LOG.info("received message='{}'", rm.getIsActive());

			RoleMaster roleRes = roleMasterDao.getRoleMasterByRoleCode(rm
					.getRoleCode());

			if (roleRes != null && roleRes.getId() > 0) {
				roleRes.setIsActive(rm.getIsActive());
				roleRes.setRoleName(rm.getRoleName());
				roleRes.setOrganizationCode(rm.getOrganizationCode());
				roleRes.setIsDeleted(rm.getIsDeleted());
				roleMasterDao.save(roleRes);
			}

		} catch (JsonParseException e) {
			LOG.error("In RoleMasterUpdateOfRegistrationKafkaService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In RoleMasterUpdateOfRegistrationKafkaService >>>>", e);
		} catch (IOException e) {
			LOG.error("In RoleMasterUpdateOfRegistrationKafkaService >>>>", e);
		} catch (Exception e) {
			LOG.error("In RoleMasterUpdateOfRegistrationKafkaService >>>>", e);
		}
	}

}
