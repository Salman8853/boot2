package com.gigflex.prototype.microservices.daysmaster.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMaster;
import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMasterRequest;
import com.gigflex.prototype.microservices.daysmaster.repository.DaysMasterDao;
import com.gigflex.prototype.microservices.daysmaster.service.DaysMasterService;
import com.gigflex.prototype.microservices.util.GigflexResponse;


@Service
public class DaysMasterServiceImpl implements DaysMasterService {

	@Autowired
	private DaysMasterDao daysMasterRep;

	@Override
	public String findAllDaysMaster() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<DaysMaster> dayslst = daysMasterRep.getAllDaysMaster();
			
			if (dayslst != null && dayslst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(dayslst);
				jsonobj.put("data", new JSONArray(Detail));
			}else{
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllDaysMasterByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
	        Pageable pageableRequest = PageRequest.of(page, limit);
	        List<DaysMaster> dayslst = daysMasterRep.getAllDaysMaster(pageableRequest);
	        jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (dayslst != null && dayslst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(dayslst);
				jsonobj.put("data", new JSONArray(Detail));
			}
			 else
	            {
	                jsonobj.put("responsecode", 200);
	            jsonobj.put("message", "Record Not Found");
	            jsonobj.put("timestamp", new Date());
	            }
			res = jsonobj.toString();
		} catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
	    return res;
	}
	
}
