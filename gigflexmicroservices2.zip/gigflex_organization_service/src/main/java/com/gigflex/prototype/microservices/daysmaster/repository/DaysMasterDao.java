package com.gigflex.prototype.microservices.daysmaster.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMaster;

@Repository
public interface DaysMasterDao extends JpaRepository<DaysMaster,Integer> {
	
	@Query("SELECT dm FROM DaysMaster dm WHERE dm.isDeleted != TRUE")
    public List<DaysMaster> getAllDaysMaster(Pageable pageableRequest);
	
	@Query("SELECT dm FROM DaysMaster dm WHERE dm.isDeleted != TRUE")
    public List<DaysMaster> getAllDaysMaster();
	
	@Query("SELECT dm FROM DaysMaster dm WHERE dm.isDeleted != TRUE AND dm.daysCode = :daysCode")
	public DaysMaster getDaysMasterByDaysCode(@Param("daysCode") String daysCode);
	


}
