package com.gigflex.prototype.microservices.certificationsmaster.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.certificationsmaster.repository.CertificationsMasterRepository;

@Service
public class CertificationsMasterUpdateOfWorkerKafkaService {
	
	@Autowired
	private CertificationsMasterRepository certificationsMasterRepository;
	
	 private static final Logger LOG = LoggerFactory.getLogger(CertificationsMasterUpdateOfWorkerKafkaService.class);
	 
	 @KafkaListener(topics = "UpdateCertificationsMaster")
	    public void listen(@Payload String message) {
			ObjectMapper objectMapper = new ObjectMapper();
			LOG.info("received message='{}'", message);
			try {
				CertificationsMaster certificationMaster = objectMapper.readValue(message, CertificationsMaster.class);
				LOG.info("received message='{}'", certificationMaster.getCertificationName());
				LOG.info("received message='{}'", certificationMaster.getCertificationCode());
				
				CertificationsMaster certificationMasterRes=certificationsMasterRepository.getCertificationsMasterByCertificationCode(certificationMaster.getCertificationCode());
	                        if(certificationMasterRes!=null && certificationMasterRes.getId()>0)
	                        {
	                        	certificationMasterRes.setCertificationName(certificationMaster.getCertificationName());
                                        certificationMasterRes.setOrganizationCode(certificationMaster.getOrganizationCode());
	                        	certificationMasterRes.setIsDeleted(certificationMaster.getIsDeleted());
	                        	certificationMasterRes.setIsAssigned(certificationMaster.getIsAssigned());
	                        	certificationsMasterRepository.save(certificationMasterRes);
	                        }
				
			} catch (JsonParseException e) {
				LOG.error("In CertificationsMasterUpdateOfWorkerKafkaService >>>>", e);
			} catch (JsonMappingException e) {
				LOG.error("In CertificationsMasterUpdateOfWorkerKafkaService >>>>", e);
			} catch (IOException e) {
				LOG.error("In CertificationsMasterUpdateOfWorkerKafkaService >>>>", e);
			}catch (Exception e) {
				LOG.error("In CertificationsMasterUpdateOfWorkerKafkaService >>>>", e);
			}

	 }
}
