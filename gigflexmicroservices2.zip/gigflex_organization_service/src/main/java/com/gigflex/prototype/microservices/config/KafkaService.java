package com.gigflex.prototype.microservices.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.gigflex.prototype.microservices.department.dtob.DepartmentMaster;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkill;
import com.gigflex.prototype.microservices.rolemaster.dtob.RoleMaster;
import com.gigflex.prototype.microservices.shift.dtob.Shift;
import com.gigflex.prototype.microservices.shift.dtob.ShiftWithDays;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.userrolemapping.dtob.UserRolesMapping;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkingLocation;
import com.gigflex.prototype.microservices.worker.dtob.Worker;

@Service
public class KafkaService {

	@Autowired
	private KafkaTemplate<String, Users> kafkaUsersTemplate;

	@Autowired
	private KafkaTemplate<String, Shift> kafkaShiftTemplate;
        
        @Autowired
	private KafkaTemplate<String, ShiftWithDays> kafkaShiftWithDaysTemplate;

	@Autowired
	private KafkaTemplate<String, DepartmentMaster> kafkaDepartmentMasterTemplate;

	@Autowired
	private KafkaTemplate<String, Organization> kafkaOrganizationTemplate;

	@Autowired
	private KafkaTemplate<String, Worker> kafkaWorkerTemplate;

	@Autowired
	private KafkaTemplate<String, WorkerApprovalStatus> kafkaWorkerApprovalStatusTemplate;

	@Autowired
	private KafkaTemplate<String, SkillMaster> kafkaSkillMasterTemplate;

	@Autowired
	private KafkaTemplate<String, OrganizationSkill> kafkaOrganizationSkillTemplate;

	@Autowired
	private KafkaTemplate<String, OrganizationWorkerSkill> kafkaOrganizationWorkerSkillTemplate;

	@Autowired
	private KafkaTemplate<String, UserRolesMapping> kafkaUserRolesMappingTemplate;

	@Autowired
	private KafkaTemplate<String, RoleMaster> kafkaRoleMasterTemplate;

	@Autowired
	private KafkaTemplate<String, WorkingLocation> kafkaWorkingLocationTemplate;

	String kafkaTopicWorkingLocationAtUpdation = "UpdateWorkingLocationFromOrganization";

	String kafkaTopicWorkingLocationAtAdd = "AddWorkingLocationFromOrganization";

	String kafkaTopicUsersAtUpdation = "UpdateUserFromOrganization";

	String kafkaTopicDepartmentMaster = "NewDepartment";

	String kafkaTopicOrganizationAtDeletion = "DeleteOrganizationFromOrganization";
	String kafkaTopicOrganizationAtUpdation = "UpdateOrganizationFromOrganization";

	String kafkaTopicWorkerAtUpdation = "UpdateWorkerFromOrganization";
	String kafkaTopicWorkerAtDeletion = "DeletionWorkerFromOrganization";

	String kafkaTopicWorkerAtAdd = "AddWorkerFromOrganization";

	String kafkaTopicWorkApprovalStatusAtUpdation = "UpdateWorkApprovalStatusFromOrganization";
	String kafkaTopicWorkApprovalStatusAtDeletion = "DeletionWorkApprovalStatusFromOrganization";

	String kafkaTopicWorkApprovalStatusAtAdd = "AddWorkApprovalStatusFromOrganization";

	String kafkaTopicSkillMaster = "NewSkillMaster";
	String kafkaTopicSkillMasterAtDeletion = "DeleteSkillMaster";
	String kafkaTopicSkillMasterAtUpdation = "UpdateSkillMaster";

	String kafkaTopicShift = "AddShiftFromOrganization";
	String kafkaTopicShiftAtUpdation = "UpdateShiftFromOrganization";
        
        String kafkaTopicShiftWithDays = "AddShiftWithDaysFromOrganization";
	String kafkaTopicShiftWithDaysAtDeletetion = "DeleteShiftWithDaysFromOrganization";
        String kafkaTopicShiftWithDaysAtUpdation = "UpdateShiftWithDaysFromOrganization";

	String kafkaTopicOrganizationSkill = "NewOrganizationSkill";
	String kafkaTopicOrganizationSkillAtDeletion = "DeleteOrganizationSkill";
	String kafkaTopicOrganizationSkillAtUpdation = "UpdateOrganizationSkill";

	String kafkaTopicOrganizationWorkerSkill = "NewOrganizationWorkerSkill";
	String kafkaTopicOrganizationWorkerSkillAtDeletion = "DeleteOrganizationWorkerSkill";
	String kafkaTopicOrganizationWorkerSkillAtUpdation = "UpdateOrganizationWorkerSkill";

	String kafkaTopicRoleMaster = "NewRoleMasterFromOrganization";
	String kafkaTopicRoleMasterAtUpdation = "UpdateRoleMasterFromOrganization";

	String kafkaTopicUserRolesMapping = "NewUserRolesMappingFromOrganization";
	String kafkaTopicUserRoleMappingAtUpdation = "UpdateUserRoleMappingFromOrganization";

	public void sendWorkingLocation(WorkingLocation message) {

		kafkaWorkingLocationTemplate.send(kafkaTopicWorkingLocationAtAdd,
				message);
	}

	public void sendUpdateWorkingLocation(WorkingLocation message) {

		kafkaWorkingLocationTemplate.send(kafkaTopicWorkingLocationAtUpdation,
				message);
	}

	public void sendUpdateUser(Users message) {

		kafkaUsersTemplate.send(kafkaTopicUsersAtUpdation, message);
	}

	public void sendOrganizationWorkerSkill(OrganizationWorkerSkill message) {

		kafkaOrganizationWorkerSkillTemplate.send(
				kafkaTopicOrganizationWorkerSkill, message);
	}

	public void sendDeleteOrganizationWorkerSkill(
			OrganizationWorkerSkill message) {

		kafkaOrganizationWorkerSkillTemplate.send(
				kafkaTopicOrganizationWorkerSkillAtDeletion, message);
	}

	public void sendUpdateOrganizationWorkerSkill(
			OrganizationWorkerSkill message) {

		kafkaOrganizationWorkerSkillTemplate.send(
				kafkaTopicOrganizationWorkerSkillAtUpdation, message);
	}

	public void sendOrganizationSkill(OrganizationSkill message) {

		kafkaOrganizationSkillTemplate.send(kafkaTopicOrganizationSkill,
				message);
	}

	public void sendDeleteOrganizationSkill(OrganizationSkill message) {

		kafkaOrganizationSkillTemplate.send(
				kafkaTopicOrganizationSkillAtDeletion, message);
	}

	public void sendUpdateOrganizationSkill(OrganizationSkill message) {

		kafkaOrganizationSkillTemplate.send(
				kafkaTopicOrganizationSkillAtUpdation, message);
	}

	public void sendSkillMaster(SkillMaster message) {

		kafkaSkillMasterTemplate.send(kafkaTopicSkillMaster, message);
	}

	public void sendDeleteSkillMaster(SkillMaster message) {

		kafkaSkillMasterTemplate.send(kafkaTopicSkillMasterAtDeletion, message);
	}

	public void sendUpdateSkillMaster(SkillMaster message) {

		kafkaSkillMasterTemplate.send(kafkaTopicSkillMasterAtUpdation, message);
	}

	public void sendShift(Shift message) {

		kafkaShiftTemplate.send(kafkaTopicShift, message);
	}

	public void sendUpdateShift(Shift message) {

		kafkaShiftTemplate.send(kafkaTopicShiftAtUpdation, message);
	}
        
        public void sendShiftWithDays(ShiftWithDays message) {

		kafkaShiftWithDaysTemplate.send(kafkaTopicShiftWithDays, message);
	}

	public void sendDeleteShiftWithDays(ShiftWithDays message) {

		kafkaShiftWithDaysTemplate.send(kafkaTopicShiftWithDaysAtDeletetion, message);
	}

        public void sendUpdateShiftWithDays(ShiftWithDays message) {

		kafkaShiftWithDaysTemplate.send(kafkaTopicShiftWithDaysAtUpdation, message);
	}
	public void sendDepartment(DepartmentMaster message) {

		kafkaDepartmentMasterTemplate.send(kafkaTopicDepartmentMaster, message);
	}

	public void sendDeleteOrganization(Organization message) {

		kafkaOrganizationTemplate.send(kafkaTopicOrganizationAtDeletion,
				message);
	}

	public void sendUpdateOrganization(Organization message) {

		kafkaOrganizationTemplate.send(kafkaTopicOrganizationAtUpdation,
				message);
	}

	public void sendAddWorker(Worker message) {

		kafkaWorkerTemplate.send(kafkaTopicWorkerAtAdd, message);
	}

	public void sendUpdateWorker(Worker message) {

		kafkaWorkerTemplate.send(kafkaTopicWorkerAtUpdation, message);
	}

	public void sendDeleteWorker(Worker message) {

		kafkaWorkerTemplate.send(kafkaTopicWorkerAtDeletion, message);
	}

	public void sendAddWAS(WorkerApprovalStatus message) {

		kafkaWorkerApprovalStatusTemplate.send(
				kafkaTopicWorkApprovalStatusAtAdd, message);
	}

	public void sendUpdateWAS(WorkerApprovalStatus message) {

		kafkaWorkerApprovalStatusTemplate.send(
				kafkaTopicWorkApprovalStatusAtUpdation, message);
	}

	public void sendDeleteWAS(WorkerApprovalStatus message) {

		kafkaWorkerApprovalStatusTemplate.send(
				kafkaTopicWorkApprovalStatusAtDeletion, message);
	}

	public void sendRoleMaster(RoleMaster message) {

		kafkaRoleMasterTemplate.send(kafkaTopicRoleMaster, message);
	}

	public void sendRoleMasterUpdate(RoleMaster message) {

		kafkaRoleMasterTemplate.send(kafkaTopicRoleMasterAtUpdation, message);
	}

	public void sendUserRolesMapping(UserRolesMapping message) {

		kafkaUserRolesMappingTemplate.send(kafkaTopicUserRolesMapping, message);
	}

	public void sendUserRolesMappingAtUpdate(UserRolesMapping message) {

		kafkaUserRolesMappingTemplate.send(kafkaTopicUserRoleMappingAtUpdation,
				message);
	}

}
