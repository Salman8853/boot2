package com.gigflex.prototype.microservices.industry.api;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.industry.dtob.IndustryMasterRequest;
import com.gigflex.prototype.microservices.industry.service.IndustryMasterService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/userservice/")
public class IndustryMasterController {

	@Autowired
	public IndustryMasterService industryMasterService;

	@GetMapping("/getAllIndustryMaster")
	public String getAllIndustryMaster() {
		return industryMasterService.findAllIndustryMaster();
	}

	@GetMapping("/getIndustryMaster/{id}")
	public String getIndustryMasterById(@PathVariable Integer id) {
		return industryMasterService.findIndustryMasterById(id);
	}

	@GetMapping("/getByIndustryCode/{industryCode}")
	public String getIndustryMasterByIndustryCode(@PathVariable String industryCode) {
		return industryMasterService.findByIndustryCode(industryCode);
	}

	@PostMapping("/saveIndustryMaster")
	public String saveNewIndustryMaster(
			@Valid @RequestBody IndustryMasterRequest industryMasterReq) {
		return industryMasterService.saveIndustryMaster(industryMasterReq);

	}

	@DeleteMapping("/deleteIndustryMaster/{id}")
	public String deleteIndustryMasterById(@PathVariable Integer id) {
		return industryMasterService.deleteIndustryMasterById(id);
	}
	
	@DeleteMapping("/deleteByIndustryCode/{industryCode}")
	public String deleteIndustryMasterByIndustryCode(@PathVariable String industryCode) {
		return industryMasterService.deleteByIndustryCode(industryCode);
	}


	@PutMapping("/updateIndustryMaster/{id}")
	public String updateIndustryMaster(@PathVariable Integer id,
			@Valid @RequestBody IndustryMasterRequest industryMasterReq) {

		if (id == null) {
			return "Industry Master with Id : (" + id + ") Not found.";
		} else {
			return industryMasterService.updateIndustryMasterById(id,
					industryMasterReq);
		}
	}
	
	

}
