package com.gigflex.prototype.microservices.permissions.api;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.permissions.dtob.PermissionsRequest;
import com.gigflex.prototype.microservices.permissions.service.PermissionsService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/userservice/")
public class PermissionsController {
	
	@Autowired
	PermissionsService permissionsService;

	@GetMapping("/getAllPermissions")
	public String getAllPermissions() {
		return permissionsService.getAllPermissions();
	}

	@GetMapping("/getPermissions/{id}")
	public String getAllPermissionById(@PathVariable Long id) {
		return permissionsService.getAllPermissionsById(id);
	}

	@GetMapping("/getPermissionsByPermissionsCode/{permissionsCode}")
	public String getPermissionsByPermissionsCode(
			@PathVariable String permissionsCode) {
		return permissionsService
				.getPermissionsByPermissionsCode(permissionsCode);
	}

	@PostMapping("/savePermissions")
	public String saveAllPermissions(
			@Valid @RequestBody PermissionsRequest permissionrqst,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return permissionsService.savePermissions(permissionrqst, ip);

	}

	@DeleteMapping("/deletePermissions/{id}")
	public String deleteAllPermissionsById(@PathVariable("id") Long id) {
		return permissionsService.deletePermissionsById(id);
	}

	@DeleteMapping("/deletePermissionsByPermissionsCode/{permissionsCode}")
	public String deletePermissionsByPermissionsCode(
			@PathVariable String permissionsCode) {
		return permissionsService.deleteByPermissionsCode(permissionsCode);
	}

	@PutMapping("/updatePermissions/{id}")
	public String updatePermissionsById(@PathVariable Long id,
			@Valid @RequestBody PermissionsRequest perrqst,
			HttpServletRequest request) {
		if (id == null) {
			return "Permissions with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return permissionsService.updatePermissionsById(id, perrqst, ip);
		}

	}

}
