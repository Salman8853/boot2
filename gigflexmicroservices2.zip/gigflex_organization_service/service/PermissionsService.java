package com.gigflex.prototype.microservices.permissions.service;

import com.gigflex.prototype.microservices.permissions.dtob.PermissionsRequest;


public interface PermissionsService {
	
	public String getAllPermissions();
	public String getAllPermissionsById(Long id);
	public String savePermissions(PermissionsRequest perrqst, String ip);
	public String deletePermissionsById(Long id);
	public String updatePermissionsById(Long id, PermissionsRequest perrqst, String ip);
	public String getPermissionsByPermissionsCode(String permissionsCode);
	public String deleteByPermissionsCode(String permissionsCode);

}
