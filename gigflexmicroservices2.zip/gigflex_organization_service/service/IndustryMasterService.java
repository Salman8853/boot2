package com.gigflex.prototype.microservices.industry.service;

import com.gigflex.prototype.microservices.industry.dtob.IndustryMasterRequest;

public interface IndustryMasterService {

	public String updateIndustryMasterById(Integer id,
			IndustryMasterRequest industryMasterReq);
	
	public String findAllIndustryMaster();

	public String findIndustryMasterById(Integer id);
	
	public String findByIndustryCode(String industryCode);

	public String saveIndustryMaster(IndustryMasterRequest industryMasterReq);

	public String deleteIndustryMasterById(Integer id);
	
	public String deleteByIndustryCode(String industryCode);


}
