package com.gigflex.prototype.microservices.permissions.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.permissions.dtob.Permissions;
import com.gigflex.prototype.microservices.permissions.dtob.PermissionsRequest;
import com.gigflex.prototype.microservices.permissions.repository.PermissionsRepository;
import com.gigflex.prototype.microservices.permissions.service.PermissionsService;
import com.gigflex.prototype.microservices.registration.utility.GigflexResponse;

@Service
public class PermissionsServiceImpl implements PermissionsService {

	@Autowired
	PermissionsRepository permissionsRepository;
	
	@Autowired
	private KafkaService kafkaService;

	@Override
	public String getAllPermissions() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Permissions> perlst = permissionsRepository.findAll();
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (perlst != null && perlst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(perlst);
				jsonobj.put("data", new JSONArray(Detail));
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllPermissionsById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<Permissions> perlst = permissionsRepository.findById(id);
			if (perlst.isPresent() && perlst.get() != null) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(perlst.get());
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String savePermissions(PermissionsRequest perrqst, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
		
			if (perrqst.getPermissionsName() != null
					&& perrqst.getPermissionsName().length() > 0) {
				Permissions perlst = permissionsRepository
						.getByPermissionsName(perrqst.getPermissionsName());
				if (perlst != null && perlst.getId() > 0) {
					
					jsonobj.put("responsecode", 409);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Permissions name already exists");
				} 
				else {
					Permissions per = new Permissions();
					per.setPermissionsName(perrqst.getPermissionsName());
					per.setIpAddress(ip);
					Permissions perRes = permissionsRepository.save(per);
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					if (perRes != null && perRes.getId() > 0) {
						kafkaService.sendPermissions(perRes);
						jsonobj.put("message",
								"Permission has been added successfully.");
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(perRes);
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("message", "Failed");
					}
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Permissions name should not be blank");
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String deletePermissionsById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<Permissions> perData = permissionsRepository.findById(id);
			if (perData.isPresent() && perData.get() != null) {
				permissionsRepository.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Permission has been deleted.");
				jsonobj.put("timestamp", new Date());
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String updatePermissionsById(Long id, PermissionsRequest perrqst,
			String ip) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && perrqst != null) {
				if (perrqst.getPermissionsName() != null
						&& perrqst.getPermissionsName().length() > 0) {
					Optional<Permissions> permissionsInDb = permissionsRepository
							.findById(id);
					if (permissionsInDb.isPresent()
							&& permissionsInDb.get() != null) {

						Permissions permissions = permissionsInDb.get();
						if (!(perrqst.getPermissionsName().equals(permissions
								.getPermissionsName()))) {
							Permissions perlst = permissionsRepository
									.getByPermissionsName(perrqst
											.getPermissionsName());
							if (perlst != null && perlst.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message",
										"Permissions name already exists");
							} else {
								permissions.setPermissionsName(perrqst
										.getPermissionsName());
								permissions.setIpAddress(ip);
								Permissions rolemasterRes = permissionsRepository
										.save(permissions);
								if (rolemasterRes != null
										&& rolemasterRes.getId() > 0) {
									jsonobj.put("responsecode", 200);
									jsonobj.put("message",
											"Permissions updation has been done");
									jsonobj.put("timestamp", new Date());
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj
											.writeValueAsString(rolemasterRes);
									jsonobj.put("data", new JSONObject(Detail));
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("message",
											"Permissions updation has been failed.");
									jsonobj.put("timestamp", new Date());
								}
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Old Permission name and New Permission name should be different.");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Permissions ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Permissions name should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String getPermissionsByPermissionsCode(String permissionsCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Permissions permissionsInDb = permissionsRepository
					.getPermissionsByPermissionsCode(permissionsCode);
			if (permissionsInDb != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(permissionsInDb);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteByPermissionsCode(String permissionsCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Integer deleteByPermissionsCode = permissionsRepository
					.deleteByPermissionsCode(permissionsCode);
			if (deleteByPermissionsCode != 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Permissions has been deleted.");
				jsonobj.put("timestamp", new Date());
				res = jsonobj.toString();
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

}
