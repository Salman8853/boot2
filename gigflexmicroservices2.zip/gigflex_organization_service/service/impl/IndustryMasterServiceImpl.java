package com.gigflex.prototype.microservices.industry.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.industry.dtob.IndustryMaster;
import com.gigflex.prototype.microservices.industry.dtob.IndustryMasterRequest;
import com.gigflex.prototype.microservices.industry.repository.IndustryMasterDao;
import com.gigflex.prototype.microservices.industry.service.IndustryMasterService;
import com.gigflex.prototype.microservices.registration.dtob.Users;
import com.gigflex.prototype.microservices.registration.utility.GigflexResponse;

@Service
public class IndustryMasterServiceImpl implements IndustryMasterService {

	@Autowired
	private IndustryMasterDao industryMasterRep;
	
	@Autowired
	private KafkaService kafkaService;

	@Override
	public String updateIndustryMasterById(Integer id,
			IndustryMasterRequest industryMasterReq) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && industryMasterReq != null) {
				Optional<IndustryMaster> industryMasterInDb = industryMasterRep
						.findById(id);
				if (industryMasterInDb.isPresent()
						&& industryMasterInDb.get() != null) {

					IndustryMaster industry = industryMasterInDb.get();
					industry.setIndustryName(industryMasterReq
							.getIndustryName());
					IndustryMaster industryRes = industryMasterRep
							.save(industry);
					if (industryRes != null && industryRes.getId() > 0) {
						jsonobj.put("responsecode", 200);
						jsonobj.put("message",
								"Industry Master updation has been done");
						jsonobj.put("timestamp", new Date());
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj
								.writeValueAsString(industryRes);
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message",
								"Industry Master updation has been failed.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Industry Master ID is not valid.");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String findAllIndustryMaster() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<IndustryMaster> industrylst = industryMasterRep.findAll();
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (industrylst != null && industrylst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(industrylst);
				jsonobj.put("data", new JSONArray(Detail));
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String findIndustryMasterById(Integer id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<IndustryMaster> industrylst = industryMasterRep
					.findById(id);

			if (industrylst.isPresent() && industrylst.get() != null) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(industrylst.get());
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveIndustryMaster(IndustryMasterRequest industryMasterReq) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			IndustryMaster industry = new IndustryMaster();

			industry.setIndustryName(industryMasterReq.getIndustryName());

			IndustryMaster industryRes = industryMasterRep.save(industry);

			jsonobj.put("responsecode", 200);
			jsonobj.put("timestamp", new Date());

			if (industryRes != null && industryRes.getId() > 0) {
				
				kafkaService.sendIndustryMaster(industryRes);

				jsonobj.put("message",
						"Industry Master has been added successfully.");
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(industryRes);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("message", "Failed");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String deleteIndustryMasterById(Integer id) {
	    String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<IndustryMaster> indusData = industryMasterRep.findById(id);
			if (indusData.isPresent() && indusData.get() !=null) {
				industryMasterRep.deleteById(id);
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Industry Master has been deleted.");
			jsonobj.put("timestamp", new Date());
			}else{
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
				}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}
	

    @Override
	public String findByIndustryCode(String industryCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			IndustryMaster industrylst = industryMasterRep
					.getIndustryMasterByIndustryCode(industryCode);
			if (industrylst != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(industrylst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteByIndustryCode(String industryCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Integer deleteByIndustryCode = industryMasterRep
					.deleteIndustryMasterByIndustryCode(industryCode);
			if (deleteByIndustryCode != 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Industry Master has been deleted.");
				jsonobj.put("timestamp", new Date());
				res = jsonobj.toString();
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

}
