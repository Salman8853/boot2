package com.gigflex.prototype.microservices.permissions.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.permissions.dtob.Permissions;



public interface PermissionsRepository extends JpaRepository<Permissions,Long>{
	
	public Permissions getPermissionsByPermissionsCode(String permissionsCode);
	
	@Transactional
	public Integer deleteByPermissionsCode(String permissionsCode);
	
	public Permissions getByPermissionsName(String permissionsName);

}
