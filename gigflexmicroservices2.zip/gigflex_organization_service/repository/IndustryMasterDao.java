package com.gigflex.prototype.microservices.industry.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import  com.gigflex.prototype.microservices.industry.dtob.IndustryMaster;

@Repository
public interface IndustryMasterDao extends JpaRepository<IndustryMaster,Integer> {
	
	public IndustryMaster getIndustryMasterByIndustryCode(String industryCode);
	
	//public Optional<IndustryMaster> getIndustryMasterByIndustryCodeOpt(String industryCode);

	
	@Transactional
	public Integer deleteIndustryMasterByIndustryCode(String industryCode);

//	public IndustryMaster updatebyIndustryCode(String industryCode);


}
