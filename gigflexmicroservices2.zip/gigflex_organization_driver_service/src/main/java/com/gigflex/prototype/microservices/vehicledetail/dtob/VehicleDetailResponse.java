package com.gigflex.prototype.microservices.vehicledetail.dtob;

import java.util.Date;

public class VehicleDetailResponse {

	private Long id;

	private String vehicleCode;

	private String vehicleTypeCode;
	
	private String vehicleTypeName;

	private Long vehicleYear;

	private Double initialMileage;

	private String vehicleImage;

	private String registrationExpiryDate;

	private Boolean inService;

	private String color;

	private String vin;

	private String licensePlate;
        
        private String licensePlateDoc;

	private String licenseExpiryDate;
        
        private String insurance;
        
        private String insuranceDoc;

	private String insuranceExpiryDate;
        
        private String vehicleLogbookDoc;                   
        
        private String vehicleMOTDoc;

	private String vehicleMOTExpiryDate;
        
        private String hireAgreementDoc;

	private String hireAgreementDocExpiryDate;

	private Long passengerQuantity;

	private Long baggageQuantity;
	
	private Boolean airCondition;

	private Boolean automaticTransmission;

	private String fuelTypeCode;
        
        private String fuelTypeName;

	private Boolean sateliteNavigation;

	private String organizationCode;
        
        private String organizationName;

	private String modelCode;
        
        private String modelName;
 
	private String registrationNumber;
 
	private String makeCode;
        
        private String makeName;
        
        private String driverCode;
	    
	private String driverName;
        
        private String dateFormat ;
        private String timeFormat;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getVehicleCode() {
        return vehicleCode;
    }

    public void setVehicleCode(String vehicleCode) {
        this.vehicleCode = vehicleCode;
    }

    public String getVehicleTypeCode() {
        return vehicleTypeCode;
    }

    public void setVehicleTypeCode(String vehicleTypeCode) {
        this.vehicleTypeCode = vehicleTypeCode;
    }

    public String getVehicleTypeName() {
        return vehicleTypeName;
    }

    public void setVehicleTypeName(String vehicleTypeName) {
        this.vehicleTypeName = vehicleTypeName;
    }

    public Long getVehicleYear() {
        return vehicleYear;
    }

    public void setVehicleYear(Long vehicleYear) {
        this.vehicleYear = vehicleYear;
    }

    public Double getInitialMileage() {
        return initialMileage;
    }

    public void setInitialMileage(Double initialMileage) {
        this.initialMileage = initialMileage;
    }

    public String getVehicleImage() {
        return vehicleImage;
    }

    public void setVehicleImage(String vehicleImage) {
        this.vehicleImage = vehicleImage;
    }

    public String getRegistrationExpiryDate() {
        return registrationExpiryDate;
    }

    public void setRegistrationExpiryDate(String registrationExpiryDate) {
        this.registrationExpiryDate = registrationExpiryDate;
    }

    public Boolean getInService() {
        return inService;
    }

    public void setInService(Boolean inService) {
        this.inService = inService;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public String getLicensePlateDoc() {
        return licensePlateDoc;
    }

    public void setLicensePlateDoc(String licensePlateDoc) {
        this.licensePlateDoc = licensePlateDoc;
    }

    public String getLicenseExpiryDate() {
        return licenseExpiryDate;
    }

    public void setLicenseExpiryDate(String licenseExpiryDate) {
        this.licenseExpiryDate = licenseExpiryDate;
    }

    public String getInsurance() {
        return insurance;
    }

    public void setInsurance(String insurance) {
        this.insurance = insurance;
    }

    public String getInsuranceDoc() {
        return insuranceDoc;
    }

    public void setInsuranceDoc(String insuranceDoc) {
        this.insuranceDoc = insuranceDoc;
    }

    public String getInsuranceExpiryDate() {
        return insuranceExpiryDate;
    }

    public void setInsuranceExpiryDate(String insuranceExpiryDate) {
        this.insuranceExpiryDate = insuranceExpiryDate;
    }

    public String getVehicleLogbookDoc() {
        return vehicleLogbookDoc;
    }

    public void setVehicleLogbookDoc(String vehicleLogbookDoc) {
        this.vehicleLogbookDoc = vehicleLogbookDoc;
    }

    public String getVehicleMOTDoc() {
        return vehicleMOTDoc;
    }

    public void setVehicleMOTDoc(String vehicleMOTDoc) {
        this.vehicleMOTDoc = vehicleMOTDoc;
    }

    public String getVehicleMOTExpiryDate() {
        return vehicleMOTExpiryDate;
    }

    public void setVehicleMOTExpiryDate(String vehicleMOTExpiryDate) {
        this.vehicleMOTExpiryDate = vehicleMOTExpiryDate;
    }

    public String getHireAgreementDoc() {
        return hireAgreementDoc;
    }

    public void setHireAgreementDoc(String hireAgreementDoc) {
        this.hireAgreementDoc = hireAgreementDoc;
    }

    public String getHireAgreementDocExpiryDate() {
        return hireAgreementDocExpiryDate;
    }

    public void setHireAgreementDocExpiryDate(String hireAgreementDocExpiryDate) {
        this.hireAgreementDocExpiryDate = hireAgreementDocExpiryDate;
    }

    public Long getPassengerQuantity() {
        return passengerQuantity;
    }

    public void setPassengerQuantity(Long passengerQuantity) {
        this.passengerQuantity = passengerQuantity;
    }

    public Long getBaggageQuantity() {
        return baggageQuantity;
    }

    public void setBaggageQuantity(Long baggageQuantity) {
        this.baggageQuantity = baggageQuantity;
    }

    public Boolean getAirCondition() {
        return airCondition;
    }

    public void setAirCondition(Boolean airCondition) {
        this.airCondition = airCondition;
    }

    public Boolean getAutomaticTransmission() {
        return automaticTransmission;
    }

    public void setAutomaticTransmission(Boolean automaticTransmission) {
        this.automaticTransmission = automaticTransmission;
    }

    public String getFuelTypeCode() {
        return fuelTypeCode;
    }

    public void setFuelTypeCode(String fuelTypeCode) {
        this.fuelTypeCode = fuelTypeCode;
    }

    public String getFuelTypeName() {
        return fuelTypeName;
    }

    public void setFuelTypeName(String fuelTypeName) {
        this.fuelTypeName = fuelTypeName;
    }

    public Boolean getSateliteNavigation() {
        return sateliteNavigation;
    }

    public void setSateliteNavigation(Boolean sateliteNavigation) {
        this.sateliteNavigation = sateliteNavigation;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getModelCode() {
        return modelCode;
    }

    public void setModelCode(String modelCode) {
        this.modelCode = modelCode;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getMakeCode() {
        return makeCode;
    }

    public void setMakeCode(String makeCode) {
        this.makeCode = makeCode;
    }

    public String getMakeName() {
        return makeName;
    }

    public void setMakeName(String makeName) {
        this.makeName = makeName;
    }

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getTimeFormat() {
        return timeFormat;
    }

    public void setTimeFormat(String timeFormat) {
        this.timeFormat = timeFormat;
    }
	

}
