/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.rideexchange.service;

/**
 *
 * @author amit.kumar
 */
public interface RideExchangeService {

    public String findAllAllRideExchange();

    public String findLastBalanceOfRideExcahange();

    public String findRideExcahangeByRideCode(String rideCode);

    public String getRideExcahangeBetweenDates(String startDT, String endDT);

}
