/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationcredittransaction.dtob;

/**
 *
 * @author amit.kumar
 */
public class OrganizationCreditTransactionRequest {
 
    private Double amount;
    private String organizationCode;
    private Boolean isCreditable;   

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public Boolean isIsCreditable() {
        return isCreditable;
    }

    public void setIsCreditable(Boolean isCreditable) {
        this.isCreditable = isCreditable;
    }
    
}
