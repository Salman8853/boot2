/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.organization.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.organization.dtob.Organization;


@Repository
public interface OrganizationDao extends JpaRepository<Organization, Long> {
	@Query("SELECT org FROM Organization org WHERE org.isDeleted != TRUE AND org.organizationName = :organizationName")
 	public Organization getOrganizationByName(
			@Param("organizationName") String organizationName);
	
	@Query("SELECT d FROM Organization d WHERE d.isDeleted != TRUE AND d.organizationCode = :organizationCode")
	public Organization findByOrganizationCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT d FROM Organization d WHERE d.isDeleted != TRUE")
	public List<Organization> getAllOrganization();

	@Query("SELECT d FROM Organization d WHERE d.isDeleted != TRUE AND d.id = :id")
	public Organization getOrganizationById(@Param("id") Long id);

	@Transactional
	public Integer deleteOrganizationByOrganizationCode(String organizationCode);
	
	
//	SELECT *
//	FROM `organization` org LEFT OUTER JOIN `organization_approval_authority` aurt ON (org.`organization_code`=aurt.`organization_code`) WHERE org.isdeleted!=TRUE
	
	
//	@Query("SELECT org,aurt.authorityCode,aurt.isProcessed,aurt.organizationApprovalAuthorityCode,aurt.id,(SELECT o.organizationName FROM Organization o WHERE o.organizationCode=aurt.authorityCode) FROM Organization org LEFT OUTER JOIN OrganizationApprovalAuthority aurt ON (org.organizationCode = aurt.organizationCode) WHERE org.isDeleted != TRUE")
//	public List<Object> getAllOrganizationWithName(Pageable pageableRequest);
	

}
