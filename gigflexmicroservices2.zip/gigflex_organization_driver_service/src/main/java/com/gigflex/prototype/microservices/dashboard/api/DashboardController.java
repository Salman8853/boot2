package com.gigflex.prototype.microservices.dashboard.api;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.dashboard.service.DashboardService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.TokenUtility;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class DashboardController {

	@Autowired
	public DashboardService dashboardService;
          @Autowired
        TokenUtility tokenutility;
	@GetMapping(path = "/getBookingForDashboardByOperatorCode/{operatorCode}")
	public String getBookingForDashboardByOperatorCode(@PathVariable String operatorCode,@RequestHeader HttpHeaders headers) {
               String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                 if (operatorCode != null && operatorCode.trim().length() > 0) {
			return dashboardService.getBookingForDashboardByOperatorCode(operatorCode.trim());

		  } else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Operator Code should not be blank.");
			return derr.toString();
		    }
               }else
               {
               return res;
               }
	}
	
        
        
	@GetMapping(path = "/getBookingForDashboardByOrganizationCode/{organizationCode}")
	public String getBookingForDashboardByOrganizationCode(@PathVariable String organizationCode,@RequestHeader HttpHeaders headers) {
            
                 String res="";
               res=tokenutility.orgCodeValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
                  if (organizationCode != null && organizationCode.trim().length() > 0) {
			return dashboardService.getBookingForDashboardByOrganizationCode(organizationCode.trim());

		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Organization Code should not be blank.");
			return derr.toString();
		}
               }else
               {
                 return res;
               }
		
	}
	
        
	@GetMapping(path = "/getBookingForDashboardByDriverCode/{driverCode}")
	public String getBookingForDashboardByDriverCode(@PathVariable String driverCode,@RequestHeader HttpHeaders headers) {
            String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true"))
               {
                   if (driverCode != null && driverCode.trim().length() > 0) {
			return dashboardService.getBookingForDashboardByDriverCode(driverCode.trim());

		   } else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Driver Code should not be blank.");
			return derr.toString();
		}
               
               }else
               {
               return res;
               }
		
	}
}
