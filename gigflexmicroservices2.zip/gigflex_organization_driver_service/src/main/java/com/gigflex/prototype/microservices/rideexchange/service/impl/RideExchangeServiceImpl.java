/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.rideexchange.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.drivertimeoff.service.impl.DriverTimeOffServiceImpl;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransaction;
import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransactionResponse;
import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationTransactionDetailsResponse;
import com.gigflex.prototype.microservices.rideexchange.dtob.RideExchange;
import com.gigflex.prototype.microservices.rideexchange.dtob.RideExchangeRes;
import com.gigflex.prototype.microservices.rideexchange.repository.RideExchangeRepository;
import com.gigflex.prototype.microservices.rideexchange.service.RideExchangeService;

import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.utility.GigflexDateUtil;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;

import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */
@Service
public class RideExchangeServiceImpl implements RideExchangeService{

    private static final Logger LOG = LoggerFactory.getLogger(RideExchangeServiceImpl.class);
    
    @Autowired
    RideExchangeRepository rideExchangeDao;
    
    @Autowired
    OrganizationRepository organizationDao;
    
    @Autowired
    GlobalSettingRepository globalSettingRepository;
    
    @Autowired
    LocalSettingRepository localSettingRepository;

    @Autowired
    UserTypeRepository userTypeDao;
    
    @Autowired
    private TimeZoneRepository timeZoneRepository;    
    
    @Override
    public String findAllAllRideExchange() {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<RideExchange> objlst = rideExchangeDao.getAllRideExchange();
			List<RideExchangeRes> maplst = new ArrayList<RideExchangeRes>();
			if (objlst != null && objlst.size() > 0) {
                            for (int i = 0; i < objlst.size(); i++) {

                                RideExchange re = objlst.get(i);
                                
                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, re.getOrganizationCodeAssigned(), GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, re.getOrganizationCodeAssigned(), GigflexConstants.TIMEFORMAT);

                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                String timeznCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, re.getOrganizationCodeAssigned(), GigflexConstants.TimeZone);

                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timeznCode);
                                String transactionDt = "";

                                Date transactionDate = re.getCreatedAt();
                                if(transactionDate != null && transactionDate.toString().trim().length() > 0)
                                {
                                    if (tzd != null && tzd.getId() > 0) {

                                        String timezone = tzd.getTimeZoneName();
                                        if(timezone!=null && timezone.length()>0 )
                                        {                              
                                            transactionDate = GigflexDateUtil.getGMTtoLocationDate(transactionDate, timezone, dtFormat);
                                            transactionDt=GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                                        }
                                    } 
                                    else
                                    {
                                        transactionDt = GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                                    }
                                }
                                    
                                    
                                RideExchangeRes reRes = new RideExchangeRes();

                                reRes.setId(re.getId());
                                reRes.setOrganizationCodePublish(re.getOrganizationCodePublish());                            
                                if(re.getOrganizationCodePublish() != null && re.getOrganizationCodePublish().trim().length() > 0)
                                {
                                    Organization org = organizationDao.findByOrganizationCode(re.getOrganizationCodePublish().trim());
                                    if(org != null)
                                    {
                                        String organizationName = org.getOrganizationName();
                                        reRes.setOrganizationNamePublish(organizationName); 
                                    }
                                }
                                   
                                reRes.setOrganizationCodeAssigned(re.getOrganizationCodeAssigned());                            
                                if(re.getOrganizationCodeAssigned() != null && re.getOrganizationCodeAssigned().trim().length() > 0)
                                {
                                    Organization org = organizationDao.findByOrganizationCode(re.getOrganizationCodeAssigned().trim());
                                    if(org != null)
                                    {
                                        String organizationName = org.getOrganizationName();
                                        reRes.setOrganizationNameAssigned(organizationName); 
                                    }
                                }
                                    
                                reRes.setRideCode(re.getRideCode()); 
                                reRes.setRideExchangeAmount(re.getRideExchangeAmount()); 
                                reRes.setRideExchangeCode(re.getRideExchangeCode()); 
                                reRes.setBalanceAmount(re.getBalanceAmount());  
                                reRes.setTransactionDate(transactionDt); 
                                maplst.add(reRes);

                            }
                            if (maplst.size() > 0) {
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(maplst);
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("message", "Success");
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("data", new JSONArray(Detail));
                            } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("message", "Record Not Found");
                                    jsonobj.put("timestamp", new Date());
                            }
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
                        
		}
		return res;
    }

    @Override
    public String findLastBalanceOfRideExcahange() {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();                            
                        List<RideExchange> objlst = rideExchangeDao.getLastBalanceOfRideExcahange();

                        if (objlst != null && objlst.size() > 0) {

                        RideExchange re = objlst.get(0);
                        
                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, re.getOrganizationCodeAssigned(), GigflexConstants.DATEFORMAT);
                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, re.getOrganizationCodeAssigned(), GigflexConstants.TIMEFORMAT);

                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                        {
                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                        }                

                        String timeznCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, re.getOrganizationCodeAssigned(), GigflexConstants.TimeZone);

                        TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timeznCode);
                        String transactionDt = "";

                        Date transactionDate = re.getCreatedAt();
                        if(transactionDate != null && transactionDate.toString().trim().length() > 0)
                        {
                            if (tzd != null && tzd.getId() > 0) {

                                String timezone = tzd.getTimeZoneName();
                                if(timezone!=null && timezone.length()>0 )
                                {                              
                                    transactionDate = GigflexDateUtil.getGMTtoLocationDate(transactionDate, timezone, dtFormat);
                                    transactionDt=GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                                }
                            } 
                            else
                            {
                                transactionDt = GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                            }
                        }
                        
                        RideExchangeRes reRes = new RideExchangeRes();

                        reRes.setId(re.getId());
                        reRes.setOrganizationCodePublish(re.getOrganizationCodePublish());                            
                        if(re.getOrganizationCodePublish() != null && re.getOrganizationCodePublish().trim().length() > 0)
                        {
                            Organization org = organizationDao.findByOrganizationCode(re.getOrganizationCodePublish().trim());
                            if(org != null)
                            {
                                String organizationName = org.getOrganizationName();
                                reRes.setOrganizationNamePublish(organizationName); 
                            }
                        }
                                   
                        reRes.setOrganizationCodeAssigned(re.getOrganizationCodeAssigned());                            
                        if(re.getOrganizationCodeAssigned() != null && re.getOrganizationCodeAssigned().trim().length() > 0)
                        {
                            Organization org = organizationDao.findByOrganizationCode(re.getOrganizationCodeAssigned().trim());
                            if(org != null)
                            {
                                String organizationName = org.getOrganizationName();
                                reRes.setOrganizationNameAssigned(organizationName); 
                            }
                        }
                                    
                        reRes.setRideCode(re.getRideCode()); 
                        reRes.setRideExchangeAmount(re.getRideExchangeAmount()); 
                        reRes.setRideExchangeCode(re.getRideExchangeCode()); 
                        reRes.setBalanceAmount(re.getBalanceAmount());   
                        reRes.setTransactionDate(transactionDt); 

                        if (reRes != null && reRes.getId() > 0) {
                                ObjectMapper mapperObj = new ObjectMapper();
                                String Detail = mapperObj.writeValueAsString(reRes);
                                jsonobj.put("responsecode", 200);
                                jsonobj.put("message", "Success");
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("data", new JSONObject(Detail));
                        } else {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("message", "Record Not Found");
                                jsonobj.put("timestamp", new Date());
                        }
                        } else {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("message", "Record Not Found");
                                jsonobj.put("timestamp", new Date());
                        }
                        
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
    }

    @Override
    public String findRideExcahangeByRideCode(String rideCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();                            
                        RideExchange re = rideExchangeDao.getRideExcahangeByRideCode(rideCode);

                        if (re != null && re.getId() > 0) {
                            
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, re.getOrganizationCodeAssigned(), GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, re.getOrganizationCodeAssigned(), GigflexConstants.TIMEFORMAT);

                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            String timeznCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, re.getOrganizationCodeAssigned(), GigflexConstants.TimeZone);

                            TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timeznCode);
                            
                            String transactionDt = "";

                            Date transactionDate = re.getCreatedAt();
                            if(transactionDate != null && transactionDate.toString().trim().length() > 0)
                            {
                                if (tzd != null && tzd.getId() > 0) {

                                    String timezone = tzd.getTimeZoneName();
                                    if(timezone!=null && timezone.length()>0 )
                                    {                              
                                        transactionDate = GigflexDateUtil.getGMTtoLocationDate(transactionDate, timezone, dtFormat);
                                        transactionDt=GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                                    }
                                } 
                                else
                                {
                                    transactionDt = GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                                }
                            }
                            
                            RideExchangeRes reRes = new RideExchangeRes();
                            reRes.setId(re.getId());
                            reRes.setOrganizationCodePublish(re.getOrganizationCodePublish());                            
                            if(re.getOrganizationCodePublish() != null && re.getOrganizationCodePublish().trim().length() > 0)
                            {
                                Organization org = organizationDao.findByOrganizationCode(re.getOrganizationCodePublish().trim());
                                if(org != null)
                                {
                                    String organizationName = org.getOrganizationName();
                                    reRes.setOrganizationNamePublish(organizationName); 
                                }
                            }
                                   
                            reRes.setOrganizationCodeAssigned(re.getOrganizationCodeAssigned());                            
                            if(re.getOrganizationCodeAssigned() != null && re.getOrganizationCodeAssigned().trim().length() > 0)
                            {
                                Organization org = organizationDao.findByOrganizationCode(re.getOrganizationCodeAssigned().trim());
                                if(org != null)
                                {
                                    String organizationName = org.getOrganizationName();
                                    reRes.setOrganizationNameAssigned(organizationName); 
                                }
                            }
                                    
                            reRes.setRideCode(re.getRideCode()); 
                            reRes.setRideExchangeAmount(re.getRideExchangeAmount()); 
                            reRes.setRideExchangeCode(re.getRideExchangeCode()); 
                            reRes.setBalanceAmount(re.getBalanceAmount());  
                            reRes.setTransactionDate(transactionDt); 

                            if (reRes != null && reRes.getId() > 0) {
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(reRes);
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("message", "Success");
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("message", "Record Not Found");
                                    jsonobj.put("timestamp", new Date());
                            }
                            } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("message", "Record Not Found");
                                    jsonobj.put("timestamp", new Date());
                            }

                            res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
    }

    @Override
    public String getRideExcahangeBetweenDates(String startDT, String endDT) {
    
     String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            
                   
            Date fromDate = null;
            Date toDate = null;
            
            try {
                fromDate = GigflexDateUtil.convertStringToDate(startDT.trim(), GigflexConstants.YYYY_MM_DD_HH_MM_SS);
                toDate =   GigflexDateUtil.convertStringToDate(endDT.trim(), GigflexConstants.YYYY_MM_DD_HH_MM_SS);
            } catch (Exception ex) {
                java.util.logging.Logger.getLogger(DriverTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);

                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                "Plz send date in correct format("+GigflexConstants.YYYY_MM_DD_HH_MM_SS+") ");
                                return derr.toString();
            }

            if(fromDate.after(toDate)) 
            {
                 GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                "From date should be less than todate ");
                                return derr.toString();
            }

            List<RideExchange> objlst = rideExchangeDao.getRideExchangeBetweenDates(toDate,fromDate);
                       
            List<RideExchangeRes> maplst = new ArrayList<RideExchangeRes>();
            if (objlst != null && objlst.size() > 0) {

               
                        
                for (int i = 0; i < objlst.size(); i++) {
                    
                    RideExchange   re = objlst.get(i);
                    
                    String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, re.getOrganizationCodeAssigned(), GigflexConstants.DATEFORMAT);
                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, re.getOrganizationCodeAssigned(), GigflexConstants.TIMEFORMAT);

                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                    {
                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                    }                

                    String timeznCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, re.getOrganizationCodeAssigned(), GigflexConstants.TimeZone);

                    TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timeznCode);
                    String transactionDt = "";

                    Date transactionDate = re.getCreatedAt();
                    if(transactionDate != null && transactionDate.toString().trim().length() > 0)
                    {
                        if (tzd != null && tzd.getId() > 0) {

                            String timezone = tzd.getTimeZoneName();
                            if(timezone!=null && timezone.length()>0 )
                            {                              
                                transactionDate = GigflexDateUtil.getGMTtoLocationDate(transactionDate, timezone, dtFormat);
                                transactionDt=GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                            }
                        } 
                        else
                        {
                            transactionDt = GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                        }
                    }
                        
                    RideExchangeRes reRes = new RideExchangeRes();
                    reRes.setId(re.getId());
                    reRes.setOrganizationCodePublish(re.getOrganizationCodePublish());                            
                    if(re.getOrganizationCodePublish() != null && re.getOrganizationCodePublish().trim().length() > 0)
                    {
                        Organization org = organizationDao.findByOrganizationCode(re.getOrganizationCodePublish().trim());
                        if(org != null)
                        {
                            String organizationName = org.getOrganizationName();
                            reRes.setOrganizationNamePublish(organizationName); 
                        }
                    }
                                   
                    reRes.setOrganizationCodeAssigned(re.getOrganizationCodeAssigned());                            
                    if(re.getOrganizationCodeAssigned() != null && re.getOrganizationCodeAssigned().trim().length() > 0)
                    {
                        Organization org = organizationDao.findByOrganizationCode(re.getOrganizationCodeAssigned().trim());
                        if(org != null)
                        {
                            String organizationName = org.getOrganizationName();
                            reRes.setOrganizationNameAssigned(organizationName); 
                        }
                    }
                                    
                    reRes.setRideCode(re.getRideCode()); 
                    reRes.setRideExchangeAmount(re.getRideExchangeAmount()); 
                    reRes.setRideExchangeCode(re.getRideExchangeCode()); 
                    reRes.setBalanceAmount(re.getBalanceAmount());  
                    reRes.setTransactionDate(transactionDt); 

                    maplst.add(reRes);

                    }
                }
                if (maplst != null && maplst.size() > 0) {
                    jsonobj.put("responsecode", 200);
                    jsonobj.put("message", "Success");
                    jsonobj.put("timestamp", new Date());                      
                    ObjectMapper mapperObj = new ObjectMapper();
                    String Detail = mapperObj.writeValueAsString(maplst);
                    jsonobj.put("data", new JSONArray(Detail));
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Record Not Found");
                    jsonobj.put("timestamp", new Date());
                }
                
            
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;
    
    }
    
    
    
    
}
