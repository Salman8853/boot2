package com.gigflex.prototype.microservices.ridetype.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.ridetype.dtob.RideType;
import com.gigflex.prototype.microservices.util.SearchCriteria;




public class RideTypeSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public RideTypeSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public RideTypeSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<RideType> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<RideType>> specs = new ArrayList<Specification<RideType>>();
        for (SearchCriteria param : params) {
            specs.add(new RideTypeSpecification(param));
        }
 
        Specification<RideType> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
