package com.gigflex.prototype.microservices.fuel.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.fuel.dtob.Fuel;

public interface FuelDao extends JpaRepository<Fuel, Long>, JpaSpecificationExecutor<Fuel> {

	@Query("SELECT a FROM Fuel a WHERE a.isDeleted != TRUE AND a.fuelTypeCode = :fuelTypeCode")
	public Fuel getFuelByFuelCode(@Param("fuelTypeCode") String fuelTypeCode);
	
	@Query("SELECT a FROM Fuel a WHERE a.isDeleted != TRUE AND a.fuelTypeName = :fuelTypeName")
	public Fuel getFuelByFuelName(@Param("fuelTypeName") String fuelTypeName);

	@Query("SELECT a FROM Fuel a WHERE a.isDeleted != TRUE")
	public List<Fuel> getAllFuel();

	@Query("SELECT a FROM Fuel a WHERE a.isDeleted != TRUE")
	public List<Fuel> getAllFuel(Pageable pageableRequest);

	@Query("SELECT a FROM Fuel a WHERE a.isDeleted != TRUE AND a.id = :id")
	public Fuel getFuelById(@Param("id") Long id);
}
