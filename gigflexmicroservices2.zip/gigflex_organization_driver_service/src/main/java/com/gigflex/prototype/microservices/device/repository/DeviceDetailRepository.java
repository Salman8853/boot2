/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.device.repository;

import com.gigflex.prototype.microservices.device.dtob.DeviceDetail;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author nirbhay.p
 */
@Repository
public interface DeviceDetailRepository extends JpaRepository<DeviceDetail, Long>,JpaSpecificationExecutor<DeviceDetail>{

    @Query("SELECT deviceDetail FROM DeviceDetail deviceDetail  WHERE deviceDetail.isDeleted != TRUE AND  deviceDetail.userCode = :userCode")
    public List<DeviceDetail> getDeviceDetailByUserCode(@Param("userCode") String userCode);
    
    @Query("SELECT deviceDetail FROM DeviceDetail deviceDetail  WHERE deviceDetail.isDeleted != TRUE AND  deviceDetail.userCode = :userCode AND deviceDetail.deviceType = :deviceType")
    public DeviceDetail getDeviceDetailByUserCodeAndDeviceType(@Param("userCode") String userCode,@Param("deviceType") String deviceType);
    
}
