/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.globalridetype.dtob;

/**
 *
 * @author m.salman
 */
public class GlobalRideTypeResponse {
       
       private Long id;
       
       private String globalRideCode;
       
       private String vehicleName;
// baseRate will be Double Type;

       private Double baseRate;
// ratePerMile will be Double Type;
      private Double ratePerMile;
       
      private String currencySymbol;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGlobalRideCode() {
        return globalRideCode;
    }

    public void setGlobalRideCode(String globalRideCode) {
        this.globalRideCode = globalRideCode;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public void setVehicleName(String vehicleName) {
        this.vehicleName = vehicleName;
    }

    public Double getBaseRate() {
        return baseRate;
    }

    public void setBaseRate(Double baseRate) {
        this.baseRate = baseRate;
    }

    public Double getRatePerMile() {
        return ratePerMile;
    }

    public void setRatePerMile(Double ratePerMile) {
        this.ratePerMile = ratePerMile;
    }

  

    

    public String getCurrencySymbol() {
        return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }
      
      
}
