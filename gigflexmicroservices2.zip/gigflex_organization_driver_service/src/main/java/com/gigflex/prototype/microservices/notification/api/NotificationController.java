package com.gigflex.prototype.microservices.notification.api;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.notification.dtob.NotificationUpdate;
import com.gigflex.prototype.microservices.notification.service.NotificationService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class NotificationController {

	@Autowired
	public NotificationService notificationService;

	@PutMapping("/updateNotification/{notificationCode}")
	public String updateNotification(@PathVariable String notificationCode,
			@RequestBody NotificationUpdate notificationReq, HttpServletRequest request) {

		String ip = request.getRemoteAddr();

		return notificationService.updateNotificationByNotificationCode(notificationReq, notificationCode, ip);

	}

	@GetMapping("/getAllNotificationByUserCodeWithReadByPage/{userCode}")
	public String getAllNotificationByUserCodeWithReadByPage(@PathVariable("userCode") String userCode,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		if (userCode != null && userCode.trim().length() > 0) {

			String notification = notificationService.getAllNotificationByUserCodeWithRead(userCode.trim(), page, limit);

			return notification;
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "User Code should not be blank.");
			return derr.toString();
		}
	}

	@GetMapping("/getAllNotificationByUserCodeWithRead/{userCode}")
	public String getAllNotificationByUserCodeWithRead(@PathVariable("userCode") String userCode) {
		if (userCode != null && userCode.trim().length() > 0) {

			return notificationService.getAllNotificationByUserCodeWithRead(userCode.trim());
			
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "User Code should not be blank.");
			return derr.toString();
		}
	}
	
	@GetMapping("/getAllNotificationByUserCodeWithUnReadByPage/{userCode}")
	public String getAllNotificationByUserCodeWithUnReadByPage(@PathVariable("userCode") String userCode,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		if (userCode != null && userCode.trim().length() > 0) {

			String notification = notificationService.getAllNotificationByUserCodeWithUnRead(userCode.trim(), page, limit);

			return notification;
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "User Code should not be blank.");
			return derr.toString();
		}
	}

	@GetMapping("/getAllNotificationByUserCodeWithUnRead/{userCode}")
	public String getAllNotificationByUserCodeWithUnRead(@PathVariable("userCode") String userCode) {
		if (userCode != null && userCode.trim().length() > 0) {

			return notificationService.getAllNotificationByUserCodeWithUnRead(userCode.trim());
			
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "User Code should not be blank.");
			return derr.toString();
		}
	}

}
