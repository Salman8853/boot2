/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.drivertimeoff.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBooking;
import com.gigflex.prototype.microservices.assignbooking.repository.AssignBookingRepository;
import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.booking.notification.SendNotification;
import com.gigflex.prototype.microservices.booking.repository.BookingDao;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.drivertimeoff.dtob.DriverTimeOff;
import com.gigflex.prototype.microservices.drivertimeoff.dtob.DriverTimeOffModel;
import com.gigflex.prototype.microservices.drivertimeoff.repository.DriverTimeOffDao;
import com.gigflex.prototype.microservices.drivertimeoff.service.DriverTimeOffService;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.utility.GigflexDateUtil;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */
@Service
public class DriverTimeOffServiceImpl implements DriverTimeOffService{
    
    
    private static final Logger LOG = LoggerFactory.getLogger(DriverTimeOffServiceImpl.class);
   
    
    @Autowired
    private DriverTimeOffDao driverTimeOffDao;
    
    @Autowired
    OrganizationRepository organizationRepository;
    
    @Autowired
    private DriverRepository driverRepository;
    
    @Autowired
    GlobalSettingRepository globalSettingRepository;
    @Autowired
    LocalSettingRepository localSettingRepository;
    @Autowired
    UserTypeRepository utr;
    
    @Autowired
    TimeZoneRepository timeZoneRepository;
    
    @Autowired
    BookingDao bookingDao;

    @Autowired
    AssignBookingRepository   assignBookingDao;
    
    @Autowired
    OperatorRepository operatorDao;
    
    
    @Value("${email.service.url}")
    private String mailServiceURL ;
    //"http://18.223.158.6:8091/superadminservice/sendEmail/to/{to}/subject/{subject}/body/{body}";
    
    @Value("${email.newtimeoffrequest.needtoreassignride.subject}")
    private String subject;

    @Override
    public String findAllDriverTimeOff() {
       
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<DriverTimeOff> driverTimeOffList = driverTimeOffDao.getAllDriverTimeOff();
                        List<DriverTimeOffModel> driverTimeOffModelList = new ArrayList<DriverTimeOffModel>();
                        
                        
                        String dtFormat=GigflexConstants.YYYY_MM_DD;
                        String timeformat = GigflexConstants.HH_MM_SS;
                        
                        if(driverTimeOffList != null && driverTimeOffList.size() > 0)
                        {
                            for(int i =0;i<driverTimeOffList.size();i++)
                            {
                               DriverTimeOff driverTimeOff =driverTimeOffList.get(i) ;
                               
                               
                               String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.userTypeDriver, driverTimeOff.getDriverCode(), GigflexConstants.DATEFORMAT);
                               timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.userTypeDriver, driverTimeOff.getDriverCode(), GigflexConstants.TIMEFORMAT);
                               if(dateformat!=null && dateformat.trim().length()>0 )
                               {
                                    dtFormat=dateformat.trim();
                               }
                               else
                               {
                                   dtFormat=GigflexConstants.YYYY_MM_DD;
                                   
                               }
                               
                               if(timeformat!=null && timeformat.trim().length()>0)
                               {
                                    timeformat=timeformat.trim();
                               }
                               else
                               {
                                   timeformat = GigflexConstants.HH_MM_SS;
                                   
                               }
                               
                               
                               DriverTimeOffModel driverTimeOffModel = new DriverTimeOffModel();

                               driverTimeOffModel.setId(driverTimeOff.getId()); 
                               driverTimeOffModel.setDriverTimeoffCode(driverTimeOff.getDriverTimeoffCode()); 
                               driverTimeOffModel.setOrganizationCode(driverTimeOff.getOrganizationCode());                            
                               Organization oroganization = organizationRepository.findByOrganizationCode(driverTimeOff.getOrganizationCode().trim());
                               if(oroganization != null)
                               {
                                   driverTimeOffModel.setOrganizationName(oroganization.getOrganizationName()); 
                               }
                               driverTimeOffModel.setDriverCode(driverTimeOff.getDriverCode()); 
                               Driver driver = driverRepository.getDriverByDriverCode(driverTimeOff.getDriverCode());
                               if(driver != null)
                               {
                                   driverTimeOffModel.setDriverName(driver.getName()); 
                               }                           
                               driverTimeOffModel.setCreatedBy(driverTimeOff.getCreatedBy());                            
                               driverTimeOffModel.setFromDate(GigflexDateUtil.convertDateToString(driverTimeOff.getFromDate(), dtFormat));
                               driverTimeOffModel.setToDate(GigflexDateUtil.convertDateToString(driverTimeOff.getToDate(), dtFormat));
                               
                               Date fromTime = GigflexDateUtil.convertStringToDate(driverTimeOff.getFromTime(), GigflexConstants.HH_MM_SS); 
                               if(fromTime != null )
                               {
                                   driverTimeOffModel.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
                               }
                               else
                               {
                                   driverTimeOffModel.setFromTime("");
                               }
                                 
                               
                               Date toTime = GigflexDateUtil.convertStringToDate(driverTimeOff.getToTime(), GigflexConstants.HH_MM_SS); 
                               
                               if(toTime != null)
                               {
                                   driverTimeOffModel.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
                               }
                               else
                               {
                                   driverTimeOffModel.setToTime("");
                               }                                                              
                               
                               driverTimeOffModel.setReason(driverTimeOff.getReason()); 


                               driverTimeOffModelList.add(driverTimeOffModel);
                            }

                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
			    jsonobj.put("message", "Record Not Found.");
			    jsonobj.put("timestamp", new Date());
                        }
                        
                        
			if (driverTimeOffModelList != null && driverTimeOffModelList.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(driverTimeOffModelList);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   java.util.logging.Logger.getLogger(DriverTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    }

    @Override
    public String findTimeOffByDriverCode(String drivercode) {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        if(drivercode != null && drivercode.trim().length() > 0)
                        {
                        
                            List<DriverTimeOff> driverTimeOffList = driverTimeOffDao.getTimeOffByDriverCode(drivercode);

                            List<DriverTimeOffModel> driverTimeOffModelList = new ArrayList<DriverTimeOffModel>();

                            if(driverTimeOffList != null && driverTimeOffList.size() > 0)
                            {

                                String dateformat = "";
                                String timezoneCode = "";
                                TimeZoneDetail tz = null;
                                String timezone = "";
                                String dtFormat=GigflexConstants.YYYY_MM_DD;
                                String timeformat = GigflexConstants.HH_MM_SS;

                                Driver driver = driverRepository.getDriverByDriverCode(drivercode);
                                String organizationCode = driver.getOrganizationCode();   


                                dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.userTypeDriver, drivercode, GigflexConstants.DATEFORMAT);
                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.userTypeDriver, drivercode, GigflexConstants.TIMEFORMAT);
                                if(dateformat!=null && dateformat.trim().length()>0 )
                                {
                                    dtFormat=dateformat.trim();
                                }                
                                
                                if(timeformat!=null && timeformat.trim().length()>0)
                               {
                                    timeformat=timeformat.trim();
                               }
                               else
                               {
                                   timeformat = GigflexConstants.HH_MM_SS;
                                   
                               }
                            
                            
                             for(int i =0;i<driverTimeOffList.size();i++)
                            {
                              DriverTimeOff driverTimeOff =driverTimeOffList.get(i) ;
                               
                               DriverTimeOffModel driverTimeOffModel = new DriverTimeOffModel();

                               driverTimeOffModel.setId(driverTimeOff.getId()); 
                               driverTimeOffModel.setDriverTimeoffCode(driverTimeOff.getDriverTimeoffCode()); 
                               driverTimeOffModel.setOrganizationCode(driverTimeOff.getOrganizationCode());                            
                               Organization oroganization = organizationRepository.findByOrganizationCode(driverTimeOff.getOrganizationCode().trim());
                               if(oroganization != null)
                               {
                                   driverTimeOffModel.setOrganizationName(oroganization.getOrganizationName()); 
                               }
                               driverTimeOffModel.setDriverCode(driverTimeOff.getDriverCode()); 
                               driver = driverRepository.getDriverByDriverCode(driverTimeOff.getDriverCode());
                               if(driver != null)
                               {
                                   driverTimeOffModel.setDriverName(driver.getName()); 
                               }                           
                               driverTimeOffModel.setCreatedBy(driverTimeOff.getCreatedBy());                            
                               driverTimeOffModel.setFromDate(GigflexDateUtil.convertDateToString(driverTimeOff.getFromDate(), dtFormat));
                               driverTimeOffModel.setToDate(GigflexDateUtil.convertDateToString(driverTimeOff.getToDate(), dtFormat));
                               
                               Date fromTime = GigflexDateUtil.convertStringToDate(driverTimeOff.getFromTime(), GigflexConstants.HH_MM_SS); 
                               if(fromTime != null )
                               {
                                   driverTimeOffModel.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
                               }
                               else
                               {
                                   driverTimeOffModel.setFromTime("");
                               }
                                 
                               
                               Date toTime = GigflexDateUtil.convertStringToDate(driverTimeOff.getToTime(), GigflexConstants.HH_MM_SS); 
                               
                               if(toTime != null)
                               {
                                   driverTimeOffModel.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
                               }
                               else
                               {
                                   driverTimeOffModel.setToTime("");
                               }                                                              
                               
                               driverTimeOffModel.setReason(driverTimeOff.getReason()); 


                               driverTimeOffModelList.add(driverTimeOffModel);
                            }
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
			    jsonobj.put("message", "Record Not Found.");
			    jsonobj.put("timestamp", new Date());
                        }
                        
			if (driverTimeOffModelList != null && driverTimeOffModelList.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(driverTimeOffModelList);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
                        
                        
                        }
                        else
                        {
                            
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Record Not Found.");
                            jsonobj.put("timestamp", new Date());
                            
                        }
                        
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   java.util.logging.Logger.getLogger(DriverTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
            }
		return res;
    }

    @Override
    public String findTimeOffByDriverCodeAndBetweenDates(String driverCode, String reqFromDate, String reqToDate) {
       String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        if(driverCode != null && driverCode.trim().length() > 0 
                                && reqFromDate != null && reqFromDate.trim().length() > 0 
                                && reqToDate != null && reqToDate.trim().length() > 0)
                        {
                              if(!GigflexDateUtil.isDate(reqFromDate.trim(), GigflexConstants.YYYY_MM_DD))
                            {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                             "Plz send From date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
                                             return derr.toString();
                            }

                            if(!GigflexDateUtil.isDate(reqToDate.trim(), GigflexConstants.YYYY_MM_DD))
                            {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                             "Plz send To date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
                                             return derr.toString();
                            }

                            Date fromdate = null;
                            Date toDate = null;

                            try {
                                fromdate = GigflexDateUtil.convertStringToDate(reqFromDate.trim(), GigflexConstants.YYYY_MM_DD);
                                toDate =   GigflexDateUtil.convertStringToDate(reqToDate.trim(), GigflexConstants.YYYY_MM_DD);
                            } catch (Exception ex) {
                                java.util.logging.Logger.getLogger(DriverTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);

                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                "Plz send date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
                                                return derr.toString();
                            }

                            if(fromdate.after(toDate)) 
                            {
                                 GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                "From date should be less than todate ");
                                                return derr.toString();
                            }
                            
                            
                            
                            List<DriverTimeOff> driverTimeOffList = driverTimeOffDao.getTimeOffByDriverCodeAndBetweenDate(driverCode,fromdate,toDate);

                            List<DriverTimeOffModel> driverTimeOffModelList = new ArrayList<DriverTimeOffModel>();

                            if(driverTimeOffList != null && driverTimeOffList.size() > 0)
                            {
                                
                                String dateformat = "";
                                String timezoneCode = "";
                                TimeZoneDetail tz = null;
                                String timezone = "";
                                String dtFormat=GigflexConstants.YYYY_MM_DD;
                                String timeformat = GigflexConstants.HH_MM_SS;

                                Driver driver = driverRepository.getDriverByDriverCode(driverCode);
                                String organizationCode = driver.getOrganizationCode();   


                                dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.DATEFORMAT);
                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TIMEFORMAT);
                                if(dateformat!=null && dateformat.trim().length()>0 )
                                {
                                    dtFormat=dateformat.trim();
                                }                

                                if(timeformat!=null && timeformat.trim().length()>0)
                               {
                                    timeformat=timeformat.trim();
                               }
                               else
                               {
                                   timeformat = GigflexConstants.HH_MM_SS;

                               }
                                
                                
                                 for(int i =0;i<driverTimeOffList.size();i++)
                                {
                                   DriverTimeOff driverTimeOff = driverTimeOffList.get(i) ;
                                   DriverTimeOffModel driverTimeOffModel = new DriverTimeOffModel();

                                   driverTimeOffModel.setId(driverTimeOff.getId()); 
                                   driverTimeOffModel.setDriverTimeoffCode(driverTimeOff.getDriverTimeoffCode()); 
                                   driverTimeOffModel.setOrganizationCode(driverTimeOff.getOrganizationCode());                            
                                   Organization oroganization = organizationRepository.findByOrganizationCode(driverTimeOff.getOrganizationCode());
                                   if(oroganization != null)
                                   {
                                       driverTimeOffModel.setOrganizationName(oroganization.getOrganizationName()); 
                                   }

                                   driverTimeOffModel.setDriverCode(driverTimeOff.getDriverCode());                                                      
                                   driver = driverRepository.getDriverByDriverCode(driverTimeOff.getDriverCode()); 
                                    if(driver != null)
                                   {
                                       driverTimeOffModel.setDriverName(driver.getName()); 
                                   }                    

                                   driverTimeOffModel.setCreatedBy(driverTimeOff.getCreatedBy());                            
                                   driverTimeOffModel.setFromDate(GigflexDateUtil.convertDateToString(driverTimeOff.getFromDate(), dtFormat));
                                   driverTimeOffModel.setToDate(GigflexDateUtil.convertDateToString(driverTimeOff.getToDate(), dtFormat));
                                   driverTimeOffModel.setFromDateTimestamp(driverTimeOff.getFromDate());
                                   driverTimeOffModel.setToDateTimestamp(driverTimeOff.getToDate());
                                   driverTimeOffModel.setFromTime(driverTimeOff.getFromTime());
                                   driverTimeOffModel.setToTime(driverTimeOff.getToTime());
                                   driverTimeOffModel.setReason(driverTimeOff.getReason());

                                   driverTimeOffModelList.add(driverTimeOffModel);
                                }
                            }
                            else
                            {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("message", "Record Not Found.");
                                jsonobj.put("timestamp", new Date());
                            }

                            if (driverTimeOffModelList != null && driverTimeOffModelList.size() > 0) {
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("message", "Success");
                                    jsonobj.put("timestamp", new Date());
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(driverTimeOffModelList);
                                    jsonobj.put("data", new JSONArray(Detail));
                            } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("message", "Record Not Found.");
                                    jsonobj.put("timestamp", new Date());
                            }
                        }
                        else
                        {
                            
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Record Not Found.");
                            jsonobj.put("timestamp", new Date());
                            
                        }
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   java.util.logging.Logger.getLogger(DriverTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
            }
		return res;
    }

    @Override
    public String findDriverTimeOffByTimeOffCode(String timeOffcode) {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        String dtFormat=GigflexConstants.YYYY_MM_DD;
                        String timeformat = GigflexConstants.HH_MM_SS;
			DriverTimeOff driverTimeOff = driverTimeOffDao.getDriverTimeOffByTimeOffCode(timeOffcode);
                        DriverTimeOffModel driverTimeOffModel = new DriverTimeOffModel();
                        
                        if(driverTimeOff != null )
                        {                       

                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.Organizations, driverTimeOff.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.Organizations, driverTimeOff.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                if(dateformat!=null && dateformat.trim().length()>0 )
                                {
                                     dtFormat=dateformat.trim();
                                }
                                else
                                {
                                    dtFormat=GigflexConstants.YYYY_MM_DD;

                                }

                                if(timeformat!=null && timeformat.trim().length()>0)
                                {
                                     timeformat=timeformat.trim();
                                }
                                else
                                {
                                    timeformat = GigflexConstants.HH_MM_SS;

                                }     
                            
                               driverTimeOffModel.setId(driverTimeOff.getId()); 
                               driverTimeOffModel.setDriverTimeoffCode(driverTimeOff.getDriverTimeoffCode()); 
                               driverTimeOffModel.setOrganizationCode(driverTimeOff.getOrganizationCode());                            
                               Organization oroganization = organizationRepository.findByOrganizationCode(driverTimeOff.getOrganizationCode());
                                if(oroganization != null)
                               {
                                   driverTimeOffModel.setOrganizationName(oroganization.getOrganizationName()); 
                               }                         
                               driverTimeOffModel.setDriverCode(driverTimeOff.getDriverCode());                                                      
                               Driver driver = driverRepository.getDriverByDriverCode(driverTimeOff.getDriverCode());
                               if(driver != null)
                               {
                                   driverTimeOffModel.setDriverName(driver.getName()); 
                               }       
                               driverTimeOffModel.setCreatedBy(driverTimeOff.getCreatedBy());                            
                               driverTimeOffModel.setFromDate(GigflexDateUtil.convertDateToString(driverTimeOff.getFromDate(), dtFormat));
                               driverTimeOffModel.setToDate(GigflexDateUtil.convertDateToString(driverTimeOff.getToDate(), dtFormat));
                             
                               Date fromTime = GigflexDateUtil.convertStringToDate(driverTimeOff.getFromTime(), GigflexConstants.HH_MM_SS); 
                               if(fromTime != null)
                               {
                                   driverTimeOffModel.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
                               }
                               else
                               {
                                   driverTimeOffModel.setFromTime("");
                               }
                                 
                               
                               Date toTime = GigflexDateUtil.convertStringToDate(driverTimeOff.getToTime(), GigflexConstants.HH_MM_SS); 
                               
                               if(toTime != null)
                               {
                                   driverTimeOffModel.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
                               }
                               else
                               {
                                   driverTimeOffModel.setToTime("");
                               }                               
                              
                               driverTimeOffModel.setReason(driverTimeOff.getReason());                            
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
			    jsonobj.put("message", "Record Not Found.");
			    jsonobj.put("timestamp", new Date());
                        }
                        
                        
                        
			if (driverTimeOffModel != null && driverTimeOffModel.toString().trim().length() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(driverTimeOffModel);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                 java.util.logging.Logger.getLogger(DriverTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                 GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
                 
        }
		return res;
    }

    @Override
    public String findDriverTimeOffByOrganizationCode(String organizationcode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        String dtFormat=GigflexConstants.YYYY_MM_DD;
                        String timeformat = GigflexConstants.HH_MM_SS;
			List<DriverTimeOff> driverTimeOffList = driverTimeOffDao.getTimeOffByOrganizationCode(organizationcode);

                        List<DriverTimeOffModel> driverTimeOffModelList = new ArrayList<DriverTimeOffModel>();
                        
                        if(driverTimeOffList != null && driverTimeOffList.size() > 0)
                        {
                             for(int i =0;i<driverTimeOffList.size();i++)
                            {
                               DriverTimeOff driverTimeOff = driverTimeOffList.get(i) ;
                               
                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.userTypeOrganization, driverTimeOff.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.userTypeOrganization, driverTimeOff.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                if(dateformat!=null && dateformat.trim().length()>0 )
                                {
                                     dtFormat=dateformat.trim();
                                }
                                else
                                {
                                    dtFormat=GigflexConstants.YYYY_MM_DD;

                                }

                                if(timeformat!=null && timeformat.trim().length()>0)
                                {
                                     timeformat=timeformat.trim();
                                }
                                else
                                {
                                    timeformat = GigflexConstants.HH_MM_SS;

                                }     
                               
                               DriverTimeOffModel driverTimeOffModel = new DriverTimeOffModel();

                               driverTimeOffModel.setId(driverTimeOff.getId()); 
                               driverTimeOffModel.setDriverTimeoffCode(driverTimeOff.getDriverTimeoffCode()); 
                               driverTimeOffModel.setOrganizationCode(driverTimeOff.getOrganizationCode());                            
                               Organization oroganization = organizationRepository.findByOrganizationCode(driverTimeOff.getOrganizationCode());
                                if(oroganization != null)
                               {
                                   driverTimeOffModel.setOrganizationName(oroganization.getOrganizationName()); 
                               }                         
                               driverTimeOffModel.setDriverCode(driverTimeOff.getDriverCode());                                                      
                               Driver driver = driverRepository.getDriverByDriverCode(driverTimeOff.getDriverCode());
                               if(driver != null)
                               {
                                   driverTimeOffModel.setDriverName(driver.getName()); 
                               }       
                               driverTimeOffModel.setCreatedBy(driverTimeOff.getCreatedBy());                            
                               driverTimeOffModel.setFromDate(GigflexDateUtil.convertDateToString(driverTimeOff.getFromDate(), dtFormat));
                               driverTimeOffModel.setToDate(GigflexDateUtil.convertDateToString(driverTimeOff.getToDate(), dtFormat));
                              
                              Date fromTime = GigflexDateUtil.convertStringToDate(driverTimeOff.getFromTime(), GigflexConstants.HH_MM_SS); 
                               if(fromTime != null)
                               {
                                   driverTimeOffModel.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
                               }
                               else
                               {
                                   driverTimeOffModel.setFromTime("");
                               }
                                 
                               
                               Date toTime = GigflexDateUtil.convertStringToDate(driverTimeOff.getToTime(), GigflexConstants.HH_MM_SS); 
                               
                               if(toTime != null)
                               {
                                   driverTimeOffModel.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
                               }
                               else
                               {
                                   driverTimeOffModel.setToTime("");
                               }                               
                               
                               driverTimeOffModel.setReason(driverTimeOff.getReason());
                               driverTimeOffModelList.add(driverTimeOffModel);
                            }
                        }
                        else
                        {
                            jsonobj.put("responsecode", 400);
			    jsonobj.put("message", "Record Not Found.");
			    jsonobj.put("timestamp", new Date());
                        }
                        
                        
                        
			if (driverTimeOffModelList != null && driverTimeOffModelList.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(driverTimeOffModelList);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                 java.util.logging.Logger.getLogger(DriverTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                 GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
                 
        }
		return res;
    }

    @Override
    public String saveDriverTimeOff(DriverTimeOffModel driverTimeOffReq, String ip) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (driverTimeOffReq != null) {
                                                        
                            
			if (driverTimeOffReq.getDriverCode()!=null && driverTimeOffReq.getDriverCode().trim().length() > 0
                                && driverTimeOffReq.getFromDate() != null &&  driverTimeOffReq.getFromDate().trim().length() > 0 
                                && driverTimeOffReq.getToDate() != null && driverTimeOffReq.getToDate().trim().length() >0
                                && driverTimeOffReq.getOrganizationCode() != null && driverTimeOffReq.getOrganizationCode().trim().length() >0) {
                                       
                            
                            if(!GigflexDateUtil.isDate(driverTimeOffReq.getFromDate().trim(), GigflexConstants.YYYY_MM_DD))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send From date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
						return derr.toString();
                               }
                               
                               if(!GigflexDateUtil.isDate(driverTimeOffReq.getToDate().trim(), GigflexConstants.YYYY_MM_DD))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send To date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
						return derr.toString();
                               }
                            
                             Date fromdate = null;
                             Date toDate = null;
                                                             
                                fromdate = GigflexDateUtil.convertStringToDate(driverTimeOffReq.getFromDate().trim(), GigflexConstants.YYYY_MM_DD);
                                toDate =   GigflexDateUtil.convertStringToDate(driverTimeOffReq.getToDate().trim(), GigflexConstants.YYYY_MM_DD);
                                
                                if(fromdate == null  ||  toDate == null)
                                {
                                    //java.util.logging.Logger.getLogger(WorkerTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                                
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
						return derr.toString();
                                }
                                
                                
                               if(driverTimeOffReq.getFromTime().trim().length() > 0)
                               {
                                   String strFromTime = driverTimeOffReq.getFromTime();
                                   
                                   Date fromTime = GigflexDateUtil.convertStringToDate(strFromTime, GigflexConstants.HH_MM_SS); 
                                   if(fromTime == null)
                                   {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send from time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                                   }
                               }
                                
                               
                                                             
                               if(driverTimeOffReq.getToTime().trim().length() > 0)
                               {
                                   String strToTime = driverTimeOffReq.getToTime();
                                   
                                   Date toTime = GigflexDateUtil.convertStringToDate(strToTime, GigflexConstants.HH_MM_SS); 
                                   if(toTime == null)
                                   {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send to time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                                   }
                               }
                                

                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.Organizations, driverTimeOffReq.getOrganizationCode(), GigflexConstants.TimeZone);

                            TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);

                            String strFromTimeOffdate = driverTimeOffReq.getFromDate().trim()+" "+driverTimeOffReq.getFromTime().trim();
                            Date fromTimeOffdate= null;
                            if (tz != null && tz.getId() > 0) {

                               fromTimeOffdate=GigflexDateUtil.convertStringDateToGMT(strFromTimeOffdate, tz.getTimeZoneName(),GigflexConstants.dateFormatterForSave);

                           }   

                            if (fromTimeOffdate == null) {
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "Date conversion has been failed.");
                                    return derr.toString();
                            }   
                               
                            String strToTimeOffdate = driverTimeOffReq.getToDate()+" "+driverTimeOffReq.getToTime();
                            Date toTimeOffDate= null;
                            if (tz != null && tz.getId() > 0) {

                               toTimeOffDate=GigflexDateUtil.convertStringDateToGMT(strToTimeOffdate, tz.getTimeZoneName(),GigflexConstants.dateFormatterForSave);

                           }   

                            if (toTimeOffDate == null) {
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "Date conversion has been failed.");
                                    return derr.toString();
                            }     
                               
                            
                            Calendar calCurTime = Calendar.getInstance();
                            Date curFromTime = calCurTime.getTime();
                                                        
                            calCurTime.add(Calendar.HOUR_OF_DAY, 2);                           
                            Date curToTime = calCurTime.getTime();

                            
                            if( (curFromTime.before(fromTimeOffdate) || curFromTime.equals(fromTimeOffdate)) && curToTime.after(fromTimeOffdate)  ) 
                            {
                                
                                List<Booking> bookingList = bookingDao.getAssignedBookingListByDriverCodeAndBetweenCurrntTime(driverTimeOffReq.getDriverCode() ,curFromTime,curToTime,GigflexConstants.bookingStatus, GigflexConstants.assignedBookingAcceptedStatus,GigflexConstants.assignedBookingInProgressStatus);
                                
                                if(bookingList != null && bookingList.size() > 0)
                                {
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "Time Off is not allowed for given time off period.");
                                    return derr.toString();
                                }
                            }
                            
                            
                            DriverTimeOff driverTimeOff = new DriverTimeOff();

                            driverTimeOff.setIpAddress(ip);
                            driverTimeOff.setOrganizationCode(driverTimeOffReq.getOrganizationCode());
                            driverTimeOff.setDriverCode(driverTimeOffReq.getDriverCode()); 
                            driverTimeOff.setCreatedBy(driverTimeOffReq.getCreatedBy());
                            driverTimeOff.setFromDate(fromdate);
                            driverTimeOff.setToDate(toDate);
                            driverTimeOff.setFromTime(driverTimeOffReq.getFromTime());
                            driverTimeOff.setToTime(driverTimeOffReq.getToTime());                            
                            driverTimeOff.setReason(driverTimeOffReq.getReason());
                            driverTimeOff.setFromTimeOffDate(fromTimeOffdate);
                            driverTimeOff.setToTimeOffDate(toTimeOffDate); 

                            DriverTimeOff workerTimeOffRes = driverTimeOffDao.save(driverTimeOff);

                            

                            if (workerTimeOffRes != null && workerTimeOffRes.getId() > 0) {
                                
                                    List<Booking> bookingList = bookingDao.getAssignedBookingListByDriverCodeAndBetweenTimeOffDates(workerTimeOffRes.getDriverCode() , driverTimeOff.getFromTimeOffDate(), driverTimeOff.getToTimeOffDate(),GigflexConstants.bookingStatus, GigflexConstants.assignedBookingAcceptedStatus);
                                    if(bookingList != null && bookingList.size() > 0)
                                    {
                                        for(Booking booking : bookingList)
                                        {
                                            String rideCode = booking.getRideCode();
                                            
                                            Booking bookingRes = bookingDao.getBookingByRideCode(rideCode);
                                            AssignBooking assignBookingRes = assignBookingDao.getAssignBookingByRideCode(rideCode);
                                            if(bookingRes != null && bookingRes.getId() > 0 && assignBookingRes != null && assignBookingRes.getId() > 0)
                                            {
                                                String bookingOperatorCode = bookingRes.getOperatorCode();
                                                
                                                bookingRes.setBookingStatus(GigflexConstants.assignedBookingStatus); 
                                                Booking bookingSaveRes = bookingDao.save(bookingRes);
                                                
                                                String assignBookingOperatorCode = assignBookingRes.getOperatorCode();
                                                assignBookingRes.setStatus(GigflexConstants.assignedBookingStatus); 
                                                assignBookingRes.setDriverCode(null);  
                                                AssignBooking assignBookingSaveRes = assignBookingDao.save(assignBookingRes); 
                                                
                                                String email = "";
                                                if(bookingOperatorCode.equals(assignBookingOperatorCode))
                                                {
                                                  Operator operatorRs =  operatorDao.getOperatorByOperatorCode(bookingOperatorCode);
                                                  if(operatorRs != null && operatorRs.getId()> 0 )
                                                  {
                                                      email = operatorRs.getEmailId();
                                                  }
                                                  
                                                }
                                                else
                                                {
                                                    Operator operatorBookingRs =  operatorDao.getOperatorByOperatorCode(bookingOperatorCode);
                                                    Operator operatorAssignBookingRs =  operatorDao.getOperatorByOperatorCode(assignBookingOperatorCode);
                                                    
                                                    if(operatorBookingRs != null )
                                                    {
                                                        email=operatorBookingRs.getEmailId();
                                                    }
                                                    
                                                    
                                                    if(operatorAssignBookingRs != null )
                                                    {
                                                        if(email.trim().length() > 0)
                                                        {
                                                            email=email+","+operatorAssignBookingRs.getEmailId();
                                                        }
                                                        else
                                                        {
                                                            email=operatorAssignBookingRs.getEmailId();
                                                        }                                                        
                                                    }
                                                    
                                                    
                                                }
                                                
                                                //code for email
                                                
                                                 String bodyContent = "For booking id : "+bookingRes.getBookingid()+" driver is going for time off so booking status for assigned/accepted  booking is reset as pending. Please reassign this booking.<br>";
                                                 SendNotification sn = new SendNotification();
                                                  
                                                 if (email != null && email.length() > 0) {
                                                    String response=  sn.sendMail(email, subject, bodyContent, mailServiceURL);

                                                    LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                                                  } 
                                            }
                                        }
                                    }
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message",
                                                    "Driver Time Off has been added successfully.");
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(workerTimeOffRes);
                                    jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                
                                    jsonobj.put("responsecode", 400);
                                    jsonobj.put("timestamp", new Date());                                
                                    jsonobj.put("message", "Failed");
                            }
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Driver Code,From Date , To Date & organization code should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
        
    }
    
    @Override
    public String updateDriverTimeOffByTimeOffcode(String timeOffCode, DriverTimeOffModel driverTimeOffReq, String ip) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if ( timeOffCode != null && timeOffCode.trim().length() > 0 && driverTimeOffReq != null) {
                            
				if (driverTimeOffReq.getDriverCode()!=null && driverTimeOffReq.getDriverCode().trim().length() > 0
                                && driverTimeOffReq.getFromDate() != null &&  driverTimeOffReq.getFromDate().trim().length() > 0 
                                && driverTimeOffReq.getToDate() != null && driverTimeOffReq.getToDate().trim().length() >0 
                                && driverTimeOffReq.getOrganizationCode() != null && driverTimeOffReq.getOrganizationCode().trim().length() >0) {
                               if(!GigflexDateUtil.isDate(driverTimeOffReq.getFromDate().trim(), GigflexConstants.YYYY_MM_DD))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send From date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
						return derr.toString();
                               }
                               
                               if(!GigflexDateUtil.isDate(driverTimeOffReq.getToDate().trim(), GigflexConstants.YYYY_MM_DD))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send To date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
						return derr.toString();
                               }
                              
                                  Date fromdate = null;
                                  Date toDate = null;
                             
                                  fromdate = GigflexDateUtil.convertStringToDate(driverTimeOffReq.getFromDate().trim(), GigflexConstants.YYYY_MM_DD);
                                  toDate =   GigflexDateUtil.convertStringToDate(driverTimeOffReq.getToDate().trim(), GigflexConstants.YYYY_MM_DD);
                                
                                  if(fromdate == null  ||  toDate == null)
                                  {
                                        //java.util.logging.Logger.getLogger(WorkerTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);

                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                    "Plz send date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
                                                    return derr.toString();
                                  }
                                    
                                if(driverTimeOffReq.getFromTime().trim().length() > 0)
                                {
                                      String strFromTime = driverTimeOffReq.getFromTime();

                                      Date fromTime = GigflexDateUtil.convertStringToDate(strFromTime, GigflexConstants.HH_MM_SS); 
                                      if(fromTime == null)
                                      {
                                           GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                   "Plz send from time in correct format("+GigflexConstants.HH_MM_SS+") ");
                                                   return derr.toString();
                                      }
                                }
                            
                                if(driverTimeOffReq.getToTime().trim().length() > 0)
                                   {
                                       String strToTime = driverTimeOffReq.getToTime();

                                       Date toTime = GigflexDateUtil.convertStringToDate(strToTime, GigflexConstants.HH_MM_SS); 
                                       if(toTime == null)
                                       {
                                            GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                    "Plz send to time in correct format("+GigflexConstants.HH_MM_SS+") ");
                                                    return derr.toString();
                                       }
                                   }
                                
                                
                                        String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.Organizations, driverTimeOffReq.getOrganizationCode(), GigflexConstants.TimeZone);

                                        TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);

                                        String strFromTimeOffdate = driverTimeOffReq.getFromDate()+" "+driverTimeOffReq.getFromTime();
                                        Date fromTimeOffdate= null;
                                        if (tz != null && tz.getId() > 0) {

                                           fromTimeOffdate=GigflexDateUtil.convertStringDateToGMT(strFromTimeOffdate, tz.getTimeZoneName(),GigflexConstants.dateFormatterForSave);

                                        }   

                                        if (fromTimeOffdate == null) {
                                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                "Date conversion has been failed.");
                                                return derr.toString();
                                        }   

                                        String strToTimeOffdate = driverTimeOffReq.getToDate()+" "+driverTimeOffReq.getToTime();
                                        Date toTimeOffDate= null;
                                        if (tz != null && tz.getId() > 0) {

                                           toTimeOffDate=GigflexDateUtil.convertStringDateToGMT(strToTimeOffdate, tz.getTimeZoneName(),GigflexConstants.dateFormatterForSave);
                                       }   

                                        if (toTimeOffDate == null) {
                                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                "Date conversion has been failed.");
                                                return derr.toString();
                                        }     
                                    
                                        
                                        Calendar calCurTime = Calendar.getInstance();
                                        Date curFromTime = calCurTime.getTime();

                                        calCurTime.add(Calendar.HOUR_OF_DAY, 2);                           
                                        Date curToTime = calCurTime.getTime();


                                        if( (curFromTime.before(fromTimeOffdate) || curFromTime.equals(fromTimeOffdate)) && curToTime.after(fromTimeOffdate)  ) 
                                        {

                                            List<Booking> bookingList = bookingDao.getAssignedBookingListByDriverCodeAndBetweenCurrntTime(driverTimeOffReq.getDriverCode() ,curFromTime,curToTime,GigflexConstants.bookingStatus, GigflexConstants.assignedBookingAcceptedStatus,GigflexConstants.assignedBookingInProgressStatus);

                                            if(bookingList != null && bookingList.size() > 0)
                                            {
                                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                "Time Off updation is not allowed for given time off period.");
                                                return derr.toString();
                                            }
                                        }
                                        
                                        
					DriverTimeOff driverTimeOffInDb = driverTimeOffDao.getDriverTimeOffByTimeOffCode(timeOffCode); 
					if (driverTimeOffInDb != null && driverTimeOffInDb.getId() > 0) {
						
                                            driverTimeOffInDb.setFromDate(fromdate);
                                            driverTimeOffInDb.setToDate(toDate); 
                                            driverTimeOffInDb.setFromTime(driverTimeOffReq.getFromTime()); 
                                            driverTimeOffInDb.setToTime(driverTimeOffReq.getToTime());                                                ; 
                                            driverTimeOffInDb.setReason(driverTimeOffReq.getReason());
                                            driverTimeOffInDb.setOrganizationCode(driverTimeOffReq.getOrganizationCode()); 
                                            driverTimeOffInDb.setIpAddress(ip);
                                            driverTimeOffInDb.setFromTimeOffDate(fromTimeOffdate);
                                            driverTimeOffInDb.setToTimeOffDate(toTimeOffDate); 

                                            DriverTimeOff driverTimeOffRes = driverTimeOffDao.save(driverTimeOffInDb);
                                            if (driverTimeOffRes != null && driverTimeOffRes.getId() > 0) {
                                                    
                                            List<Booking> bookingList = bookingDao.getAssignedBookingListByDriverCodeAndBetweenTimeOffDates(driverTimeOffRes.getDriverCode() , driverTimeOffInDb.getFromTimeOffDate(), driverTimeOffInDb.getToTimeOffDate(),GigflexConstants.bookingStatus, GigflexConstants.assignedBookingAcceptedStatus);
                                            if(bookingList != null && bookingList.size() > 0)
                                            {
                                                for(Booking booking : bookingList)
                                                {
                                                    String rideCode = booking.getRideCode();

                                                    Booking bookingRes = bookingDao.getBookingByRideCode(rideCode);
                                                    AssignBooking assignBookingRes = assignBookingDao.getAssignBookingByRideCode(rideCode);
                                                    if(bookingRes != null && bookingRes.getId() > 0 && assignBookingRes != null && assignBookingRes.getId() > 0)
                                                    {
                                                        String bookingOperatorCode = bookingRes.getOperatorCode();

                                                        bookingRes.setBookingStatus(GigflexConstants.assignedBookingStatus); 
                                                        Booking bookingSaveRes = bookingDao.save(bookingRes);

                                                        String assignBookingOperatorCode = assignBookingRes.getOperatorCode();
                                                        assignBookingRes.setStatus(GigflexConstants.assignedBookingStatus); 
                                                        assignBookingRes.setDriverCode(null);  
                                                        AssignBooking assignBookingSaveRes = assignBookingDao.save(assignBookingRes); 

                                                        String email = "";
                                                        if(bookingOperatorCode.equals(assignBookingOperatorCode))
                                                        {
                                                          Operator operatorRs =  operatorDao.getOperatorByOperatorCode(bookingOperatorCode);
                                                          if(operatorRs != null && operatorRs.getId()> 0 )
                                                          {
                                                              email = operatorRs.getEmailId();
                                                          }

                                                        }
                                                        else
                                                        {
                                                            Operator operatorBookingRs =  operatorDao.getOperatorByOperatorCode(bookingOperatorCode);
                                                            Operator operatorAssignBookingRs =  operatorDao.getOperatorByOperatorCode(assignBookingOperatorCode);

                                                            if(operatorBookingRs != null )
                                                            {
                                                                email=operatorBookingRs.getEmailId();
                                                            }


                                                            if(operatorAssignBookingRs != null )
                                                            {
                                                                if(email.trim().length() > 0)
                                                                {
                                                                    email=email+","+operatorAssignBookingRs.getEmailId();
                                                                }
                                                                else
                                                                {
                                                                    email=operatorAssignBookingRs.getEmailId();
                                                                }                                                        
                                                            }
                                                        }
                                                        //code for email
                                                         String bodyContent = "For booking id : "+bookingRes.getBookingid()+" driver is going for time off so booking status for assigned/accepted  booking is reset as pending. Please reassign this booking.<br>";
                                                         SendNotification sn = new SendNotification();

                                                         if (email != null && email.length() > 0) { 
                                                            String response=  sn.sendMail(email, subject, bodyContent, mailServiceURL);

                                                            LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                                                          } 
                                                        }
                                                    }
                                                }
                                                                                                        
                                                jsonobj.put("responsecode", 200);
                                                jsonobj.put("message",
                                                                "Driver Time Off updation has been done");
                                                jsonobj.put("timestamp", new Date());
                                                ObjectMapper mapperObj = new ObjectMapper();
                                                String Detail = mapperObj
                                                                .writeValueAsString(driverTimeOffRes); 
                                                jsonobj.put("data", new JSONObject(Detail));
                                            } else {
                                                    jsonobj.put("responsecode", 400);
                                                    jsonobj.put("message",
                                                                    "Driver Time Off updation has been failed.");
                                                    jsonobj.put("timestamp", new Date());
                                            }
                                    } else {
                                            jsonobj.put("responsecode", 404);
                                            jsonobj.put("message", "Driver Time Off ID is not valid.");
                                            jsonobj.put("timestamp", new Date());
                                    }
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Driver Code,From Date , To Date & organization code  should not be blank");

				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }
    
    @Override
    public String cancelDriverTimeOffBytimeOffCode(String timeOffCode, String reason) {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			DriverTimeOff driverTimeOffInDb = driverTimeOffDao.getDriverTimeOffByTimeOffCode(timeOffCode); 
			if (driverTimeOffInDb != null && driverTimeOffInDb.getId() > 0) {

                                driverTimeOffInDb.setIsDeleted(true);
                                driverTimeOffInDb.setCancelReason(reason); 
                                DriverTimeOff driverTimeOffRes = driverTimeOffDao.save(driverTimeOffInDb);
                                if (driverTimeOffRes != null && driverTimeOffRes.getId() > 0) {
                                        jsonobj.put("responsecode", 200);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message",
                                                        "Driver Time Off cancelled successfully.");
                                        // kafkaService.
                                } else {
                                        jsonobj.put("responsecode", 400);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Failed");
                                }
                        }

			else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
                    GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
                    res = derr.toString();
                    ex.printStackTrace();
                 LOG.error("Error in cancelTimeOffBytimeOffCode>>>>>>", ex);
                }catch(org.springframework.orm.jpa.JpaSystemException ex)
                {
                    GigflexResponse derr = new GigflexResponse(401, new Date(), GigUtil.getRootException(ex));
                    res = derr.toString();
                    ex.printStackTrace();
		} catch (Exception ex) {
		 ex.printStackTrace();
                  LOG.error("Error in cancelTimeOffBytimeOffCode>>>>>>", ex);	
                    GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String cancelMultipleDriverTimeOffBytimeOffCode(List<String> timeOffCodeList, String reason) {
       
         String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String timeOffCode : timeOffCodeList) {
				if (timeOffCode != null && timeOffCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					timeOffCode = timeOffCode.trim();

					DriverTimeOff driverTimeOffInDb = driverTimeOffDao.getDriverTimeOffByTimeOffCode(timeOffCode); 

					if (driverTimeOffInDb != null && driverTimeOffInDb.getId() > 0) {
						
						try{
							driverTimeOffInDb.setIsDeleted(true);
                                                        driverTimeOffInDb.setCancelReason(reason); 
							DriverTimeOff driverTimeOffRes = driverTimeOffDao.save(driverTimeOffInDb);
							if (driverTimeOffRes != null && driverTimeOffRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", timeOffCode);
								jsonobj.put("message",
										"Driver Time Off cancelled successfully.");
								// kafkaService.sendUseronUpdate(usersDataRes);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", timeOffCode);
								jsonobj.put("message", "Failed");
							}
						}catch(org.springframework.orm.jpa.JpaSystemException ex){
							jsonobj.put("responsecode", 500);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", timeOffCode);
							jsonobj.put("message",  GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", timeOffCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple cancel failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
    }

    

    
    
    
    
    
}
