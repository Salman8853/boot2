/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.operator.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.ridetype.repository.RideTypeRepository;

/**
 *
 * @author Abhishek
 */
@Service
public class KafkaOperatorService {
	private Operator operator;

	@Autowired
	OperatorRepository operatorRepository;

	@Autowired
	RideTypeRepository rideTypeDao;

	
        
	private static final Logger LOG = LoggerFactory.getLogger(KafkaOperatorService.class);

	@KafkaListener(topics = "AddNewOperator")
	public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			Operator operatorDetail = objectMapper.readValue(message, Operator.class);
			LOG.info("received message for AddNewOperator='{}'", operatorDetail.getOperatorName());
			LOG.info("received message for AddNewOperator='{}'", operatorDetail.getOperatorCode());
			LOG.info("received message for AddNewOperator='{}'", operatorDetail.getEmailId());
			LOG.info("received message for AddNewOperator='{}'", operatorDetail.getOrganizationCode());
			operator = new Operator();
			operator.setOperatorCode(operatorDetail.getOperatorCode());
			operator.setOperatorName(operatorDetail.getOperatorName());
			operator.setEmailId(operatorDetail.getEmailId());
			operator.setOrganizationCode(operatorDetail.getOrganizationCode());
			operator.setIsDeleted(operatorDetail.getIsDeleted());
                        operator.setContactNumber(operatorDetail.getContactNumber());
                        operator.setCountryCode(operatorDetail.getCountryCode());
			 
			Operator operatorRes = operatorRepository.save(operator);
                        
//                        if(operatorRes != null && operatorRes.getId() > 0)
//                        {
//                            UserType userype = userTypeRepository.getUserTypeByUserTypeName(GigflexConstants.USER_TYPE_SUPER_ADMIN);
//                            if(userype != null && userype.getId() > 0)
//                            {
//                                String userTypeCode = userype.getUserTypeCode();
//                                
//                                GlobalSetting globalSetting = globalSettingDao.getGlobalSettingByUserTypeSettingName(userTypeCode, GigflexConstants.SETTING_NAME_CREDIT_AMOUNT);
//                              
//                                if(globalSetting != null && globalSetting.getId() > 0)
//                                {
//                                    try
//                                    {
//                                        double creditAmount = Double.parseDouble(globalSetting.getSettingValue()); 
//                                        
//                                        OrganizationCreditTransaction oc= new OrganizationCreditTransaction();
//                                        oc.setBalanceAmount(creditAmount);
//                                        oc.setBookingid(null); 
//                                        oc.setOperatorCode(operatorRes.getOperatorCode()); 
//                                        oc.setTransactionBy(GigflexConstants.USER_TYPE_SUPER_ADMIN); 
//                                        oc.setCreditAmount(creditAmount); 
//                                        
//                                        OrganizationCreditTransaction operatorCreditTransactionRes = operatorCreditTransactionDao.save(oc);
//                                    
//                                    }
//                                    catch(Exception e)
//                                    {
//                                        e.printStackTrace();
//                                    }                                    
//                                }
//                            }
//                        }
			
//			if (operatorRes != null && operatorRes.getId() > 0) {
//
//				List<GlobalRideType> globalRideTypelst = globalRideTypeDao.getAllGlobalRideType();
//
//				for (GlobalRideType grt : globalRideTypelst) {
//					
//
//					RideType rt = rideTypeDao.getRideTypeByVehicleNameAndOrganizationCode(grt.getVehicleName(),
//							operator.getOrganizationCode());
//
//					if (rt != null && rt.getId() > 0) {
//						LOG.info("received message for record already exists='{}'", grt.getVehicleName(),
//								operator.getOrganizationCode());
//
//					} else {
//						RideType rideType = new RideType();
//						rideType.setBaseRate(grt.getBaseRate());
//						rideType.setRatePerMile(grt.getRatePerMile());
//						rideType.setVehicleName(grt.getVehicleName());
//						rideType.setOrganizationCode(operator.getOrganizationCode());
//						rideType.setIsGlobal(true);
//
//						rideTypeDao.save(rideType);
//
//					}
//
//				}
//			}
		} catch (JsonParseException e) {
			LOG.error("In KafkaDriverService for AddNewOperator >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaDriverService for AddNewOperator >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaDriverService for AddNewOperator >>>>", e);
		} catch (Exception e) {
			LOG.error("In KafkaDriverService for AddNewOperator >>>>", e);
		}
	}

}
