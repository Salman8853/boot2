/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.booking.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "additional_charges")
public class AdditionalCharges  extends CommonAttributes{
        @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	 private Long id;
        @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
        @Column(name = "additionalchargecode", nullable = false,unique = true)
        private String additionalChargeCode;
       
	@Column(name = "ride_code",nullable = false)
	private String rideCode;
       
        @Column(name = "additionalfareypecode", nullable = false)
        private String additionalFareypeCode;
        
       @Column(name = "ammount", nullable = false)
        private Double ammount;
    
        
       @Column(name = "quantity")
        private Integer quantity;
        @PrePersist
	private void assignUUID() {
		if (this.getAdditionalChargeCode() == null || this.getAdditionalChargeCode().length() == 0) {
			this.setAdditionalChargeCode(UUID.randomUUID().toString());
		}
	}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAdditionalChargeCode() {
        return additionalChargeCode;
    }

    public void setAdditionalChargeCode(String additionalChargeCode) {
        this.additionalChargeCode = additionalChargeCode;
    }

    public String getRideCode() {
        return rideCode;
    }

    public void setRideCode(String rideCode) {
        this.rideCode = rideCode;
    }

    public String getAdditionalFareypeCode() {
        return additionalFareypeCode;
    }

    public void setAdditionalFareypeCode(String additionalFareypeCode) {
        this.additionalFareypeCode = additionalFareypeCode;
    }

   

    public Double getAmmount() {
        return ammount;
    }

    public void setAmmount(Double ammount) {
        this.ammount = ammount;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
    
       
        
}
