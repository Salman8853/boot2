/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.assignbooking.api;

import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingCancelledRequest;
import java.util.Base64;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.FormParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingRejectedCommentsResponse;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingRequest;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingStatus;
import com.gigflex.prototype.microservices.assignbooking.dtob.RideLocationRequest;
import com.gigflex.prototype.microservices.assignbooking.dtob.TrackingRideLocationReqest;
import com.gigflex.prototype.microservices.assignbooking.service.AssignBookingService;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.TokenUtility;
import java.text.SimpleDateFormat;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;

/**
 *
 * @author nirbhay.p
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class AssignBookingController {
    @Autowired
    public AssignBookingService assignBookingService;
       @Autowired
        TokenUtility tokenutility;
    @GetMapping("/getAllValidUnAssignedBooking")
	public String getAllValidUnAssignedBooking() {
		return assignBookingService.getAllValidUnAssignedBooking();
	}
        
         @GetMapping("/getAllValidUnAssignedBookingByPage")
	public String getAllValidUnAssignedBookingByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {
		 String allValidUnAssignedBookingByPage = assignBookingService.getAllValidUnAssignedBookingByPage( page, limit);
		 System.out.println(allValidUnAssignedBookingByPage);
		 return allValidUnAssignedBookingByPage;
	}
         
         @GetMapping("/getAllValidUnAssignedBookingByDriverCode/{driverCode}")
     	  public String getAllValidUnAssignedBookingByDriverCode(@PathVariable String driverCode,@RequestHeader HttpHeaders headers) {
                  String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true"))
               {
                  return assignBookingService.getAllValidUnAssignedBookingByDriverCode(driverCode);
               }else
               {
                 return res;
               }
     		
     	}
             
              @GetMapping("/getAllValidUnAssignedBookingByDriverCodeByPage/{driverCode}")
     	public String getAllValidUnAssignedBookingByDriverCodeByPage(@PathVariable String driverCode,@RequestParam(value = "page", defaultValue = "0") int page,
                 @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
             String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true"))
               {
               return assignBookingService.getAllValidUnAssignedBookingByDriverCodeByPage(driverCode, page, limit);
               }else
               {
                 return res;
               }
     		
     	}
         
        
        @GetMapping("/getAllValidUnAssignedBookingExceptCreator/{operatorCode}")
	public String getAllValidUnAssignedBookingExceptCreator(@PathVariable String operatorCode,@RequestHeader HttpHeaders headers) {
             String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                   if(operatorCode!=null && operatorCode.trim().length()>0)
                   {	
                      return assignBookingService.getAllValidUnAssignedBookingExceptCreator(operatorCode.trim());
                     }else{
                      GigflexResponse derr = new GigflexResponse(400, new Date(), "Operator code should not be blank.");
                       return derr.toString();  
                  }
               
               }else
               {
               return res;
               }
	
	}
        
         @GetMapping("/getAllValidUnAssignedBookingExceptCreatorByPage/{operatorCode}")
	public String getAllValidUnAssignedBookingExceptCreatorByPage(@PathVariable String operatorCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
            String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                  if(operatorCode!=null && operatorCode.trim().length()>0){		
                     return assignBookingService.getAllValidUnAssignedBookingExceptCreatorByPage(operatorCode.trim(), page, limit);
                   }
                 else{
                      GigflexResponse derr = new GigflexResponse(400, new Date(), "Operator code should not be blank.");
                return derr.toString();  
      }
               }else
               {
                   return res;
               
               }
	
	}
        
        
        
         @GetMapping("/getAllValidUnAssignedBookingExceptCreatorOrganizationByPage/{organizationCode}")
	public String getAllValidUnAssignedBookingExceptCreatorOrganizationByPage(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
               String res="";
               res=tokenutility.orgCodeValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
                 if(organizationCode!=null && organizationCode.trim().length()>0){		
                return assignBookingService.getAllValidUnAssignedBookingExceptCreatorOrganizationByPage(organizationCode.trim(), page, limit);
                }
               else{
               GigflexResponse derr = new GigflexResponse(400, new Date(), "Organization Code should not be blank.");
                   return derr.toString();  
               }
               }else
               {
               return res;
               }
	
	}
         
        
        
         @GetMapping("/getAssignedBookingByDriverCode/{driverCode}")
     	public String getAssignedBookingByDriverCode(@PathVariable String driverCode,@RequestHeader HttpHeaders headers ) {
             String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true"))
               {
               return assignBookingService.getAssignedBookingByDriverCode(driverCode);
               }else 
               {
                    return res;
               }
            
     		
     	}
         
         @GetMapping(path="/getAssignedBookingByDriverCodeByPage/{driverCode}")
         public String getAssignedBookingByDriverCodeByPage(@PathVariable String driverCode,@RequestParam(value = "page", defaultValue = "0") int page,
                 @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
                 String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true"))
               {
                  return assignBookingService.getAssignedBookingByDriverCode(driverCode, page, limit);
               }else
               {
                 return res;
               }
            
         }
         
         @GetMapping("/getAcceptedBookingByDriverCode/{driverCode}")
     	public String getAcceptedBookingByDriverCode(@PathVariable String driverCode,@RequestHeader HttpHeaders headers) {
             String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true")) 
               {
                return assignBookingService.getAcceptedBookingByDriverCode(driverCode);
               }else
               {
               return res;
               }
     	}
         
         @GetMapping("/getCurrentLocationByRideCode/{rideCode}")
      	public String getCurrentLocationByRideCode(@PathVariable String rideCode) {
      		return assignBookingService.getCurrentLocationByRideCode(rideCode);
      	}
          
         
         @GetMapping(path="/getAcceptedBookingByDriverCodeByPage/{driverCode}/{status}/{stratDT}/{endDT}")
         public String getAcceptedBookingByDriverCodeByPage(@PathVariable String driverCode,@PathVariable String status,
            @PathVariable String stratDT,@PathVariable String endDT,@RequestParam(value = "page", defaultValue = "0") int page,
                 @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
               String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true")) 
               {
               if(driverCode!=null && driverCode.trim().length()>0 && status!=null && status.trim().length()>0  ) {
                 if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
                 {
		 Date sDT = null;
		 Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(stratDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                    }
                  }
                
               }
         else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}

             return assignBookingService.getAcceptedBookingByDriverCodeByPage(driverCode.trim(),status.trim(),stratDT.trim(), endDT.trim(), page, limit);
           
             }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Driver Code and Status should not be blank.");
			return derr.toString();
		}
               }else
           {
              return res;
           }
  
         }
            
         
         @GetMapping(path="/getAcceptedBookingByDriverCodeByPage/{driverCode}/{status}")
         public String getAcceptedBookingByDriverCodeByPage(@PathVariable String driverCode,@PathVariable String status,
            @RequestParam(value = "page", defaultValue = "0") int page,
                 @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
               String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true")) 
               {
                     if(driverCode!=null && driverCode.trim().length()>0 && status!=null && status.trim().length()>0  ) {
                        return assignBookingService.getAcceptedBookingByDriverCodeByPage(driverCode.trim(),status.trim(),null, null, page, limit);
           
                      }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Driver Code and Status should not be blank.");
			return derr.toString();
		         }
               
               }else
               {
                return res;
               }
         
         }
        
          
         @GetMapping(path="/getAllLatestBookingByDriverCodeWithFilterByPage/{driverCode}/{status}/{stratDT}/{endDT}")
         public String getAllLatestBookingByDriverCodeWithFilterByPage(@PathVariable String driverCode,@PathVariable List<String> status,
            @PathVariable String stratDT,@PathVariable String endDT,@RequestParam(value = "page", defaultValue = "0") int page,
                 @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
             
              String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true")) 
               {
                if(driverCode!=null && driverCode.trim().length()>0 && status!=null && status.size()>0  ) {
                     if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
                     {
		            Date sDT = null;
		            Date eDT = null;
		   try {
			sDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(stratDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		     } catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
			return derr.toString();
		    }
                
                          if(sDT!=null && eDT!=null)
                         {
                            if (!(sDT.equals(eDT) || (eDT.after(sDT)))) 
                            {
                              GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			      return derr.toString();
                             }
                          }
                
                   }
                  else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		  }

             return assignBookingService.getAllLatestBookingByDriverCodeWithFilterByPage(driverCode.trim(),status,stratDT.trim(), endDT.trim(), page, limit);
           
             }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Driver Code and Status should not be blank.");
			return derr.toString();
		}
           }else
           {
                return res;  
           }
 
       }
            
         
           
         @GetMapping(path="/getAllLatestBookingByDriverCodeWithFilterForMobile/{driverCode}/{status}/{stratDT}/{endDT}")
         public String getAllLatestBookingByDriverCodeWithFilterForMobile(@PathVariable String driverCode,@PathVariable List<String> status,
            @PathVariable String stratDT,@PathVariable String endDT,@RequestHeader HttpHeaders headers) {
             
              String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true")) 
               {
                if(driverCode!=null && driverCode.trim().length()>0 && status!=null && status.size()>0  ) {
                     if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
                     {
		            Date sDT = null;
		            Date eDT = null;
		   try {
			sDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(stratDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		     } catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
			return derr.toString();
		    }
                
                          if(sDT!=null && eDT!=null)
                         {
                            if (!(sDT.equals(eDT) || (eDT.after(sDT)))) 
                            {
                              GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			      return derr.toString();
                             }
                          }
                
                   }
                  else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		  }

             return assignBookingService.getAllLatestBookingByDriverCodeWithFilterForMobile(driverCode.trim(),status,stratDT.trim(), endDT.trim());
           
             }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Driver Code and Status should not be blank.");
			return derr.toString();
		}
           }else
           {
                return res;  
           }
 
       }
            
              
         @GetMapping(path="/getAllLatestBookingByDriverCodeWithFilterForMobileByPage/{driverCode}/{status}/{stratDT}/{endDT}")
         public String getAllLatestBookingByDriverCodeWithFilterForMobileByPage(@PathVariable String driverCode,@PathVariable List<String> status,
            @PathVariable String stratDT,@PathVariable String endDT,@RequestParam(value = "page", defaultValue = "0") int page,
                 @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
             
              String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true")) 
               {
                if(driverCode!=null && driverCode.trim().length()>0 && status!=null && status.size()>0  ) {
                     if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
                     {
		            Date sDT = null;
		            Date eDT = null;
		   try {
			sDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(stratDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		     } catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
			return derr.toString();
		    }
                
                          if(sDT!=null && eDT!=null)
                         {
                            if (!(sDT.equals(eDT) || (eDT.after(sDT)))) 
                            {
                              GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			      return derr.toString();
                             }
                          }
                
                   }
                  else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		  }

             return assignBookingService.getAllLatestBookingByDriverCodeWithFilterForMobileByPage(driverCode.trim(),status,stratDT.trim(), endDT.trim(),page, limit);
           
             }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Driver Code and Status should not be blank.");
			return derr.toString();
		}
           }else
           {
                return res;  
           }
 
       }
            
         
         @GetMapping(path="/getAllLatestBookingByDriverCodeWithFilterByPage/{driverCode}/{status}")
         public String getAllLatestBookingByDriverCodeWithFilterByPage(@PathVariable String driverCode,@PathVariable List<String> status,
            @RequestParam(value = "page", defaultValue = "0") int page,
                 @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) 
         {
              String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true")) 
               {  
                      if(driverCode!=null && driverCode.trim().length()>0 && status!=null && status.size()>0  ) {
    

                          return assignBookingService.getAllLatestBookingByDriverCodeWithFilterByPage(driverCode.trim(),status,null, null, page, limit);
           
                     }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Driver Code and Status should not be blank.");
			return derr.toString();
		     }
               
               }else
               {
                 return res;
               }
           
         }
        
         
         
         @GetMapping(path="/getAllLatestBookingByDriverCodeWithFilterForMobile/{driverCode}/{status}")
         public String getAllLatestBookingByDriverCodeWithFilterForMobile(@PathVariable String driverCode,@PathVariable List<String> status, @RequestHeader HttpHeaders headers) 
         {
              String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true")) 
               {  
                      if(driverCode!=null && driverCode.trim().length()>0 && status!=null && status.size()>0  ) {
    

                          return assignBookingService.getAllLatestBookingByDriverCodeWithFilterForMobile(driverCode.trim(),status,null, null);
           
                     }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Driver Code and Status should not be blank.");
			return derr.toString();
		     }
               
               }else
               {
                 return res;
               }
           
         }
        
         @GetMapping(path="/getAllLatestBookingByDriverCodeWithFilterForMobileByPage/{driverCode}/{status}")
         public String getAllLatestBookingByDriverCodeWithFilterForMobileByPage(@PathVariable String driverCode,@PathVariable List<String> status,@RequestParam(value = "page", defaultValue = "0") int page,
                 @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) 
         {
              String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true")) 
               {  
                      if(driverCode!=null && driverCode.trim().length()>0 && status!=null && status.size()>0  ) {
    

                          return assignBookingService.getAllLatestBookingByDriverCodeWithFilterForMobileByPage(driverCode.trim(),status,null, null,page, limit);
           
                     }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Driver Code and Status should not be blank.");
			return derr.toString();
		     }
               
               }else
               {
                 return res;
               }
           
         }
        
         
   
         
        @GetMapping("/changeAssignBookingStatusViaMail")
	public String changeAssignBookingStatusViaMail(@FormParam("tok") String tok,
			@FormParam("tok1") String tok1,@FormParam("tok2") String tok2) {
		String res = "";
		try {
			if (tok != null && tok.length() > 0 && tok1 != null  && tok1.length() > 0) {
				
				byte bttok[] = Base64.getDecoder().decode(tok);
				String assignbookingcode = new String(bttok);

				byte bttok1[] = Base64.getDecoder().decode(tok1);
				String status = new String(bttok1);
                                Boolean st=null;
				if(status!=null && status.length()>0)
                                {
                                    if(status.equalsIgnoreCase("true"))
                                    {
                                        st=true;
                                    }
                                    else if(status.equalsIgnoreCase("false"))
                                    {
                                        st=false;
                                    }
                                }
                                
                                byte bttok2[] = Base64.getDecoder().decode(tok2);
				String driverCode = new String(bttok2);
                                
                                
				if (assignbookingcode!=null && assignbookingcode.length() > 0 &&  st!=null && driverCode != null) {
					res = assignBookingService.changeAssignBookingStatusViaMail(assignbookingcode,st,driverCode);
				} else {
					res = "Given input is not valid";
				}
			} else {
				res = "Given input is not valid";
			}
		} catch (Exception e) {
			res = "Given input is not valid";
			e.printStackTrace();
		}
		return res;
	}
       
        
        @PostMapping("/assignBookingToDriver")
     public String assignBookingToDriver(@RequestBody  AssignBookingRequest ABR,HttpServletRequest req){
      if(ABR!=null && ABR.getDriverCode()!=null && ABR.getDriverCode().trim().length()>0 && ABR.getRideCode()!=null && ABR.getRideCode().trim().length()>0
              && ABR.getOperatorCode()!=null && ABR.getOperatorCode().trim().length()>0
              && ABR.getOrganizationCode()!=null && ABR.getOrganizationCode().trim().length()>0){
          ABR.setDriverCode(ABR.getDriverCode().trim());
          ABR.setRideCode(ABR.getRideCode().trim());
          ABR.setOperatorCode(ABR.getOperatorCode().trim());
          ABR.setOrganizationCode(ABR.getOrganizationCode().trim());
      return assignBookingService.assignBookingToDriver(ABR, req.getRemoteAddr());
      }
      else{
         GigflexResponse derr = new GigflexResponse(400, new Date(), "Operator code, Organization code, Driver code and Ride code should not be blank.");
         return derr.toString();  
      }
    }
        
        @PostMapping("/assignBookingAccepted")
     public String assignBookingAccepted(@RequestBody  AssignBookingStatus ABS,HttpServletRequest req){
      if(ABS!=null && ABS.getDriverCode()!=null && ABS.getDriverCode().trim().length()>0 && ABS.getRideCode()!=null && ABS.getRideCode().trim().length()>0){
          ABS.setDriverCode(ABS.getDriverCode().trim());
          ABS.setRideCode(ABS.getRideCode().trim());
      return assignBookingService.assignBookingAccepted(ABS, req.getRemoteAddr());
      }
      else{
         GigflexResponse derr = new GigflexResponse(400, new Date(), "Driver code and Ride code should not be blank.");
         return derr.toString();  
      }
    }
        
        @PostMapping("/assignBookingInProgress")
     public String assignBookingInProgress(@RequestBody  AssignBookingStatus ABS,HttpServletRequest req){
      if(ABS!=null && ABS.getDriverCode()!=null && ABS.getDriverCode().trim().length()>0 && ABS.getRideCode()!=null && ABS.getRideCode().trim().length()>0){
          ABS.setDriverCode(ABS.getDriverCode().trim());
          ABS.setRideCode(ABS.getRideCode().trim());
      return assignBookingService.assignBookingInProgress(ABS, req.getRemoteAddr());
      }
      else{
         GigflexResponse derr = new GigflexResponse(400, new Date(), "Driver code and Ride code should not be blank.");
         return derr.toString();  
      }
    }
     
    @PostMapping("/assignBookingRejected")
 public String assignBookingRejected(@RequestBody  AssignBookingRejectedCommentsResponse ABS,HttpServletRequest req){
       if(ABS!=null && ABS.getDriverCode()!=null && ABS.getDriverCode().trim().length()>0 && ABS.getRideCode()!=null && ABS.getRideCode().trim().length()>0 && ABS.getComments() != null && ABS.getComments().trim().length()>0){
          ABS.setDriverCode(ABS.getDriverCode().trim());
          ABS.setRideCode(ABS.getRideCode().trim());
          ABS.setComments(ABS.getComments().trim());
      return assignBookingService.assignBookingRejected(ABS, req.getRemoteAddr());
      }
      else{
         GigflexResponse derr = new GigflexResponse(400, new Date(), "Driver code and Ride code and comments should not be blank.");
         return derr.toString();  
      }
    }
    
 
  @PostMapping("/assignBookingCancelled")
 public String assignBookingCancelled(@RequestBody  AssignBookingCancelledRequest ABS,HttpServletRequest req){
       if(ABS!=null && ABS.getOperatorCode()!=null && ABS.getOperatorCode().trim().length()>0 && ABS.getRideCode()!=null && ABS.getRideCode().trim().length()>0 && ABS.getComments() != null && ABS.getComments().trim().length()>0){
          ABS.setOperatorCode(ABS.getOperatorCode().trim());
          ABS.setRideCode(ABS.getRideCode().trim());
          ABS.setComments(ABS.getComments().trim());
      return assignBookingService.assignBookingCancelled(ABS, req.getRemoteAddr());
      }
      else{
         GigflexResponse derr = new GigflexResponse(400, new Date(), "Operator code and Ride code and comments should not be blank.");
         return derr.toString();  
      }
    }
    
    @PutMapping("/updateRideCurrentLocationByRideCode/{rideCode}")
	public String updateVehicleToDriver(@PathVariable String rideCode,
			@RequestBody RideLocationRequest rideLocReq,
			HttpServletRequest request) {

		if (rideCode == null) {
			return "Assign Booking with Ride Code : (" + rideCode + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return assignBookingService.updateRideCurrentLocationByRideCode(rideCode, rideLocReq, ip);

		}

	}
        
        
        @PostMapping("/saveRideCurrentLocation")
	public String saveRideCurrentLocation(@RequestBody TrackingRideLocationReqest trackingRideLocReq,
			HttpServletRequest request) 
        {		
            String ip = request.getRemoteAddr();
            return assignBookingService.saveRideCurrentLocation(trackingRideLocReq, ip);
        }

	@GetMapping("/getAllTrackingRideLocation")
	public String getAllTrackingRideLocation() {
		return assignBookingService.getAllTrackingRideLocation();
	}
        
        
        @GetMapping("/getTrackingLastRideLocationByRideCode/{rideCode}")
     	  public String getTrackingLastRideLocationByRideCode(@PathVariable String rideCode) {
                 
               return assignBookingService.getTrackingLastRideLocationByRideCode(rideCode);
     	}
          
          @GetMapping("/getAllTrackingRideLocationByRideCode/{rideCode}")
     	  public String getAllTrackingRideLocationByRideCode(@PathVariable String rideCode) {
                 
               return assignBookingService.getAllTrackingRideLocationByRideCode(rideCode);
     	}
}
