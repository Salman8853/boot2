/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.rideexchange.dtob;

/**
 *
 * @author amit.kumar
 */
public class RideExchangeRes {
    
    private Long id; 
    private String rideExchangeCode;
    private String organizationCodePublish;
    private String organizationCodeAssigned;
    private double balanceAmount;
    private double rideExchangeAmount;
    private String organizationNamePublish;
    private String organizationNameAssigned;
    private String rideCode;
    private String transactionDate;

    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRideExchangeCode() {
        return rideExchangeCode;
    }

    public void setRideExchangeCode(String rideExchangeCode) {
        this.rideExchangeCode = rideExchangeCode;
    }

    public String getOrganizationCodePublish() {
        return organizationCodePublish;
    }

    public void setOrganizationCodePublish(String organizationCodePublish) {
        this.organizationCodePublish = organizationCodePublish;
    }

    public String getOrganizationCodeAssigned() {
        return organizationCodeAssigned;
    }

    public void setOrganizationCodeAssigned(String organizationCodeAssigned) {
        this.organizationCodeAssigned = organizationCodeAssigned;
    }

    public double getBalanceAmount() {
        return balanceAmount;
    }

    public void setBalanceAmount(double balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    public double getRideExchangeAmount() {
        return rideExchangeAmount;
    }

    public void setRideExchangeAmount(double rideExchangeAmount) {
        this.rideExchangeAmount = rideExchangeAmount;
    }

    public String getOrganizationNamePublish() {
        return organizationNamePublish;
    }

    public void setOrganizationNamePublish(String organizationNamePublish) {
        this.organizationNamePublish = organizationNamePublish;
    }

    public String getOrganizationNameAssigned() {
        return organizationNameAssigned;
    }

    public void setOrganizationNameAssigned(String organizationNameAssigned) {
        this.organizationNameAssigned = organizationNameAssigned;
    }

    public String getRideCode() {
        return rideCode;
    }

    public void setRideCode(String rideCode) {
        this.rideCode = rideCode;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }
    
}
