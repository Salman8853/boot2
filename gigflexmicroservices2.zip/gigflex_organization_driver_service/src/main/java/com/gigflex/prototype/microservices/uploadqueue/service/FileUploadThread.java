/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.uploadqueue.service;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBooking;
import com.gigflex.prototype.microservices.assignbooking.repository.AssignBookingRepository;
import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.booking.repository.BookingDao;
import com.gigflex.prototype.microservices.uploadqueue.dtob.UploadQueue;
import com.gigflex.prototype.microservices.uploadqueue.repository.UploadQueueDao;
import com.gigflex.prototype.microservices.util.GigflexConstants;

public class FileUploadThread implements Runnable {

	private String fileName;
	private String uploadCode;
	private BookingDao bookingDao;
	private UploadQueueDao uploadQueueDao;

	private AssignBookingRepository assignBookingDao;

	
	public FileUploadThread(String fileName, String uploadCode,
			BookingDao bookingDao, UploadQueueDao uploadQueueDao,
			AssignBookingRepository assignBookingDao) {
		super();
		this.fileName = fileName;
		this.uploadCode = uploadCode;
		this.bookingDao = bookingDao;
		this.uploadQueueDao = uploadQueueDao;
		this.assignBookingDao = assignBookingDao;
	}


	@Override
	public void run() {
		try {
			File myFile = new File(fileName);
			FileInputStream fis = new FileInputStream(myFile);

			Workbook myWorkBook;
			Sheet mySheet = null;

			int inx = fileName.lastIndexOf(".");
			String filenameEnd = fileName.substring(inx);

			if (filenameEnd.equalsIgnoreCase(".xls")) {
				myWorkBook = new HSSFWorkbook(fis);
				mySheet = myWorkBook.getSheetAt(0);
			} else if (filenameEnd.equalsIgnoreCase(".xlsx")) {
				myWorkBook = new XSSFWorkbook(fis);
				mySheet = myWorkBook.getSheetAt(0);
			}
			Iterator<Row> rowIterator = mySheet.iterator();
			int rowCount = -1;
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				Boolean status = false;
				try {

					if (row != null) {
						rowCount++;

						if (rowCount != 0) {
							Iterator<Cell> cellIterator = row.cellIterator();
							int cellCount = 0;
							Booking booking = new Booking();

							while (cellIterator.hasNext()) {
								cellCount++;
								Double fare = null;

								Cell cell = cellIterator.next();

								if (cell != null) {
									String res = "";
									switch (cell.getCellType()) {
									case Cell.CELL_TYPE_STRING:
										res = cell.getStringCellValue();
										break;
									case Cell.CELL_TYPE_NUMERIC:
										double var = cell.getNumericCellValue();
										if (cellCount != 9) {
											Long l = (long) var;
											res = l.toString();
										} else {
											fare = var;
										}
										break;
									case Cell.CELL_TYPE_BOOLEAN:
										if (cell.getBooleanCellValue()) {
											res = "true";
										} else {
											res = "false";
										}

										break;
									default:

									}

									if (cellCount == 11) {

										booking.setAdditionalComment(res);

										break;
									} else if (cellCount == 10) {

										booking.setPaymentOption(res);
									} else if (cellCount == 9) {

										booking.setCustomerFare(fare);

									} else if (cellCount == 8) {

										booking.setNoOfBaggage(Integer
												.parseInt(res));

									} else if (cellCount == 7) {

										if (res.trim().length() > 0) {
											booking.setNoOfPassengers(Integer
													.parseInt(res));

										}

									} else if (cellCount == 6) {
										if (res.trim().length() > 0) {

											booking.setAdditionalStopPage(res);

										}

									} else if (cellCount == 5) {
										booking.setDropOffAddress(res);

									} else if (cellCount == 4) {

										booking.setPickUpAddress(res);

									} else if (cellCount == 3) {

										booking.setSecondaryContactNumber(res);

									} else if (cellCount == 2) {

										booking.setPrimaryContactNumber(res);

									} else if (cellCount == 1) {

										booking.setPassengerName(res);
									}

								}

							}
							if (booking != null
									&& booking.getPassengerName() != null) {
								booking.setIsPublished(false);
								booking.setIsDeleted(false);
								booking.setBookingStatus(GigflexConstants.assignedBookingStatus);

								Booking bookingRes = bookingDao.save(booking);

								if (bookingRes != null
										&& bookingRes.getId() > 0) {
									status = true;
									AssignBooking as = new AssignBooking();
									as.setRideCode(bookingRes.getRideCode());
									as.setStatus(GigflexConstants.assignedBookingStatus);
									assignBookingDao.save(as);
								}

							}

						}
					}
				}

				catch (Exception ex) {
					ex.printStackTrace();
				}
				if (rowCount >= 1) {
					UploadQueue uploadRes = uploadQueueDao
							.getUploadQueueByUploadCode(uploadCode);

					if (uploadRes != null && uploadRes.getId() > 0) {
						if (status) {
							uploadRes.setProcessedRecords(uploadRes
									.getProcessedRecords() + 1);
						} else {
							uploadRes.setFaliedRecords(uploadRes
									.getFaliedRecords() + 1);
						}

						uploadQueueDao.save(uploadRes);
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

}
