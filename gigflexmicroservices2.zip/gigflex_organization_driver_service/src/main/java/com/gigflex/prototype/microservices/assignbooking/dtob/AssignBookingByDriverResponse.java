package com.gigflex.prototype.microservices.assignbooking.dtob;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import org.hibernate.annotations.GenericGenerator;

public class AssignBookingByDriverResponse {
	
	private Long id;

    private String assignBookingCode;

    private String rideCode;
    
    private String passengerName;
    
//    private String vehicleName;

    private String driverCode;
    
    private String name;

    private String operatorCode;
    
    private String operatorName;

    private String status;
    
    private String comments;
    
    

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAssignBookingCode() {
		return assignBookingCode;
	}

	public void setAssignBookingCode(String assignBookingCode) {
		this.assignBookingCode = assignBookingCode;
	}

	public String getRideCode() {
		return rideCode;
	}

	public void setRideCode(String rideCode) {
		this.rideCode = rideCode;
	}

//	public String getVehicleName() {
//		return vehicleName;
//	}
//
//	public void setVehicleName(String vehicleName) {
//		this.vehicleName = vehicleName;
//	}

	public String getDriverCode() {
		return driverCode;
	}

	public void setDriverCode(String driverCode) {
		this.driverCode = driverCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOperatorCode() {
		return operatorCode;
	}

	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
    
    
    
    

}
