package com.gigflex.prototype.microservices.assignbooking.dtob;

import javax.persistence.Column;

public class RideLocationRequest {

	@Column(name = "lat")
	private String lat;

	@Column(name = "lang")
	private String lang;

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

}
