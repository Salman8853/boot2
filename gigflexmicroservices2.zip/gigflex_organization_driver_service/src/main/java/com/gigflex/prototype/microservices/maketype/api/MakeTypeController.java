package com.gigflex.prototype.microservices.maketype.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.maketype.dtob.MakeTypeRequest;
import com.gigflex.prototype.microservices.maketype.service.MakeTypeService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class MakeTypeController {

	@Autowired
	public MakeTypeService makeTypeService;

	@GetMapping("/MakeType/{search}")
	public String search(@PathVariable("search") String search) {
		return makeTypeService.search(search);
	}

	@GetMapping("/getAllMakeType")
	public String getAllMakeType() {
		return makeTypeService.getAllMakeType();
	}

	@GetMapping(path = "/getMakeTypeByPage")
	public String getMakeTypeByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String makeType = makeTypeService.getAllMakeTypeByPgae(page, limit);

		return makeType;

	}

	@GetMapping("/getMakeType/{id}")
	public String getMakeTypeById(@PathVariable Long id) {
		return makeTypeService.getMakeTypeById(id);
	}

	@GetMapping("/getMakeTypeByVehicleCode/{vehicleCode}")
	public String getMakeTypeByVehicleCode(@PathVariable String vehicleCode) {
		return makeTypeService.getMakeTypeByVehicleCode(vehicleCode);
	}

	@PostMapping("/saveMakeType")
	public String saveMakeType(@RequestBody MakeTypeRequest makeTypeReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return makeTypeService.saveNewMakeType(makeTypeReq, ip);

	}

	@PutMapping("/updateMakeType/{id}")
	public String updateMakeType(@PathVariable Long id,
			@RequestBody MakeTypeRequest makeTypeReq, HttpServletRequest request) {

		if (id == null) {
			return "MakeType with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return makeTypeService.updateMakeTypeById(id, makeTypeReq, ip);

		}

	}

	@DeleteMapping("/softDeleteMakeTypeByVehicleCode/{vehicleCode}")
	public String softDeleteMakeTypeByVehicleCode(
			@PathVariable String vehicleCode) {
		return makeTypeService.softDeleteByVehicleCode(vehicleCode);
	}

	@DeleteMapping("/softMultipleDeleteByVehicleCode/{vehicleCodeList}")
	public String softMultipleDeleteByVehicleCode(
			@PathVariable List<String> vehicleCodeList) {
		if (vehicleCodeList != null && vehicleCodeList.size() > 0) {
			return makeTypeService
					.softMultipleDeleteByVehicleCode(vehicleCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

}
