/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.assignbooking.dtob;

/**
 *
 * @author amit.kumar
 */
public class TrackingRideLocationResponse {
    
    private String lat;
    private String lang;
    private String rideCode;
    private boolean isNearestDistanceFromFropOff;
    private String trackingRideStatusCode;

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getRideCode() {
        return rideCode;
    }

    public void setRideCode(String rideCode) {
        this.rideCode = rideCode;
    }

    public boolean isIsNearestDistanceFromFropOff() {
        return isNearestDistanceFromFropOff;
    }

    public void setIsNearestDistanceFromFropOff(boolean isNearestDistanceFromFropOff) {
        this.isNearestDistanceFromFropOff = isNearestDistanceFromFropOff;
    }

    public String getTrackingRideStatusCode() {
        return trackingRideStatusCode;
    }

    public void setTrackingRideStatusCode(String trackingRideStatusCode) {
        this.trackingRideStatusCode = trackingRideStatusCode;
    }
    
    
}
