/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.service.impl;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBooking;
import com.gigflex.prototype.microservices.assignbooking.repository.AssignBookingRepository;
import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.booking.repository.BookingDao;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocument;
import com.gigflex.prototype.microservices.documentmapping.repository.DriverDocumentRepository;
import com.gigflex.prototype.microservices.documenttype.dtob.DocumentType;
import com.gigflex.prototype.microservices.documenttype.repository.DocumentTypeRepository;
import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetail;
import com.gigflex.prototype.microservices.documenttypedetail.repository.DocumentTypeDetailRepository;
import com.gigflex.prototype.microservices.driver.dtob.DefaultVehicleUpdateRequest;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.dtob.DriverContactDetailByRideCodeforMobileRes;
import com.gigflex.prototype.microservices.driver.dtob.DriverDefaultVehicleResponse;
import com.gigflex.prototype.microservices.driver.dtob.DriverDocsReq;
import com.gigflex.prototype.microservices.driver.dtob.DriverDocsResponse;
import com.gigflex.prototype.microservices.driver.dtob.DriverDocumentsReq;
import com.gigflex.prototype.microservices.driver.dtob.DriverFullDetailRes;
import com.gigflex.prototype.microservices.driver.dtob.DriverRegistrationOTPDetail;
import com.gigflex.prototype.microservices.driver.dtob.DriverRequest;
import com.gigflex.prototype.microservices.driver.dtob.DriverResponse;
import com.gigflex.prototype.microservices.driver.dtob.DriverUpRequest;
import com.gigflex.prototype.microservices.driver.dtob.DriverVehicleDetail;
import com.gigflex.prototype.microservices.driver.dtob.DriverVehicleRequest;
import com.gigflex.prototype.microservices.driver.dtob.DriverVehicleResponse;
import com.gigflex.prototype.microservices.driver.dtob.GeneralDetailRes;
import com.gigflex.prototype.microservices.driver.dtob.NewDriverRes;
import com.gigflex.prototype.microservices.driver.dtob.PersonalDetailTabRes;
import com.gigflex.prototype.microservices.driver.dtob.Users;
import com.gigflex.prototype.microservices.driver.dtob.VehicleDriverMapping;
import com.gigflex.prototype.microservices.driver.repository.DriverRegistrationDao;
import com.gigflex.prototype.microservices.driver.repository.DriverRegistrationOTPRepository;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.driver.repository.VehicleDriverMappingRepository;
import com.gigflex.prototype.microservices.driver.search.DriverSpecificationsBuilder;
import com.gigflex.prototype.microservices.driver.service.DriverService;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.notification.service.NotificationService;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.operator.repository.UserRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationDao;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.passenger.dtob.Passenger;
import com.gigflex.prototype.microservices.passenger.repository.PassengerDao;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.utility.GigflexDateUtil;
import com.gigflex.prototype.microservices.utility.PushNotification;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetail;
import com.gigflex.prototype.microservices.vehicledetail.repository.VehicleDetailRepository;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 *
 * @author Abhishek
 */

@Service
public class DriverServiceImpl implements DriverService {

	@Autowired
	private NotificationService notificationService;

	@Autowired
	DriverRepository driverRepository;

	@Autowired
	OperatorRepository opertaorRepository;

	@Autowired
	OrganizationDao orgDao;

	@Autowired
	VehicleDriverMappingRepository vehDriverDao;

	@Autowired
	KafkaService kafkaService;
        
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	private DriverRegistrationDao driverRegistrationDao;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	DriverRegistrationOTPRepository driverRegistrationOTPRepository;

	@Autowired
	DriverDocumentRepository driverDocumentRepository;

	@Autowired
	UserRepository userRepository;
        @Autowired
        GlobalSettingRepository globalSettingRepository;
    
        @Autowired
        LocalSettingRepository localSettingRepository;
        
        @Autowired
	private TimeZoneRepository timeZoneRepository;
        
        @Autowired
	UserTypeRepository userTypeRepository;
        
       @Autowired
        DocumentTypeRepository documentTypeRepository;
       @Autowired
       DocumentTypeDetailRepository documentTypeDetailRepository;
      @Autowired 
      BookingDao bookingDao;
      @Autowired
      AssignBookingRepository assignBookingRepository;
      
       @Autowired 
       PassengerDao passengerDao;
	@Value("${email.driverregistration.subject}")
	private String subject;// ="Driver Registration Request";

	@Value("${email.driverregistration.link}")
	private String mailUrl;

	@Value("${email.driverregistration.body}")
	private String mailBody;// ="Please click on following link to register";

	@Value("${email.service.url}")
	private String mailServiceURL;// ="http://18.223.158.6:8091/superadminservice/sendEmail/to/{to}/subject/{subject}/body/{body}";

	@Value("${email.drivercreatecredential.subject}")
	private String credentialSubject;// ="Driver Registration Request";

	@Value("${email.drivercreatecredential.link}")
	private String credentialMailUrl;

	@Value("${email.drivercreatecredential.body}")
	private String credentialMailBody;// ="Please click on following link to register";

	private String shortMessage;
        
        @Value("${notification.deviceid}")
        private String deviceId;

        @Value("${notification.fcm.url}")
        private String FMCurl;  
        
        @Value("${notification.fcm.authkey}")
        private String authKey;
        
    public DriverServiceImpl(BCryptPasswordEncoder bCryptPasswordEncoder) {
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }
        

	@Autowired
	VehicleDetailRepository vehicleDetailRepository;

	@Override
	public Driver saveDriversDetatil(Driver driver) {
		return driverRepository.save(driver);
	}

	@Override
	public String findAllDriver() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = driverRepository.getAllDriver();
			List<DriverResponse> maplst = new ArrayList<DriverResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {
						List<DriverVehicleDetail> vdData = new ArrayList<DriverVehicleDetail>();

						DriverResponse dro = new DriverResponse();

						Driver data = (Driver) arr[0];
						dro.setId(data.getId());
						dro.setDriverCode(data.getDriverCode());
						dro.setName(data.getName());
						dro.setContactNumber(data.getContactNumber());
						dro.setCountryCode(data.getCountryCode());
						dro.setEmailId(data.getEmailId());
						// dro.setFleetSize(data.getFleetSize());
						dro.setCallsign(data.getCallsign());
						dro.setOperatorCode(data.getOperatorCode());
						dro.setOrganizationCode(data.getOrganizationCode());
						dro.setOperatorName((String) arr[1]);
						dro.setOrganizationName((String) arr[2]);
                                                dro.setIsActive((Boolean)arr[3]);

						dro.setDriverImage(data.getDriverImage());
                                                dro.setDefaultVehicleCode(data.getDefaultVehicleCode()); 
						if (data.getDriverCode() != null && data.getDriverCode().length() > 0) {
							// dro.setVehicleCode(data.getVehicleCode());
							List<VehicleDetail> vd = vehicleDetailRepository
									.getDriverVehicleDetailByVehicleCode(data.getDriverCode());
							if (!vd.isEmpty() && vd.size() > 0) {
								DriverVehicleDetail driverDetail = new DriverVehicleDetail();
								for (VehicleDetail vehicleDetails : vd) {
									driverDetail.setVehicleCode(vehicleDetails.getVehicleCode());
									//driverDetail.setVehicleName(vehicleDetails.getVehicleName());
									vdData.add(driverDetail);
								}
								dro.setDriverVehicleDetails(vdData);
							}
						}
						List<DriverDocument> ddexplst = driverDocumentRepository
								.getExpiredDriverDocumentByDriverCode(data.getDriverCode(), new Date());
						if (ddexplst != null && ddexplst.size() > 0) {
							dro.setDocExpiryStatus(Boolean.TRUE);
						} else {
							dro.setDocExpiryStatus(Boolean.FALSE);
						}
						maplst.add(dro);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllDriverByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
				List<Object> objlstCheck = driverRepository.getAllDriver();
				Integer count = objlstCheck.size();
				Pageable pageableRequest = PageRequest.of(page, limit);

				List<Object> objlst = driverRepository.getAllDriver(pageableRequest);
				List<DriverResponse> maplst = new ArrayList<DriverResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {
							List<DriverVehicleDetail> vdData = new ArrayList<DriverVehicleDetail>();
							DriverResponse dro = new DriverResponse();

							Driver data = (Driver) arr[0];
							dro.setId(data.getId());
							dro.setDriverCode(data.getDriverCode());
							dro.setName(data.getName());
							dro.setContactNumber(data.getContactNumber());
							dro.setCountryCode(data.getCountryCode());

							dro.setEmailId(data.getEmailId());
							// dro.setFleetSize(data.getFleetSize());
							dro.setCallsign(data.getCallsign());
							dro.setOperatorCode(data.getOperatorCode());
							dro.setOrganizationCode(data.getOrganizationCode());
							dro.setOperatorName((String) arr[1]);
							dro.setOrganizationName((String) arr[2]);
                                                        dro.setIsActive((Boolean)arr[3]);
							dro.setDriverImage(data.getDriverImage());
                                                        dro.setDefaultVehicleCode(data.getDefaultVehicleCode()); 
							if (data.getDriverCode() != null && data.getDriverCode().length() > 0) {
								// dro.setVehicleCode(data.getVehicleCode());
								List<VehicleDetail> vd = vehicleDetailRepository
										.getDriverVehicleDetailByVehicleCode(data.getDriverCode());
								if (!vd.isEmpty() && vd.size() > 0) {
									DriverVehicleDetail driverDetail = new DriverVehicleDetail();
									for (VehicleDetail vehicleDetails : vd) {
										driverDetail.setVehicleCode(vehicleDetails.getVehicleCode());
										//driverDetail.setVehicleName(vehicleDetails.getVehicleName());
										vdData.add(driverDetail);
									}
									dro.setDriverVehicleDetails(vdData);
								}
							}
							List<DriverDocument> ddexplst = driverDocumentRepository
									.getExpiredDriverDocumentByDriverCode(data.getDriverCode(), new Date());
							if (ddexplst != null && ddexplst.size() > 0) {
								dro.setDocExpiryStatus(Boolean.TRUE);
							} else {
								dro.setDocExpiryStatus(Boolean.FALSE);
							}
							maplst.add(dro);

						}
					}
					if (maplst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(maplst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("count", count);

						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	
        
        
        
        
        @Override
	public String getDriverByDriverCode(String driverCode) {
		String res = "";
		DriverResponse dro = null;
		try {
			JSONObject jsonobj = new JSONObject();
			if (driverCode != null && driverCode.trim().length() > 0) {

				List<Object> objlst = driverRepository.findDriverByDriverCode(driverCode);
//			List<DriverResponse> maplst = new ArrayList<DriverResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {
							List<DriverVehicleDetail> vdData = new ArrayList<DriverVehicleDetail>();

							dro = new DriverResponse();

							Driver data = (Driver) arr[0];
							dro.setId(data.getId());
							dro.setDriverCode(data.getDriverCode());
							dro.setName(data.getName());
							dro.setContactNumber(data.getContactNumber());
							dro.setCountryCode(data.getCountryCode());

							dro.setEmailId(data.getEmailId());
							// dro.setFleetSize(data.getFleetSize());
							dro.setCallsign(data.getCallsign());
							dro.setOperatorCode(data.getOperatorCode());
							dro.setOrganizationCode(data.getOrganizationCode());
							dro.setOperatorName((String) arr[1]);
							dro.setOrganizationName((String) arr[2]);
							dro.setDriverImage(data.getDriverImage());
                                                        dro.setDefaultVehicleCode(data.getDefaultVehicleCode()); 
                                                        
							if (data.getDriverCode() != null && data.getDriverCode().length() > 0) {
								// dro.setVehicleCode(data.getVehicleCode());
								List<VehicleDetail> vd = vehicleDetailRepository
										.getDriverVehicleDetailByVehicleCode(data.getDriverCode());
								if (!vd.isEmpty() && vd.size() > 0) {
									DriverVehicleDetail driverDetail = new DriverVehicleDetail();
									for (VehicleDetail vehicleDetails : vd) {
										driverDetail.setVehicleCode(vehicleDetails.getVehicleCode());
										//driverDetail.setVehicleName(vehicleDetails.getVehicleName());
										vdData.add(driverDetail);
									}
									dro.setDriverVehicleDetails(vdData);
								}
							}
							List<DriverDocument> ddexplst = driverDocumentRepository
									.getExpiredDriverDocumentByDriverCode(data.getDriverCode(), new Date());
							if (ddexplst != null && ddexplst.size() > 0) {
								dro.setDocExpiryStatus(Boolean.TRUE);
							} else {
								dro.setDocExpiryStatus(Boolean.FALSE);
							}
//						maplst.add(dro);

						}
					}
					if (dro != null) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(dro);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String findDriverById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Driver driverlst = driverRepository.getDriverById(id);
			if (driverlst != null && driverlst.getId() > 0) {
                           NewDriverRes dres=new NewDriverRes();
                          dres.setId(driverlst.getId());
                          dres.setAddress(driverlst.getAddress());
                          dres.setApproveStatus(driverlst.getApproveStatus());
                          dres.setCallsign(driverlst.getCallsign());
                          dres.setCity(driverlst.getCity());
                          dres.setContactNumber(driverlst.getContactNumber());
                          dres.setCountry(driverlst.getCountry());
                          dres.setCountryCode(driverlst.getCountryCode());
                          dres.setDefaultVehicleCode(driverlst.getDefaultVehicleCode());
                         String onlydate= GigflexConstants.saveDateWithoutTime;
                         String  dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driverlst.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                   if(dateformat!=null && dateformat.trim().length()>0 )
                            {
                                onlydate=dateformat.trim();
                            }  
              if(driverlst.getDob()!=null){
                DateFormat dateFormat = new SimpleDateFormat(onlydate);      
                dres.setDob( dateFormat.format(driverlst.getDob()));
                }
                       dres.setDriverCode(driverlst.getDriverCode());
                       dres.setDriverImage(driverlst.getDriverImage());
                      dres.setEmailId(driverlst.getEmailId());
                      dres.setEmergencyContactNo(driverlst.getEmergencyContactNo());
                      dres.setLanguage(driverlst.getLanguage());
                      dres.setLatitude(driverlst.getLatitude());
                    
                     dres.setDateFormat(dateformat);
                       dres.setName(driverlst.getName());
                       dres.setOperatorCode(driverlst.getOperatorCode());
                       dres.setOrganizationCode(driverlst.getOrganizationCode());
                       dres.setPostCode(driverlst.getPostCode());
                       dres.setLongitude(driverlst.getLongitude());
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(dres);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String updateDriverById(Long id, DriverUpRequest driverReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (driverReq != null) {

				if (driverReq.getName() != null && driverReq.getName().trim().length() > 0
						&& driverReq.getOperatorCode() != null && driverReq.getOperatorCode().trim().length() > 0) {

					Organization org = orgDao.findByOrganizationCode(driverReq.getOrganizationCode());

					if (org != null && org.getId() > 0) {

						Operator operator = opertaorRepository.getOperatorByOperatorCode(driverReq.getOperatorCode());
						if (operator != null && operator.getId() > 0) {

							Driver driverlst = driverRepository.getDriverById(id);
							if (driverlst != null && driverlst.getId() > 0) {

//							if (GigflexUtility.emailPatternValidation(driverReq
//									.getEmailId()) == true) {

								Driver driver = driverlst;

								driver.setName(driverReq.getName());
								driver.setContactNumber(driverReq.getContactNumber());
								driver.setCountryCode(driverReq.getCountryCode());
								// driver.setFleetSize(driverReq.getFleetSize());
								driver.setCallsign(driverReq.getCallsign());
								driver.setDriverImage(driverReq.getDriverImage());
								driver.setOrganizationCode(driverReq.getOrganizationCode());
								driver.setOperatorCode(driverReq.getOperatorCode());
								driver.setIpAddress(ip);
                                                               
                                                                Date dtob=null;
                                                                try
                                                                {
                                                                DateFormat dateFormat = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime);      
                                                                 if(driverReq.getDob()!=null)
                                                                 {
                                                                 dtob=  dateFormat.parse(driverReq.getDob());
                                                                 }
                                                                }catch(Exception ex)
                                                                {
                                                                 ex.printStackTrace();
                                                                 jsonobj.put("responsecode", 500);
									jsonobj.put("message", "Exception occurred in date parsing.send date in ("+GigflexConstants.saveDateWithoutTime+")");
									jsonobj.put("timestamp", new Date());
                                                                         return jsonobj.toString();
                                                                }
                                                                 driver.setLanguage(driverReq.getLanguage());
                                                                 driver.setDob(dtob);
                                                                  driver.setAddress(driverReq.getAddress());
                                                                  driver.setCity(driverReq.getCity());
                                                                    driver.setCountry(driverReq.getCountry());
                                                                     driver.setPostCode(driverReq.getPostCode());
                                                                    driver.setEmergencyContactNo(driverReq.getEmergencyContactNo());
                                                                     driver.setLatitude(driverReq.getLatitude());
                                                                      driver.setLongitude(driverReq.getLongitude());

								Driver driverRes = driverRepository.save(driver);

								if (driverRes != null && driverRes.getId() > 0) {
									jsonobj.put("responsecode", 200);
									jsonobj.put("message", "Driver updation has been done");
									jsonobj.put("timestamp", new Date());
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj.writeValueAsString(driverRes);
									jsonobj.put("data", new JSONObject(Detail));
									kafkaService.sendDriverForUpdate(driverRes);
									Users user = userRepository.findByUserCode(driverRes.getDriverCode());
									if (user != null && user.getId() > 0) {
										user.setName(driverRes.getName());
										user.setEmail(driverRes.getEmailId());
										Users userres = userRepository.save(user);
										if (userres != null && userres.getId() > 0) {
											kafkaService.sendUpdateUser(userres);

											try {

												Notification notification = new Notification();

												String bodyContent = "Dear Operator" + ",Driver has been updated."
														+ "Driver Name : " + driverRes.getName();
												shortMessage = "Driver has been updated.";

												notification.setUserCode(driverRes.getOperatorCode());
												notification.setMessage(bodyContent);
												notification.setShortMessage(shortMessage);
												notification.setIpAddress(ip);
												notification.setIsRead(Boolean.FALSE);

												notificationService.saveNotification(notification);
                                                                                                //for push notification
                                                                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);

											}

											catch (Exception e) {
												e.printStackTrace();
											}

										}
									}
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("message", "Driver updation has been failed.");
									jsonobj.put("timestamp", new Date());

								}
//							} else {
//								jsonobj.put("responsecode", 400);
//								jsonobj.put("timestamp", new Date());
//								jsonobj.put("message",
//										"Please check your email format.");
//							}
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("message", "Driver ID is not valid.");
								jsonobj.put("timestamp", new Date());
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Operator Code not found.");
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Organization Code not found.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByDriverCode(String driverCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Driver driverlst = driverRepository.getDriverByDriverCode(driverCode);
			if (driverlst != null && driverlst.getId() > 0) {
				driverlst.setIsDeleted(true);
				Driver driverRes = driverRepository.save(driverlst);
				if (driverRes != null && driverRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Driver deleted successfully.");
					kafkaService.sendDriverForUpdate(driverRes);

					try {

						Notification notification = new Notification();

						String bodyContent = "Dear Operator" + ",Driver has been deleted." + "Driver Name : "
								+ driverRes.getName();
						shortMessage = "Driver has been deleted.";

						notification.setUserCode(driverRes.getOperatorCode());
						notification.setMessage(bodyContent);
						notification.setShortMessage(shortMessage);
						notification.setIsRead(Boolean.FALSE);

						notificationService.saveNotification(notification);
                                                //for push notification
                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);

					}

					catch (Exception e) {
						e.printStackTrace();
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByDriverCode(List<String> driverCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String driverCode : driverCodeList) {
				if (driverCode != null && driverCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					driverCode = driverCode.trim();

					Driver driverlst = driverRepository.getDriverByDriverCode(driverCode);
					if (driverlst != null && driverlst.getId() > 0) {
						driverlst.setIsDeleted(true);
						Driver driverRes = driverRepository.save(driverlst);
						if (driverRes != null && driverRes.getId() > 0) {
							kafkaService.sendDriverForUpdate(driverRes);
							try {

								Notification notification = new Notification();

								String bodyContent = "Dear Operator" + ",Driver has been deleted." + "Driver Name : "
										+ driverRes.getName();
								shortMessage = "Driver has been deleted.";

								notification.setUserCode(driverRes.getOperatorCode());
								notification.setMessage(bodyContent);
								notification.setShortMessage(shortMessage);
								notification.setIsRead(Boolean.FALSE);

								notificationService.saveNotification(notification);
                                                                //for push notification
                                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);

							}

							catch (Exception e) {
								e.printStackTrace();
							}
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", driverCode);
							jsonobj.put("message", "Driver deleted successfully.");

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", driverCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", driverCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

        
	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				DriverSpecificationsBuilder builder = new DriverSpecificationsBuilder();
				Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
				}

				Specification<Driver> spec = builder.build();
				if (spec != null) {
					List<Driver> Driverlst = driverRepository.findAll(spec);
					if (Driverlst != null && Driverlst.size() > 0) {
						for (Driver act : Driverlst) {
							if (act.getIsDeleted() != null && act.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(act);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("driver", new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveDriver(DriverRequest driverReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (driverReq != null) {
				// GigflexResponse driverResponse = new GigflexResponse();

				if (driverReq.getName() != null && driverReq.getName().trim().length() > 0
						&& driverReq.getOperatorCode() != null && driverReq.getOperatorCode().trim().length() > 0) {

					Organization org = orgDao.findByOrganizationCode(driverReq.getOrganizationCode().trim());

					if (org != null && org.getId() > 0) {
						Operator operator = opertaorRepository
								.getOperatorByOperatorCode(driverReq.getOperatorCode().trim());
						if (operator != null && operator.getId() > 0) {

//						if (GigflexUtility.emailPatternValidation(driverReq
//								.getEmailId()) == true) {

							Driver driver = new Driver();

							driver.setName(driverReq.getName().trim());
							driver.setEmailId(driverReq.getEmailId().trim());
							driver.setContactNumber(driverReq.getContactNumber());
							// driver.setFleetSize(0);
							driver.setCallsign(driverReq.getCallsign());
							driver.setCountryCode(driverReq.getCountryCode());
							driver.setOrganizationCode(driverReq.getOrganizationCode().trim());
							driver.setOperatorCode(driverReq.getOperatorCode().trim());
							driver.setApproveStatus(Boolean.FALSE);
                                                        driver.setDefaultVehicleCode(driverReq.getDefaultVehicleCode()); 
							driver.setIpAddress(ip);

							Driver driverRes = driverRepository.save(driver);

							if (driverRes != null && driverRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Driver has been added successfully.");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(driverRes);
								jsonobj.put("data", new JSONObject(Detail));
								kafkaService.sendDriverForSave(driverRes);
								try {
									String ress = sendLinkToDriverForCreateCredential(driverRes.getDriverCode());
								} catch (Exception ee) {
									ee.printStackTrace();
								}

								try {

									Notification notification = new Notification();

									String bodyContent = "Dear Operator" + ",Driver has been added." + "Driver Name : "
											+ driverRes.getName();
									shortMessage = "Driver has been added.";

									notification.setUserCode(driverRes.getOperatorCode());
									notification.setMessage(bodyContent);
									notification.setShortMessage(shortMessage);
									notification.setIsRead(Boolean.FALSE);
									notification.setIpAddress(ip);

								        notificationService.saveNotification(notification);
                                                                        //for push notification
                                                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);

								}

								catch (Exception e) {
									e.printStackTrace();
								}

							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Failed");
							}
//						} else {
//							jsonobj.put("responsecode", 400);
//							jsonobj.put("timestamp", new Date());
//							jsonobj.put("message",
//									"Please check your email format.");
//						}

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Operator Code not found.");
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Organization Code not found.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public Driver getUserEmail(String userEmail) {
		return driverRepository.findByEmail(userEmail);
	}

	@Override
	public String sendRegistrationLinkTODriverByOperator(String operatorCode, String driverEmail,
			String organizationCode) {
		String res = "";
		String mailRes = "false";
		try {
			if (operatorCode != null && operatorCode.trim().length() > 0 && driverEmail.trim().length() > 0
					&& organizationCode != null && organizationCode.trim().length() > 0) {
				Operator operator = opertaorRepository.getOperatorByOperatorCodeAndorganizationCode(operatorCode,
						organizationCode);
				Organization organization = organizationRepository.findByOrganizationCode(organizationCode);
				DriverRegistrationOTPDetail driverRegistrationOTPDetail = new DriverRegistrationOTPDetail();
				driverRegistrationOTPDetail.setEmailID(driverEmail);
				driverRegistrationOTPDetail.setRegistrationStatus(Boolean.FALSE);
				DriverRegistrationOTPDetail registrationOTPDetail = driverRegistrationOTPRepository
						.save(driverRegistrationOTPDetail);
				if (registrationOTPDetail != null && registrationOTPDetail.getId() > 0) {
					if (operator != null && organization != null) {
						byte[] encoded1 = Base64.getEncoder().encode(operator.getOperatorCode().getBytes());
						String tok = new String(encoded1);

						byte[] encoded2 = Base64.getEncoder().encode(organization.getOrganizationCode().getBytes());
						String tok1 = new String(encoded2);

						byte[] encoded3 = Base64.getEncoder().encode(registrationOTPDetail.getEmailID().getBytes());
						String tok2 = new String(encoded3);

						byte[] encoded4 = Base64.getEncoder().encode(registrationOTPDetail.getTokenID().getBytes());
						String tok3 = new String(encoded4);

						String url = mailUrl + "?tok=" + tok + "&tok1=" + tok1 + "&tok2=" + tok2 + "&tok3=" + tok3;
						String bodyContent = "Dear Candidate" + ",<br><br> ";
						bodyContent += mailBody;
						bodyContent += "<br><br><a href='" + url + "' target='_blank'>" + url + "</a>";
						String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
						Map<String, String> map = new HashMap<>();
						map.put("to", driverEmail);
						map.put("subject", subject);
						map.put("body", encodeURL);
						try {
							RestTemplate restTemplate = new RestTemplate();
							ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL, String.class,
									map);
							mailRes = response.getBody();
							if (mailRes.equalsIgnoreCase("true")) {
								kafkaService.sendDriverRegistrationOTP(registrationOTPDetail);
								GigflexResponse derr = new GigflexResponse(200, new Date(),
										"Registration link is successfully sent to driver");
								res = derr.toString();
							} else {
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Sending registration link has been failed.");
								res = derr.toString();
							}
						} catch (Exception ex) {
							ex.printStackTrace();
							GigflexResponse derr = new GigflexResponse(500, new Date(),
									"Exception occurred at sending email");
							res = derr.toString();
						}
					} else {
						GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Operator or organization code is not found");
						return derr.toString();
					}
				} else {
					GigflexResponse derr = new GigflexResponse(400, new Date(),
							"DriverRegistration OTP Detail is not save");
					return derr.toString();
				}

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Operator Code or Driver email can not be null");
				return derr.toString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}

		return res;

	}

	@Override
	public String getDriverDetailByOperatorCode(String operatorCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (operatorCode != null && operatorCode.trim().length() > 0) {

				List<Object> objlst = driverRepository.findDriverByOperatorCode(operatorCode);
				List<DriverResponse> maplst = new ArrayList<DriverResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {
							List<DriverVehicleDetail> vdData = new ArrayList<DriverVehicleDetail>();

							DriverResponse dro = new DriverResponse();

							Driver data = (Driver) arr[0];
							dro.setId(data.getId());
							dro.setDriverCode(data.getDriverCode());
							dro.setName(data.getName());
							dro.setContactNumber(data.getContactNumber());
							dro.setCountryCode(data.getCountryCode());

							dro.setEmailId(data.getEmailId());
							// dro.setFleetSize(data.getFleetSize());
							dro.setCallsign(data.getCallsign());
							dro.setOperatorCode(data.getOperatorCode());
							dro.setOrganizationCode(data.getOrganizationCode());
							dro.setOperatorName((String) arr[1]);
							dro.setOrganizationName((String) arr[2]);
							dro.setDriverImage(data.getDriverImage());
                                                        dro.setDefaultVehicleCode(data.getDefaultVehicleCode());
							if (data.getDriverCode() != null && data.getDriverCode().length() > 0) {
								// dro.setVehicleCode(data.getVehicleCode());
								List<VehicleDetail> vd = vehicleDetailRepository
										.getDriverVehicleDetailByVehicleCode(data.getDriverCode());
								if (!vd.isEmpty() && vd.size() > 0) {
									DriverVehicleDetail driverDetail = new DriverVehicleDetail();
									for (VehicleDetail vehicleDetails : vd) {
										driverDetail.setVehicleCode(vehicleDetails.getVehicleCode());
										//driverDetail.setVehicleName(vehicleDetails.getVehicleName());
										vdData.add(driverDetail);
									}
									dro.setDriverVehicleDetails(vdData);
								}
							}
							List<DriverDocument> ddexplst = driverDocumentRepository
									.getExpiredDriverDocumentByDriverCode(data.getDriverCode(), new Date());
							if (ddexplst != null && ddexplst.size() > 0) {
								dro.setDocExpiryStatus(Boolean.TRUE);
							} else {
								dro.setDocExpiryStatus(Boolean.FALSE);
							}
							maplst.add(dro);

						}
					}
					if (maplst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(maplst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String verifyDriverByDriverCode(String driverCode, Boolean approveStatus) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (driverCode != null && driverCode.trim().length() > 0 && approveStatus != null) {
				Driver driver = driverRepository.getDriverByDriverCode(driverCode);
				if (driver != null && driver.getId() > 0) {
					driver.setApproveStatus(Boolean.TRUE);
					Driver driverAfterUpdateStatus = driverRepository.save(driver);
					if (driverAfterUpdateStatus != null && driverAfterUpdateStatus.getId() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(driverAfterUpdateStatus);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
						
						
						try {

							Notification notification = new Notification();

							String bodyContent = "Dear Operator"
									+ ",Driver verified successfully."
									+ "Driver Name : " + driverAfterUpdateStatus.getName();
							shortMessage = "Driver verified successfully.";

							notification.setUserCode(driverAfterUpdateStatus.getOperatorCode());
							notification.setMessage(bodyContent);
//							notification.setUserType("All");
							notification.setShortMessage(shortMessage);
							notification.setIsRead(Boolean.FALSE);

							notificationService.saveNotification(notification);
                                                        //for push notification
                                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);

						}

						catch (Exception e) {
							e.printStackTrace();
						}
					}
					res = jsonobj.toString();
				} else {
					GigflexResponse derr = new GigflexResponse(400, new Date(), "Driver is not found");
					return derr.toString();
				}
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Driver Code and approve status can not be null");
				return derr.toString();
			}

		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public String sendLinkToDriverForCreateCredential(String driverCode) {
		String res = "";
		String mailRes = "false";
		try {
			if (driverCode != null && driverCode.trim().length() > 0) {
				Driver driver = driverRepository.getDriverByDriverCode(driverCode);
                                
                                
				if (driver != null && driver.getId() > 0 && driver.getDriverCode() != null
						&& driver.getEmailId() != null) {
                                    
                                    Users usr= userRepository.findByEmailID(driver.getEmailId());
                                    
                                    if(usr != null)
                                    {
                                        GigflexResponse derr = new GigflexResponse(409, new Date(), "Driver already exist");
					return derr.toString();                                        
                                    }
                                    
                                    
					byte[] encoded1 = Base64.getEncoder().encode(driver.getDriverCode().getBytes());
					String tok = new String(encoded1);
					String url = credentialMailUrl + "?tok=" + tok;
					String bodyContent = "Dear " + driver.getName() + ",<br><br> ";
					bodyContent += credentialMailBody;
					bodyContent += "<br><br><a href='" + url + "' target='_blank'>" + " Credential Link" + "</a>";
					String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
					Map<String, String> map = new HashMap<>();
					map.put("to", driver.getEmailId());
					map.put("subject", credentialSubject);
					map.put("body", encodeURL);
					try {
						RestTemplate restTemplate = new RestTemplate();
						ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL, String.class, map);
						mailRes = response.getBody();
						if (mailRes.equalsIgnoreCase("true")) {
							GigflexResponse derr = new GigflexResponse(200, new Date(),
									"Create credential link is successfully sent to driver.");
							res = derr.toString();
						} else {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Sending create credential link has been failed.");
							res = derr.toString();
						}
					} catch (Exception ex) {
						ex.printStackTrace();
						GigflexResponse derr = new GigflexResponse(500, new Date(),
								"Exception occurred at sending email in sendLinkToDriverForCreateCredential");
						res = derr.toString();
					}

				} else {
					GigflexResponse derr = new GigflexResponse(400, new Date(), "Driver Code is not exit");
					return derr.toString();
				}

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Driver Code can not be null");
				return derr.toString();
			}
		} catch (Exception e) {

		}

		return res;

	}

	@Override
	public String getDriverDetailByOperatorCodeByPage(String operatorCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {

				if (operatorCode != null && operatorCode.trim().length() > 0) {
					Pageable pageableRequest = PageRequest.of(page, limit);
					int count = 0;
					List<Object> objlstCnt = driverRepository.findDriverByOperatorCode(operatorCode);
					if (objlstCnt != null && objlstCnt.size() > 0) {
						count = objlstCnt.size();
					}
					List<Object> objlst = driverRepository.findDriverByOperatorCode(operatorCode, pageableRequest);
					List<DriverResponse> maplst = new ArrayList<DriverResponse>();
					if (objlst != null && objlst.size() > 0) {
						for (int i = 0; i < objlst.size(); i++) {
							Object[] arr = (Object[]) objlst.get(i);
							if (arr.length >= 3) {
								List<DriverVehicleDetail> vdData = new ArrayList<DriverVehicleDetail>();

								DriverResponse dro = new DriverResponse();

								Driver data = (Driver) arr[0];
								dro.setId(data.getId());
								dro.setDriverCode(data.getDriverCode());
								dro.setName(data.getName());
								dro.setContactNumber(data.getContactNumber());
								dro.setCountryCode(data.getCountryCode());

								dro.setEmailId(data.getEmailId());
								// dro.setFleetSize(data.getFleetSize());
								dro.setCallsign(data.getCallsign());
								dro.setOperatorCode(data.getOperatorCode());
								dro.setOrganizationCode(data.getOrganizationCode());
								dro.setOperatorName((String) arr[1]);
								dro.setOrganizationName((String) arr[2]);
								dro.setDriverImage(data.getDriverImage());
                                                                dro.setDefaultVehicleCode(data.getDefaultVehicleCode()); 
								if (data.getDriverCode() != null && data.getDriverCode().length() > 0) {
									// dro.setVehicleCode(data.getVehicleCode());
									List<VehicleDetail> vd = vehicleDetailRepository
											.getDriverVehicleDetailByVehicleCode(data.getDriverCode());
									if (!vd.isEmpty() && vd.size() > 0) {
										DriverVehicleDetail driverDetail = new DriverVehicleDetail();
										for (VehicleDetail vehicleDetails : vd) {
											driverDetail.setVehicleCode(vehicleDetails.getVehicleCode());
											//driverDetail.setVehicleName(vehicleDetails.getVehicleName());
											vdData.add(driverDetail);
										}
										dro.setDriverVehicleDetails(vdData);
									}
								}
								List<DriverDocument> ddexplst = driverDocumentRepository
										.getExpiredDriverDocumentByDriverCode(data.getDriverCode(), new Date());
								if (ddexplst != null && ddexplst.size() > 0) {
									dro.setDocExpiryStatus(Boolean.TRUE);
								} else {
									dro.setDocExpiryStatus(Boolean.FALSE);
								}
								maplst.add(dro);

							}
						}
						if (maplst.size() > 0) {
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(maplst);
							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("count", count);
							jsonobj.put("data", new JSONArray(Detail));
						} else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("message", "Record Not Found");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Input data is not valid.");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDriverByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (organizationCode != null && organizationCode.trim().length() > 0) {

				List<Object> objlst = driverRepository.findDriverByOrganizationCode(organizationCode);
				List<DriverResponse> maplst = new ArrayList<DriverResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {
							List<DriverVehicleDetail> vdData = new ArrayList<DriverVehicleDetail>();

							DriverResponse dro = new DriverResponse();

							Driver data = (Driver) arr[0];
							dro.setId(data.getId());
							dro.setDriverCode(data.getDriverCode());
							dro.setName(data.getName());
							dro.setContactNumber(data.getContactNumber());
							dro.setCountryCode(data.getCountryCode());

							dro.setEmailId(data.getEmailId());
							// dro.setFleetSize(data.getFleetSize());
							dro.setCallsign(data.getCallsign());
							dro.setOperatorCode(data.getOperatorCode());
							dro.setOrganizationCode(data.getOrganizationCode());
							dro.setOperatorName((String) arr[1]);
							dro.setOrganizationName((String) arr[2]);
							dro.setDriverImage(data.getDriverImage());
                                                        dro.setDefaultVehicleCode(data.getDefaultVehicleCode()); 
							if (data.getDriverCode() != null && data.getDriverCode().length() > 0) {
								// dro.setVehicleCode(data.getVehicleCode());
								List<VehicleDetail> vd = vehicleDetailRepository
										.getDriverVehicleDetailByVehicleCode(data.getDriverCode());
								if (!vd.isEmpty() && vd.size() > 0) {
									DriverVehicleDetail driverDetail = new DriverVehicleDetail();
									for (VehicleDetail vehicleDetails : vd) {
										driverDetail.setVehicleCode(vehicleDetails.getVehicleCode());
										//driverDetail.setVehicleName(vehicleDetails.getVehicleName());
										vdData.add(driverDetail);
									}
									dro.setDriverVehicleDetails(vdData);
								}
							}
							List<DriverDocument> ddexplst = driverDocumentRepository
									.getExpiredDriverDocumentByDriverCode(data.getDriverCode(), new Date());
							if (ddexplst != null && ddexplst.size() > 0) {
								dro.setDocExpiryStatus(Boolean.TRUE);
							} else {
								dro.setDocExpiryStatus(Boolean.FALSE);
							}
							maplst.add(dro);

						}
					}
					if (maplst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(maplst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDriverByOrgCodeByPage(String organizationCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {

				if (organizationCode != null && organizationCode.trim().length() > 0) {
					List<Object> objlstCheck = driverRepository.findDriverByOrganizationCode(organizationCode);
					Integer count = objlstCheck.size();
					Pageable pageableRequest = PageRequest.of(page, limit);

					List<Object> objlst = driverRepository.findDriverByOrganizationByPage(organizationCode,
							pageableRequest);
					List<DriverResponse> maplst = new ArrayList<DriverResponse>();
					if (objlst != null && objlst.size() > 0) {
						for (int i = 0; i < objlst.size(); i++) {
							Object[] arr = (Object[]) objlst.get(i);
							if (arr.length >= 3) {
								List<DriverVehicleDetail> vdData = new ArrayList<DriverVehicleDetail>();

								DriverResponse dro = new DriverResponse();

								Driver data = (Driver) arr[0];
								dro.setId(data.getId());
								dro.setDriverCode(data.getDriverCode());
								dro.setName(data.getName());
								dro.setContactNumber(data.getContactNumber());
								dro.setCountryCode(data.getCountryCode());

								dro.setEmailId(data.getEmailId());
								// dro.setFleetSize(data.getFleetSize());
								dro.setCallsign(data.getCallsign());
								dro.setOperatorCode(data.getOperatorCode());
								dro.setOrganizationCode(data.getOrganizationCode());
								dro.setOperatorName((String) arr[1]);
								dro.setOrganizationName((String) arr[2]);
								dro.setDriverImage(data.getDriverImage());
                                                                dro.setDefaultVehicleCode(data.getDefaultVehicleCode());
								if (data.getDriverCode() != null && data.getDriverCode().length() > 0) {
									// dro.setVehicleCode(data.getVehicleCode());
									List<VehicleDetail> vd = vehicleDetailRepository
											.getDriverVehicleDetailByVehicleCode(data.getDriverCode());
									if (!vd.isEmpty() && vd.size() > 0) {
										DriverVehicleDetail driverDetail = new DriverVehicleDetail();
										for (VehicleDetail vehicleDetails : vd) {
											driverDetail.setVehicleCode(vehicleDetails.getVehicleCode());
											//driverDetail.setVehicleName(vehicleDetails.getVehicleName());
											vdData.add(driverDetail);
										}
										dro.setDriverVehicleDetails(vdData);
									}
								}

								List<DriverDocument> ddexplst = driverDocumentRepository
										.getExpiredDriverDocumentByDriverCode(data.getDriverCode(), new Date());
								if (ddexplst != null && ddexplst.size() > 0) {
									dro.setDocExpiryStatus(Boolean.TRUE);
								} else {
									dro.setDocExpiryStatus(Boolean.FALSE);
								}
								maplst.add(dro);

							}
						}
						if (maplst.size() > 0) {
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(maplst);
							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("count", count);

							jsonobj.put("data", new JSONArray(Detail));
						} else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("message", "Record Not Found");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Input data is not valid.");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String assignVehicleToDriver(DriverVehicleRequest driverVReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			VehicleDetail vd = vehicleDetailRepository.getVehicleDetailByVehicleCode(driverVReq.getVehicleCode());

			if (vd != null && vd.getId() > 0) {

				Driver driverlst = driverRepository.getDriverByDriverCode(driverVReq.getDriverCode());
				if (driverlst != null && driverlst.getId() > 0) {

					VehicleDriverMapping vehDriver = vehDriverDao.getVehicleDriverMappingByDriverCodeAndVehicleCode(
							driverVReq.getDriverCode(), driverVReq.getVehicleCode());

					if (vehDriver != null && vehDriver.getId() > 0) {
						jsonobj.put("responsecode", 409);
						jsonobj.put("message", "Record Already exists!");
						jsonobj.put("timestamp", new Date());
					} else {
						VehicleDriverMapping vehicleDriver = new VehicleDriverMapping();
						vehicleDriver.setVehicleCode(driverVReq.getVehicleCode());
						vehicleDriver.setDriverCode(driverVReq.getDriverCode());
						vehicleDriver.setIpAddress(ip);
//								driverlst.setVehicleCode(driverVReq.getVehicleCode());
////                                                                driverlst.setIpAddress(ip);
//
//								Driver driverRes = driverRepository.save(driverlst);

						VehicleDriverMapping driverRes = vehDriverDao.save(vehicleDriver);

						if (driverRes != null && driverRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Vehicle has been assigned to driver");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(driverRes);
							jsonobj.put("data", new JSONObject(Detail));
//                                                                     kafkaService.sendDriverForUpdate(driverRes);
//                                                                    try {
//                                                                        List<VehicleDriverMapping> mvlst = vehDriverDao.getVehicleDriverMappingByDriverCode(driverlst.getDriverCode());
//                                                                        if (mvlst != null && mvlst.size() > 0) {
//                                                                            driverlst.setFleetSize(mvlst.size());
//                                                                        } else {
//                                                                            driverlst.setFleetSize(0);
//                                                                        }
//                                                                        driverRepository.save(driverlst);
//                                                                    } catch (Exception exp) {
//                                                                        exp.printStackTrace();
//                                                                    }

									try {

										Notification notification = new Notification();

										String bodyContent = "Dear Operator"
												+ ",Vehicle has been assign to driver."
												+ "Driver Name : " + driverlst.getName();
										shortMessage = "Vehicle has been assign to driver.";

										notification.setUserCode(driverlst.getOperatorCode());
										notification.setMessage(bodyContent);
										notification.setShortMessage(shortMessage);
										notification.setIsRead(Boolean.FALSE);

										notificationService.saveNotification(notification);
                                                                                //for push notification
                                                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
										
									}

									catch (Exception e) {
										e.printStackTrace();
									}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Assign activity has been failed.");
							jsonobj.put("timestamp", new Date());

						}
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Driver code is not valid.");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Vehicle code is not valid.");
			}

			res = jsonobj.toString();

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String UnassignVehicleToDriver(String driverCode, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

//			VehicleDetail vd = vehicleDetailRepository
//					.getVehicleDetailByVehicleCode(driverVReq.getVehicleCode());
//
//			if (vd != null && vd.getId() > 0) {

				Driver driverlst = driverRepository
						.getDriverByDriverCode(driverCode);
				
				if(driverlst != null && driverlst.getId() > 0) {
//
			List<VehicleDriverMapping> vehicleList = vehDriverDao.getVehicleDriverMappingByDriverCode(driverCode);
			if (vehicleList != null && vehicleList.size() > 0) {
				Boolean status = false;
				for (VehicleDriverMapping vehicle : vehicleList) {
					vehicle.setIsDeleted(true);
					vehicle.setIpAddress(ip);
//					driverlst.setVehicleCode(null);
//					Driver driverRes = driverRepository.save(driverlst);
					VehicleDriverMapping driverRes = vehDriverDao.save(vehicle);
					status = true;

				}
				if (status) {

//                                            try {
//                                                Driver dr = driverRepository.getDriverByDriverCode(driverCode);
//                                                dr.setFleetSize(0);
//                                                driverRepository.save(dr);
//                                            } catch (Exception exp) {
//                                                exp.printStackTrace();
//                                            }

					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Vehicle has been Unassigned to driver");
					jsonobj.put("timestamp", new Date());
					
					try {

						Notification notification = new Notification();

						String bodyContent = "Dear Operator" + ",All vehicles has been unassign to driver." + "Driver Name : "
								+ driverlst.getName();
						shortMessage = "All vehicles has been unassign to driver.";

						notification.setUserCode(driverlst.getOperatorCode());
						notification.setMessage(bodyContent);
						notification.setShortMessage(shortMessage);
						notification.setIsRead(Boolean.FALSE);
						notification.setIpAddress(ip);

                                                notificationService.saveNotification(notification);
                                               //for push notification
                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);

					}

					catch (Exception e) {
						e.printStackTrace();
					}

//						kafkaService.sendDriverForUpdate(driverRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Unassigned activity has been failed.");
					jsonobj.put("timestamp", new Date());

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record not found.");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Driver code is not valid.");
			}

			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDriverByVehicleTypeCode(String vehicleCode) {
		String res = "";
		DriverVehicleResponse dro = null;
		try {
			JSONObject jsonobj = new JSONObject();
			if (vehicleCode != null && vehicleCode.trim().length() > 0) {

				List<Object> objlst = driverRepository.getDriverByVehicleTypeCode(vehicleCode);
//			List<DriverVehicleResponse> maplst = new ArrayList<DriverVehicleResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {

							dro = new DriverVehicleResponse();

							Driver data = (Driver) arr[0];
							dro.setId(data.getId());
							dro.setDriverCode(data.getDriverCode());
							dro.setName(data.getName());
							dro.setContactNumber(data.getContactNumber());
							dro.setCountryCode(data.getCountryCode());

							dro.setEmailId(data.getEmailId());
							// dro.setFleetSize(data.getFleetSize());
							dro.setCallsign(data.getCallsign());
							dro.setOperatorCode(data.getOperatorCode());
							dro.setOrganizationCode(data.getOrganizationCode());
							dro.setOperatorName((String) arr[1]);
							dro.setOrganizationName((String) arr[2]);
							dro.setDriverImage(data.getDriverImage());
                                                        dro.setDefaultVehicleCode(data.getDefaultVehicleCode());
                                                        
							if (vehicleCode != null && vehicleCode.length() > 0) {

								VehicleDetail vd = vehicleDetailRepository.getVehicleDetailByVehicleCode(vehicleCode);
								if (vd != null && vd.getId() > 0) {
									dro.setVehicleCode(vd.getVehicleCode());
									//dro.setVehicleName(vd.getVehicleName());
								}
							}
							List<DriverDocument> ddexplst = driverDocumentRepository
									.getExpiredDriverDocumentByDriverCode(data.getDriverCode(), new Date());
							if (ddexplst != null && ddexplst.size() > 0) {
								dro.setDocExpiryStatus(Boolean.TRUE);
							} else {
								dro.setDocExpiryStatus(Boolean.FALSE);
							}
//						maplst.add(dro);

						}
					}
					if (dro != null) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(dro);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDriverByVehicleTypeCodeAndOrganizationCode(String vehicleCode, String organizationCode) {
		String res = "";
		DriverVehicleResponse dro = null;
		try {
			JSONObject jsonobj = new JSONObject();
			if (vehicleCode != null && vehicleCode.trim().length() > 0 && organizationCode != null
					&& organizationCode.trim().length() > 0) {

				List<Object> objlst = driverRepository.getDriverByVehicleTypeCodeAndOrganizationCode(vehicleCode,
						organizationCode);
//			List<DriverResponse> maplst = new ArrayList<DriverResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {

							dro = new DriverVehicleResponse();

							Driver data = (Driver) arr[0];
							dro.setId(data.getId());
							dro.setDriverCode(data.getDriverCode());
							dro.setName(data.getName());
							dro.setContactNumber(data.getContactNumber());
							dro.setCountryCode(data.getCountryCode());

							dro.setEmailId(data.getEmailId());
							// dro.setFleetSize(data.getFleetSize());
							dro.setCallsign(data.getCallsign());
							dro.setOperatorCode(data.getOperatorCode());
							dro.setOrganizationCode(data.getOrganizationCode());
							dro.setOperatorName((String) arr[1]);
							dro.setOrganizationName((String) arr[2]);
							dro.setDriverImage(data.getDriverImage());
                                                        dro.setDefaultVehicleCode(data.getDefaultVehicleCode());
							if (vehicleCode != null && vehicleCode.length() > 0) {

								VehicleDetail vd = vehicleDetailRepository.getVehicleDetailByVehicleCode(vehicleCode);
								if (vd != null && vd.getId() > 0) {
									dro.setVehicleCode(vd.getVehicleCode());
									//dro.setVehicleName(vd.getVehicleName());
								}
							}
							List<DriverDocument> ddexplst = driverDocumentRepository
									.getExpiredDriverDocumentByDriverCode(data.getDriverCode(), new Date());
							if (ddexplst != null && ddexplst.size() > 0) {
								dro.setDocExpiryStatus(Boolean.TRUE);
							} else {
								dro.setDocExpiryStatus(Boolean.FALSE);
							}
//						maplst.add(dro);

						}
					}
					if (dro != null) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(dro);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDriverByVehicleTypeCode(String vehicleCode, int page, int limit) {
		String res = "";
		DriverVehicleResponse dro = null;
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {

				if (vehicleCode != null && vehicleCode.trim().length() > 0) {

					List<Object> objlstCheck = driverRepository.getDriverByVehicleTypeCode(vehicleCode);
					Integer count = objlstCheck.size();
					Pageable pageableRequest = PageRequest.of(page, limit);
					List<Object> objlst = driverRepository.getDriverByVehicleTypeCode(vehicleCode, pageableRequest);
//			List<DriverResponse> maplst = new ArrayList<DriverResponse>();
					if (objlst != null && objlst.size() > 0) {
						for (int i = 0; i < objlst.size(); i++) {
							Object[] arr = (Object[]) objlst.get(i);
							if (arr.length >= 3) {

								dro = new DriverVehicleResponse();

								Driver data = (Driver) arr[0];
								dro.setId(data.getId());
								dro.setDriverCode(data.getDriverCode());
								dro.setName(data.getName());
								dro.setContactNumber(data.getContactNumber());
								dro.setCountryCode(data.getCountryCode());

								dro.setEmailId(data.getEmailId());
								// dro.setFleetSize(data.getFleetSize());
								dro.setCallsign(data.getCallsign());
								dro.setOperatorCode(data.getOperatorCode());
								dro.setOrganizationCode(data.getOrganizationCode());
								dro.setOperatorName((String) arr[1]);
								dro.setOrganizationName((String) arr[2]);
								dro.setDriverImage(data.getDriverImage());
                                                                dro.setDefaultVehicleCode(data.getDefaultVehicleCode());
								if (vehicleCode != null && vehicleCode.length() > 0) {

									VehicleDetail vd = vehicleDetailRepository
											.getVehicleDetailByVehicleCode(vehicleCode);
									if (vd != null && vd.getId() > 0) {
										dro.setVehicleCode(vd.getVehicleCode());
										//dro.setVehicleName(vd.getVehicleName());
									}
								}
								List<DriverDocument> ddexplst = driverDocumentRepository
										.getExpiredDriverDocumentByDriverCode(data.getDriverCode(), new Date());
								if (ddexplst != null && ddexplst.size() > 0) {
									dro.setDocExpiryStatus(Boolean.TRUE);
								} else {
									dro.setDocExpiryStatus(Boolean.FALSE);
								}
//						maplst.add(dro);

							}
						}
						if (dro != null) {
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(dro);
							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("count", count);

							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("message", "Record Not Found");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Input data is not valid.");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDriverByVehicleTypeCodeAndOrganizationCode(String vehicleCode, String organizationCode, int page,
			int limit) {
		String res = "";
		DriverVehicleResponse dro = null;
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {

				if (vehicleCode != null && vehicleCode.trim().length() > 0 && organizationCode != null
						&& organizationCode.trim().length() > 0) {
					List<Object> objlstCheck = driverRepository
							.getDriverByVehicleTypeCodeAndOrganizationCode(vehicleCode, organizationCode);
					Integer count = objlstCheck.size();

					Pageable pageableRequest = PageRequest.of(page, limit);
					List<Object> objlst = driverRepository.getDriverByVehicleTypeCodeAndOrganizationCode(vehicleCode,
							organizationCode, pageableRequest);
//			List<DriverResponse> maplst = new ArrayList<DriverResponse>();
					if (objlst != null && objlst.size() > 0) {
						for (int i = 0; i < objlst.size(); i++) {
							Object[] arr = (Object[]) objlst.get(i);
							if (arr.length >= 3) {

								dro = new DriverVehicleResponse();

								Driver data = (Driver) arr[0];
								dro.setId(data.getId());
								dro.setDriverCode(data.getDriverCode());
								dro.setName(data.getName());
								dro.setContactNumber(data.getContactNumber());
								dro.setCountryCode(data.getCountryCode());

								dro.setEmailId(data.getEmailId());
								// dro.setFleetSize(data.getFleetSize());
								dro.setCallsign(data.getCallsign());
								dro.setOperatorCode(data.getOperatorCode());
								dro.setOrganizationCode(data.getOrganizationCode());
								dro.setOperatorName((String) arr[1]);
								dro.setOrganizationName((String) arr[2]);
								dro.setDriverImage(data.getDriverImage());
                                                                dro.setDefaultVehicleCode(data.getDefaultVehicleCode());
								if (vehicleCode != null && vehicleCode.length() > 0) {

									VehicleDetail vd = vehicleDetailRepository
											.getVehicleDetailByVehicleCode(vehicleCode);
									if (vd != null && vd.getId() > 0) {
										dro.setVehicleCode(vd.getVehicleCode());
										//dro.setVehicleName(vd.getVehicleName());
									}
								}
								List<DriverDocument> ddexplst = driverDocumentRepository
										.getExpiredDriverDocumentByDriverCode(data.getDriverCode(), new Date());
								if (ddexplst != null && ddexplst.size() > 0) {
									dro.setDocExpiryStatus(Boolean.TRUE);
								} else {
									dro.setDocExpiryStatus(Boolean.FALSE);
								}
//						maplst.add(dro);

							}
						}
						if (dro != null) {
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(dro);
							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("count", count);

							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("message", "Record Not Found");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Input data is not valid.");

				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String UnassignVehicleToDriverByVehicleAndDriverCode(String driverCode, String vehicleCode, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			
			Driver driverlst = driverRepository
					.getDriverByDriverCode(driverCode);
			
			if(driverlst != null && driverlst.getId() > 0) {

			VehicleDriverMapping vehicle = vehDriverDao.getVehicleDriverMappingByDriverCodeAndVehicleCode(driverCode,
					vehicleCode);
			if (vehicle != null && vehicle.getId() > 0) {

				vehicle.setIsDeleted(true);
				vehicle.setIpAddress(ip);

				VehicleDriverMapping driverRes = vehDriverDao.save(vehicle);

				if (driverRes != null && driverRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Vehicle has been Unassigned to driver");
					jsonobj.put("timestamp", new Date());
					
					try {

						Notification notification = new Notification();

						String bodyContent = "Dear Operator" + ",Vehicle has been unassign to driver." + "Driver Name : "
								+ driverlst.getName();
						shortMessage = "Vehicle has been unassign to driver.";

						notification.setUserCode(driverlst.getOperatorCode());
						notification.setMessage(bodyContent);
						notification.setShortMessage(shortMessage);
						notification.setIsRead(Boolean.FALSE);
						notification.setIpAddress(ip);

					        notificationService.saveNotification(notification);
                                                
                                                //for push notification
                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);

					}

					catch (Exception e) {
						e.printStackTrace();
					}

//                                              try {
//                                                Driver dr=driverRepository.getDriverByDriverCode(driverCode);
//                                                if(dr!=null && dr.getId()>0)
//                                                {
//                                                    if(dr.getFleetSize()!=null && dr.getFleetSize()>0)
//                                                    {
//                                                        dr.setFleetSize(dr.getFleetSize()-1);
//                                                    }
//                                                    else
//                                                    {
//                                                        dr.setFleetSize(0);
//                                                    }
//                                                    driverRepository.save(dr);
//                                                }
//                                            } catch (Exception exp) {
//                                                exp.printStackTrace();
//                                            }
//						kafkaService.sendDriverForUpdate(driverRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Unassigned activity has been failed.");
					jsonobj.put("timestamp", new Date());

				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record not found.");
				jsonobj.put("timestamp", new Date());
			}
			
		} else {
			jsonobj.put("responsecode", 400);
			jsonobj.put("timestamp", new Date());
			jsonobj.put("message", "Driver code is not valid.");
		}

			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

    @Override
    public String getDefaultVehicleDetailByDriverCode(String driverCode) {
        
        String res = "";
	DriverDefaultVehicleResponse ddv = null;	
		try {
			JSONObject jsonobj = new JSONObject();
			if (driverCode != null && driverCode.trim().length() > 0) {

				Object objlst = driverRepository.findDefaultVehicleDetailByDriverCode(driverCode);		
				if (objlst != null ) {
					
						Object[] arr = (Object[]) objlst;
						if (arr.length >= 2) {							

							ddv = new DriverDefaultVehicleResponse();

							Driver data = (Driver) arr[0];
                                                        VehicleDetail vd = (VehicleDetail) arr[1];							
							ddv.setDriverCode(data.getDriverCode());
							ddv.setDriverName(data.getName());
							ddv.setDefaultVehicleCode(data.getDefaultVehicleCode()); 
                                                        ddv.setVehicleDetail(vd); 
						}
					
					if (ddv != null) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(ddv);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    
    
    @Override
    public String updateDefaultVehicleByDriverCode(String drivercode, DefaultVehicleUpdateRequest defaultVehicleReq, String ip) {
       
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (defaultVehicleReq != null) {

				if (defaultVehicleReq.getDefaultVehicleCode()!= null && defaultVehicleReq.getDefaultVehicleCode().trim().length() > 0
						&& defaultVehicleReq.getDriverCode()!= null && defaultVehicleReq.getDriverCode().trim().length() > 0) {

                                    Driver driverlst = driverRepository.getDriverByDriverCode(drivercode);
                                    if (driverlst != null && driverlst.getId() > 0) {

                                            Driver driver = driverlst;
                                            driver.setDefaultVehicleCode(defaultVehicleReq.getDefaultVehicleCode());							  
                                            driver.setIpAddress(ip);

                                            Driver driverRes = driverRepository.save(driver);

                                            if (driverRes != null && driverRes.getId() > 0) {
                                                    jsonobj.put("responsecode", 200);
                                                    jsonobj.put("message", "Default vehicle updation has been done");
                                                    jsonobj.put("timestamp", new Date());
                                                    ObjectMapper mapperObj = new ObjectMapper();
                                                    String Detail = mapperObj.writeValueAsString(driverRes);
                                                    jsonobj.put("data", new JSONObject(Detail));							
                                            } else {
                                                    jsonobj.put("responsecode", 400);
                                                    jsonobj.put("message", "Default vehicle updation has been failed.");
                                                    jsonobj.put("timestamp", new Date());

                                            }
                                    } else {
                                            jsonobj.put("responsecode", 400);
                                            jsonobj.put("message", "Driver Code is not valid.");
                                            jsonobj.put("timestamp", new Date());
                                    }
						
					
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
        
    }
    
        @Override
     public String getAllDetailBydriverCode( String driverCode)
     {    
           String res="";
           try{
               DriverFullDetailRes dfdres=new DriverFullDetailRes();
              
               List<DriverDocsResponse>ddList =new ArrayList<>();
           JSONObject jsonobj = new JSONObject();
          Driver driver = driverRepository.getDriverByDriverCode(driverCode);
                            
          List<Object> objlst = driverDocumentRepository.getAllDriverDocumentByDriverCode(driverCode);
            if(driver!=null && driver.getId()>0)
            {
              String onlydate= GigflexConstants.saveDateWithoutTime;
                String  dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                  if(dateformat!=null && dateformat.trim().length()>0 )
                            {
                                onlydate=dateformat.trim();
                            }  
                dfdres.setName(driver.getName());
                dfdres.setLangauge(driver.getLanguage());
                if(driver.getDob()!=null){
                DateFormat dateFormat = new SimpleDateFormat(onlydate);      
                dfdres.setDob( dateFormat.format(driver.getDob()));
                }
                dfdres.setContectNo(driver.getContactNumber());
                dfdres.setEmergencyContectNo(driver.getEmergencyContactNo());
                dfdres.setAddress(driver.getAddress());
                dfdres.setCity(driver.getCity());
                dfdres.setPostCode(driver.getPostCode());
                dfdres.setCountry(driver.getCountry());
                dfdres.setLatitude(driver.getLatitude());
                dfdres.setLongitude(driver.getLongitude());
                dfdres.setEmail(driver.getEmailId());
                dfdres.setImage(driver.getDriverImage());
                if(driver.getApproveStatus()!=null){
                dfdres.setStatus(driver.getApproveStatus());
                }
                if(objlst!=null && objlst.size()>0)
                {
                    String timezoneCode = "";
                            TimeZoneDetail tz = null;
                            String timezone = "";
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;

                  timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.TimeZone);
                            tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            timezone = tz.getTimeZoneName(); 
                  String  timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                  
                  if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }  
                  for(int i=0;i<objlst.size();i++)
                {
                  Object []arr  = (Object[])objlst.get(i);
                  if(arr.length >= 3)
                  {
                    DriverDocument data = (DriverDocument) arr[0];
                    DriverDocsResponse ddr=new DriverDocsResponse();
                                               
                    String conDt = "";

						if (data.getDocExpiration() != null) {
//							TimeZoneDetail tz = driverDocumentRepository.getTimeZoneByDriverCode(data.getDriverCode());
						    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        Date docExpDate = data.getDocExpiration();
							docExpDate = GigflexDateUtil.getGMTtoLocationDate(docExpDate, timezone,dtFormat);
							conDt = GigflexDateUtil.convertDateToString(docExpDate,dtFormat);
                                                    }
                                                        
						}

                                                ddr.setDateFormat(dateformat);
                                                ddr.setTimeFormat(timeformat);
						ddr.setId(data.getId());
						ddr.setDriverDocumentCode(data.getDriverDocumentCode());
						ddr.setDocumentCode(data.getDocumentCode());
						
                                                ddr.setDocValue(data.getDocValue());
						ddr.setDocExpiration(conDt);

						ddr.setDocumentName((String) arr[1]);
                                                DocumentType dt=(DocumentType)arr[3];
                                                ddr.setDocumentType(dt.getDocumentTypeName());
                                                
                                                
                                      ddList.add(ddr);
                  }
//                  ddres.setId();
                }
                  dfdres.setDdList(ddList);
                }
                                                   jsonobj.put("responsecode", 200);
                                                    jsonobj.put("message", "Success");
                                                    jsonobj.put("timestamp", new Date());
                                                    ObjectMapper mapperObj = new ObjectMapper();
                                                    String Detail = mapperObj.writeValueAsString(dfdres);
                                                    jsonobj.put("data", new JSONObject(Detail));		
                
              
            }
            else
            {
                                        jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data not found");
            }
            res=jsonobj.toString();
           }catch(Exception ex)
           {
                       GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
           }
            return res;
     }
     
     
        @Override
  public String getPersonaldetailsTabsBydriverCode( String driverCode)
  {
     String res="";
      try{
            PersonalDetailTabRes pdtres=new PersonalDetailTabRes();
            Driver driver = driverRepository.getDriverByDriverCode(driverCode);
            JSONObject jsonobj = new JSONObject();
            if(driver!=null && driver.getId()>0)
            {
                 String  timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                    
              pdtres.setName(driver.getName());
              String onlydate= GigflexConstants.saveDateWithoutTime;
               String  dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                  if(dateformat!=null && dateformat.trim().length()>0 )
                            {
                                onlydate=dateformat.trim();
                            }  
              if(driver.getDob()!=null){
                DateFormat dateFormat = new SimpleDateFormat(onlydate);      
                pdtres.setDob( dateFormat.format(driver.getDob()));
                }
               pdtres.setMobileNo(driver.getContactNumber());
               pdtres.setEmergencyNo(driver.getEmergencyContactNo());
               pdtres.setAddress(driver.getAddress());
               pdtres.setCity(driver.getCity());
               pdtres.setPostCode(driver.getPostCode());
               pdtres.setCountry(driver.getCountry());
               pdtres.setDateFormat(dateformat);
               pdtres.setTimeFormat(timeformat);
               pdtres.setImage(driver.getDriverImage());
                jsonobj.put("responsecode", 200);
                jsonobj.put("message", "Success");
                jsonobj.put("timestamp", new Date());
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(pdtres);
                jsonobj.put("data", new JSONObject(Detail));		
                 
              
            }else
            {
                  jsonobj.put("responsecode", 400);
                  jsonobj.put("timestamp", new Date());
		  jsonobj.put("message", "Data not found");
            }
          res= jsonobj.toString();
      }catch(Exception ex)
      { GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
	res = derr.toString();
	ex.printStackTrace();
      }
        return  res;
  }
  @Override
   public String updatePersonaldetailsTabsBydriverCode( String driverCode,PersonalDetailTabRes req)
   {
      String res="";
       try{
           JSONObject jsonobj=new JSONObject();
         Driver driver = driverRepository.getDriverByDriverCode(driverCode);
           if(driver!=null && driver.getId()>0)
           {
            driver.setName(req.getName());
             String onlydate= GigflexConstants.saveDateWithoutTime;
//                String  dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.DATEFORMAT);
//                  if(dateformat!=null && dateformat.trim().length()>0 )
//                            {
//                                onlydate=dateformat.trim();
//                            }
           Date date1=new SimpleDateFormat(onlydate).parse(req.getDob());  
            driver.setDob(date1);
           driver.setContactNumber(req.getMobileNo()); 
           driver.setEmergencyContactNo(req.getEmergencyNo()); 
           driver.setAddress(req.getAddress()); 
           driver.setCity(req.getCity());
           driver.setPostCode(req.getPostCode());
           driver.setCountry(req.getCountry());
           driver.setDriverImage(req.getImage()); 
           Driver d=driverRepository.save(driver);
              if(d!=null && d.getId()>0)
              {
                   kafkaService.sendDriverForUpdate(d);
                  Users user = userRepository.findByUserCode(d.getDriverCode());
	             if (user != null && user.getId() > 0) {
		     user.setName(d.getName());
		 
		  Users userres = userRepository.save(user);
	          if (userres != null && userres.getId() > 0) {
	           kafkaService.sendUpdateUser(userres);
                     }
                  }
                  jsonobj.put("responsecode", 200);
                  jsonobj.put("timestamp", new Date());
		  jsonobj.put("message", "Success");
              }else
              {
                  jsonobj.put("responsecode", 200);
                  jsonobj.put("timestamp", new Date());
		  jsonobj.put("message", "failed");
              }
           }else
           {
                   jsonobj.put("responsecode", 200);
                  jsonobj.put("timestamp", new Date());
		  jsonobj.put("message", "record not found"); 
           }
        res= jsonobj.toString();
         }catch(Exception ex)
         {
          GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
	  res = derr.toString();
	  ex.printStackTrace();
         }
   return res;
   }
  
  
  
        @Override
     public  String getGeneraldetailsTabsBydriverCode(String driverCode)
     {
         
                 String res="";
                  try{
                   GeneralDetailRes  grdRes=new GeneralDetailRes();
                   JSONObject jsonobj = new JSONObject();
                   Driver driver = driverRepository.getDriverByDriverCode(driverCode); 
                   if(driver!=null && driver.getId()>0)
                   {
                       String  timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                       String  dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                       grdRes.setName(driver.getName());
                       grdRes.setEmail(driver.getEmailId());
                       grdRes.setLanguage(driver.getLanguage());
                       grdRes.setImage(driver.getDriverImage());
                       grdRes.setDateFormat(dateformat);
                       grdRes.setTimeFormat(timeformat);
                       jsonobj.put("responsecode", 200);
                       jsonobj.put("message", "Success");
                       jsonobj.put("timestamp", new Date());
                       ObjectMapper mapperObj = new ObjectMapper();
                       String Detail = mapperObj.writeValueAsString(grdRes);
                       jsonobj.put("data", new JSONObject(Detail));		
                 
                   }else
                   {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("timestamp", new Date());
		    jsonobj.put("message", "Data not found");
                   }
                 res= jsonobj.toString();  
                  }catch(Exception ex)
                  {
                    GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
	            res = derr.toString();
	             ex.printStackTrace();
                  }
                  return res;
     }
     @Override
     public String getOthersdetailsTabsBydriverCode( String driverCode)
     {
        String res="";
         try{
            
             List<DriverDocsResponse>ddList =new ArrayList<>();
           JSONObject jsonobj = new JSONObject();
          Driver driver = driverRepository.getDriverByDriverCode(driverCode);
             
          List<Object> objlst = driverDocumentRepository.getAllDriverDocumentByDriverCode(driverCode);
         if(objlst!=null && objlst.size()>0 &&driver !=null && driver.getId()>0 )
         {
                   
                            String timezoneCode = "";
                            TimeZoneDetail tz = null;
                            String timezone = "";
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;

                  timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.TimeZone);
                            tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            timezone = tz.getTimeZoneName(); 
                  String  timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                  String  dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                  if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }  
                  for(int i=0;i<objlst.size();i++)
                {
                  Object []arr  = (Object[])objlst.get(i);
                  if(arr.length >= 3)
                  {
                       DriverDocsResponse ddr=new DriverDocsResponse();
                        ddr.setImage(driver.getDriverImage());
                      ddr.setEmail(driver.getEmailId());
                    DriverDocument data = (DriverDocument) arr[0];
                  
                                               
                    String conDt = "";

						if (data.getDocExpiration() != null) {
//							TimeZoneDetail tz = driverDocumentRepository.getTimeZoneByDriverCode(data.getDriverCode());
						    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        Date docExpDate = data.getDocExpiration();
							docExpDate = GigflexDateUtil.getGMTtoLocationDate(docExpDate, timezone,dtFormat);
							conDt = GigflexDateUtil.convertDateToString(docExpDate,dtFormat);
                                                    }
                                                        
						}

                                                ddr.setDateFormat(dateformat);
                                                ddr.setTimeFormat(timeformat);
						ddr.setId(data.getId());
						ddr.setDriverDocumentCode(data.getDriverDocumentCode());
						ddr.setDocumentCode(data.getDocumentCode());
						
                                                ddr.setDocValue(data.getDocValue());
						ddr.setDocExpiration(conDt);

						ddr.setDocumentName((String) arr[1]);
                                                DocumentType dt=(DocumentType)arr[3];
                                                ddr.setDocumentType(dt.getDocumentTypeName());
                                      ddList.add(ddr);
                  }
//                  ddres.setId();
                }
                                                    jsonobj.put("responsecode", 200);
                                                    jsonobj.put("message", "Success");
                                                    jsonobj.put("timestamp", new Date());
                                                    ObjectMapper mapperObj = new ObjectMapper();
                                                    String Detail = mapperObj.writeValueAsString(ddList);
                                                    jsonobj.put("data", new JSONArray(Detail));		
                  
                 
                }else
               {
           jsonobj.put("responsecode", 400);
	   jsonobj.put("timestamp", new Date());
	   jsonobj.put("message", "Data not found");
          }
         res=jsonobj.toString();
         }catch(Exception ex)
         {
              GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
	      res = derr.toString();
	      ex.printStackTrace();  
         }
          return res;
     }
        @Override
      public String updatedriverPassword(GeneralDetailRes req, String driverCode)
      {
         String res="";
            try{
              JSONObject jsonobj = new JSONObject();      
             Driver driver=  driverRepository.getDriverByDriverCode(driverCode);
             Users users=userRepository.findByUserCode(driverCode);
             if(driver!=null && driver.getId()>0 && users!=null && users.getId()>0)
             {
                 driver.setName(req.getName());
                
                driver.setLanguage(req.getLanguage());
                 driver.setDriverImage(req.getImage());
            Driver d= driverRepository.getdriverBydriverCodeAndemail(driverCode,req.getEmail());
            if(d==null)
           {
              driver.setEmailId(req.getEmail());
           }else
           {
                jsonobj.put("responsecode", 409);
	        jsonobj.put("timestamp", new Date());
	        jsonobj.put("message", "Email already exists");
               return  jsonobj.toString();
              //terminate
           }
        //set the valuse to usertable 
             users.setName(req.getName());
              
              
             users.setEmail(req.getEmail());
         
                if(req.getPassword()!=null && req.getPassword().trim().length()>0)
                {
               users.setPassword(bCryptPasswordEncoder.encode(req.getPassword().trim()));
                }
          
           Users usr=  userRepository.save(users);
          Driver drvr=driverRepository.save(driver);
          if(usr!=null &&drvr!=null)
          {
              //updated
              kafkaService.sendDriverForUpdate(drvr);
              kafkaService.sendUpdateUser(usr);
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
          }else
          {
                jsonobj.put("responsecode", 400);
	        jsonobj.put("timestamp", new Date());
	        jsonobj.put("message", "Not Updated");
          } 
             
         }else
         {
                jsonobj.put("responsecode", 400);
	        jsonobj.put("timestamp", new Date());
	        jsonobj.put("message", "Record Not Found"); 
         }
        res= jsonobj.toString();      
            }catch(Exception ex)
            {
                GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
	         res = derr.toString();
	          ex.printStackTrace();
            }
             return res;
      }
      
        @Override
      public String updateOthersdetailsTabsBydriverCode(DriverDocsReq req,  String driverCode)
      { 
          String res="";
          try{
            
          JSONObject jsonobj = new JSONObject();
          Driver driver = driverRepository.getDriverByDriverCode(driverCode);
         // List< DriverDocument> ddList=driverDocumentRepository.getdriverDocumentBydriverCode(driverCode) ;
         // DocumentType dt=documentTypeRepository.getDriverDocumentTypeByDriverCode(driverCode);
        //  DocumentTypeDetail dtd=documentTypeDetailRepository.getDocumentTypedetailBydriverCode(driverCode);
          
          
         if(driver!=null && driver.getId()>0)
         {
             Driver d= driverRepository.getdriverBydriverCodeAndemail(driverCode,req.getEmail());
            if(d==null)
            {
              driver.setEmailId(req.getEmail());
            }else
            {
                jsonobj.put("responsecode", 409);
	        jsonobj.put("timestamp", new Date());
	        jsonobj.put("message", "Email already exists");
               return  jsonobj.toString();
              //terminate
            }  
             driver.setDriverImage(req.getImage());
             List<DriverDocumentsReq> ddreq= req.getDdList();
             for(DriverDocumentsReq dd:ddreq)
             {
            DriverDocument ddocuments=driverDocumentRepository.getDriverDocumentByDriverDocumentCode(dd.getDriverDocumentCode());
               if(ddocuments!=null && ddocuments.getId()>0)
               {
                  if(dd.getDocExpiration()!=null && dd.getDocExpiration().trim().length()>0)
                  {
                   try{
                     String onlydate= GigflexConstants.saveDateWithoutTime;
                     Date date1=new SimpleDateFormat(onlydate).parse(dd.getDocExpiration().trim());
                   if(date1!=null)
                   {
                    ddocuments.setDocExpiration(date1);
                    }else
                   {
                      jsonobj.put("responsecode", 400);
                      jsonobj.put("message", "Date Formate Parsing exception occurred.");
                      jsonobj.put("timestamp", new Date());
                     return jsonobj.toString();
                   }
           
               }catch(Exception ex)
               {
            
                GigflexResponse derr = new GigflexResponse(500, new Date(), "Date Formate Parsing exception occurred.");
	        res = derr.toString();
	        ex.printStackTrace();  
                return res;
                }
                  }
                 ddocuments.setDocValue(dd.getDocValue());
                 ddocuments.setDocumentCode(dd.getDocumentCode());
                 ddocuments.setDriverDocumentCode(dd.getDriverDocumentCode());
                 ddocuments.setDriverCode(driverCode);
                  
                  driverDocumentRepository.save(ddocuments);
                  
               }
               
           
             }
  
                  Driver drvr=driverRepository.save(driver);
                
         
           if(drvr!=null && drvr.getId()>0)
           {
               kafkaService.sendDriverForUpdate(drvr);
                  Users user = userRepository.findByUserCode(drvr.getDriverCode());
	             if (user != null && user.getId() > 0) {
		     user.setName(drvr.getName());
                     user.setEmail(drvr.getEmailId());
		     
		  Users userres = userRepository.save(user);
	          if (userres != null && userres.getId() > 0) {
	           kafkaService.sendUpdateUser(userres);
                     }
                  }
               
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Record Updated Successfully");
                        jsonobj.put("timestamp", new Date());
           }else
           {
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("message", "failed");
                        jsonobj.put("timestamp", new Date());
           }
         }else
         {
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
         }
       
      res= jsonobj.toString();           
                      
       }catch(Exception ex)
       {
             GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
	     res = derr.toString();
	     ex.printStackTrace();             
       }
          return res; 
      }
      
        @Override
  public String getDriverContactDetailByRideCodeforMobile(String rideCode)
  {
     String res="";
          try{
              DriverContactDetailByRideCodeforMobileRes driverRes=new DriverContactDetailByRideCodeforMobileRes();
          JSONObject jsonobj = new JSONObject();
        Booking booking=bookingDao.getBookingByRideCode(rideCode);
            if(booking!=null && booking.getId()>0)  
            {
                Passenger passanger=  passengerDao.getPassengerByPassengerCode(booking.getPassengerCode());
                if(passanger!=null && passanger.getId()>0)
                { 
                driverRes.setPassangerno( "+"+passanger.getpCountryCode()+passanger.getPrimaryContactNumber());
                }
            Operator op=opertaorRepository.getOperatorByOperatorCode(booking.getOperatorCode());
            if(op!=null && op.getId()>0)
            {
              driverRes.setOperatorno("+"+op.getCountryCode()+op.getContactNumber());
            }
              AssignBooking assignBooking = assignBookingRepository.getAssignBookingByRideCode(rideCode);
              
              if(assignBooking.getOperatorCode()!=null && assignBooking.getId()>0 &&!(assignBooking.getOperatorCode().equals(op.getOperatorCode())))
              {
                 Operator opp=    opertaorRepository.getOperatorByOperatorCode(assignBooking.getOperatorCode());
                 if(opp!=null && opp.getId()>0)
                 {
                 driverRes.setOperatorno("+"+opp.getCountryCode()+opp.getContactNumber());
                  }
              }
              driverRes.setRidecode(rideCode);
              jsonobj.put("responsecode", 200);
              jsonobj.put("message", "Success");
              jsonobj.put("timestamp", new Date());
              ObjectMapper mapperObj = new ObjectMapper();
              String Detail = mapperObj.writeValueAsString(driverRes);
               jsonobj.put("data", new JSONObject(Detail));	
            }else
            {
            jsonobj.put("responsecode", 400);
            jsonobj.put("message", "failed");
            jsonobj.put("timestamp", new Date());
            }
        res=jsonobj.toString();
            }catch(JSONException ex)
            {                
                GigflexResponse derr = new GigflexResponse(500, new Date(), " JSON Parsing exception occurred.");
	        res = derr.toString();
	        ex.printStackTrace();  
                return res;
             }
            catch(Exception ex)
            {                
                 GigflexResponse derr = new GigflexResponse(500, new Date(), "exception occurred.");
	        res = derr.toString();
	        ex.printStackTrace();  
                return res;
             }
          
        return res; 
  }
}
