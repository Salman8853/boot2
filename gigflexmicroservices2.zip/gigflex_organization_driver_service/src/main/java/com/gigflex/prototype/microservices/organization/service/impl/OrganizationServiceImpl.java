package com.gigflex.prototype.microservices.organization.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.notification.service.NotificationService;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.dtob.OrganizationRequest;
import com.gigflex.prototype.microservices.organization.repository.OrganizationDao;
import com.gigflex.prototype.microservices.organization.service.OrganizationService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.utility.PushNotification;
import org.springframework.beans.factory.annotation.Value;

@Service
public class OrganizationServiceImpl implements OrganizationService {

	@Autowired
	private OrganizationDao orgDao;
	
	@Autowired
	private DriverRepository driverDao;
	
	@Autowired
	private OperatorRepository operatorDao;
        
        @Autowired
        KafkaService kafkaService;
        
        String shortMessage;
        
        @Autowired
    	NotificationService notificationService;
    	
        @Value("${notification.deviceid}")
        private String deviceId;
        
        @Value("${notification.fcm.url}")
        private String FMCurl;  
        
        @Value("${notification.fcm.authkey}")
        private String authKey;
        
        
	@Override
	public String getOrganizationByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Organization organization = orgDao.findByOrganizationCode(organizationCode);
			if (organization != null && organization.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(organization);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String updateOrganization(String organizationCode, OrganizationRequest orgReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Organization organization = orgDao.findByOrganizationCode(organizationCode);

					if (organization != null && organization.getId() > 0) {


							Date approvedDate = null;
							if (orgReq.getApprovedDate() != null
									&& orgReq.getApprovedDate().trim().length() > 0) {
								try {
									approvedDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
											.parse(orgReq.getApprovedDate().trim());
									if (approvedDate == null) {
										GigflexResponse derr = new GigflexResponse(400, new Date(),
												"Plz send approved date in correct format(yyyy-MM-dd HH:mm:ss) ");
										return derr.toString();
									}
								} catch (Exception ex) {
									ex.printStackTrace();
									GigflexResponse derr = new GigflexResponse(400, new Date(),
											"Plz send approved date in correct format(yyyy-MM-dd HH:mm:ss) ");
									return derr.toString();
								}
							}
							Organization org = organization;
							org.setOrganizationName(orgReq
									.getOrganizationName());
							org.setCountryCode(orgReq.getCountryCode());
							org.setPhoneNumber(orgReq.getPhoneNumber());
							org.setAddress(orgReq.getAddress());
							org.setAddress1(orgReq.getAddress1());
							org.setCity(orgReq.getCity());
							org.setStateProvince(orgReq.getStateProvince());
							org.setCountry(orgReq.getCountry());
							org.setZipCode(orgReq.getZipCode());
							org.setTaxId(orgReq.getTaxId());
							org.setRegNo(orgReq.getRegNo());
							org.setWorkFrom(orgReq.getWorkFrom());
							org.setWorkTo(orgReq.getWorkTo());
//							org.setIndustryCode(orgReq.getIndustryCode());
							org.setLat(orgReq.getLat());
							org.setLang(orgReq.getLang());
							org.setIsActive(orgReq.getIsActive());
							org.setApprovedDate(approvedDate);
							org.setIsVerified(orgReq.getIsVerified());
							org.setOrganizationLogo(orgReq.getOrganizationLogo());
							
	                        org.setTimezone(orgReq.getTimezone());
	                        org.setConfigureMinutes(orgReq.getConfigureMinutes());
                                org.setAlertMinutes(orgReq.getAlertMinutes());
                                org.setIsRecursive(orgReq.getIsRecursive());
				org.setExpiredMinutes(orgReq.getExpiredMinutes());

							org.setIpAddress(ip);

							Organization orgRes = orgDao.save(org);
							if (orgRes != null && orgRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("message", "Organization has been updated");
								jsonobj.put("timestamp", new Date());
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(orgRes);
								jsonobj.put("data", new JSONObject(Detail));
                                                                kafkaService.sendOrganizationForUpdate(orgRes);
                                                                
                                                                try {
                               									 
                                									List<Driver> driver = driverDao.getDriverByOrganizationCode(organizationCode);
                                									List<Operator> operator = operatorDao.getOperatorByOrganizationCode(organizationCode);
                                									if(driver != null && driver.size() > 0 ){
                                										for(Driver dr : driver){
                                										
                                									Notification notification = new Notification();

                                									String bodyContent = "Dear Driver"
                                											+ ",Organization has been updated.";
                                										
                                									shortMessage = "Organization has been updated.";

                                									notification.setUserCode(dr.getDriverCode());
                                									notification.setIpAddress(ip);
                                									notification.setMessage(bodyContent);
                                									notification.setShortMessage(shortMessage);
                                									notification.setIsRead(Boolean.FALSE);

                                									notificationService.saveNotification(notification);
                                                                                                        
                                                                                                        //for push notification
                                                                                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
                                									}
                                										
                                									}
                                									if(operator != null && operator.size() > 0){
                                										for(Operator or : operator){
                                    										
                                        									Notification notification = new Notification();

                                        									String bodyContent = "Dear Operator"
                                        											+ ",Organization has been updated.";
                                        											
                                        									shortMessage = "Organization has been updated.";

                                        									notification.setUserCode(or.getOperatorCode());
                                        									notification.setIpAddress(ip);
                                        									notification.setMessage(bodyContent);
                                        									notification.setShortMessage(shortMessage);
                                        									notification.setIsRead(Boolean.FALSE);

                                        									notificationService.saveNotification(notification);
                                                                                                                //for push notification
                                                                                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
                                        									}
                                									}
                                									
                                								}

                                								catch (Exception e) {
                                									e.printStackTrace();
                                								}
                                                                
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("message", "Organization updation has been failed.");
								jsonobj.put("timestamp", new Date());
							}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Organization Code is not valid.");
						jsonobj.put("timestamp", new Date());
					}


			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

}
