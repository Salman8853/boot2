package com.gigflex.prototype.microservices.booking.dtob;

import java.util.Date;

public class BookingAllResponseWithFilterforMobile {

	private Long id;
private Long bookingid;
	private String rideCode;

	private String passengerName;

	

	private String pickUpTime;
        private Date pickUpTimeStamp;

	private String pickLat;

	private String pickLang;

	private String pickUpAddress;

	private String dropLat;

	private String dropLang;

	private String dropOffAddress;

	
	private String bookingStatus;

        private Boolean isStarted ;
        private Boolean isComplete ;
        private String globalRideCode ;
        private String globalRideName ;
private Boolean isFocused=false;
        private String currencySymbol;

    public String getCurrencySymbol() {
        return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }
        
        
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBookingid() {
        return bookingid;
    }

    public void setBookingid(Long bookingid) {
        this.bookingid = bookingid;
    }

    public String getRideCode() {
        return rideCode;
    }

    public void setRideCode(String rideCode) {
        this.rideCode = rideCode;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public String getPickUpTime() {
        return pickUpTime;
    }

    public void setPickUpTime(String pickUpTime) {
        this.pickUpTime = pickUpTime;
    }

    public String getPickLat() {
        return pickLat;
    }

    public void setPickLat(String pickLat) {
        this.pickLat = pickLat;
    }

    public String getPickLang() {
        return pickLang;
    }

    public void setPickLang(String pickLang) {
        this.pickLang = pickLang;
    }

    public String getPickUpAddress() {
        return pickUpAddress;
    }

    public void setPickUpAddress(String pickUpAddress) {
        this.pickUpAddress = pickUpAddress;
    }

    public String getDropLat() {
        return dropLat;
    }

    public void setDropLat(String dropLat) {
        this.dropLat = dropLat;
    }

    public String getDropLang() {
        return dropLang;
    }

    public void setDropLang(String dropLang) {
        this.dropLang = dropLang;
    }

    public String getDropOffAddress() {
        return dropOffAddress;
    }

    public void setDropOffAddress(String dropOffAddress) {
        this.dropOffAddress = dropOffAddress;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public Boolean getIsStarted() {
        return isStarted;
    }

    public void setIsStarted(Boolean isStarted) {
        this.isStarted = isStarted;
    }

    public Boolean getIsComplete() {
        return isComplete;
    }

    public void setIsComplete(Boolean isComplete) {
        this.isComplete = isComplete;
    }

    public Boolean getIsFocused() {
        return isFocused;
    }

    public void setIsFocused(Boolean isFocused) {
        this.isFocused = isFocused;
    }

    public Date getPickUpTimeStamp() {
        return pickUpTimeStamp;
    }

    public void setPickUpTimeStamp(Date pickUpTimeStamp) {
        this.pickUpTimeStamp = pickUpTimeStamp;
    }

    public String getGlobalRideCode() {
        return globalRideCode;
    }

    public void setGlobalRideCode(String globalRideCode) {
        this.globalRideCode = globalRideCode;
    }

    public String getGlobalRideName() {
        return globalRideName;
    }

    public void setGlobalRideName(String globalRideName) {
        this.globalRideName = globalRideName;
    }

 
}
