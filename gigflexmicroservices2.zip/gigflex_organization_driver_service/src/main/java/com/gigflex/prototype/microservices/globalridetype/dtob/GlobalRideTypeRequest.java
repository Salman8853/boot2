package com.gigflex.prototype.microservices.globalridetype.dtob;


public class GlobalRideTypeRequest {
	
	private String vehicleName;

	private Double baseRate;

	private Double ratePerMile;

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public Double getBaseRate() {
		return baseRate;
	}

	public void setBaseRate(Double baseRate) {
		this.baseRate = baseRate;
	}

	public Double getRatePerMile() {
		return ratePerMile;
	}

	public void setRatePerMile(Double ratePerMile) {
		this.ratePerMile = ratePerMile;
	}
	
	

}
