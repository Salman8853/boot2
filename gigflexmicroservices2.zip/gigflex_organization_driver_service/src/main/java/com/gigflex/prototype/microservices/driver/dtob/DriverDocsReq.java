/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.dtob;

import java.util.Date;
import java.util.List;

/**
 *
 * @author m.salman
 */
public class DriverDocsReq {
    List<DriverDocumentsReq>ddList;
    private String email;
    private String image;

    public List<DriverDocumentsReq> getDdList() {
        return ddList;
    }

    public void setDdList(List<DriverDocumentsReq> ddList) {
        this.ddList = ddList;
    }
   
   
  

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    

  
    
}
