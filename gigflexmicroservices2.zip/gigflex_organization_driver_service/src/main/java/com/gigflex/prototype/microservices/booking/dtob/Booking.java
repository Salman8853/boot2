package com.gigflex.prototype.microservices.booking.dtob;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "booking")
public class Booking extends CommonAttributes implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
        @Column(name = "bookingid", nullable = false,unique = true)
        private Long bookingid;

	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "ride_code", unique = true)
	private String rideCode;

	@Column(name = "passengername")
	private String passengerName;

	@Column(name = "primarycontactnumber")
	private String primaryContactNumber;

	@Column(name = "secondarycontactnumber")
	private String secondaryContactNumber;
	

	@Column(name = "pcountry_code")
    private String pCountryCode;
	
	@Column(name = "scountry_code")
    private String sCountryCode;


	@Column(name = "pickuptime", columnDefinition = "DATETIME")
	private Date pickUpTime;

	@Column(name = "dropofftime", columnDefinition = "DATETIME")
	private Date dropOffTime;

	@Column(name = "picklat", nullable = false)
	private String pickLat;

	@Column(name = "picklang", nullable = false)
	private String pickLang;

	@Column(name = "pickupaddress", nullable = false)
	private String pickUpAddress;

	@Column(name = "droplat", nullable = false)
	private String dropLat;

	@Column(name = "droplang", nullable = false)
	private String dropLang;

	@Column(name = "dropoffaddress", nullable = false)
	private String dropOffAddress;

	@Column(name = "additionalstoppage")
	private String additionalStopPage;

	@Column(name = "vehicle_code", nullable = false)
	private String vehicleCode;

	@Column(name = "noofpassengers")
	private Integer noOfPassengers;

	@Column(name = "noofbaggage")
	private Integer noOfBaggage;

	@Column(name = "comment")
	private String additionalComment;
        @Column(name = "cancelation_comment")
	private String cancelationComment;

	@Column(name = "customerfare")
	private Double customerFare;

	@Column(name = "bookingstatus")
	private String bookingStatus;

	@Column(name = "paymentoption", nullable = false)
	private String paymentOption;

	@Column(name = "organization_code")
	private String organizationCode;

	@Column(name = "operator_code")
	private String operatorCode;

	@Column(name = "ispublished", columnDefinition = "boolean default false", nullable = false)
	private Boolean isPublished;
	
	@Column(name = "oldstatus")
	private String oldStatus;
        
        @Column(name = "passenger_code")
	private String passengerCode;

	@PrePersist
	private void assignUUID() {
		if (this.getRideCode() == null || this.getRideCode().length() == 0) {
			this.setRideCode(UUID.randomUUID().toString());
		}
	}

	public Date getDropOffTime() {
		return dropOffTime;
	}

	public void setDropOffTime(Date dropOffTime) {
		this.dropOffTime = dropOffTime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRideCode() {
		return rideCode;
	}

	public void setRideCode(String rideCode) {
		this.rideCode = rideCode;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public String getPrimaryContactNumber() {
		return primaryContactNumber;
	}

	public void setPrimaryContactNumber(String primaryContactNumber) {
		this.primaryContactNumber = primaryContactNumber;
	}

	public String getSecondaryContactNumber() {
		return secondaryContactNumber;
	}

	public void setSecondaryContactNumber(String secondaryContactNumber) {
		this.secondaryContactNumber = secondaryContactNumber;
	}

	public Date getPickUpTime() {
		return pickUpTime;
	}

	public void setPickUpTime(Date pickUpTime) {
		this.pickUpTime = pickUpTime;
	}

	public String getPickLat() {
		return pickLat;
	}

	public void setPickLat(String pickLat) {
		this.pickLat = pickLat;
	}

	public String getPickLang() {
		return pickLang;
	}

	public void setPickLang(String pickLang) {
		this.pickLang = pickLang;
	}

	public String getPickUpAddress() {
		return pickUpAddress;
	}

	public void setPickUpAddress(String pickUpAddress) {
		this.pickUpAddress = pickUpAddress;
	}

	public String getDropLat() {
		return dropLat;
	}

	public void setDropLat(String dropLat) {
		this.dropLat = dropLat;
	}

	public String getDropLang() {
		return dropLang;
	}

	public void setDropLang(String dropLang) {
		this.dropLang = dropLang;
	}

	public String getDropOffAddress() {
		return dropOffAddress;
	}

	public void setDropOffAddress(String dropOffAddress) {
		this.dropOffAddress = dropOffAddress;
	}

	public String getAdditionalStopPage() {
		return additionalStopPage;
	}

	public void setAdditionalStopPage(String additionalStopPage) {
		this.additionalStopPage = additionalStopPage;
	}

	public String getVehicleCode() {
		return vehicleCode;
	}

	public void setVehicleCode(String vehicleCode) {
		this.vehicleCode = vehicleCode;
	}

	public Integer getNoOfPassengers() {
		return noOfPassengers;
	}

	public void setNoOfPassengers(Integer noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}

	public Integer getNoOfBaggage() {
		return noOfBaggage;
	}

	public void setNoOfBaggage(Integer noOfBaggage) {
		this.noOfBaggage = noOfBaggage;
	}

	public String getAdditionalComment() {
		return additionalComment;
	}

	public void setAdditionalComment(String additionalComment) {
		this.additionalComment = additionalComment;
	}

	public Double getCustomerFare() {
		return customerFare;
	}

	public void setCustomerFare(Double customerFare) {
		this.customerFare = customerFare;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public String getPaymentOption() {
		return paymentOption;
	}

	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public Boolean getIsPublished() {
		return isPublished;
	}

	public void setIsPublished(Boolean isPublished) {
		this.isPublished = isPublished;
	}

	public String getOperatorCode() {
		return operatorCode;
	}

	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}

	public String getpCountryCode() {
		return pCountryCode;
	}

	public void setpCountryCode(String pCountryCode) {
		this.pCountryCode = pCountryCode;
	}

	public String getsCountryCode() {
		return sCountryCode;
	}

	public void setsCountryCode(String sCountryCode) {
		this.sCountryCode = sCountryCode;
	}

    public String getCancelationComment() {
        return cancelationComment;
    }

    public void setCancelationComment(String cancelationComment) {
        this.cancelationComment = cancelationComment;
    }

	public String getOldStatus() {
		return oldStatus;
	}

	public void setOldStatus(String oldStatus) {
		this.oldStatus = oldStatus;
	}

    public Long getBookingid() {
        return bookingid;
    }

    public void setBookingid(Long bookingid) {
        this.bookingid = bookingid;
    }

    public String getPassengerCode() {
        return passengerCode;
    }

    public void setPassengerCode(String passengerCode) {
        this.passengerCode = passengerCode;
    }    

}
