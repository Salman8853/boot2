package com.gigflex.prototype.microservices.makemodelmapping.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.makemodelmapping.dtob.MakeModelMapping;
import com.gigflex.prototype.microservices.util.SearchCriteria;




public class MakeModelMappingSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public MakeModelMappingSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public MakeModelMappingSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<MakeModelMapping> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<MakeModelMapping>> specs = new ArrayList<Specification<MakeModelMapping>>();
        for (SearchCriteria param : params) {
            specs.add(new MakeModelMappingSpecification(param));
        }
 
        Specification<MakeModelMapping> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
