package com.gigflex.prototype.microservices.timezone.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.util.SearchCriteria;




public class TimeZoneDetailSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public TimeZoneDetailSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public TimeZoneDetailSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<TimeZoneDetail> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<TimeZoneDetail>> specs = new ArrayList<Specification<TimeZoneDetail>>();
        for (SearchCriteria param : params) {
            specs.add(new TimeZoneDetailSpecification(param));
        }
 
        Specification<TimeZoneDetail> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
