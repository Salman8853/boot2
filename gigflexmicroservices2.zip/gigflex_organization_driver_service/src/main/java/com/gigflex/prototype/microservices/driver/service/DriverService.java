/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.service;

import com.gigflex.prototype.microservices.driver.dtob.DefaultVehicleUpdateRequest;
import java.util.List;

import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.dtob.DriverDocsReq;
import com.gigflex.prototype.microservices.driver.dtob.DriverDocsResponse;
import com.gigflex.prototype.microservices.driver.dtob.DriverRequest;
import com.gigflex.prototype.microservices.driver.dtob.DriverUpRequest;
import com.gigflex.prototype.microservices.driver.dtob.DriverVehicleRequest;
import com.gigflex.prototype.microservices.driver.dtob.GeneralDetailRes;
import com.gigflex.prototype.microservices.driver.dtob.PersonalDetailTabRes;

/**
 *
 * @author Abhishek
 */
public interface DriverService {
    public Driver saveDriversDetatil(Driver driver);
    
    public String findAllDriver();
    
//    public String getAllDriverWithDocument();
    public String UnassignVehicleToDriverByVehicleAndDriverCode(String driverCode,String vehicleCode,
			String ip);
	public String getAllDriverByPage(int page, int limit);

	public String getDriverByDriverCode(String driverCode);
	
	public String getDriverByOrgCode(String organizationCode);
	public String getDriverByOrgCodeByPage(String organizationCode,int page, int limit);


	public String findDriverById(Long id);
	
	public String saveDriver(DriverRequest driverReq,
			String ip);

	public String updateDriverById(Long id, DriverUpRequest driverReq,
			String ip);

	public String softDeleteByDriverCode(String driverCode);

	public String softMultipleDeleteByDriverCode(List<String> driverCodeList);

	public String search(String search);
	
	public Driver getUserEmail(String userEmail);
        public String sendRegistrationLinkTODriverByOperator(String operatorCode,String driverEmail,String organizationCode);
        public String getDriverDetailByOperatorCode(String operatorCode);
        public String getDriverDetailByOperatorCodeByPage(String operatorCode,int page, int limit);
        public String verifyDriverByDriverCode(String driverCode,Boolean approveStatus);
        public String sendLinkToDriverForCreateCredential(String driverCode);
        public String assignVehicleToDriver(DriverVehicleRequest driverVReq ,String ip);
        public String UnassignVehicleToDriver(String driverCode ,String ip);
        public String getDriverByVehicleTypeCode(String vehicleCode);
        public String getDriverByVehicleTypeCodeAndOrganizationCode(String vehicleCode,String organizationCode);
        public String getDriverByVehicleTypeCode(String vehicleCode,int page, int limit);
        public String getDriverByVehicleTypeCodeAndOrganizationCode(String vehicleCode,String organizationCode,int page, int limit);

        public String getDefaultVehicleDetailByDriverCode(String driverCode);

        public String updateDefaultVehicleByDriverCode(String drivercode, DefaultVehicleUpdateRequest defaultVehicleReq, String ip);
        
        public String getAllDetailBydriverCode( String driverCode);
         
        public String getPersonaldetailsTabsBydriverCode( String driverCode);
         
        public  String getGeneraldetailsTabsBydriverCode(String driverCode);
          
        public String getOthersdetailsTabsBydriverCode( String driverCode);
        
        public String updatedriverPassword(GeneralDetailRes req, String driverCode);
        
       public String updatePersonaldetailsTabsBydriverCode( String driverCode,PersonalDetailTabRes req);
       
       public String updateOthersdetailsTabsBydriverCode( DriverDocsReq req,String driverCode);
       
      public String getDriverContactDetailByRideCodeforMobile(String rideCode);
}
