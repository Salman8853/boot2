/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.passenger.repository;

import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.passenger.dtob.Passenger;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface PassengerDao extends JpaRepository<Passenger,Long>,JpaSpecificationExecutor<Passenger>{

    @Query("SELECT ps FROM Passenger ps  WHERE ps.isDeleted != TRUE AND ps.organizationCode = :organizationCode")
    public List<Passenger> getPassengerByOrgCode(@Param("organizationCode") String organizationCode);

    @Query("SELECT ps FROM Passenger ps  WHERE ps.isDeleted != TRUE AND ps.passengerCode = :passengerCode")
    public Passenger getPassengerByPassengerCode(@Param("passengerCode") String passengerCode);

    @Query("SELECT ps FROM Passenger ps  WHERE ps.isDeleted != TRUE ")
    public List<Passenger> getAllPassenger();

    @Query("SELECT b FROM Booking b WHERE b.isDeleted != TRUE AND b.passengerCode = :passengerCode")
    public List<Booking> getBookingListByPassengerCode(@Param("passengerCode") String passengerCode);

    @Query("SELECT b FROM Booking b WHERE b.isDeleted != TRUE AND b.organizationCode = :organizationCode AND b.passengerCode = :passengerCode")
    public List<Booking> getBookingListByOrganizationCodeAndPassengerCode(@Param("organizationCode") String organizationCode,@Param("passengerCode") String passengerCode);

   
}
