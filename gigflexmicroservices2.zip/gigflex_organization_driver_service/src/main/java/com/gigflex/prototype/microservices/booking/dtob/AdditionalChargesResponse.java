/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.booking.dtob;

/**
 *
 * @author amit.kumar
 */
public class AdditionalChargesResponse {
    
    private String additionalFareypeCode;
    private Double ammount;
    private Integer quantity;
    private String additionalFareypeCodeName;
    private String currencySymbol;

    public String getAdditionalFareypeCode() {
        return additionalFareypeCode;
    }

    public void setAdditionalFareypeCode(String additionalFareypeCode) {
        this.additionalFareypeCode = additionalFareypeCode;
    }

    public Double getAmmount() {
        return ammount;
    }

    public void setAmmount(Double ammount) {
        this.ammount = ammount;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getAdditionalFareypeCodeName() {
        return additionalFareypeCodeName;
    }

    public void setAdditionalFareypeCodeName(String additionalFareypeCodeName) {
        this.additionalFareypeCodeName = additionalFareypeCodeName;
    }

    public String getCurrencySymbol() {
        return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }

    
}
