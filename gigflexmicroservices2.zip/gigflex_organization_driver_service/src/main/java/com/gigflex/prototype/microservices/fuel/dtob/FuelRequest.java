package com.gigflex.prototype.microservices.fuel.dtob;

public class FuelRequest {
	
	  private String fuelTypename;

	public String getFuelTypename() {
		return fuelTypename;
	}

	public void setFuelTypename(String fuelTypename) {
		this.fuelTypename = fuelTypename;
	}
	  
	  

}
