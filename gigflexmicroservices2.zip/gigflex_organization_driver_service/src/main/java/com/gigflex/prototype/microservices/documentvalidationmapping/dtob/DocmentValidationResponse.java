package com.gigflex.prototype.microservices.documentvalidationmapping.dtob;

public class DocmentValidationResponse {

	private Long id;

	private String documentValidationCode;

	private String documentCode;

	private String documentName;

	private String validationCode;

	private String validationName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocumentValidationCode() {
		return documentValidationCode;
	}

	public void setDocumentValidationCode(String documentValidationCode) {
		this.documentValidationCode = documentValidationCode;
	}

	public String getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getValidationCode() {
		return validationCode;
	}

	public void setValidationCode(String validationCode) {
		this.validationCode = validationCode;
	}

	public String getValidationName() {
		return validationName;
	}

	public void setValidationName(String validationName) {
		this.validationName = validationName;
	}

}
