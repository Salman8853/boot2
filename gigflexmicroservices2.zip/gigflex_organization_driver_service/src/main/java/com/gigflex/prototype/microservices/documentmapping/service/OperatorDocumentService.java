/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service;

import com.gigflex.prototype.microservices.documentmapping.dtob.OperatorDocumentRequest;
import java.util.List;

/**
 *
 * @author nirbhay.p
 */
public interface OperatorDocumentService {
    public String getAllOperatorDocument();
    public String getAllOperatorDocumentByOperatorCode(String operatorCode);
    public String getAllOperatorDocument(int page, int limit);
    public String getAllOperatorDocumentByOperatorCode(String operatorCode,int page, int limit);
    public String getOperatorDocumentByOperatorDocumentCode(String operatorDocumentCode);
    public String softDeleteOperatorDocumentByOperatorDocumentCode(String operatorDocumentCode);
    public String softMultipleDeleteOperatorDocumentByOperatorDocumentCode(List<String> operatorDocumentCodeList);
    public String saveOperatorDocument(OperatorDocumentRequest driDetReq,String ip);
    public String updateOperatorDocument(String operatorDocumentCode,OperatorDocumentRequest driDetReq,String ip);
    public String getDocumentExpirationStatusByOperatorCode(String operatorCode);
}
