/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.dtob;

import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import java.util.List;

/**
 *
 * @author Abhishek
 */
public class DocumentExpirationByOperator {
    private Boolean isExpired;
    private Operator operator;
    private List<Driver>  drivers;

    public Boolean getIsExpired() {
        return isExpired;
    }

    public void setIsExpired(Boolean isExpired) {
        this.isExpired = isExpired;
    }

    public Operator getOperator() {
        return operator;
    }

    public void setOperator(Operator operator) {
        this.operator = operator;
    }

    public List<Driver> getDrivers() {
        return drivers;
    }

    public void setDrivers(List<Driver> drivers) {
        this.drivers = drivers;
    }
    
    
    
    
}
