/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.additionalfaretype.api;

import com.gigflex.prototype.microservices.additionalfaretype.dtob.AdditionalFareTypeReq;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.gigflex.prototype.microservices.additionalfaretype.service.AdditionalFareTypeService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;

/**
 *
 * @author m.salman
 */
@RestController
@RequestMapping("/organizationdriverservice")
public class AdditionalFareTypeController {
    @Autowired
    AdditionalFareTypeService additionalfaretypeservice;
    @PostMapping("/saveAdditionalfaretypedetail")
    public String saveAdditionalfaretypedetail(@RequestBody AdditionalFareTypeReq additionalfaretypereq)
    {   if(additionalfaretypereq!=null && additionalfaretypereq.getName()!=null &&additionalfaretypereq.getName().length()>0){
         return  additionalfaretypeservice.saveAdditionalfaretypedetail(additionalfaretypereq);
       }else
       {
        return "Variable Should not be left blank";
                
       }
    }
     @GetMapping("/getAlladditionalfaretypedetail")
    public String getAlladditionalfaretypedetail()
    {   
         return  additionalfaretypeservice.getAlladditionalfaretypedetail();
    }
     @GetMapping("/getadditionalfaretypedetailByadditionfareCode/{additionalFareTypeCode}")
    public String getadditionalfaretypedetailByadditionfareCode(@PathVariable String additionalFareTypeCode)
    {     if(additionalFareTypeCode!=null && additionalFareTypeCode.trim().length()>0){
         return  additionalfaretypeservice.getadditionalfaretypByAfc(additionalFareTypeCode);
        }else
    {
       return "custumFareTypeCode  not left as blank";
    }
    }
    @PutMapping("/updateadditionalfaretypedetailByadditionalfareCode/{additionalFareTypeCode}")
    public String updateadditionalfaretypedetailByadditionalfareCode(@PathVariable String additionalFareTypeCode,@RequestBody AdditionalFareTypeReq req)
    {     if(additionalFareTypeCode!=null && additionalFareTypeCode.trim().length()>0){
         return  additionalfaretypeservice.updateadditionalfaretypByAfc(additionalFareTypeCode,req);
        }else
    {
       return "custumFareTypeCode  not left as blank";
    }
    }
    
    @DeleteMapping("/softdeleteadditionalfaretypedetailByadditionalfareCode/{additionalFareTypeCode}")
    public String softdeleteadditionalfaretypedetailByadditionalfareCode(@PathVariable String additionalFareTypeCode)
    {     if(additionalFareTypeCode!=null && additionalFareTypeCode.trim().length()>0){
         return  additionalfaretypeservice.softdeleteadditionalfaretypeByAfc(additionalFareTypeCode);
        }else
    {
       return "plase Enter custumFareTypeCode";
    }
    }
}
