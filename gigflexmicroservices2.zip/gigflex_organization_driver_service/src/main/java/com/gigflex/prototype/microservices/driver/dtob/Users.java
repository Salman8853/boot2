/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.dtob;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Where;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gigflex.prototype.microservices.util.CommonAttributes;

/**
 *
 * @author abhishek
 */
@Entity
//@Where(clause="isdeleted=false")
@Table(name = "users")
public class Users extends CommonAttributes implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "user_code", unique = true)
    private String userCode;
    
    @Column(name = "name", nullable = false)
    private String name;
    
    @Column(name = "email", nullable = false)
    private String email;

    @Column(name = "username", nullable = false)
    private String userName;
    
//    @JsonIgnore
    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "isowner")
    private Boolean isOwner;

    @Column(name = "isadmin")
    private Boolean isAdmin;

    @Column(name = "isactive")
    private Boolean isActive;
    
    @Column(name = "isverified")
    private Boolean isVerified;
    
    @Column(name = "email_link_expired_at", columnDefinition = "DATETIME")
    private Date emailLinkExpiredAt;
    
    @PrePersist
    private void assignUUID() {
        if (this.getUserCode() == null || this.getUserCode().length() == 0) {
            this.setUserCode(UUID.randomUUID().toString());
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getEmailLinkExpiredAt() {
        return emailLinkExpiredAt;
    }

    public void setEmailLinkExpiredAt(Date emailLinkExpiredAt) {
        this.emailLinkExpiredAt = emailLinkExpiredAt;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Boolean getIsOwner() {
        return isOwner;
    }

    public void setIsOwner(Boolean isOwner) {
        this.isOwner = isOwner;
    }

    public Boolean getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(Boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Boolean getIsVerified() {
        return isVerified;
    }

    public void setIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

}
