/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.util;

import com.gigflex.prototype.microservices.globalsetting.dtob.GlobalSetting;
import com.gigflex.prototype.microservices.globalsetting.dtob.LocalSetting;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.usertype.dtob.UserType;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import java.security.MessageDigest;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class GigflexUtility {
	static boolean isPwdValid = false;
	

	public static String hashAlgorithem(String password) throws Exception {
		StringBuffer sb = null;
		if (password != null && !"".equals(password)) {
			try {
				MessageDigest md = MessageDigest.getInstance("SHA-256");
				md.update(password.getBytes());
				byte byteData[] = md.digest();
				sb = new StringBuffer();
				for (int i = 0; i < byteData.length; i++) {
					sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
				}
				System.out.println("Hex format : " + sb.toString());
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			GigflexResponse gigresp = new GigflexResponse(200, new Date(), "Invalid Password");
			sb.append(gigresp.toString());
		}
		return sb.toString();
	}

	public static boolean passwordPattern(String pwd) {
		if (pwd != null) {
			try {
				String pattern = "(?=.*[0-7])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{7,}";
				isPwdValid = pwd.matches(pattern);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return isPwdValid;
	}

	public static boolean emailPatternValidation(String email) {
		 Boolean isEmailValid = false;
		if (email != null && !email.equals("")) {
			
			try {
				String regex = "^(.+)@(.+)$";
				Pattern pattern = Pattern.compile(regex);
				Matcher matcher = pattern.matcher(email);
				if (matcher.matches()) {
					isEmailValid = true;
				}
				// System.out.println(email + " : " + matcher.matches());
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		return isEmailValid;
	}
	
	public static boolean isSpecialCharactersInString(String s) {
		 boolean isNameValid = true;

		try {
		if (s == null || s.trim().isEmpty()) {
		return true;
		}
		Pattern p = Pattern.compile("[^A-Za-z0-9\\s]");
		Matcher m = p.matcher(s);
		return m.find();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isNameValid;

	}
	
	public static boolean checkLatLangFormat(String s) {
		boolean isLatLangValid = false;
		try {
		String twoDoublesRegularExpression = "-?[1-9][0-9]*(\\.[0-9]+)?";

		if (s.matches(twoDoublesRegularExpression)) {
			isLatLangValid = true;
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isLatLangValid;

		}

         public static String findSettingValueByName(GlobalSettingRepository globalSettingRepository,LocalSettingRepository localSettingRepository, UserTypeRepository utr,String userTypeName,String userCode,String settingName) {
            String res=null;
                  try
                  {
                    UserType ut=utr.getUserTypeByUserTypeName(userTypeName);
                    if(ut!=null && ut.getId()>0)
                    {
                    String usetTypeCode=ut.getUserTypeCode();
                    GlobalSetting gs=globalSettingRepository.getGlobalSettingByUserTypeSettingName(usetTypeCode, settingName);
                    if(gs!=null && gs.getId()>0 && gs.getGlobalSettingCode()!=null)
                    {
                    LocalSetting ls=localSettingRepository.getLocalSettingByUserCodeGlobalSetingCode(userCode, gs.getGlobalSettingCode());
                    if(ls!=null && ls.getId()>0 && ls.getLocalSettingValue()!=null && ls.getLocalSettingValue().trim().length()>0)        
                    {
                        res=ls.getLocalSettingValue().trim();    
                    }
                    else if( gs.getSettingValue()!=null && gs.getSettingValue().trim().length()>0)
                    {
                        res=gs.getSettingValue().trim();
                    }        
                    }
                    }
                  }
                  catch(Exception ex)
                  {
                      ex.printStackTrace();
                  }
            
            return res;
        }
        

        public static String findSettingValueByName(GlobalSettingRepository globalSettingRepository,LocalSettingRepository localSettingRepository,String usetTypeCode,String userCode,String settingName) {
            String res=null;
                  try
                  {
                    
                    GlobalSetting gs=globalSettingRepository.getGlobalSettingByUserTypeSettingName(usetTypeCode, settingName);
                    if(gs!=null && gs.getId()>0 && gs.getGlobalSettingCode()!=null)
                    {
                    LocalSetting ls=localSettingRepository.getLocalSettingByUserCodeGlobalSetingCode(userCode, gs.getGlobalSettingCode());
                    if(ls!=null && ls.getId()>0 && ls.getLocalSettingValue()!=null && ls.getLocalSettingValue().trim().length()>0)        
                    {
                        res=ls.getLocalSettingValue().trim();    
                    }
                    else if( gs.getSettingValue()!=null && gs.getSettingValue().trim().length()>0)
                    {
                        res=gs.getSettingValue().trim();
                    }        
                    }
                  }
                  catch(Exception ex)
                  {
                      ex.printStackTrace();
                  }
            
            return res;
        }
        
        
        public static boolean findSettingValueByNameForNotification(GlobalSettingRepository globalSettingRepository,LocalSettingRepository localSettingRepository,String usetTypeCode,String userCode,String settingName) {
            boolean res=false;
                  try
                  {
                    
                    GlobalSetting gs=globalSettingRepository.getGlobalSettingByUserTypeSettingName(usetTypeCode, settingName);
                    if(gs!=null && gs.getId()>0 && gs.getGlobalSettingCode()!=null)
                    {
                    LocalSetting ls=localSettingRepository.getLocalSettingByUserCodeGlobalSetingCode(userCode, gs.getGlobalSettingCode());
                    if(ls!=null && ls.getId()>0 && ls.getLocalSettingValue()!=null && ls.getLocalSettingValue().trim().length()>0)        
                    {
                        if (ls.getLocalSettingValue().trim().equalsIgnoreCase("false")) {
                        res=false;    
                        }
                    }
                    else if( gs.getSettingValue()!=null && gs.getSettingValue().trim().length()>0)
                    {
                        if (gs.getSettingValue().trim().equalsIgnoreCase("false")) {
                        res=false;    
                        }
                    }        
                    }
                  }
                  catch(Exception ex)
                  {
                      ex.printStackTrace();
                  }
            
            return res;
        }
}
