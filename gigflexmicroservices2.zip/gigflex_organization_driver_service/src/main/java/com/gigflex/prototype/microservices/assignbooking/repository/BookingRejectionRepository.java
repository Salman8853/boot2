/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.assignbooking.repository;

import com.gigflex.prototype.microservices.assignbooking.dtob.BookingRejection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface BookingRejectionRepository extends JpaRepository< BookingRejection, Long>{
    
    @Query("SELECT b FROM BookingRejection b  WHERE b.isDeleted != TRUE AND  b.rideCode= :rideCode AND b.driverCode = :driverCode")
	public List<BookingRejection> getBookingRejectionByDriverCodeRideCode(@Param("driverCode") String driverCode,@Param("rideCode") String rideCode);
        
}
