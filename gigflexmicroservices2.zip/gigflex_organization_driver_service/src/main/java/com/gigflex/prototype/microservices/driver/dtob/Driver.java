package com.gigflex.prototype.microservices.driver.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author Abhishek
 */
@Entity
@Table(name = "driver")
public class Driver extends CommonAttributes implements Serializable  {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "driver_code", unique = true)
    private String driverCode;
    
    @Column(name = "name")
    private String name;
    
    @Column(name = "contactnumber")
    private String contactNumber;
    
    @Column(name = "country_code")
    private String countryCode;
    
    @Column(name = "emailid")
    private String emailId;
    
    @Column(name = "callsign")
    private String callsign;
    
    @Column(name = "operator_code")
    private String operatorCode;
    
    @Column(name="approveStatus")
    private Boolean approveStatus;
    
    @Column(name="organization_code")
    private String organizationCode;
    
    @Column(name = "driver_image")
    private String driverImage;
    
    @Column(name = "default_vehicle_code")
    private String defaultVehicleCode;
    
    @Column(name = "language")
    private String language;
    
    @Column(name = "dob",columnDefinition = "DATE")
    private Date dob;
    
     @Column(name = "emergency_contact_no")
    private String emergencyContactNo;
   
   
    @Column(name = "address")
     private String address;
     
    @Column(name = "city")
    private String city;
    
    @Column(name = "postCode")
    private String postCode;
    
    @Column(name = "country")
    private String country;
    
    @Column(name = "latitude")
    private String latitude;
    
    @Column(name = "longitude")
    private String longitude;
    
    @PrePersist
    private void assignUUID() {
        if(this.getDriverCode()==null || this.getDriverCode().length()==0)
        {
            this.setDriverCode(UUID.randomUUID().toString());
        }
    }

    public Driver() {
    }


    public Driver(Long id, String driverCode, String name,
			String contactNumber, String countryCode,String emailId,String callsign,
			String operatorCode, Boolean approveStatus,
			String organizationCode, String driverImage,String defaultVehicleCode) {
		super();
		this.id = id;
		this.driverCode = driverCode;
		this.name = name;
		this.contactNumber = contactNumber;
		this.countryCode = countryCode;
		this.emailId = emailId;
                this.callsign=callsign;
		this.operatorCode = operatorCode;
		this.approveStatus = approveStatus;
		this.organizationCode = organizationCode;
		this.driverImage = driverImage;
                this.defaultVehicleCode = defaultVehicleCode;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getCallsign() {
        return callsign;
    }

    public void setCallsign(String callsign) {
        this.callsign = callsign;
    }

    public String getOperatorCode() {
        return operatorCode;
    }

    public void setOperatorCode(String operatorCode) {
        this.operatorCode = operatorCode;
    }

    public Boolean getApproveStatus() {
        return approveStatus;
    }

    public void setApproveStatus(Boolean approveStatus) {
        this.approveStatus = approveStatus;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getDriverImage() {
        return driverImage;
    }

    public void setDriverImage(String driverImage) {
        this.driverImage = driverImage;
    }

    public String getCountryCode() {
            return countryCode;
    }

    public void setCountryCode(String countryCode) {
            this.countryCode = countryCode;
    }

    public String getDefaultVehicleCode() {
        return defaultVehicleCode;
    }

    public void setDefaultVehicleCode(String defaultVehicleCode) {
        this.defaultVehicleCode = defaultVehicleCode;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getEmergencyContactNo() {
        return emergencyContactNo;
    }

    public void setEmergencyContactNo(String emergencyContactNo) {
        this.emergencyContactNo = emergencyContactNo;
    }

   

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }




}
