package com.gigflex.prototype.microservices.booking.dtob;

import java.util.List;
import javax.persistence.Column;

public class BookingAllResponse {

	private Long id;

        private Long bookingid;
        
	private String rideCode;

	private String passengerName;

	private String primaryContactNumber;

	private String secondaryContactNumber;
	
	   private String pCountryCode;
		
	    private String sCountryCode;


	private String pickUpTime;

       private String dropOffTime;
       
	private String pickLat;

	private String pickLang;

	private String pickUpAddress;

	private String dropLat;

	private String dropLang;

	private String dropOffAddress;

	private String additionalStopPage;

	private Integer noOfPassengers;

	private Integer noOfBaggage;

	private String additionalComment;
// custumerFare will be Double Type;
	private Double customerFare;
        private String currencySymbol;
        
	private String bookingStatus;

	private String paymentOption;

	private String organizationCode;

	private String organizationName;

	private String vehicleCode;

	private String vehicleName;

	private Boolean isPublished;

	private String operatorCode;
	private String operatorName;
        
        private String assignorOperatorCode;
	private String assignorOperatorName;
        
        private String driverCode;
	private String driverName;
        
        private String globalRideCode;
	private String globalRideName;
        
        private String dateFormat ;
        private String timeFormat;

   private String cancelationComment;

   private Boolean isFocused=false;
   
   private String passengerCode;
   private String driverVehicleCode;
   
   private List<AdditionalChargesResponse> additionalChargesDetails;

    public String getDriverVehicleCode() {
        return driverVehicleCode;
    }

    public void setDriverVehicleCode(String driverVehicleCode) {
        this.driverVehicleCode = driverVehicleCode;
    }
   
    public String getGlobalRideCode() {
        return globalRideCode;
    }

    public void setGlobalRideCode(String globalRideCode) {
        this.globalRideCode = globalRideCode;
    }

    public String getGlobalRideName() {
        return globalRideName;
    }

    public void setGlobalRideName(String globalRideName) {
        this.globalRideName = globalRideName;
    }

    public Boolean getIsFocused() {
        return isFocused;
    }

    public void setIsFocused(Boolean isFocused) {
        this.isFocused = isFocused;
    }
	

    public String getAssignorOperatorCode() {
		return assignorOperatorCode;
	}

	public void setAssignorOperatorCode(String assignorOperatorCode) {
		this.assignorOperatorCode = assignorOperatorCode;
	}

	public String getAssignorOperatorName() {
        return assignorOperatorName;
    }

    public void setAssignorOperatorName(String assignorOperatorName) {
        this.assignorOperatorName = assignorOperatorName;
    }

    

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }
        

	public Boolean getIsPublished() {
		return isPublished;
	}

	public void setIsPublished(Boolean isPublished) {
		this.isPublished = isPublished;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRideCode() {
		return rideCode;
	}

	public void setRideCode(String rideCode) {
		this.rideCode = rideCode;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public String getPrimaryContactNumber() {
		return primaryContactNumber;
	}

	public void setPrimaryContactNumber(String primaryContactNumber) {
		this.primaryContactNumber = primaryContactNumber;
	}

	public String getSecondaryContactNumber() {
		return secondaryContactNumber;
	}

	public void setSecondaryContactNumber(String secondaryContactNumber) {
		this.secondaryContactNumber = secondaryContactNumber;
	}


	public String getPickUpTime() {
		return pickUpTime;
	}

	public void setPickUpTime(String pickUpTime) {
		this.pickUpTime = pickUpTime;
	}

    public String getDropOffTime() {
        return dropOffTime;
    }

    public void setDropOffTime(String dropOffTime) {
        this.dropOffTime = dropOffTime;
    }

	public String getPickLat() {
		return pickLat;
	}

	public void setPickLat(String pickLat) {
		this.pickLat = pickLat;
	}

	public String getPickLang() {
		return pickLang;
	}

	public void setPickLang(String pickLang) {
		this.pickLang = pickLang;
	}

	public String getPickUpAddress() {
		return pickUpAddress;
	}

	public void setPickUpAddress(String pickUpAddress) {
		this.pickUpAddress = pickUpAddress;
	}

	public String getDropLat() {
		return dropLat;
	}

	public void setDropLat(String dropLat) {
		this.dropLat = dropLat;
	}

	public String getDropLang() {
		return dropLang;
	}

	public void setDropLang(String dropLang) {
		this.dropLang = dropLang;
	}

	public String getDropOffAddress() {
		return dropOffAddress;
	}

	public void setDropOffAddress(String dropOffAddress) {
		this.dropOffAddress = dropOffAddress;
	}

	public String getAdditionalStopPage() {
		return additionalStopPage;
	}

	public void setAdditionalStopPage(String additionalStopPage) {
		this.additionalStopPage = additionalStopPage;
	}

	public Integer getNoOfPassengers() {
		return noOfPassengers;
	}

	public void setNoOfPassengers(Integer noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}

	public Integer getNoOfBaggage() {
		return noOfBaggage;
	}

	public void setNoOfBaggage(Integer noOfBaggage) {
		this.noOfBaggage = noOfBaggage;
	}

	public String getAdditionalComment() {
		return additionalComment;
	}

	public void setAdditionalComment(String additionalComment) {
		this.additionalComment = additionalComment;
	}

    public Double getCustomerFare() {
        return customerFare;
    }

    public void setCustomerFare(Double customerFare) {
        this.customerFare = customerFare;
    }

   

    public String getCurrencySymbol() {
        return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }

	

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public String getPaymentOption() {
		return paymentOption;
	}

	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getVehicleCode() {
		return vehicleCode;
	}

	public void setVehicleCode(String vehicleCode) {
		this.vehicleCode = vehicleCode;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public String getOperatorCode() {
		return operatorCode;
	}

	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public String getpCountryCode() {
		return pCountryCode;
	}

	public void setpCountryCode(String pCountryCode) {
		this.pCountryCode = pCountryCode;
	}

	public String getsCountryCode() {
		return sCountryCode;
	}

	public void setsCountryCode(String sCountryCode) {
		this.sCountryCode = sCountryCode;
	}

    public String getCancelationComment() {
        return cancelationComment;
    }

    public void setCancelationComment(String cancelationComment) {
        this.cancelationComment = cancelationComment;
    }

    public Long getBookingid() {
        return bookingid;
    }

    public void setBookingid(Long bookingid) {
        this.bookingid = bookingid;
    }

    public String getPassengerCode() {
        return passengerCode;
    }

    public void setPassengerCode(String passengerCode) {
        this.passengerCode = passengerCode;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getTimeFormat() {
        return timeFormat;
    }

    public void setTimeFormat(String timeFormat) {
        this.timeFormat = timeFormat;
    }

    public List<AdditionalChargesResponse> getAdditionalChargesDetails() {
        return additionalChargesDetails;
    }

    public void setAdditionalChargesDetails(List<AdditionalChargesResponse> additionalChargesDetails) {
        this.additionalChargesDetails = additionalChargesDetails;
    }

	
}
