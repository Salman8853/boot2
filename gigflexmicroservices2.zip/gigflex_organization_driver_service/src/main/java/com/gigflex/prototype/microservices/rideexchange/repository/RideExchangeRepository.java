/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.rideexchange.repository;

import com.gigflex.prototype.microservices.rideexchange.dtob.RideExchange;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface RideExchangeRepository extends JpaRepository<RideExchange, Long>, JpaSpecificationExecutor<RideExchange>{

    @Query("SELECT re FROM RideExchange re WHERE re.isDeleted != TRUE ORDER BY re.id DESC")
    public List<RideExchange> getLastBalanceOfRideExcahange();

    @Query("SELECT re FROM RideExchange re WHERE re.isDeleted != TRUE ")
    public List<RideExchange> getAllRideExchange();

    @Query("SELECT re FROM RideExchange re WHERE re.isDeleted != TRUE AND re.rideCode = :rideCode ")
    public RideExchange getRideExcahangeByRideCode(String rideCode);

    @Query("SELECT re FROM RideExchange re WHERE re.isDeleted != TRUE AND re.createdAt>=:fromDate  AND re.createdAt <=:toDate")
    public List<RideExchange> getRideExchangeBetweenDates(@Param("toDate") Date toDate ,@Param("fromDate") Date fromDate);
    
}
