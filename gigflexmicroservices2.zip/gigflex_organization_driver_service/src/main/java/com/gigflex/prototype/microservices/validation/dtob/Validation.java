package com.gigflex.prototype.microservices.validation.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "validation")
public class Validation extends CommonAttributes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "validation_code", unique = true)
	private String validationCode;

	@Column(name = "validation_name", nullable = false)
	private String validationName;

	@Column(name = "validationtype", nullable = false)
	private String validationType;

	@Column(name = "validationvalue", nullable = false)
	private String validationValue;

	@PrePersist
	private void assignUUID() {
		if (this.getValidationCode() == null || this.getValidationCode().length() == 0) {
			this.setValidationCode((UUID.randomUUID().toString()));
		}
	}

	public Validation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Validation(Long id, String validationCode, String validationName, String validationType,
			String validationValue) {
		super();
		this.id = id;
		this.validationCode = validationCode;
		this.validationName = validationName;
		this.validationType = validationType;
		this.validationValue = validationValue;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getValidationCode() {
		return validationCode;
	}

	public void setValidationCode(String validationCode) {
		this.validationCode = validationCode;
	}

	public String getValidationName() {
		return validationName;
	}

	public void setValidationName(String validationName) {
		this.validationName = validationName;
	}

	public String getValidationType() {
		return validationType;
	}

	public void setValidationType(String validationType) {
		this.validationType = validationType;
	}

	public String getValidationValue() {
		return validationValue;
	}

	public void setValidationValue(String validationValue) {
		this.validationValue = validationValue;
	}

	@Override
	public String toString() {
		return "Validation [id=" + id + ", validationCode=" + validationCode + ", validationName=" + validationName
				+ ", validationType=" + validationType + ", validationValue=" + validationValue + "]";
	}

}
