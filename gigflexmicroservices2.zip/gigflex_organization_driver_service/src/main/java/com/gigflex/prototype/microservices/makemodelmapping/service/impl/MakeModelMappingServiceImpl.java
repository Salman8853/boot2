package com.gigflex.prototype.microservices.makemodelmapping.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.makemodelmapping.dtob.MakeModelMapping;
import com.gigflex.prototype.microservices.makemodelmapping.dtob.MakeModelMappingRequest;
import com.gigflex.prototype.microservices.makemodelmapping.dtob.MakeModelResponse;
import com.gigflex.prototype.microservices.makemodelmapping.repository.MakeModelMappingRepository;
import com.gigflex.prototype.microservices.makemodelmapping.search.MakeModelMappingSpecificationsBuilder;
import com.gigflex.prototype.microservices.makemodelmapping.service.MakeModelMappingService;
import com.gigflex.prototype.microservices.maketype.dtob.MakeType;
import com.gigflex.prototype.microservices.maketype.repository.MakeTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexResponse;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

@Service
public class MakeModelMappingServiceImpl implements MakeModelMappingService {

	@Autowired
	MakeModelMappingRepository makeModelMappRepository;
	
	@Autowired
	MakeTypeRepository makeTypeDao;

	@Override
	public String getAllMakeModelMapping() {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//			List<MakeModelMapping> makeModelMapplst = makeModelMappRepository
//					.getAllMakeModelMapping();
//
//			if (makeModelMapplst != null && makeModelMapplst.size() > 0) {
//				jsonobj.put("responsecode", 200);
//				jsonobj.put("message", "Success");
//				jsonobj.put("timestamp", new Date());
//				ObjectMapper mapperObj = new ObjectMapper();
//				String Detail = mapperObj.writeValueAsString(makeModelMapplst);
//				jsonobj.put("data", new JSONArray(Detail));
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("message", "Record Not Found.");
//				jsonobj.put("timestamp", new Date());
//			}
//			res = jsonobj.toString();
//		} catch (JSONException | JsonProcessingException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception occurred.");
//			res = derr.toString();
//		}
//		return res;
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
		
			List<Object> objlst = makeModelMappRepository.getAllMakeModelMapping();
			List<MakeModelResponse> maplst = new ArrayList<MakeModelResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {
						
						MakeModelResponse mmr = new MakeModelResponse();

						MakeModelMapping data = (MakeModelMapping) arr[0];
						
						mmr.setId(data.getId());
						mmr.setModelCode(data.getModelCode());
						mmr.setModelName(data.getModelName());
						mmr.setMakeCode(data.getMakeCode());
						mmr.setVehicleName((String) arr[1]);
				

						maplst.add(mmr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getMakeModelMappingById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			MakeModelMapping makeModelMapplst = makeModelMappRepository
					.getMakeModelMappingById(id);
			if (makeModelMapplst != null && makeModelMapplst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(makeModelMapplst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveNewMakeModelMapping(
			MakeModelMappingRequest makeModelMapReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (makeModelMapReq != null) {

				if ((makeModelMapReq.getMakeCode() != null && makeModelMapReq
						.getMakeCode().trim().length() > 0)
						
						&& (makeModelMapReq.getModelName() != null && makeModelMapReq
								.getModelName().trim().length() > 0)) {

					MakeModelMapping mmm = makeModelMappRepository.getMakeModelMappingByMakeCodeAndModelName(makeModelMapReq.getMakeCode(), makeModelMapReq.getModelName());
					MakeType makeType = makeTypeDao.getMakeTypeByVehicleCode(makeModelMapReq.getMakeCode())	;
                    if(makeType != null && makeType.getId() > 0) {
					if (mmm != null && mmm.getId() > 0) {
						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record already exist.");
					} else {

						MakeModelMapping makeModelMapplst = new MakeModelMapping();

						makeModelMapplst.setMakeCode(makeModelMapReq
								.getMakeCode());
						makeModelMapplst.setModelName(makeModelMapReq
								.getModelName());
						
						makeModelMapplst.setIpAddress(ip);

						MakeModelMapping makeModelMappRes = makeModelMappRepository
								.save(makeModelMapplst);

						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());

						if (makeModelMappRes != null
								&& makeModelMappRes.getId() > 0) {

							jsonobj.put("message",
									"Make Model Mapping has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(makeModelMappRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("message", "Failed");
						}
					}
                    } else {
    					jsonobj.put("responsecode", 400);
    					jsonobj.put("timestamp", new Date());
    					jsonobj.put("message",
    							"Make Code not found.");
    				}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateMakeModelMappingById(Long id,
			MakeModelMappingRequest makeModelMapReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && makeModelMapReq != null) {

				if ((makeModelMapReq.getMakeCode() != null && makeModelMapReq
						.getMakeCode().trim().length() > 0)
						
						&& (makeModelMapReq.getModelName() != null && makeModelMapReq
								.getModelName().trim().length() > 0)) {
					
					MakeType makeType = makeTypeDao.getMakeTypeByVehicleCode(makeModelMapReq.getMakeCode())	;

				      if(makeType != null && makeType.getId() > 0) {

					MakeModelMapping makeModelMapplst = makeModelMappRepository
							.getMakeModelMappingById(id);
					if (makeModelMapplst != null
							&& makeModelMapplst.getId() > 0) {

						MakeModelMapping makeModelMappL = makeModelMappRepository
								.getMakeModelMappingByIdMakeCodeAndModelName(
										id, makeModelMapReq.getMakeCode(), makeModelMapReq.getModelName());
						if (makeModelMappL != null
								&& makeModelMappL.getId() > 0) {
							jsonobj.put("responsecode", 409);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Record already exist.");
						} else {

							MakeModelMapping makeModMapp = makeModelMapplst;

							makeModMapp.setMakeCode(makeModelMapReq
									.getMakeCode());
							makeModMapp.setModelName(makeModelMapReq
									.getModelName());
							makeModMapp.setIpAddress(ip);

							MakeModelMapping makeModMappRes = makeModelMappRepository
									.save(makeModMapp);
							if (makeModMappRes != null
									&& makeModMappRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("message",
										"Make Model Mapping updation has been done");
								jsonobj.put("timestamp", new Date());
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(makeModMappRes);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("message",
										"Make Model Mapping updation has been failed.");
								jsonobj.put("timestamp", new Date());
							}
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message",
								"Make Model Mapping ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				      } else {
	    					jsonobj.put("responsecode", 400);
	    					jsonobj.put("timestamp", new Date());
	    					jsonobj.put("message",
	    							"Make Code not found.");
	    				}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteMakeModelMappingByModelCode(String modelCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			MakeModelMapping makeModelMapplst = makeModelMappRepository.getMakeModelMappingByModelCode(modelCode);
			

			if (makeModelMapplst != null && makeModelMapplst.getId() > 0) {
				makeModelMapplst.setIsDeleted(true);
				MakeModelMapping makeModMappRes = makeModelMappRepository
						.save(makeModelMapplst);
				if (makeModMappRes != null && makeModMappRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());

					jsonobj.put("message",
							"Make Model Mapping deleted successfully.");
					// kafkaService.sendUserRolesMappingAtUpdate(useroleRes);

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByModelCode(List<String> modelCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String modelCode : modelCodeList) {
				if (modelCode != null && modelCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					MakeModelMapping makeModelMapplst = makeModelMappRepository.getMakeModelMappingByModelCode(modelCode);

					if (makeModelMapplst != null
							&& makeModelMapplst.getId() > 0) {

						makeModelMapplst.setIsDeleted(true);
						MakeModelMapping makeModMappRes = makeModelMappRepository
								.save(makeModelMapplst);
						if (makeModMappRes != null
								&& makeModMappRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("modelCode", modelCode);
							jsonobj.put("message",
									"Make Model Mapping deleted successfully.");
							// kafkaService
							// .sendUserRolesMappingAtUpdate(useroleRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("modelCode", modelCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("modelCode", modelCode);
						jsonobj.put("message", "Record Not Found");
					}

					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllMakeModelMappingByPage(int page, int limit) {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//			Pageable pageableRequest = PageRequest.of(page, limit);
//			List<MakeModelMapping> makeModelMapplst = makeModelMappRepository
//					.getAllMakeModelMapping(pageableRequest);
//
//			if (makeModelMapplst != null && makeModelMapplst.size() > 0) {
//				jsonobj.put("responsecode", 200);
//				jsonobj.put("message", "Success");
//				jsonobj.put("timestamp", new Date());
//				ObjectMapper mapperObj = new ObjectMapper();
//				String Detail = mapperObj.writeValueAsString(makeModelMapplst);
//				jsonobj.put("data", new JSONArray(Detail));
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("message", "Record Not Found.");
//				jsonobj.put("timestamp", new Date());
//			}
//			res = jsonobj.toString();
//		} catch (JSONException | JsonProcessingException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception occurred.");
//			res = derr.toString();
//		}
//		return res;
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<Object> objlst = makeModelMappRepository.getAllMakeModelMapping(pageableRequest);
			 int count=0;
                        List<Object> cntlst =  makeModelMappRepository.getAllMakeModelMapping();
                        if(cntlst!=null)
                        {
                        count=cntlst.size();
                        }
                        List<MakeModelResponse> maplst = new ArrayList<MakeModelResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {
						
						MakeModelResponse mmr = new MakeModelResponse();

						MakeModelMapping data = (MakeModelMapping) arr[0];
						
						mmr.setId(data.getId());
						mmr.setModelCode(data.getModelCode());
						mmr.setModelName(data.getModelName());
						mmr.setMakeCode(data.getMakeCode());
						mmr.setVehicleName((String) arr[1]);
				

						maplst.add(mmr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
                                         jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
            } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				MakeModelMappingSpecificationsBuilder builder = new MakeModelMappingSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<MakeModelMapping> spec = builder.build();
                                if(spec!=null){
				List<MakeModelMapping> MakeModelMappingLst = makeModelMappRepository
						.findAll(spec);
				if (MakeModelMappingLst != null
						&& MakeModelMappingLst.size() > 0) {
					for (MakeModelMapping dept : MakeModelMappingLst) {
						if (dept.getIsDeleted() != null
								&& dept.getIsDeleted() != true) {

							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(dept);
							JSONObject jsonobjNew = new JSONObject();
							jsonobjNew.put("MakeModelMapping", new JSONObject(
									Detail));
							jarr.add(jsonobjNew);

						}

					}
					if (jarr.size() > 0) {

						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", jarr);
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}}
                                else{
                                   jsonobj.put("responsecode", 400);
				   jsonobj.put("message", "Record Not Found!");
				   jsonobj.put("timestamp", new Date()); 
                                }
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;

	}

	@Override
	public String getByModelCode(String modelCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
		
			Object objlst = makeModelMappRepository.getByModelCode(modelCode);
			 
//			if (objlst != null && objlst.size() > 0) {
//				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst;
					if (arr.length >= 2) {
						
						MakeModelResponse mmr = new MakeModelResponse();

						MakeModelMapping data = (MakeModelMapping) arr[0];
						
						mmr.setId(data.getId());
						mmr.setModelCode(data.getModelCode());
						mmr.setModelName(data.getModelName());
						mmr.setMakeCode(data.getMakeCode());
						mmr.setVehicleName((String) arr[1]);
				
						MakeModelResponse maplst = mmr;
//						maplst.add(mmr);

//					}
//				}
				if (maplst != null) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getModelByMakeCode(String makeCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
		
			List<Object> objlst = makeModelMappRepository.getModelByMakeCode(makeCode);
			List<MakeModelResponse> maplst = new ArrayList<MakeModelResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {
						
						MakeModelResponse mmr = new MakeModelResponse();

						MakeModelMapping data = (MakeModelMapping) arr[0];
						
						mmr.setId(data.getId());
						mmr.setModelCode(data.getModelCode());
						mmr.setModelName(data.getModelName());
						mmr.setMakeCode(data.getMakeCode());
						mmr.setVehicleName((String) arr[1]);
				

						maplst.add(mmr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getModelByMakeCodeByPage(String makeCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<Object> objlst = makeModelMappRepository.getModelByMakeCode(makeCode, pageableRequest);
			List<MakeModelResponse> maplst = new ArrayList<MakeModelResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {
						
						MakeModelResponse mmr = new MakeModelResponse();

						MakeModelMapping data = (MakeModelMapping) arr[0];
						
						mmr.setId(data.getId());
						mmr.setModelCode(data.getModelCode());
						mmr.setModelName(data.getModelName());
						mmr.setMakeCode(data.getMakeCode());
						mmr.setVehicleName((String) arr[1]);
				

						maplst.add(mmr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

}
