/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.util;

/**
 *
 * @author abhishek
 */
public class GigflexConstants {
    public static final String assignedBookingStatus = "pending";
    public static final String assignedBookingInProgressStatus = "inProgress";
    public static final String assignedBookingAcceptedStatus = "accepted";
    public static final String assignedBookingCancelledStatus = "cancelled";
    public static final String assignedBookingExpiredStatus = "expired";
    public static final String assignedBookingRejectedStatus = "rejected";
    public static final String assignedBookingChangedStatus = "changed";
    public static final String assignedBookingCompletedStatus = "completed";
    public static final String assignedBookingPublishedStatus = "published";
    public static final String bookingStatus = "assigned";
    public static final String dateFormatterForView = "dd-MM-yyyy hh:mm a";
    public static final String dateFormatterForSave ="yyyy-MM-dd HH:mm:ss";
    public static final String saveDateWithoutTime ="yyyy-MM-dd";
    public static final String  YYYY_MM_DD = "yyyy-MM-dd";
    public static final String userTypeOrganization ="Organizations";
    public static final String userTypeOperator ="Operators";
    public static final String userTypeDriver ="Drivers";
    public static final String DATEFORMAT="DateFormat";
    public static final String TIMEFORMAT="TimeFormat";
    public static final String TimeZone="TimeZone";
    public static final String HH_MM_SS = "HH:mm:ss";
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static final String Organizations = "Organizations";
    public static final String Operators = "Operators";
    public static final String Drivers = "Drivers";
    public static final String CURRENCYNAME="CurrencyName";
    public static final String CURRENCYSYMBOL="CurrencySymbol";
    public static final Integer MON_DAY=1;
    public static final Integer TUES_DAY=2;
    public static final Integer WEDNES_DAY=3;
    public static final Integer THURS_DAY=4;
    public static final Integer FRI_DAY=5;
    public static final Integer SATUR_DAY=6;
    public static final Integer SUN_DAY=7;
    public static final int REAPONSECODE_SUCCESS=200; 
    public static final int REAPONSECODE_FAILED=400;
    public static final int REAPONSECODE_NOTVALID=400;
    public static final int REAPONSECODE_NOTFOUND=404;
    public static final int REAPONSECODE_UNAUTHORIZED=401;
    public static final int REAPONSECODE_ALREADYEXIST=409;
    public static final double NEAREST_DISTANCE_MILES = 0.0994194; //2.0
    public static final String USER_TYPE_SUPER_ADMIN = "SuperAdmin";
    public static final String SETTING_NAME_CREDIT_AMOUNT = "CreditAmount";
    public static final String SETTING_NAME_COMMISION_PERSENTAGE = "CommissionPercentage";
    public static final String BOOKING = "Booking";
    public static final String TRANSACTION_TYPE_CREDIT = "Credit";
    public static final String TRANSACTION_TYPE_DEBIT = "Debit";
    
     
            
    
}
