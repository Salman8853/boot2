package com.gigflex.prototype.microservices.documentvalidationmapping.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.documentvalidationmapping.dtob.DocumentValidationMapping;

public interface DocumentValidationMappingRepository extends JpaRepository<DocumentValidationMapping, Long>,JpaSpecificationExecutor<DocumentValidationMapping>{
	
	@Query("SELECT m,dt.documentName,v.validationName FROM DocumentValidationMapping m,DocumentTypeDetail dt,Validation v WHERE m.documentCode = dt.documentCode AND m.validationCode = v.validationCode AND m.isDeleted != TRUE")
	public List<Object> getAllDocumentValidationMapping();
	
	@Query("SELECT m,dt.documentName,v.validationName FROM DocumentValidationMapping m,DocumentTypeDetail dt,Validation v WHERE m.documentCode = dt.documentCode AND m.validationCode = v.validationCode AND m.isDeleted != TRUE")
	public List<Object> getAllDocumentValidationMapping(Pageable pageableRequest);
	
	@Query("SELECT m,dt.documentName,v.validationName FROM DocumentValidationMapping m,DocumentTypeDetail dt,Validation v WHERE m.documentCode = dt.documentCode AND m.validationCode = v.validationCode AND m.isDeleted != TRUE AND m.documentValidationCode = :documentValidationCode")
	public Object getDocumentValidationMappingByDocumentValidationCode(@Param("documentValidationCode") String documentValidationCode);
	
	@Query("SELECT m FROM DocumentValidationMapping m WHERE m.isDeleted != TRUE AND m.documentValidationCode = :documentValidationCode")
	public DocumentValidationMapping findDocumentValidationMappingByDocumentValidationCode(@Param("documentValidationCode") String documentValidationCode);
	
	@Query("SELECT m,dt.documentName,v.validationName FROM DocumentValidationMapping m,DocumentTypeDetail dt,Validation v WHERE m.documentCode = dt.documentCode AND m.validationCode = v.validationCode AND m.isDeleted != TRUE AND m.id = :id")
	public Object getDocumentValidationMappingById(@Param("id") Long id);
	
	@Query("SELECT m FROM DocumentValidationMapping m WHERE m.isDeleted != TRUE AND m.id = :id")
	public DocumentValidationMapping findDocumentValidationMappingById(@Param("id") Long id);
	
	@Query("SELECT m FROM DocumentValidationMapping m WHERE m.isDeleted != TRUE AND m.documentCode = :documentCode AND m.validationCode = :validationCode")
	public DocumentValidationMapping getDocumentValidationMappingByDocumentCodeAndValidationCode(@Param("documentCode") String documentCode,@Param("validationCode") String validationCode);
	
	@Query("SELECT m FROM DocumentValidationMapping m WHERE m.isDeleted != TRUE AND m.id != :id AND m.documentCode = :documentCode AND m.validationCode = :validationCode")
	public DocumentValidationMapping getDocumentValidationMappingByDocumentCodeAndValidationCodeById(@Param("id") Long id,@Param("documentCode") String documentCode,@Param("validationCode") String validationCode);
	
	@Query("SELECT m,dt.documentName,v.validationName FROM DocumentValidationMapping m,DocumentTypeDetail dt,Validation v WHERE m.documentCode = dt.documentCode AND m.validationCode = v.validationCode AND m.isDeleted != TRUE AND m.documentCode = :documentCode")
	public List<Object> getDocumentValidationMappingByDocumentCode(@Param("documentCode") String documentCode);
	
	@Query("SELECT m,dt.documentName,v.validationName FROM DocumentValidationMapping m,DocumentTypeDetail dt,Validation v WHERE m.documentCode = dt.documentCode AND m.validationCode = v.validationCode AND m.isDeleted != TRUE AND m.documentCode = :documentCode")
	public List<Object> getDocumentValidationMappingByDocumentCode(@Param("documentCode") String documentCode,Pageable pageableRequest);
	
	@Query("SELECT m,dt.documentName,v.validationName FROM DocumentValidationMapping m,DocumentTypeDetail dt,Validation v WHERE m.documentCode = dt.documentCode AND m.validationCode = v.validationCode AND m.isDeleted != TRUE AND m.validationCode = :validationCode")
	public List<Object> getDocumentValidationMappingByValidationCode(@Param("validationCode") String validationCode);
	
	@Query("SELECT m,dt.documentName,v.validationName FROM DocumentValidationMapping m,DocumentTypeDetail dt,Validation v WHERE m.documentCode = dt.documentCode AND m.validationCode = v.validationCode AND m.isDeleted != TRUE AND m.validationCode = :validationCode")
	public List<Object> getDocumentValidationMappingByValidationCode(@Param("validationCode") String validationCode,Pageable pageableRequest);

}
