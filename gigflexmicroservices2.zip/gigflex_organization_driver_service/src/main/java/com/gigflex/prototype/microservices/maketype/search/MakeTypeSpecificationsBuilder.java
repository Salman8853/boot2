package com.gigflex.prototype.microservices.maketype.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.maketype.dtob.MakeType;
import com.gigflex.prototype.microservices.util.SearchCriteria;




public class MakeTypeSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public MakeTypeSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public MakeTypeSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<MakeType> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<MakeType>> specs = new ArrayList<Specification<MakeType>>();
        for (SearchCriteria param : params) {
            specs.add(new MakeTypeSpecification(param));
        }
 
        Specification<MakeType> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
