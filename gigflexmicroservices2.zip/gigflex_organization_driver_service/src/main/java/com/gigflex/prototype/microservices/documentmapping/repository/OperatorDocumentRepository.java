/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.repository;

import com.gigflex.prototype.microservices.documentmapping.dtob.OperatorDocument;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import java.util.Date;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface OperatorDocumentRepository extends JpaRepository<OperatorDocument, Long>,JpaSpecificationExecutor<OperatorDocument>{
	
	@Query("SELECT a,b.documentName,c.operatorName FROM OperatorDocument a, DocumentTypeDetail b,Operator c WHERE a.isDeleted != TRUE AND b.documentCode = a.documentCode AND a.operatorCode = c.operatorCode")
    public List<Object> getAllOperatorDocument();
	
	@Query("SELECT a,b.documentName,c.operatorName FROM OperatorDocument a, DocumentTypeDetail b,Operator c WHERE a.isDeleted != TRUE AND b.documentCode = a.documentCode AND a.operatorCode = c.operatorCode AND a.operatorCode = :operatorCode")
    public List<Object> getAllOperatorDocumentByOperatorCode(@Param("operatorCode") String operatorCode);
	
	@Query("SELECT a,b.documentName,c.operatorName FROM OperatorDocument a, DocumentTypeDetail b,Operator c WHERE a.isDeleted != TRUE AND b.documentCode = a.documentCode AND a.operatorCode = c.operatorCode")
    public List<Object> getAllOperatorDocument(Pageable pageableRequest);
	
	@Query("SELECT a,b.documentName,c.operatorName FROM OperatorDocument a, DocumentTypeDetail b,Operator c WHERE a.isDeleted != TRUE AND b.documentCode = a.documentCode AND a.operatorCode = c.operatorCode AND a.operatorCode = :operatorCode")
    public List<Object> getAllOperatorDocumentByOperatorCode(@Param("operatorCode") String operatorCode,Pageable pageableRequest);

	
//    @Query("SELECT d FROM OperatorDocument d WHERE d.isDeleted != TRUE")
//    public List<OperatorDocument> getAllOperatorDocument();
//    
//    @Query("SELECT d FROM OperatorDocument d WHERE d.isDeleted != TRUE AND d.operatorCode=:operatorCode")
//    public List<OperatorDocument> getAllOperatorDocumentByOperatorCode(@Param("operatorCode") String operatorCode);
    
    @Query("SELECT d FROM OperatorDocument d WHERE d.isDeleted != TRUE AND d.operatorDocumentCode=:operatorDocumentCode")
    public OperatorDocument getOperatorDocumentByOperatorDocumentCode(@Param("operatorDocumentCode") String operatorDocumentCode);
 
    @Query("SELECT d FROM OperatorDocument d WHERE d.isDeleted != TRUE AND d.documentCode=:documentCode AND d.operatorCode=:operatorCode")
    public OperatorDocument getOperatorDocumentByOperatorCodeDocumentCode(@Param("documentCode") String documentCode,@Param("operatorCode") String operatorCode);
    
    @Query("SELECT d FROM OperatorDocument d WHERE d.isDeleted != TRUE AND d.documentCode=:documentCode AND d.operatorCode=:operatorCode AND d.operatorDocumentCode!=:operatorDocumentCode")
    public OperatorDocument getOperatorDocumentByOperatorCodeDocumentCodeNotInCode(@Param("operatorDocumentCode") String operatorDocumentCode,@Param("documentCode") String documentCode,@Param("operatorCode") String operatorCode);

	@Query("SELECT a FROM TimeZoneDetail a,Organization b,Operator c WHERE a.isDeleted != TRUE AND c.isDeleted != TRUE AND b.isDeleted != TRUE AND c.organizationCode = b.organizationCode AND b.timezone = a.timeZoneCode AND c.operatorCode = :operatorCode")
    public TimeZoneDetail getTimeZoneByOperatorCode(@Param("operatorCode") String operatorCode);
    
    @Query("SELECT od FROM OperatorDocument od  WHERE od.operatorCode=:operatorCode AND od.docExpiration<:docExpiration AND od.isDeleted != TRUE ")
    public List<OperatorDocument> getOperatorDocumentExpirationByOperatorCode(@Param("operatorCode") String operatorCode,@Param("docExpiration") Date docExpiration);
    
    @Query("SELECT DISTINCT (dm.driverCode) FROM DriverDocument dm WHERE dm.docExpiration<:docExpiration AND dm.isDeleted != TRUE  AND dm.driverCode IN(SELECT d.driverCode FROM Driver d WHERE d.operatorCode=:operatorCode AND d.isDeleted != TRUE)")
    public List<String> getDriverExpiredDocumentDetail(@Param("docExpiration") Date docExpiration,@Param("operatorCode") String operatorCode);
    
}
