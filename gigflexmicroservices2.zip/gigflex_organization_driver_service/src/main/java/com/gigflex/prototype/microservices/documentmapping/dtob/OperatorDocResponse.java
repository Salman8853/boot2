package com.gigflex.prototype.microservices.documentmapping.dtob;


public class OperatorDocResponse {
	
	private Long id;

	private String operatorDocumentCode;

	private String operatorCode;

	private String documentCode;
	
    
	private String docValue;

	private String docExpiration;

//	private String documentType;
	private String documentName;

	private String operatorName;

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}



	public String getOperatorDocumentCode() {
		return operatorDocumentCode;
	}

	public void setOperatorDocumentCode(String operatorDocumentCode) {
		this.operatorDocumentCode = operatorDocumentCode;
	}

	public String getOperatorCode() {
		return operatorCode;
	}

	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}

	public String getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}

	

	public String getDocValue() {
		return docValue;
	}

	public void setDocValue(String docValue) {
		this.docValue = docValue;
	}

	public String getDocExpiration() {
		return docExpiration;
	}

	public void setDocExpiration(String docExpiration) {
		this.docExpiration = docExpiration;
	}

//	public String getDocumentType() {
//		return documentType;
//	}
//
//	public void setDocumentType(String documentType) {
//		this.documentType = documentType;
//	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}
	
	

}
