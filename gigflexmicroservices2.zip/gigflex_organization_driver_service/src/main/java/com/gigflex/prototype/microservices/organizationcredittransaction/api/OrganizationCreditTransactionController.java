/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationcredittransaction.api;


import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransactionRequest;
import com.gigflex.prototype.microservices.organizationcredittransaction.service.OrganizationCreditTransactionService;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author amit.kumar
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class OrganizationCreditTransactionController {
    
    
    
    @Autowired
    public OrganizationCreditTransactionService organizationCreditAmountService;

    
    @GetMapping("/getAllOrganizationCreditTransactions")
    public String getAllOperatorCreditTransactions() {
            return organizationCreditAmountService.findAllOrganizationCreditTransactions();
    }
    
    @GetMapping("/getLastTransactionBalanceByOrganizationCode/{organizationCode}")
    public String getLastTransactionBalanceByOrganizationCode(@PathVariable String organizationCode,@RequestHeader HttpHeaders headers) {
         
            return organizationCreditAmountService.getLastTransactionBalanceByOrganizationCode(organizationCode);
           
    }
    
    @GetMapping("/getTransactionDetailsByOrganizationCodeAndBetweenDates/{organizationCode}/{stratDT}/{endDT}")
    public String getTransactionDetailsByOrganizationCodeAndBetweenDates(@PathVariable String organizationCode,@PathVariable String stratDT,@PathVariable String endDT,@RequestHeader HttpHeaders headers) {
         
        
         if(organizationCode!=null && organizationCode.trim().length()>0 ) {
        
            if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(stratDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

                } catch (Exception ex) {
                        ex.printStackTrace();
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
                        return derr.toString();
                }
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "End Date must be after Start Date.");
                        return derr.toString();
                   }
                }
                
            }
            else {
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Start Date and End Date should not be blank.");
                        return derr.toString();
                }
				
                return organizationCreditAmountService.getTransactionDetailsByOrganizationCodeAndBetweenDates(organizationCode.trim(),stratDT.trim(), endDT.trim());
           
         }else {
                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                                    "Organization Code should not be blank.");
                    return derr.toString();
            }
	}

              
     @GetMapping("/getSummaryOfTransactionDetailsByOrgCodeAndBetweenDates/{organizationCode}/{stratDT}/{endDT}")
    public String getSummaryOfTransactionDetailsByOrgCodeAndBetweenDates(@PathVariable String organizationCode,@PathVariable String stratDT,@PathVariable String endDT,@RequestHeader HttpHeaders headers) {
         
        
         if(organizationCode!=null && organizationCode.trim().length()>0 ) {
        
            if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(stratDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

                } catch (Exception ex) {
                        ex.printStackTrace();
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
                        return derr.toString();
                }
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "End Date must be after Start Date.");
                        return derr.toString();
                   }
                }
                
            }
            else {
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Start Date and End Date should not be blank.");
                        return derr.toString();
                }
				
                return organizationCreditAmountService.getSummaryOfTransactionDetailsByOrgCodeAndBetweenDates(organizationCode.trim(),stratDT.trim(), endDT.trim());
           
         }else {
                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                                    "Organization Code should not be blank.");
                    return derr.toString();
            }
	}
    
      @PostMapping("/saveOrganizationCreditTransaction")
	public String saveOrganizationCreditTransaction(@RequestBody OrganizationCreditTransactionRequest organizationReq,
			HttpServletRequest request) {
           
            String ip = request.getRemoteAddr();
            return organizationCreditAmountService.saveOrganizationCreditTransaction(organizationReq, ip);        
                  
	}  
        
    
    
}
