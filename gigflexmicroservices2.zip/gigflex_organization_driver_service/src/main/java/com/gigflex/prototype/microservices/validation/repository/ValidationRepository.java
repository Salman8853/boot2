package com.gigflex.prototype.microservices.validation.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.validation.dtob.Validation;



public interface ValidationRepository extends JpaRepository<Validation, Long>,JpaSpecificationExecutor<Validation>{
	
	@Query("SELECT m FROM Validation m WHERE m.isDeleted != TRUE")
	public List<Validation> getAllValidation();
	
	@Query("SELECT m FROM Validation m WHERE m.isDeleted != TRUE")
	public List<Validation> getAllValidation(Pageable pageableRequest);
	
	@Query("SELECT m FROM Validation m WHERE m.isDeleted != TRUE AND m.validationCode = :validationCode")
	public Validation getValidationByValidationCode(@Param("validationCode") String validationCode);
	
	@Query("SELECT m FROM Validation m WHERE m.isDeleted != TRUE AND m.id = :id")
	public Validation getValidationById(@Param("id") Long id);
	
	@Query("SELECT m FROM Validation m WHERE m.isDeleted != TRUE AND m.validationName = :validationName AND m.validationType = :validationType")
	public Validation getValidationByValidationNameAndValidationType(@Param("validationName") String validationName,@Param("validationType") String validationType);
	
	@Query("SELECT m FROM Validation m WHERE m.isDeleted != TRUE AND m.id != :id AND m.validationName = :validationName AND m.validationType = :validationType")
	public Validation getValidationByValidationNameAndValidationTypeById(@Param("id") Long id,@Param("validationName") String validationName,@Param("validationType") String validationType);
}
