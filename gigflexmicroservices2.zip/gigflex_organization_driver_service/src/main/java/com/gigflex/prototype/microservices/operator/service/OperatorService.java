/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.operator.service;

import java.util.List;

import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.dtob.OperatorRequest;
import com.gigflex.prototype.microservices.operator.dtob.OperatorUpRequest;

/**
 *
 * @author Abhishek
 */
public interface OperatorService {
    public Operator saveOperatorsDetatil(Operator Operator);
    
    public String findAllOperators();

	public String getAllOperatorsByPage(int page, int limit);

	public String getOperatorByOperatorCode(String operatorCode);

	public String findOperatorById(Long id);
	
	public String saveOperator(OperatorRequest operatorReq,
			String ip);

	public String updateOperatorById(Long id,OperatorUpRequest operatorReq,
			String ip);

	public String softDeleteByOperatorCode(String operatorCode);

	public String softMultipleDeleteByOperatorCode(List<String> operatorCodeList);

	public String search(String search);
	
	public Operator getUserEmail(String userEmail);
	
	public String getOperatorByOrganizationCode(String organizationCode);
	
	public String getOperatorByOrganizationCodeByPage(String organizationCode,int page, int limit);
	
	
    
}
