package com.gigflex.prototype.microservices.notification.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBooking;
import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.booking.dtob.BookingResponse;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.notification.dtob.NotificationRequest;
import com.gigflex.prototype.microservices.notification.dtob.NotificationUpdate;
import com.gigflex.prototype.microservices.notification.repository.NotificationDao;
import com.gigflex.prototype.microservices.notification.service.NotificationService;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.utility.GigflexDateUtil;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

@Service
public class NotificationServiceImpl implements NotificationService {

	@Autowired
	private NotificationDao notificationDao;

	@Autowired
	private DriverRepository driverDao;

	@Autowired
	private OperatorRepository operatorDao;
	
	@Autowired
	KafkaService kafkaService;

	@Override
	public String saveNotification(NotificationRequest notificationReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (notificationReq != null) {

				if (notificationReq.getUserCode() != null && notificationReq.getUserCode().trim().length() > 0
						&& notificationReq.getMessage() != null && notificationReq.getMessage().trim().length() > 0) {

					Driver driver = driverDao.getDriverByDriverCode(notificationReq.getUserCode());

					Operator operator = operatorDao.getOperatorByOperatorCode(notificationReq.getUserCode());

					if ((operator != null && operator.getId() > 0) || (driver != null && driver.getId() > 0)) {

						Notification notification = new Notification();

						notification.setUserCode(notificationReq.getUserCode());
						notification.setMessage(notificationReq.getMessage());
						notification.setIsRead(Boolean.FALSE);
						notification.setIpAddress(ip);

						Notification notificationRes = notificationDao.save(notification);

						if (notificationRes != null && notificationRes.getId() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Notification has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(notificationRes);
							jsonobj.put("data", new JSONObject(Detail));

						} else {
							jsonobj.put("message", "Failed");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "User Code not found.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String updateNotificationByNotificationCode(NotificationUpdate notificationReq, String notificationCode,
			String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			Notification notification = notificationDao.getNotificationByNotificationCode(notificationCode);

			if (notification != null && notification.getId() > 0) {

				notification.setIsRead(notificationReq.getIsRead());
				notification.setIpAddress(ip);

				Notification notificationRes = notificationDao.save(notification);

				if (notificationRes != null && notificationRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Notification has been updated");
					jsonobj.put("timestamp", new Date());
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(notificationRes);
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Notification updation has been failed.");
					jsonobj.put("timestamp", new Date());
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Notification Code is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllNotificationByUserCodeWithRead(String userCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Notification> list = notificationDao.getAllNotificationByUserCodeAndIsRead(userCode);

			if (list != null && list.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(list);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllNotificationByUserCodeWithRead(String userCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
				Pageable pageableRequest = PageRequest.of(page, limit);

				List<Notification> listCheck = notificationDao.getAllNotificationByUserCodeAndIsRead(userCode);

				Integer count = listCheck.size();

				List<Notification> list = notificationDao.getAllNotificationByUserCodeAndIsRead(userCode,
						pageableRequest);

				if (list != null && list.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(list);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllNotificationByUserCodeWithUnRead(String userCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Notification> list = notificationDao.getAllNotificationByUserCode(userCode);

			if (list != null && list.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(list);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllNotificationByUserCodeWithUnRead(String userCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
				Pageable pageableRequest = PageRequest.of(page, limit);

				List<Notification> listCheck = notificationDao.getAllNotificationByUserCode(userCode);

				Integer count = listCheck.size();

				List<Notification> list = notificationDao.getAllNotificationByUserCode(userCode, pageableRequest);

				if (list != null && list.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(list);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public void saveNotification(Notification notification) {
	
		try {
	
			if (notification != null) {
				

               Notification notificationRes = notificationDao.save(notification);

						if (notificationRes != null && notificationRes.getId() > 0) {
							
							kafkaService.sendNotifications(notificationRes);
						}
//
//							ObjectMapper mapperObj = new ObjectMapper();
//							String Detail = mapperObj.writeValueAsString(notificationRes);
//
//						} else {
//		
//						}
						
			}

			}catch (Exception ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			ex.printStackTrace();
		}
		

		
	}

}
