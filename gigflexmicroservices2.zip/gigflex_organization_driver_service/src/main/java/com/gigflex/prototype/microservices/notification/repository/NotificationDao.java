package com.gigflex.prototype.microservices.notification.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.notification.dtob.Notification;

public interface NotificationDao extends JpaRepository<Notification, Long>, JpaSpecificationExecutor<Notification> {

	@Query("SELECT a FROM Notification a WHERE a.isDeleted != TRUE AND a.isRead != TRUE AND a.userCode = :userCode ORDER BY a.id DESC")
	public List<Notification> getAllNotificationByUserCode(@Param("userCode") String userCode, Pageable pageableRequest);

	@Query("SELECT a FROM Notification a WHERE a.isDeleted != TRUE AND a.isRead != TRUE AND a.userCode = :userCode ORDER BY a.id DESC")
	public List<Notification> getAllNotificationByUserCode(@Param("userCode") String userCode);

	@Query("SELECT a FROM Notification a WHERE a.isDeleted != TRUE AND a.isRead = TRUE AND a.userCode = :userCode ORDER BY a.id DESC")
	public List<Notification> getAllNotificationByUserCodeAndIsRead(@Param("userCode") String userCode);

	@Query("SELECT a FROM Notification a WHERE a.isDeleted != TRUE AND a.isRead = TRUE AND a.userCode = :userCode ORDER BY a.id DESC")
	public List<Notification> getAllNotificationByUserCodeAndIsRead(@Param("userCode") String userCode, Pageable pageableRequest);

	@Query("SELECT a FROM Notification a WHERE a.isDeleted != TRUE AND a.notificationCode = :notificationCode")
	public Notification getNotificationByNotificationCode(@Param("notificationCode") String notificationCode);
}
