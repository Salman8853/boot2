package com.gigflex.prototype.microservices.globalridetype.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "globalridetype")
public class GlobalRideType extends CommonAttributes implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "global_ride_code", unique = true)
    private String globalRideCode;

	@Column(name = "vechiclename", nullable = false)
	private String vehicleName;

	@Column(name = "baserate", nullable = false)
	private Double baseRate;

	@Column(name = "ratepermile", nullable = false)
	private Double ratePerMile;
	
	  @PrePersist
	    private void assignUUID() {
	        if(this.getGlobalRideCode()==null || this.getGlobalRideCode().length()==0)
	        {
	            this.setGlobalRideCode((UUID.randomUUID().toString()));
	        }
	    }

	public GlobalRideType() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GlobalRideType(Long id, String globalRideCode, String vehicleName, Double baseRate, Double ratePerMile) {
		super();
		this.id = id;
		this.globalRideCode = globalRideCode;
		this.vehicleName = vehicleName;
		this.baseRate = baseRate;
		this.ratePerMile = ratePerMile;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getGlobalRideCode() {
		return globalRideCode;
	}

	public void setGlobalRideCode(String globalRideCode) {
		this.globalRideCode = globalRideCode;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public Double getBaseRate() {
		return baseRate;
	}

	public void setBaseRate(Double baseRate) {
		this.baseRate = baseRate;
	}

	public Double getRatePerMile() {
		return ratePerMile;
	}

	public void setRatePerMile(Double ratePerMile) {
		this.ratePerMile = ratePerMile;
	}
	
	

}
