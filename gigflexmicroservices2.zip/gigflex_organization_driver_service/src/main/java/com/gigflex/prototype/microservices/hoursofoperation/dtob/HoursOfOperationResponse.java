/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.hoursofoperation.dtob;

import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetail;

/**
 *
 * @author amit.kumar
 */
public class HoursOfOperationResponse {
    
    private Long id;
    private String hoursOfOperationCode;
    private String vehicleCode;
    private String driverCode;
    private String fromTime;
    private String toTime;
    private Integer dayCode;  
    private String vehicleType;
    private String vehicleTypeName;
    private String driverName;
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getHoursOfOperationCode() {
        return hoursOfOperationCode;
    }

    public void setHoursOfOperationCode(String hoursOfOperationCode) {
        this.hoursOfOperationCode = hoursOfOperationCode;
    }

    public String getVehicleCode() {
        return vehicleCode;
    }

    public void setVehicleCode(String vehicleCode) {
        this.vehicleCode = vehicleCode;
    }

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }

    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public Integer getDayCode() {
        return dayCode;
    }

    public void setDayCode(Integer dayCode) {
        this.dayCode = dayCode;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getVehicleTypeName() {
        return vehicleTypeName;
    }

    public void setVehicleTypeName(String vehicleTypeName) {
        this.vehicleTypeName = vehicleTypeName;
    }
    
    
    
}
