package com.gigflex.prototype.microservices.validation.service.impl;

import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.validation.dtob.Validation;
import com.gigflex.prototype.microservices.validation.dtob.ValidationRequest;
import com.gigflex.prototype.microservices.validation.repository.ValidationRepository;
import com.gigflex.prototype.microservices.validation.search.ValidationSpecificationsBuilder;
import com.gigflex.prototype.microservices.validation.service.ValidationService;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

@Service
public class ValidationServiceImpl implements ValidationService {

	@Autowired
	ValidationRepository validationDao;

	@Override
	public String getAllValidation() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Validation> validationlst = validationDao.getAllValidation();

			if (validationlst != null && validationlst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(validationlst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getValidationById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Validation validationlst = validationDao.getValidationById(id);
			if (validationlst != null && validationlst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(validationlst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getValidationByValidationCode(String validationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Validation Validationlst = validationDao.getValidationByValidationCode(validationCode);
			if (Validationlst != null && Validationlst.getId() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(Validationlst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String saveNewValidation(ValidationRequest validationReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (validationReq != null) {

				if (validationReq.getValidationName() != null && validationReq.getValidationName().trim().length() > 0
						&& validationReq.getValidationType() != null
						&& validationReq.getValidationType().trim().length() > 0
						&& validationReq.getValidationValue() != null
						&& validationReq.getValidationValue().trim().length() > 0) {

					Validation ValidationCheck = validationDao.getValidationByValidationNameAndValidationType(
							validationReq.getValidationName(), validationReq.getValidationType());

					if (ValidationCheck != null && ValidationCheck.getId() > 0) {
						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record already exist.");
					} else {

						Validation validationlst = new Validation();

						validationlst.setValidationValue(validationReq.getValidationValue());
						validationlst.setValidationName(validationReq.getValidationName());
						validationlst.setValidationType(validationReq.getValidationType());

						validationlst.setIpAddress(ip);

						Validation validationRes = validationDao.save(validationlst);

						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());

						if (validationRes != null && validationRes.getId() > 0) {

							jsonobj.put("message", "Validation has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(validationRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("message", "Failed");
						}
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateValidationById(Long id, ValidationRequest validationReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && validationReq != null) {

				if (validationReq.getValidationName() != null && validationReq.getValidationName().trim().length() > 0
						&& validationReq.getValidationType() != null
						&& validationReq.getValidationType().trim().length() > 0
						&& validationReq.getValidationValue() != null
						&& validationReq.getValidationValue().trim().length() > 0) {

					Validation validationlst = validationDao.getValidationById(id);

					if (validationlst != null && validationlst.getId() > 0) {

						Validation validationCheck = validationDao.getValidationByValidationNameAndValidationTypeById(
								id, validationReq.getValidationName(), validationReq.getValidationType());

						if (validationCheck != null && validationCheck.getId() > 0) {
							jsonobj.put("responsecode", 409);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Record already exist.");
						} else {

							Validation validation = validationlst;

							validation.setValidationValue(validationReq.getValidationValue());
							validation.setValidationName(validationReq.getValidationName());
							validation.setValidationType(validationReq.getValidationType());

							validation.setIpAddress(ip);

							Validation ValidationRes = validationDao.save(validation);

							if (ValidationRes != null && ValidationRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("message", "Validation updation has been done");
								jsonobj.put("timestamp", new Date());
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(ValidationRes);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("message", "Validation updation has been failed.");
								jsonobj.put("timestamp", new Date());
							}
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Validation ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByValidationCode(String validationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Validation validationlst = validationDao.getValidationByValidationCode(validationCode);
			if (validationlst != null && validationlst.getId() > 0) {
				validationlst.setIsDeleted(true);
				Validation ValidationRes = validationDao.save(validationlst);

				if (ValidationRes != null && ValidationRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Validation deleted successfully.");
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByValidationCode(List<String> validationCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String validationCode : validationCodeList) {
				if (validationCode != null && validationCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					validationCode = validationCode.trim();

					Validation validationlst = validationDao.getValidationByValidationCode(validationCode);
					if (validationlst != null && validationlst.getId() > 0) {

						validationlst.setIsDeleted(true);
						Validation ValidationRes = validationDao.save(validationlst);
						if (ValidationRes != null && ValidationRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", validationCode);
							jsonobj.put("message", "Validation deleted successfully.");
							// kafkaService.se
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", validationCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", validationCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllValidationByPgae(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Validation> validationlst = validationDao.getAllValidation(pageableRequest);

			if (validationlst != null && validationlst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(validationlst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				ValidationSpecificationsBuilder builder = new ValidationSpecificationsBuilder();
				Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
				}

				Specification<Validation> spec = builder.build();
				if (spec != null) {
					List<Validation> validationlst = validationDao.findAll(spec);
					if (validationlst != null && validationlst.size() > 0) {
						for (Validation valdtn : validationlst) {
							if (valdtn.getIsDeleted() != null && valdtn.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(valdtn);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("Validation", new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

}
