/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.rideexchange.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "ride_exchange")
public class RideExchange extends CommonAttributes implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "ride_exchange_code", unique = true)
    private String rideExchangeCode;
    
    @Column(name = "organization_code_publish")
    private String organizationCodePublish;
    
    @Column(name = "organization_code_assigned")
    private String organizationCodeAssigned;
    
    @Column(name = "balance_amount")
    private double balanceAmount;
    
    @Column(name = "ride_exchange_amount")
    private double rideExchangeAmount;
    
    @Column(name = "ride_code")
    private String rideCode;
    
    
     @PrePersist
    private void assignUUID() {
        if(this.getRideExchangeCode()==null || this.getRideExchangeCode().length()==0)
        {
            this.setRideExchangeCode(UUID.randomUUID().toString());
        }
    }
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRideExchangeCode() {
        return rideExchangeCode;
    }

    public void setRideExchangeCode(String rideExchangeCode) {
        this.rideExchangeCode = rideExchangeCode;
    }

    public String getOrganizationCodePublish() {
        return organizationCodePublish;
    }

    public void setOrganizationCodePublish(String organizationCodePublish) {
        this.organizationCodePublish = organizationCodePublish;
    }

    public String getOrganizationCodeAssigned() {
        return organizationCodeAssigned;
    }

    public void setOrganizationCodeAssigned(String organizationCodeAssigned) {
        this.organizationCodeAssigned = organizationCodeAssigned;
    }

    public double getBalanceAmount() {
        return balanceAmount;
    }

    public void setBalanceAmount(double balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    public double getRideExchangeAmount() {
        return rideExchangeAmount;
    }

    public void setRideExchangeAmount(double rideExchangeAmount) {
        this.rideExchangeAmount = rideExchangeAmount;
    }

    public String getRideCode() {
        return rideCode;
    }

    public void setRideCode(String rideCode) {
        this.rideCode = rideCode;
    }    
    
}
