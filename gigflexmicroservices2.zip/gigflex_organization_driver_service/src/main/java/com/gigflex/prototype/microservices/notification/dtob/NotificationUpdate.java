package com.gigflex.prototype.microservices.notification.dtob;

public class NotificationUpdate {
	
	private Boolean isRead;

	public Boolean getIsRead() {
		return isRead;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}


}
