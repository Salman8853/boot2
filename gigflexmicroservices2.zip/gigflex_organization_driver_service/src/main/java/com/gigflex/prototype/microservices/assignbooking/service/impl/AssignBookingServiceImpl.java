/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.assignbooking.service.impl;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBooking;
import com.gigflex.prototype.microservices.assignbooking.dtob.BookingRejection;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingRejectedCommentsResponse;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingRequest;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingResponse;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingStatus;
import com.gigflex.prototype.microservices.assignbooking.dtob.RideLocationRequest;
import com.gigflex.prototype.microservices.assignbooking.repository.AssignBookingRepository;
import com.gigflex.prototype.microservices.assignbooking.repository.BookingRejectionRepository;
import com.gigflex.prototype.microservices.assignbooking.service.AssignBookingService;
import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.booking.dtob.BookingAllResponse;
import com.gigflex.prototype.microservices.booking.dtob.BookingAllResponseWithFilter;
import com.gigflex.prototype.microservices.booking.dtob.BookingResponse;
import com.gigflex.prototype.microservices.booking.repository.BookingDao;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.notification.service.NotificationService;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationDao;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.utility.GigflexDateUtil;

import java.util.Calendar;

import com.gigflex.prototype.microservices.utility.SendMessageAPI;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingCancelledRequest;
import com.gigflex.prototype.microservices.assignbooking.dtob.TrackingRideLocationReqest;
import com.gigflex.prototype.microservices.assignbooking.dtob.TrackingRideLocationResponse;
import com.gigflex.prototype.microservices.assignbooking.dtob.TrackingRideStatus;
import com.gigflex.prototype.microservices.assignbooking.repository.TrackingRideLocationRepository;
import com.gigflex.prototype.microservices.booking.dtob.AdditionalCharges;
import com.gigflex.prototype.microservices.booking.dtob.AdditionalChargesResponse;
import com.gigflex.prototype.microservices.booking.dtob.BookingAllResponseWithFilterforMobile;
import com.gigflex.prototype.microservices.booking.repository.AdditionalChargesRepository;
import com.gigflex.prototype.microservices.device.dtob.DeviceDetail;
import com.gigflex.prototype.microservices.device.repository.DeviceDetailRepository;
import com.gigflex.prototype.microservices.drivertimeoff.service.impl.DriverTimeOffServiceImpl;
import com.gigflex.prototype.microservices.globalridetype.dtob.GlobalRideType;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.hoursofoperation.dtob.HoursOfOperation;
import com.gigflex.prototype.microservices.hoursofoperation.repository.HoursOfOperationDao;
import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransaction;
import com.gigflex.prototype.microservices.organizationcredittransaction.repository.OrganizationCreditTransactionRepository;
import com.gigflex.prototype.microservices.passenger.dtob.Passenger;
import com.gigflex.prototype.microservices.passenger.repository.PassengerDao;
import com.gigflex.prototype.microservices.ridetype.dtob.RideType;
import com.gigflex.prototype.microservices.ridetype.repository.RideTypeRepository;
import com.gigflex.prototype.microservices.usertype.dtob.UserType;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.utility.PushNotification;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetail;
import com.gigflex.prototype.microservices.vehicledetail.repository.VehicleDetailRepository;
import java.util.logging.Level;


/**
 *
 * @author nirbhay.p
 */
@Service
public class AssignBookingServiceImpl implements AssignBookingService {

	@Autowired
	AssignBookingRepository assignBookingRepository;
	@Autowired
	DriverRepository driverRepository;
	@Autowired
	OperatorRepository operatorRepository;
	@Autowired
	BookingDao bookingDao;
	
	@Autowired
	OrganizationDao organizationDao;
        @Autowired
        BookingRejectionRepository bookingRejectionRepository;
        @Autowired
        RideTypeRepository rideTypeRepository;
        
        @Autowired
        TrackingRideLocationRepository trackingRideRepository;
	
        @Autowired
        private TimeZoneRepository timeZoneRepository;

        @Autowired
        private NotificationService notificationService;
        @Autowired
        GlobalSettingRepository globalSettingRepository;
        
        @Autowired
        AdditionalChargesRepository additionalchargesdao;        
    
        @Autowired
        LocalSettingRepository localSettingRepository;
        
        @Autowired
	UserTypeRepository userTypeDao;
	@Autowired
	private OrganizationRepository orgDao;
        @Autowired
        VehicleDetailRepository vehicleDetailRepository;
        
        @Autowired
        OrganizationCreditTransactionRepository organizationCreditTransactionRepository;
        
        @Autowired
        HoursOfOperationDao hoursOfOperationDao;
        
        @Autowired
        DeviceDetailRepository deviceDetailDao;
        
        @Autowired
        private PassengerDao passengerDao;
        
	@Value("${email.changeassignbookingstatus.subject}")
	private String subject; // ="New Booking Request by Operator";

	private String subjectAcc = "Booking Request Acceptance Notification";
	
	private String subjectRej = "Booking Request Rejectance Notification";
	
	private String subjectInPr = "Booking Request In Progress Notification";
        
        private String subjectcancel= "Booking Cancellation Notification";
        
        String  shortMessage;
        
        private Character unitMiles ='M';

//for test	@Value("${email.service.url}")
	private String mailServiceURL= "http://18.223.158.6:8091/superadminservice/sendEmail/to/{to}/subject/{subject}/body/{body}";

	@Value("${email.changeassignbookingstatus.urllink}")
	private String changeAssignBookingStatusUrl;// = "http://localhost:8083/organizationdriverservice/";
        
        @Value("${message.appKey}")
        private String appKey;//="5f660e09-e0b7-474e-889c-fd3c077f195c";
        
        @Value("${message.appSecret}")
        private String appSecret;//="qegMoUCBT0OGXuASFMPB+Q==";

        @Value("${message.url}")
        private String url;//="https://messagingapi.sinch.com/v1/sms/";
       
        @Value("${setting.name.sms.notifications}")
        private String smsNotiName;
        
        @Value("${setting.name.mail.notifications}")
        private String mailNotiName;
        
        @Value("${notification.deviceid}")
        private String deviceId;

        @Value("${notification.fcm.url}")
        private String FMCurl;  
        
        @Value("${notification.fcm.authkey}")
        private String authKey;
        
	@Override
	public String getAllValidUnAssignedBooking() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Date curDT = new Date();
			List<Object> objlst = assignBookingRepository.getAllValidUnAssignedBooking(curDT,
					GigflexConstants.assignedBookingStatus,GigflexConstants.assignedBookingPublishedStatus);
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt="";
			                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                 String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                
                                            
                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                               TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                               if (tzd != null && tzd.getId() > 0) {

                                                   String timezone = tzd.getTimeZoneName();
                                                   if(timezone!=null && timezone.length()>0 )
                                                   {
                                                        Date pDate = data.getPickUpTime();
                                                        pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                        conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                   }

                                               }         

                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);  
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
						
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setIsPublished(data.getIsPublished());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date curdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (curdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                                   GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            } 
                                                maplst.add(brwo);

					}
				}
			}
			if (maplst != null && maplst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();

		}
		return res;
	}

	@Override
	public String getAllValidUnAssignedBookingByPage(int page, int limit) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if(limit > 0){
			Pageable pageableRequest = PageRequest.of(page, limit);
			
			Date curDT = new Date();
			
			List<Object> objlst1 = assignBookingRepository.getAllValidUnAssignedBooking(curDT,
					GigflexConstants.assignedBookingStatus,GigflexConstants.assignedBookingPublishedStatus);
			int count = objlst1.size();
			
			List<Object> objlst = assignBookingRepository.getAllValidUnAssignedBookingByPage(curDT,
					GigflexConstants.assignedBookingStatus,GigflexConstants.assignedBookingPublishedStatus, pageableRequest);
			
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt="";
			                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                
                                            
                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                               TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                               if (tzd != null && tzd.getId() > 0) {

                                                   String timezone = tzd.getTimeZoneName();
                                                   if(timezone!=null && timezone.length()>0 )
                                                   {
                                                        Date pDate = data.getPickUpTime();
                                                        pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                        conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                   }

                                               }         
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);  
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                
						brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setIsPublished(data.getIsPublished());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date curdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (curdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
			}
			if (maplst != null && maplst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			}else{
	            jsonobj.put("responsecode", 400);
	        jsonobj.put("message", "Limit should not be Zero or Negative.");
	        jsonobj.put("timestamp", new Date());
	        }

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();

		}
		return res;

	}
        
        @Override
        public String getAllValidUnAssignedBookingExceptCreator(String operatorCode) {
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Date curDT = new Date();
			List<Object> objlst = assignBookingRepository.getAllValidUnAssignedBookingExceptCreator(curDT,GigflexConstants.assignedBookingStatus,GigflexConstants.assignedBookingPublishedStatus,operatorCode);
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                                Operator operator = operatorRepository.getOperatorByOperatorCode(operatorCode);
                                String organizationCode = operator.getOrganizationCode(); 
                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);
                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt="";
			                                                                       
                                               if (tzd != null && tzd.getId() > 0) {

                                                   String timezone = tzd.getTimeZoneName();
                                                   if(timezone!=null && timezone.length()>0 )
                                                   {
                                                        Date pDate = data.getPickUpTime();
                                                        pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                        conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                   }

                                               }         
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);  
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                
					        brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());


						brwo.setPickUpTime(conDt);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setIsPublished(data.getIsPublished());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date curdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (curdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
			}
			if (maplst != null && maplst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();

		}
		return res;
	
    }

    @Override
    public String getAllValidUnAssignedBookingExceptCreatorByPage(String operatorCode, int page, int limit) {
       
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if(limit > 0){
            Pageable pageableRequest = PageRequest.of(page, limit);
            Date curDT = new Date();
            
			List<Object> objlst1 = assignBookingRepository.getAllValidUnAssignedBookingExceptCreator(curDT,GigflexConstants.assignedBookingStatus,GigflexConstants.assignedBookingPublishedStatus,operatorCode);
			int count = objlst1.size();
			
			
			List<Object> objlst = assignBookingRepository.getAllValidUnAssignedBookingExceptCreatorByPage(curDT,GigflexConstants.assignedBookingStatus,GigflexConstants.assignedBookingPublishedStatus,operatorCode,pageableRequest);
			
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                                Operator operator = operatorRepository.getOperatorByOperatorCode(operatorCode);
                                String organizationCode = operator.getOrganizationCode(); 
                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;//currencySymbol
                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);

                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();                                                
						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
                                                
						String conDt="";
			             	       
                                               if (tzd != null && tzd.getId() > 0) {

                                                   String timezone = tzd.getTimeZoneName();
                                                   if(timezone!=null && timezone.length()>0 )
                                                   {
                                                        Date pDate = data.getPickUpTime();
                                                        pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                        conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                   }

                                               }         
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);  
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                
					        brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setIsPublished(data.getIsPublished());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date curdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (curdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
			}
			if (maplst != null && maplst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			}else{
	            jsonobj.put("responsecode", 400);
	        jsonobj.put("message", "Limit should not be Zero or Negative.");
	        jsonobj.put("timestamp", new Date());
	        }

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();

		}
		return res;
	
    }


	@Override
	public String assignBookingAccepted(AssignBookingStatus abs, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			Driver d = driverRepository.getDriverByDriverCode(abs.getDriverCode().trim());
			if (d != null && d.getId() > 0) {
//                            if(d.getFleetSize()!=null && d.getFleetSize()>0)
//                            {
                        List<VehicleDetail> vdlst=vehicleDetailRepository.getVehicleListByDriverCode(d.getDriverCode());
                        if(vdlst!=null && vdlst.size()>0)
                        {
                        Booking b = bookingDao.getBookingByRideCode(abs.getRideCode());
						if (b != null && b.getId() > 0) {
                                                    
                                                    Boolean bst=false;
                                                    int noP=0;
                                                    int noB=0;
                                                    
                                                    String passengerName="";
                                                    Passenger pgr=  passengerDao.getPassengerByPassengerCode(b.getPassengerCode());
                                                    if(pgr!=null && pgr.getId()>0)
                                                     {
                                                       passengerName=pgr.getPassengerName();
                                                     }
                                                    if(b.getNoOfPassengers()!=null && b.getNoOfPassengers()>0 )
                                                    {
                                                       noP=b.getNoOfPassengers();  
                                                    }
                                                    if(b.getNoOfBaggage()!=null && b.getNoOfBaggage()>0 )
                                                    {
                                                       noB=b.getNoOfBaggage();  
                                                    }
                                                    for(VehicleDetail vd:vdlst)
                                                    {
                                                        if(vd!=null && vd.getBaggageQuantity()!=null && vd.getPassengerQuantity()!=null && vd.getBaggageQuantity()>= noB && vd.getPassengerQuantity()>=noP)
                                                        {
                                                            bst=true;
                                                            break;
                                                        }
                                                    }
                                                    if(bst)
                                                    {
				AssignBooking ab = assignBookingRepository
						.getAssignBookingByRideCodeAndDriverCodeForAccepted(abs.getRideCode(), abs.getDriverCode());
				if (ab != null && ab.getId() > 0) {
                                    if(!(ab.getStatus().equalsIgnoreCase(GigflexConstants.assignedBookingAcceptedStatus)))
                                    {
					ab.setStatus(GigflexConstants.assignedBookingAcceptedStatus);
					ab.setIpAddress(ip);
					ab.setDriverCode(abs.getDriverCode());
					AssignBooking abres = assignBookingRepository.save(ab);
					if (abres != null && abres.getId() > 0) {

						
							b.setBookingStatus(GigflexConstants.assignedBookingAcceptedStatus);
							Booking bookingRes = bookingDao.save(b);
							
							if (bookingRes != null && bookingRes.getId() > 0) {
								String abOperatorCode = ab.getOperatorCode();
							    String bOperatorCode = b.getOperatorCode();
							    String toMail = "";
                                                            String contactNumber="";
						            String conDt="";
							    String operatorCodes = null;
                                                            boolean SMSSt=true;
                                                            boolean MailST=true;
                                                            UserType utOtr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOperator);
                                                            UserType utDvr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeDriver);
							    if(abOperatorCode != null && bOperatorCode != null ) {
							    	if(abOperatorCode.equals(bOperatorCode)) {
								    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

								    	toMail = operator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                            contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								    	}
								    	operatorCodes = abOperatorCode;
								    }else {
								    	Operator aboperator = operatorRepository.getOperatorByOperatorCode(abOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, mailNotiName);
								    	if(MailST && aboperator!=null && aboperator.getEmailId() != null && aboperator.getEmailId().length() > 0) {

								    	toMail = aboperator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, smsNotiName);
                                                                        if(SMSSt && aboperator!=null && aboperator.getContactNumber() != null && aboperator.getContactNumber().length() > 0 && aboperator.getCountryCode() != null && aboperator.getCountryCode().length() > 0) {

                                                                        contactNumber="+"+aboperator.getCountryCode()+aboperator.getContactNumber();
								    	}
								    	Operator boperator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && boperator!=null && boperator.getEmailId() != null && boperator.getEmailId().length() > 0) {
								    		if(toMail != null && toMail.length() > 0) {
								    	toMail += ","+boperator.getEmailId();
								    	}else {
									    	toMail = boperator.getEmailId();

								    	}
                                                                        }
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && boperator!=null && boperator.getContactNumber() != null && boperator.getContactNumber().length() > 0 && boperator.getCountryCode() != null && boperator.getCountryCode().length() > 0) {
								    		if(contactNumber != null && contactNumber.length() > 0) {
								    	
                                                                        contactNumber +=",+"+boperator.getCountryCode()+ boperator.getContactNumber();
								    	}else {
                                                                                contactNumber="+"+boperator.getCountryCode()+ boperator.getContactNumber();

								    	}
								    	}
								    	operatorCodes = abOperatorCode+","+bOperatorCode;
								    }
							    	
							    }else if(bOperatorCode != null){
							    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
							    	if(MailST && operator.getEmailId() != null && operator.getEmailId().length() > 0) {
							    	toMail = operator.getEmailId();
							    	}
                                                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                   contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								}
							    	operatorCodes = bOperatorCode;
							    }
							   
								   
						            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                            {
                                                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                            }                

                                                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TimeZone);

                                                           TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                           if (tzd != null && tzd.getId() > 0) {

                                                               String timezone = tzd.getTimeZoneName();
                                                               if(timezone!=null && timezone.length()>0 )
                                                               {
                                                                    Date pDate = b.getPickUpTime();
                                                                    pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                    conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                               }

                                                           }         
								   String bodyContent = "Dear Operator " 
									+ ", <br><br>Assigned booking has been accepted. Details are given below-<br><br>";
                                                                        if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                        {
                                                                        bodyContent+=" Driver Name : "+d.getName()+",";
                                                                        }   
									bodyContent+="Passenger Name : "+passengerName+"<br>" + "Pick-up Time : "
									+ conDt + "<br>" + "Pick-up Address : " + b.getPickUpAddress()
									+ "<br>" + "Drop-off Address : " + b.getDropOffAddress();
                                                                   
                                                                   String messageBodyForOperator = "Dear Operator, "+"\n"+" Assigned booking has been accepted. Details are given below-";
                                                                   if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                        {
                                                                        messageBodyForOperator+="\n"+"Driver Name : "+d.getName();
                                                                        }
									 messageBodyForOperator+= "\n"+"Passenger Name : "+passengerName+"\n" + "Pick-up Time : "
									+ conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
									+ "\n" + "Drop-off Address : " + b.getDropOffAddress();
                                                                   
                                                                   String messageBodyForDriver = "Dear "+d.getName()+","+"\n"+" You have accepted assigned booking. Details are given below-"
									+ "\n" +"Passenger Name : "+passengerName+"\n"+ "Pick-up Time : "
									+ conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
									+ "\n" + "Drop-off Address : " + b.getDropOffAddress();
							if(toMail != null && toMail.length() > 0) {		
							
//                                                            byte[] encodedbody = Base64.getEncoder().encode(bodyContent.getBytes());
//                                                            String body = new String(encodedbody);
							String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
							Map<String, String> map = new HashMap<>();
							map.put("to", toMail);
							map.put("subject", subjectAcc);
							map.put("body", encodeURL);
                                                         
							try {
								RestTemplate restTemplate = new RestTemplate();
								ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL,
										String.class, map);
								String mailRes = response.getBody();
                                                                  
                                                               

							} catch (Exception ex) {
								ex.printStackTrace();
							}
							   }
                                                        
                                                        SendMessageAPI sendmessageapi = new SendMessageAPI();
                                                        try {
                                                           boolean SMSStdr=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), d.getDriverCode(), smsNotiName);
                                                                if (SMSStdr && d.getContactNumber() != null && d.getContactNumber().trim().length() > 0 && d.getCountryCode()!=null && d.getCountryCode().length()>0) {
                                                                    String mob="+"+d.getCountryCode()+d.getContactNumber();
                                                                    String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, mob, messageBodyForDriver);
                                                                    System.out.println("====messageToken for driver=====" + messageToken);
                                                                }
                                                            } catch (Exception e) {
                                                                e.printStackTrace();
                                                            }
                                                            try {
                                                                if (contactNumber != null && contactNumber.length()>0) {
                                                                    String contactArray[] = contactNumber.split(",");
                                                                    for (int i = 0; i <contactArray.length; i++) {
                                                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, contactArray[i], messageBodyForOperator);
                                                                        System.out.println("====messageToken For operators=====" + messageToken);
                                                                    }
                                                                }
                                                            } catch (Exception e) {
                                                                e.printStackTrace();
                                                            }
                                                        
							   try {
								   if(operatorCodes != null && operatorCodes.length() > 0) {
									   String userCodes[] = operatorCodes.split(",");
									   for(String userCode : userCodes) {
										  if(userCode != null && userCode.length() > 0) {
											  Notification notification = new Notification();
											  
											  String bodyContentnoti = "Dear Operator" 
														+ ",Assigned booking has been accepted. Details are given below-";
                                                                                          if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                                            {
                                                                                            bodyContentnoti+="Driver Name : "+d.getName()+", ";
                                                                                            }
														bodyContentnoti+="Passenger Name : "+passengerName+","+ "Pick-up Time : "
														+ conDt + "," + "Pick-up Address : " + b.getPickUpAddress()
														+ "," + "Drop-off Address : " + b.getDropOffAddress();
											  shortMessage = "Assigned booking has been accepted.";
											  
											  notification.setUserCode(userCode);
											  notification.setMessage(bodyContentnoti);
											  notification.setShortMessage(shortMessage);
											  notification.setRideCode(b.getRideCode());
											  notification.setIpAddress(ip);
											  notification.setIsRead(Boolean.FALSE);
											  
											  notificationService.saveNotification(notification);
                                                                                      
//                                                                                          List<DeviceDetail> deviceDetailResList  = deviceDetailDao.getDeviceDetailByUserCode(d.getDriverCode().trim());
//                                                                                          if(deviceDetailResList != null && deviceDetailResList.size() > 0)
//                                                                                          {
//                                                                                            for(DeviceDetail deviceDetail:deviceDetailResList)
//                                                                                            {
//                                                                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), shortMessage, bodyContent);
//
//                                                                                            }
//                                                                                          }
                                                                                          

										  }
									   }
								   }
								   
							   }catch(Exception e){
								   e.printStackTrace();
							   }
							   
							 
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Assigned Booking has been accepted successfully");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(abres);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Failed");
							}
						
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Failed");
					}
                                    } else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Booking is already accepted.");
				}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found.");
				}
                                } else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "This action is not possible as booking requirements have not been fulfilled.");
						}
                                } else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Booking Record Not Found.");
						}
                         } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Booking is not possible as driver do'nt have any vehicle.");
			}
//                        } else {
//				jsonobj.put("responsecode", 400);
//				jsonobj.put("timestamp", new Date());
//				jsonobj.put("message", "Booking is not possible as driver do'nt have any vehicle.");
//			}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Driver does not exist.");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();

		}
		return res;
	}

        
        @Override
    public String assignBookingCancelled(AssignBookingCancelledRequest abs, String ip) {
            String res = "";
            try {
                JSONObject jsonobj = new JSONObject();
                OrganizationCreditTransaction operatorCreditTransactionRes = null;

                Booking b = bookingDao.getBookingByRideCode(abs.getRideCode());
                if (b != null && b.getId() > 0) {

                    String passengerName="";
                    Passenger pgr=  passengerDao.getPassengerByPassengerCode(b.getPassengerCode());
                    if(pgr!=null && pgr.getId()>0)
                     {
                       passengerName=pgr.getPassengerName();
                     }
                    if (b.getOperatorCode() != null && b.getOperatorCode().equalsIgnoreCase(abs.getOperatorCode())) {
                        if (!(b.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingCancelledStatus))) {
                            if (!(b.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingInProgressStatus))) {
                                if (!(b.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingCompletedStatus))) {
                                    String oldst = b.getBookingStatus();
                                    b.setBookingStatus(GigflexConstants.assignedBookingCancelledStatus);
                                    b.setIpAddress(ip);
                                    b.setCancelationComment(abs.getComments());
                                    b.setDropOffTime(new Date());
                                    
                                    //code for check balance amount before new booking
                                    List<OrganizationCreditTransaction> objlst = organizationCreditTransactionRepository.getLastTransactionBalanceByOrganizationCode(b.getOrganizationCode());


                                    double creditAmount = 0.0;
                                    double debitAmount =0.0;
                                    double balaceAmount = 0.0;
                                    double lastBalance = 0.0;
                                    if (objlst != null && objlst.size() > 0) {

                                        OrganizationCreditTransaction oprRes = objlst.get(0);

                                        if(oprRes != null && oprRes.getId() >0 )
                                        {
                                            lastBalance = oprRes.getBalanceAmount();
                                            creditAmount = b.getCustomerFare();
                                            balaceAmount = lastBalance+ creditAmount ;

                                            OrganizationCreditTransaction oct = new OrganizationCreditTransaction();

                                            oct.setBalanceAmount(balaceAmount); 
                                            oct.setCreditAmount(creditAmount); 
                                            oct.setDebitAmount(debitAmount);
                                            oct.setOrganizationCode(b.getOrganizationCode()); 
                                            oct.setBookingid(b.getBookingid());
                                            oct.setTransactionBy(GigflexConstants.BOOKING); 
                                            oct.setTransactionType(GigflexConstants.TRANSACTION_TYPE_CREDIT); 
                                            oct.setIpAddress(ip); 

                                            operatorCreditTransactionRes = organizationCreditTransactionRepository.save(oct);

                                            if(operatorCreditTransactionRes == null || operatorCreditTransactionRes.getId()==0 )
                                            {
                                                jsonobj.put("message", "Failed due to credit transaction");
                                                jsonobj.put("responsecode", 400);
                                                jsonobj.put("timestamp", new Date());

                                                return jsonobj.toString();
                                            }                                               
                                        }

                                    }
                                        
                                    
                                    Booking bookingRes = bookingDao.save(b);
                                    if (bookingRes != null && bookingRes.getId() > 0) {

                                        
                                        AssignBooking ab = assignBookingRepository.getAssignBookingByRideCode(b.getRideCode());
                                        if (ab != null && ab.getId() > 0) {
                                            ab.setStatus(GigflexConstants.assignedBookingCancelledStatus);
                                            ab.setIpAddress(ip);
                                            AssignBooking abres = assignBookingRepository.save(ab);

                                            if (abres != null && abres.getId() > 0) {

                                                jsonobj.put("responsecode", 200);
                                                jsonobj.put("timestamp", new Date());
                                                jsonobj.put("message", "Booking has been cancelled successfully");
                                                if ((ab.getOperatorCode() != null && ab.getOperatorCode().length() > 0) || (b.getOperatorCode() != null && b.getOperatorCode().length() > 0) || (ab.getDriverCode() != null && ab.getDriverCode().length() > 0 && !(ab.getStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus)))) {
                                                    String conDt = "";
                                                    String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                    {
                                                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                    }                
                                            
                                                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TimeZone);

                                                        TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                        if (tzd != null && tzd.getId() > 0) {

                                                            String timezone = tzd.getTimeZoneName();
                                                            if(timezone!=null && timezone.length()>0 )
                                                            {
                                                                 Date pDate = b.getPickUpTime();
                                                                 pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                 conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                            }

                                                        }         
                                                   
                                                    
                                                    Driver dr = null;
                                                    if(oldst!=null && !(oldst.equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus)) && !(oldst.equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))  && !(oldst.equalsIgnoreCase(GigflexConstants.assignedBookingStatus)))
                                                    {
                                                        dr=driverRepository.getDriverByDriverCode(abres.getDriverCode());   
                                                    }
                                                                                                     
                                                    
                                                            String abOperatorCode = ab.getOperatorCode();
							    String bOperatorCode = b.getOperatorCode();
							    String toMail = "";
                                                            String contactNumber="";
						            String operatorCodes = null;
                                                            boolean SMSSt=true;
                                                            boolean MailST=true;
                                                            UserType utOtr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOperator);
                                                            
							    if(abOperatorCode != null && bOperatorCode != null ) {
							    	if(abOperatorCode.equals(bOperatorCode)) {
								    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

								    	toMail = operator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                            contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								    	}
								    	operatorCodes = abOperatorCode;
								    }else {
								    	Operator aboperator = operatorRepository.getOperatorByOperatorCode(abOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, mailNotiName);
								    	if(MailST && aboperator!=null && aboperator.getEmailId() != null && aboperator.getEmailId().length() > 0) {

								    	toMail = aboperator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, smsNotiName);
                                                                        if(SMSSt && aboperator!=null && aboperator.getContactNumber() != null && aboperator.getContactNumber().length() > 0 && aboperator.getCountryCode() != null && aboperator.getCountryCode().length() > 0) {

                                                                        contactNumber="+"+aboperator.getCountryCode()+aboperator.getContactNumber();
								    	}
								    	Operator boperator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && boperator!=null && boperator.getEmailId() != null && boperator.getEmailId().length() > 0) {
								    		if(toMail != null && toMail.length() > 0) {
								    	toMail += ","+boperator.getEmailId();
								    	}else {
									    	toMail = boperator.getEmailId();

								    	}
                                                                        }
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && boperator!=null && boperator.getContactNumber() != null && boperator.getContactNumber().length() > 0 && boperator.getCountryCode() != null && boperator.getCountryCode().length() > 0) {
								    		if(contactNumber != null && contactNumber.length() > 0) {
								    	
                                                                        contactNumber +=",+"+boperator.getCountryCode()+ boperator.getContactNumber();
								    	}else {
                                                                                contactNumber="+"+boperator.getCountryCode()+ boperator.getContactNumber();

								    	}
								    	}
								    	operatorCodes = abOperatorCode+","+bOperatorCode;
								    }
							    	
							    }else if(bOperatorCode != null){
							    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
							    	if(MailST && operator.getEmailId() != null && operator.getEmailId().length() > 0) {
							    	toMail = operator.getEmailId();
							    	}
                                                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                   contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								}
							    	operatorCodes = bOperatorCode;
							    }
							   
                                                    
                                                    
                                                    
                                                    if (toMail != null && toMail.length() > 0) {
                                                       
                                                                try {
                                                                    String bodyContent = "Dear Operator"
                                                                            + ", <br><br>Booking has been cancelled. Details are given below-<br><br>";
                                                                    if(dr!=null && dr.getName()!=null && dr.getName().length()>0)
                                                                    {
                                                                    bodyContent+="Driver Name : "+dr.getName()+"<br>";
                                                                    }
                                                                           bodyContent +="Passenger Name : "+passengerName+"<br>"+ "Pick-up Time : "
                                                                            + conDt + "<br>" + "Pick-up Address : " + b.getPickUpAddress()
                                                                            + "<br>" + "Drop-off Address : " + b.getDropOffAddress();

                                                                    String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
                                                                    Map<String, String> map = new HashMap<>();
                                                                    map.put("to", toMail);
                                                                    map.put("subject", subjectcancel);
                                                                    map.put("body", encodeURL);

                                                                    RestTemplate restTemplate = new RestTemplate();
                                                                    ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL,
                                                                            String.class, map);
                                                                    String mailRes = response.getBody();
                                                                } catch (Exception ee) {
                                                                    ee.printStackTrace();
                                                                }
                                                            }
                                                       
                                                            if (contactNumber != null && contactNumber.length() > 0) {
                                                                String mobarr[]=contactNumber.split(",");
                                                                for(String mob:mobarr)
                                                                {
                                                                try {
                                                                    SendMessageAPI sendmessageapi = new SendMessageAPI();
                                                                    String messageBodyForOperator = "Dear Operator, " + "\n" + "Booking has been cancelled. Details are given below-";
                                                                    if(dr!=null && dr.getName()!=null && dr.getName().length()>0)
                                                                    {
                                                                    messageBodyForOperator+="\n"+"Driver Name : "+dr.getName();
                                                                    }
                                                                        messageBodyForOperator    += "\n" +"Passenger Name : "+passengerName+"\n"+ "Pick-up Time : "
                                                                            + conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
                                                                            + "\n" + "Drop-off Address : " + b.getDropOffAddress();
                                                                    String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, mob, messageBodyForOperator);
                                                                    System.out.println("====messageToken for driver=====" + messageToken);
                                                                } catch (Exception e) {
                                                                    e.printStackTrace();
                                                                }
                                                                }
                                                            }

                                                            String bodyContentnoti = "Dear Operator"
                                                                    + ",Booking has been cancelled. Details are given below-";
                                                                    if(dr!=null && dr.getName()!=null && dr.getName().length()>0)
                                                                    {
                                                                    bodyContentnoti+="Driver Name : "+dr.getName()+", ";
                                                                    }
                                                                    bodyContentnoti+="Passenger Name : "+passengerName+","+ "Pick-up Time : "
                                                                    + conDt + "," + "Pick-up Address : " + b.getPickUpAddress()
                                                                    + "," + "Drop-off Address : " + b.getDropOffAddress();
                                                            shortMessage = "Booking has been cancelled.";
                                                            String operatorCodesarr[]=operatorCodes.split(",");
                                                            for(String ucode:operatorCodesarr)
                                                            {
                                                                    Notification notification = new Notification();
                                                                    notification.setUserCode(ucode);
                                                                    notification.setMessage(bodyContentnoti);
                                                                    notification.setShortMessage(shortMessage);
                                                                                                            notification.setRideCode(b.getRideCode());
                                                                    notification.setIpAddress(ip);
                                                                    notification.setIsRead(Boolean.FALSE);

                                                                    notificationService.saveNotification(notification);

//                                                                    List<DeviceDetail> deviceDetailResList  = deviceDetailDao.getDeviceDetailByUserCode(dr.getDriverCode().trim());
//                                                                    if(deviceDetailResList != null && deviceDetailResList.size() > 0)
//                                                                    {
//                                                                        for(DeviceDetail deviceDetail:deviceDetailResList)
//                                                                        {
//                                                                             PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Ride Alert", "Booking has been cancelled.");
//                                                                        }
//                                                                    }
           
                                                              }

                                                    if (ab.getDriverCode() != null && ab.getDriverCode().length() > 0 && oldst!=null && !(oldst.equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus)) && !(oldst.equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))  && !(oldst.equalsIgnoreCase(GigflexConstants.assignedBookingStatus))) {
                                                        
                                                        //Driver dr = driverRepository.getDriverByDriverCode(ab.getDriverCode());
                                                        if (dr != null && dr.getId() > 0) {
                                                            UserType utDvr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeDriver);
                                                            boolean MailSTdr=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), dr.getDriverCode(), mailNotiName);
                                                            if (MailSTdr && dr.getEmailId() != null && dr.getEmailId().length() > 0) {
                                                                try {
                                                                    String bodyContent = "Dear Driver"
                                                                            + ", <br><br>Booking has been cancelled. Details are given below-<br><br>";
                                                                            if(!(oldst.equalsIgnoreCase( GigflexConstants.assignedBookingStatus)) && !(oldst.equalsIgnoreCase( GigflexConstants.bookingStatus)))
                                                                            {
                                                                            bodyContent+="Passenger Name : "+passengerName+"<br>";
                                                                             }
                                                                            bodyContent+= "Pick-up Time : "
                                                                            + conDt + "<br>" + "Pick-up Address : " + b.getPickUpAddress()
                                                                            + "<br>" + "Drop-off Address : " + b.getDropOffAddress();

                                                                    String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
                                                                    Map<String, String> map = new HashMap<>();
                                                                    map.put("to", dr.getEmailId());
                                                                    map.put("subject", subjectcancel);
                                                                    map.put("body", encodeURL);

                                                                    RestTemplate restTemplate = new RestTemplate();
                                                                    ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL,
                                                                            String.class, map);
                                                                    String mailRes = response.getBody();
                                                                } catch (Exception ee) {
                                                                    ee.printStackTrace();
                                                                }
                                                            }
                                                            boolean SmsSTdr=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), dr.getDriverCode(), smsNotiName);
                                                            if (SmsSTdr && dr.getContactNumber() != null && dr.getContactNumber().trim().length() > 0 && dr.getCountryCode()!= null && dr.getCountryCode().trim().length() > 0) {
                                                                try {
                                                                    String mob="+" +dr.getCountryCode()+dr.getContactNumber();
                                                                    SendMessageAPI sendmessageapi = new SendMessageAPI();
                                                                    String messageBodyForDriver = "Dear Driver, " + "\n" + "Booking has been cancelled. Details are given below-";
                                                                            if(!(oldst.equalsIgnoreCase( GigflexConstants.assignedBookingStatus)) && !(oldst.equalsIgnoreCase( GigflexConstants.bookingStatus)))
                                                                            {
                                                                            messageBodyForDriver+="\n Passenger Name : "+passengerName;
                                                                             }
                                                                            messageBodyForDriver+= "\n" + "Pick-up Time : "
                                                                            + conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
                                                                            + "\n" + "Drop-off Address : " + b.getDropOffAddress();
                                                                    String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, mob, messageBodyForDriver);
                                                                    System.out.println("====messageToken for driver=====" + messageToken);
                                                                } catch (Exception e) {
                                                                    e.printStackTrace();
                                                                }
                                                            }

                                                            Notification notification = new Notification();

                                                            String bodyContent = "Dear Driver"
                                                                    + ",Booking has been cancelled. Details are given below-";
                                                                    if(!(oldst.equalsIgnoreCase( GigflexConstants.assignedBookingStatus)) && !(oldst.equalsIgnoreCase( GigflexConstants.bookingStatus)))
                                                                            {
                                                                            bodyContent+=" Passenger Name : "+passengerName+",";
                                                                             }
                                                                    bodyContent+= "Pick-up Time : "
                                                                    + conDt + "," + "Pick-up Address : " + b.getPickUpAddress()
                                                                    + "," + "Drop-off Address : " + b.getDropOffAddress();
                                                                    shortMessage = "Booking has been cancelled.";

                                                            notification.setUserCode(dr.getDriverCode());
                                                            notification.setMessage(bodyContent);
                                                            notification.setShortMessage(shortMessage);
                                                            notification.setRideCode(b.getRideCode());
                                                            notification.setIpAddress(ip);
                                                            notification.setIsRead(Boolean.FALSE);

                                                            notificationService.saveNotification(notification);
                                                            //for push notification  
                                                            List<DeviceDetail> deviceDetailResList  = deviceDetailDao.getDeviceDetailByUserCode(dr.getDriverCode().trim());
                                                            if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                                                            {
                                                                for(DeviceDetail deviceDetail:deviceDetailResList)
                                                                {
                                                                    PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Ride Alert", "Booking has been cancelled.");
                                                                }
                                                                 
                                                            }
                                                           

                                                        }

                                                    }

                                                }

                                            } else {
                                                jsonobj.put("responsecode", 400);
                                                jsonobj.put("timestamp", new Date());
                                                jsonobj.put("message", "Failed");
                                                b.setBookingStatus(oldst);
                                                b.setCancelationComment("");
                                                bookingDao.save(b);
                                                if(operatorCreditTransactionRes != null)
                                                {
                                                    organizationCreditTransactionRepository.deleteById(operatorCreditTransactionRes.getId()); 
                                                }
                                            }
                                        } else {
                                            jsonobj.put("responsecode", 200);
                                            jsonobj.put("timestamp", new Date());
                                            jsonobj.put("message", "Booking has been cancelled successfully");

                                        }

                                    } else {
                                        
                                        if(operatorCreditTransactionRes != null)
                                        {
                                            organizationCreditTransactionRepository.deleteById(operatorCreditTransactionRes.getId()); 
                                        }
                                        jsonobj.put("responsecode", 400);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Failed");
                                    }
                                } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message", "Booking is already completed.");
                                }
                            } else {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("message", "Booking is already inprogress.");
                            }
                        } else {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Booking is already cancelled.");
                        }
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Record Not Found");
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Booking Record Not Found");
                }

                res = jsonobj.toString();

            } catch (Exception e) {
                GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
                res = derr.toString();

            }
            return res;

        }

    
        
	@Override
	public String assignBookingRejected(AssignBookingRejectedCommentsResponse abs, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Driver d = driverRepository.getDriverByDriverCode(abs.getDriverCode());
			if (d != null && d.getId() > 0) {
                        Booking b = bookingDao.getBookingByRideCode(abs.getRideCode());
						if (b != null && b.getId() > 0) {
                                                    
                                                    String passengerName="";
                                    Passenger pgr=  passengerDao.getPassengerByPassengerCode(b.getPassengerCode());
                                    if(pgr!=null && pgr.getId()>0)
                                     {
                                       passengerName=pgr.getPassengerName();
                                     }
				AssignBooking ab = assignBookingRepository.getAssignBookingByRideCodeAndDriverCode(abs.getRideCode(),
						abs.getDriverCode());
				if (ab != null && ab.getId() > 0) {
                                    if(!(ab.getStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus)))
                                    {
					ab.setStatus(GigflexConstants.assignedBookingRejectedStatus);
					ab.setIpAddress(ip);
					ab.setDriverCode(abs.getDriverCode());
					ab.setComments(abs.getComments());
					AssignBooking abres = assignBookingRepository.save(ab);
					if (abres != null && abres.getId() > 0) {

						

							b.setBookingStatus(GigflexConstants.assignedBookingRejectedStatus);
							Booking bookingRes = bookingDao.save(b);
							if (bookingRes != null && bookingRes.getId() > 0) {
								
								

							    String conDt="";
							    String abOperatorCode = ab.getOperatorCode();
							    String bOperatorCode = b.getOperatorCode();
							    String toMail = "";
                                                            String contactNumber="";
						            String operatorCodes = null;
                                                            boolean SMSSt=true;
                                                            boolean MailST=true;
                                                            UserType utOtr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOperator);
                                                            
							    if(abOperatorCode != null && bOperatorCode != null ) {
							    	if(abOperatorCode.equals(bOperatorCode)) {
								    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

								    	toMail = operator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                            contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								    	}
								    	operatorCodes = abOperatorCode;
								    }else {
								    	Operator aboperator = operatorRepository.getOperatorByOperatorCode(abOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, mailNotiName);
								    	if(MailST && aboperator!=null && aboperator.getEmailId() != null && aboperator.getEmailId().length() > 0) {

								    	toMail = aboperator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, smsNotiName);
                                                                        if(SMSSt && aboperator!=null && aboperator.getContactNumber() != null && aboperator.getContactNumber().length() > 0 && aboperator.getCountryCode() != null && aboperator.getCountryCode().length() > 0) {

                                                                        contactNumber="+"+aboperator.getCountryCode()+aboperator.getContactNumber();
								    	}
								    	Operator boperator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && boperator!=null && boperator.getEmailId() != null && boperator.getEmailId().length() > 0) {
								    		if(toMail != null && toMail.length() > 0) {
								    	toMail += ","+boperator.getEmailId();
								    	}else {
									    	toMail = boperator.getEmailId();

								    	}
                                                                        }
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && boperator!=null && boperator.getContactNumber() != null && boperator.getContactNumber().length() > 0 && boperator.getCountryCode() != null && boperator.getCountryCode().length() > 0) {
								    		if(contactNumber != null && contactNumber.length() > 0) {
								    	
                                                                        contactNumber +=",+"+boperator.getCountryCode()+ boperator.getContactNumber();
								    	}else {
                                                                                contactNumber="+"+boperator.getCountryCode()+ boperator.getContactNumber();

								    	}
								    	}
								    	operatorCodes = abOperatorCode+","+bOperatorCode;
								    }
							    	
							    }else if(bOperatorCode != null){
							    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
							    	if(MailST && operator.getEmailId() != null && operator.getEmailId().length() > 0) {
							    	toMail = operator.getEmailId();
							    	}
                                                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                   contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								}
							    	operatorCodes = bOperatorCode;
							    }
                                                    
                                                    
							   
								   
						            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                            {
                                                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                            }                
                                            
                                                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TimeZone);

                                                            TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                            if (tzd != null && tzd.getId() > 0) {

                                                                String timezone = tzd.getTimeZoneName();
                                                                if(timezone!=null && timezone.length()>0 )
                                                                {
                                                                     Date pDate = b.getPickUpTime();
                                                                     pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                     conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                }

                                                            }         
								   String bodyContent = "Dear Operator " 
									+ ", <br><br>Assigned booking has been rejected. Details are given below-<br><br>";
								if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                    {
                                                                    bodyContent+="Driver Name : "+d.getName()+"<br>";
                                                                    }
                                                                          bodyContent +="Passenger Name : "+passengerName+"<br>"+ "Pick-up Time : "
									+ conDt + "<br>" + "Pick-up Address : " + b.getPickUpAddress()
									+ "<br>" + "Drop-off Address : " + b.getDropOffAddress();
                                                                   String messageBodyForDriver="Dear "+d.getName()+","+"\n"
									+ ", You have rejected assigned booking . Details are given below-"+"\n"
									+ "Pick-up Time : "
									+ conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
									+ "\n" + "Drop-off Address : " + b.getDropOffAddress();
                                                                    String messageBodyForOperator="Dear Operator "+"\n"
									+ ", Assigned booking has been rejected. Details are given below-"+"\n";
                                                                    if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                    {
                                                                    messageBodyForOperator+="Driver Name : "+d.getName()+"\n";
                                                                    }
									messageBodyForOperator+="Passenger Name : "+passengerName+ "\n" + "Pick-up Time : "
									+ conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
									+ "\n" + "Drop-off Address : " + b.getDropOffAddress();

                                                                    if(toMail != null && toMail.length() > 0) {
							String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
							Map<String, String> map = new HashMap<>();
							map.put("to", toMail);
							map.put("subject", subjectRej);
							map.put("body", encodeURL);
							try {
							       	
								RestTemplate restTemplate = new RestTemplate();
								ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL,
										String.class, map);
								String mailRes = response.getBody();
                                                                
                                                                 

							} catch (Exception ex) {
								ex.printStackTrace();
							}
							   }
                                                                    
                                                               SendMessageAPI sendmessageapi = new SendMessageAPI();	      
                                                                    try {
                                                                        UserType utDvr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeDriver);
                                                            boolean SmsSTdr=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), d.getDriverCode(), smsNotiName);
                                                            
                                                                if (SmsSTdr && d.getContactNumber() != null && d.getContactNumber().trim().length() > 0 && d.getCountryCode() != null && d.getCountryCode().trim().length() > 0) {
                                                                    String mob="+"+d.getCountryCode()+ d.getContactNumber();
                                                                    String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url,mob, messageBodyForDriver);
                                                                    System.out.println("====messageToken for driver=====" + messageToken);
                                                                }
                                                            } catch (Exception e) {
                                                                e.printStackTrace();
                                                            }
                                                            try {
                                                                if (contactNumber != null && contactNumber.length()>0) {
                                                                    String contactArray[] = contactNumber.split(",");
                                                                    for (int i = 0; i <contactArray.length; i++) {
                                                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, contactArray[i], messageBodyForOperator);
                                                                        System.out.println("====messageToken For operators=====" + messageToken);
                                                                    }
                                                                }
                                                            } catch (Exception e) {
                                                                e.printStackTrace();
                                                            }
                                                                    
                                                                    
							   try {
								   if(operatorCodes != null && operatorCodes.length() > 0) {
									   String userCodes[] = operatorCodes.split(",");
									   for(String userCode : userCodes) {
										  if(userCode != null && userCode.length() > 0) {
											  Notification notification = new Notification();
											  
											  String bodyContentnoti = "Dear Operator" 
														+ ",Assigned booking has been rejected. Details are given below-";
                                                                                           if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                                            {
                                                                                            bodyContentnoti+="Driver Name : "+d.getName()+", ";
                                                                                            }
														bodyContentnoti+="Passenger Name : "+passengerName+","+ "Pick-up Time : "
														+ conDt + "," + "Pick-up Address : " + b.getPickUpAddress()
                                                                                                                + "," + "Drop-off Address : " + b.getDropOffAddress();
                                                                                          shortMessage = "Assigned booking has been rejected.";

                                                                                          notification.setUserCode(userCode);
                                                                                          notification.setMessage(bodyContentnoti);
                                                                                          notification.setShortMessage(shortMessage);
                                                                                          notification.setRideCode(b.getRideCode());
                                                                                          notification.setIpAddress(ip);
                                                                                          notification.setIsRead(Boolean.FALSE);

                                                                                          notificationService.saveNotification(notification);
                                                                                          //for push notification  
//                                                                                        List<DeviceDetail> deviceDetailResList  = deviceDetailDao.getDeviceDetailByUserCode(d.getDriverCode().trim());
//                                                                                        if(deviceDetailResList != null && deviceDetailResList.size() > 0)
//                                                                                        {
//                                                                                            for(DeviceDetail deviceDetail:deviceDetailResList)
//                                                                                            {
//                                                                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), shortMessage, bodyContent);
//
//                                                                                            }
//                                                                                        }
                                                                                   
										  }
									   }
								   }
								   
							   }catch(Exception e){
								   e.printStackTrace();
							   }

								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Assigned Booking has been rejected successfully");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(abres);
								jsonobj.put("data", new JSONObject(Detail));
                                                                BookingRejection br=new BookingRejection();
                                                                br.setComments(abs.getComments());
                                                                br.setDriverCode(abs.getDriverCode());
                                                                br.setRideCode(abs.getRideCode());
                                                                br.setIpAddress(ip);
                                                                bookingRejectionRepository.save(br);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Failed");
							}
						

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Failed");
					}
                                } else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Booking is already rejected.");
				}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
                                } else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Booking Record Not Found");
						}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Driver does not exist.");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();

		}
		return res;
	}

	@Override
	public String assignBookingToDriver(AssignBookingRequest abs, String ip) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Operator o = operatorRepository.getOperatorByOperatorCode(abs.getOperatorCode().trim());
			if (o != null && o.getId() > 0) {
				Driver d = driverRepository.getDriverByDriverCode(abs.getDriverCode().trim());
				if (d != null && d.getId() > 0) {
                                List<BookingRejection> brej  =  bookingRejectionRepository.getBookingRejectionByDriverCodeRideCode(abs.getDriverCode().trim(), abs.getRideCode().trim());
                                
                                if(brej==null || brej.size()==0)
                                {
                                    Booking b = bookingDao.getBookingByRideCode(abs.getRideCode().trim());
                                                                                
                                        if(b != null && b.getId() > 0)
                                        {
//                                    if(d.getFleetSize()!=null && d.getFleetSize()>0)
//                            {
//                                    List<VehicleDetail> vdlst=vehicleDetailRepository.getVehicleListByDriverCode(d.getDriverCode());
                                    Driver driver = driverRepository.getDriverByDriverCode(d.getDriverCode());
                                            String timezone = null;
                                            String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TimeZone);

                                            TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                            if (tzd != null && tzd.getId() > 0) {

                                                timezone = tzd.getTimeZoneName();
                                            }
                                    Date bookingPickupTime  = b.getPickUpTime();
                                    Date pdt=null;
                                    try
                                    {
                                    pdt=GigflexDateUtil.getGMTtoLocationDate( bookingPickupTime, timezone, GigflexConstants.YYYY_MM_DD_HH_MM_SS);
                                    }
                                    catch(Exception ee)
                                    {
                                        ee.printStackTrace();
                                    }
                                    if(pdt==null )
                                    {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "Date conversion has been failed.");
                                            return derr.toString();
                                    }
                                    Calendar calPickupDate = Calendar.getInstance();
                                    calPickupDate.setTime(pdt);
                                    int currentDay = calPickupDate.get(Calendar.DAY_OF_WEEK);
                                    HoursOfOperation  hoursOfOperation = hoursOfOperationDao.getHoursByDriverCodeAndDayCode(driver.getDriverCode(), currentDay); 
                                    if(hoursOfOperation == null )
                                    {
                                        jsonobj.put("responsecode", 400);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Hours of operation is not present for driver");
                                        return jsonobj.toString();
                                    }
                                    
                                    
                                    VehicleDetail vd  = vehicleDetailRepository.getVehicleDetailByVehicleCode(hoursOfOperation.getVehicleCode());
                                    if(vd!=null )
                                    {
                                                    
                                            
                                            
                                            Date bookingDropoffTime = b.getDropOffTime();
                                            Calendar cal = Calendar.getInstance();

                                            cal.setTime(bookingPickupTime);
                                            cal.add(Calendar.HOUR_OF_DAY, -1);                           
                                            Date decrementedPickupTime = cal.getTime();

                                            cal.setTime(bookingDropoffTime);
                                            cal.add(Calendar.HOUR_OF_DAY, 1);
                                            Date incrementedDropOffTime = cal.getTime();
                                            
                                            
                                            List<String> drivercodeList = new ArrayList<>();
                                            drivercodeList.add(d.getDriverCode());
                                            List<Driver> busyDriverList = bookingDao.getAssignedBusyDriver(decrementedPickupTime,incrementedDropOffTime,drivercodeList,GigflexConstants.assignedBookingCancelledStatus,GigflexConstants.assignedBookingRejectedStatus,GigflexConstants.assignedBookingCompletedStatus,GigflexConstants.assignedBookingExpiredStatus);

                                            if(busyDriverList != null && busyDriverList.size() > 0)
                                            {
                                                 jsonobj.put("responsecode", 400);
                                                 jsonobj.put("timestamp", new Date());
                                                 jsonobj.put("message", "Driver is busy for other booking");
                                                 return jsonobj.toString();
                                            }
                                            
                                            
                                            if(b.getBookingStatus().equalsIgnoreCase(GigflexConstants.bookingStatus))
                                            {
                                                jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Booking is already assigned!");
						 return jsonobj.toString();
                                            }
                                            else
                                            {
                                              if(b.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || b.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || b.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                            {
                                                    Boolean bst=false;
                                                    int noP=0;
                                                    int noB=0;
                                                    if(b.getNoOfPassengers()!=null && b.getNoOfPassengers()>0 )
                                                    {
                                                       noP=b.getNoOfPassengers();  
                                                    }
                                                    if(b.getNoOfBaggage()!=null && b.getNoOfBaggage()>0 )
                                                    {
                                                       noB=b.getNoOfBaggage();  
                                                    }
                                                    RideType vrt=    rideTypeRepository.getRideTypeByVehicleCode(b.getVehicleCode());
                                                    if(vrt!=null && vrt.getId()>0 && vrt.getGlobalRidetypeCode()!=null && vrt.getGlobalRidetypeCode().length()>0)
                                                    {
//                                                    for(VehicleDetail vd:vdlst)
//                                                    {
                                                    GlobalRideType grt= rideTypeRepository.getRideTypeByVehicleCodeForGlobal(vd.getVehicleType());
                                                    if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode().equalsIgnoreCase(vrt.getGlobalRidetypeCode()))
                                                    {
                                                        if(vd!=null && vd.getBaggageQuantity()!=null && vd.getPassengerQuantity()!=null && vd.getBaggageQuantity()>= noB && vd.getPassengerQuantity()>=noP)
                                                        {
                                                            bst=true;
                                                        }
                                                    }
//                                                    }
                                                    }
                                                    if(bst)
                                                    {   
                                                        AssignBooking ab = assignBookingRepository.getAssignBookingByRideCode(abs.getRideCode().trim());
					
					if (ab != null && ab.getId() > 0) {
						ab.setStatus(GigflexConstants.bookingStatus);
						ab.setIpAddress(ip);
						ab.setDriverCode(abs.getDriverCode());
						ab.setOperatorCode(abs.getOperatorCode());
                                                ab.setOrganizationCode(abs.getOrganizationCode());
						AssignBooking abres = assignBookingRepository.save(ab);
						if (abres != null && abres.getId() > 0) {

							Booking b1 = bookingDao.getBookingByRideCode(abs.getRideCode());
							if (b1 != null && b1.getId() > 0) {

								b1.setBookingStatus(GigflexConstants.bookingStatus);
								Booking bookingRes = bookingDao.save(b1);
								if (bookingRes != null && bookingRes.getId() > 0) {

									byte[] encoded = Base64.getEncoder()
											.encode(abres.getAssignBookingCode().getBytes());
									String tok = new String(encoded);

									String accept = "True";
									String reject = "False";

									byte[] encoded1 = Base64.getEncoder().encode(accept.getBytes());
									String tok1 = new String(encoded1);

									byte[] encoded2 = Base64.getEncoder().encode(reject.getBytes());
									String tok2 = new String(encoded2);
                                                                        
                                                                        byte[] encoded3 = Base64.getEncoder().encode(abs.getDriverCode().getBytes());
									String tok3 = new String(encoded3);

									String approve_url = changeAssignBookingStatusUrl
											+ "changeAssignBookingStatusViaMail?tok=" + tok + "&tok1=" + tok1+ "&tok2=" + tok3;
									String disapprove_url = changeAssignBookingStatusUrl
											+ "changeAssignBookingStatusViaMail?tok=" + tok + "&tok1=" + tok2+ "&tok2=" + tok3;

									   
									String conDt="";
								    
							                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                                        {
                                                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                                        }                

                                                                 
                                                                            if(timezone!=null && timezone.length()>0 )
                                                                            {
                                                                                 Date pDate = b.getPickUpTime();
                                                                                 pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                                 conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                            }

                                                                               
									String bodyContent = "Dear " + d.getName()
											+ ", <br><br>New booking has been assigned to you. Details are given below-<br><br>"
											+ "Pick-up Time : "
											+ conDt + "<br>" + "Pick-up Address : " + b.getPickUpAddress()
											+ "<br>" + "Drop-off Address : " + b.getDropOffAddress() + "<br>"
											+ "<br><br>Please accept/reject by clicking below button,";

									bodyContent += "<br><br>  <a href='" + approve_url
											+ "' style='background: #fa7d04;color: #FFF;padding: 8px 12px;border-radius: 6px;border: solid;text-decoration: none;' target='_blank'>Accept Ride</a>";
									bodyContent += "<t>  <a href='" + disapprove_url
											+ "' style='background: #06d7f5;color: #FFF;padding: 8px 12px;border-radius: 6px;border: solid;text-decoration: none;' target='_blank'>Reject Ride</a><br><br>";

                                                                        String messageBody = "Dear "+d.getName()+","+"\n"+"New booking has been assigned to you. Details are given below-"+"\n"
                                                                                 + "Pick-up Time : "	+ conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
											+ "\n" + "Drop-off Address : " + b.getDropOffAddress() + "\n"+ "Please check your Dashboard or Email to take appropriate action ";
                                                                        
                                                                        
//                                                                     byte[] encodedbody = Base64.getEncoder().encode(bodyContent.getBytes());
//                                                                     String body = new String(encodedbody);
									String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
									Map<String, String> map = new HashMap<>();
									map.put("to", d.getEmailId());
									map.put("subject", subject);
									map.put("body", encodeURL);
									try {
										RestTemplate restTemplate = new RestTemplate();
										ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL,
												String.class, map);
										String mailRes = response.getBody();
                                                                                

									} catch (Exception ex) {
										ex.printStackTrace();
									}
                                                                        
                                                                        SendMessageAPI sendmessageapi = new SendMessageAPI();
                                                                                 try {
                                                                                     UserType utDvr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeDriver);
                                                                                     boolean SMSStdr=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), d.getDriverCode(), smsNotiName);
                                                                                    if(SMSStdr && d.getContactNumber()!=null && d.getContactNumber().trim().length()>0 && d.getCountryCode()!=null && d.getCountryCode().trim().length()>0){
                                                                                   String mob="+"+d.getCountryCode()+ d.getContactNumber();
                                                                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, mob, messageBody);
                                                                                    System.out.println("====messageToken=====" + messageToken);
                                                                                    }
                                                                                } catch (Exception e) {
                                                                                    e.printStackTrace();
                                                                                }
									try {
								
                                                                                Notification notification = new Notification();

                                                                                String body =  "Dear " + d.getName()
                                                                                      + ",New booking has been assigned to you. Details are given below-"
                                                                                      + "Pick-up Time : "
                                                                                      + conDt + "," + "Pick-up Address : " + b.getPickUpAddress()
                                                                                      + "," + "Drop-off Address : " + b.getDropOffAddress() ;
                                                                                shortMessage = "Booking has been Assigned to driver.";
                                                                                notification.setUserCode(d.getDriverCode());
                                                                                notification.setMessage(body);
                                                                                notification.setShortMessage(shortMessage);
                                                                                notification.setRideCode(b.getRideCode());
                                                                                notification.setIpAddress(ip);
                                                                                notification.setIsRead(Boolean.FALSE);

                                                                                notificationService.saveNotification(notification);
                                                                                
                                                                                List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(d.getDriverCode().trim());
                                                                                if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                                                                                {
                                                                                    //for push notification  
                                                                                    for(DeviceDetail deviceDetail:deviceDetailResList)
                                                                                    {
                                                                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "New Ride Alert", "A new ride is assigned to you");
                                                                                    }
                                                                                    
                                                                                }
                                                                                

									   }catch(Exception e){
										   e.printStackTrace();
									   }

									jsonobj.put("responsecode", 200);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message", "Booking has been Assigned to driver.");
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj.writeValueAsString(abres);
									jsonobj.put("data", new JSONObject(Detail));
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message", "Failed");
								}
							} else {
								jsonobj.put("responsecode", 404);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Booking Record Not Found");
							}

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");
					}
                                        } else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "This action is not possible as booking requirements have not been fulfilled.");
					}
                                        } else {
                                        jsonobj.put("responsecode", 400);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Booking cannot be assigned!");
					}
                                        }
                                              
                                        
                                        } else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Booking is not possible as driver do'nt have any vehicle.");
					}
//                                     } else {
//						jsonobj.put("responsecode", 400);
//						jsonobj.put("timestamp", new Date());
//						jsonobj.put("message", "Booking is not possible as driver do'nt have any vehicle.");
//					}

                                        } else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");
					}
                                        } else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Booking can not be reassigned as driver had been rejected this booking.");
				}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Driver does not exist.");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Operator does not exist.");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();

		}
		return res;
	}

	@Override
	public String changeAssignBookingStatusViaMail(String assignbookingcode, Boolean status,String driverCode) {
		String res = "";
		try {

			AssignBooking ab = assignBookingRepository.getAssignBookingByCode(assignbookingcode);
			if (ab != null && ab.getId() > 0) {
                            
                            
                            AssignBooking abCheck = assignBookingRepository.getAssignBookingByDriverCodeAndRideCode(driverCode,ab.getRideCode(),GigflexConstants.bookingStatus);
                            
                            if(abCheck == null )
                            {
                                GigflexResponse derr = new GigflexResponse(400, new Date(), "Invalid Action!.");
			        return derr.toString();
                            }
                            
                            
                            Booking b1 = bookingDao.getBookingByRideCode(ab.getRideCode());
					if (b1 != null && b1.getId() > 0) {
                            
                                            String passengerName="";
                                            Passenger pgr=  passengerDao.getPassengerByPassengerCode(b1.getPassengerCode());
                                            if(pgr!=null && pgr.getId()>0)
                                             {
                                               passengerName=pgr.getPassengerName();
                                             }
				if (status == true) {
                                    if(ab.getStatus().equalsIgnoreCase(GigflexConstants.assignedBookingAcceptedStatus))
                                                    {
                                                        return "Booking is already accepted.";
                                                    }
					ab.setStatus(GigflexConstants.assignedBookingAcceptedStatus);
				} else {
                                    if(ab.getStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus))
                                                    {
                                                        return "Booking is already rejected.";
                                                    }
					ab.setStatus(GigflexConstants.assignedBookingRejectedStatus);
				}
				AssignBooking abres = assignBookingRepository.save(ab);
				if (abres != null && abres.getId() > 0) {
					
						if (status == true) {
                                                    
							b1.setBookingStatus(GigflexConstants.assignedBookingAcceptedStatus);
						} else {
                                                    
							b1.setBookingStatus(GigflexConstants.assignedBookingRejectedStatus);
						}
						Booking bookingRes = bookingDao.save(b1);
						if (bookingRes != null && bookingRes.getId() > 0) {

                                                    Driver d=null;
                                                    if(abres.getDriverCode()!=null)
                                                    {
                                                        d=driverRepository.getDriverByDriverCode(abres.getDriverCode());  
                                                    }
							if (status == true) {								                                                            
							    String conDt="";
							    String abOperatorCode = ab.getOperatorCode();
							    String bOperatorCode = b1.getOperatorCode();
							    String toMail = "";
                                                            String contactNumber="";
						            String operatorCodes = null;
                                                            boolean SMSSt=true;
                                                            boolean MailST=true;
                                                            UserType utOtr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOperator);
                                                            
							    if(abOperatorCode != null && bOperatorCode != null ) {
							    	if(abOperatorCode.equals(bOperatorCode)) {
								    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

								    	toMail = operator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                            contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								    	}
								    	operatorCodes = abOperatorCode;
								    }else {
								    	Operator aboperator = operatorRepository.getOperatorByOperatorCode(abOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, mailNotiName);
								    	if(MailST && aboperator!=null && aboperator.getEmailId() != null && aboperator.getEmailId().length() > 0) {

								    	toMail = aboperator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, smsNotiName);
                                                                        if(SMSSt && aboperator!=null && aboperator.getContactNumber() != null && aboperator.getContactNumber().length() > 0 && aboperator.getCountryCode() != null && aboperator.getCountryCode().length() > 0) {

                                                                        contactNumber="+"+aboperator.getCountryCode()+aboperator.getContactNumber();
								    	}
								    	Operator boperator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && boperator!=null && boperator.getEmailId() != null && boperator.getEmailId().length() > 0) {
								    		if(toMail != null && toMail.length() > 0) {
								    	toMail += ","+boperator.getEmailId();
								    	}else {
									    	toMail = boperator.getEmailId();

								    	}
                                                                        }
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && boperator!=null && boperator.getContactNumber() != null && boperator.getContactNumber().length() > 0 && boperator.getCountryCode() != null && boperator.getCountryCode().length() > 0) {
								    		if(contactNumber != null && contactNumber.length() > 0) {
								    	
                                                                        contactNumber +=",+"+boperator.getCountryCode()+ boperator.getContactNumber();
								    	}else {
                                                                                contactNumber="+"+boperator.getCountryCode()+ boperator.getContactNumber();

								    	}
								    	}
								    	operatorCodes = abOperatorCode+","+bOperatorCode;
								    }
							    	
							    }else if(bOperatorCode != null){
							    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
							    	if(MailST && operator.getEmailId() != null && operator.getEmailId().length() > 0) {
							    	toMail = operator.getEmailId();
							    	}
                                                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                   contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								}
							    	operatorCodes = bOperatorCode;
							    }
                                                    
							                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b1.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b1.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                                        {
                                                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                                        }                

                                                                        String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b1.getOrganizationCode(), GigflexConstants.TimeZone);

                                                                        TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                                        if (tzd != null && tzd.getId() > 0) {

                                                                            String timezone = tzd.getTimeZoneName();
                                                                            if(timezone!=null && timezone.length()>0 )
                                                                            {
                                                                                 Date pDate = b1.getPickUpTime();
                                                                                 pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                                 conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                            }

                                                                        }         
									String bodyContent = "Dear Operator "
											+ ", <br><br>Assigned booking has been accepted. Details are given below-<br><br>";
										if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                                {
                                                                                bodyContent+="Driver Name : "+d.getName()+"<br>";
                                                                                }
                                                                                bodyContent+="Passenger Name : "+passengerName+"<br>"+ "Pick-up Time : "
											+ conDt+ "<br>" + "Pick-up Address : " + b1.getPickUpAddress()
											+ "<br>" + "Drop-off Address : " + b1.getDropOffAddress();
                                                                        String messageBody="Dear Operator , "+"\n"
											+ "Assigned booking has been accepted. Details are given below-";
                                                                        if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                                {
                                                                                messageBody+="\n Driver Name : "+d.getName();
                                                                                }
											messageBody+="\n Passenger Name : "+passengerName+"\n"+ "Pick-up Time : "
											+ conDt+ "\n" + "Pick-up Address : " + b1.getPickUpAddress()
											+ "\n" + "Drop-off Address : " + b1.getDropOffAddress();

                                                                        if (toMail != null && toMail.length() > 0) {
									String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
									Map<String, String> map = new HashMap<>();
									map.put("to", toMail);
									map.put("subject", subjectAcc);
									map.put("body", encodeURL);
									try {
                                                                                
										RestTemplate restTemplate = new RestTemplate();
										ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL,
												String.class, map);
										String mailRes = response.getBody();
                                                                               
									} catch (Exception ex) {
										ex.printStackTrace();
									}
								}
                                                                        
                                                                        try {
                                                                                if (contactNumber != null && contactNumber.length()>0) {
                                                                                     SendMessageAPI sendmessageapi = new SendMessageAPI();
                                                                                    String contactArray[] = contactNumber.split(",");
                                                                                    for (int i = 0; i <contactArray.length; i++) {
                                                                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, contactArray[i], messageBody);
                                                                                        System.out.println("====messageToken For operators=====" + messageToken);
                                                                                    }
                                                                                }
                                                                            } catch (Exception e) {
                                                                                e.printStackTrace();
                                                                            }

                                                                        
								   try {
									   if(operatorCodes != null && operatorCodes.length() > 0) {
										   String userCodes[] = operatorCodes.split(",");
										   for(String userCode : userCodes) {
											  if(userCode != null && userCode.length() > 0) {
												  Notification notification = new Notification();
												  
												  String bodyContentnoti = "Dear Operator" 
															+ ",Assigned booking has been accepted. Details are given below-";
															if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                                                                        {
                                                                                                                        bodyContentnoti+="Driver Name : "+d.getName()+",";
                                                                                                                        }
                                                                                                          bodyContentnoti+="Passenger Name : "+passengerName+","+ "Pick-up Time : "
															+ conDt + "," + "Pick-up Address : " + b1.getPickUpAddress()
															+ "," + "Drop-off Address : " + b1.getDropOffAddress();
												  shortMessage = "Assigned booking has been accepted.";
												  
												  notification.setUserCode(userCode);
												  notification.setMessage(bodyContentnoti);
												  notification.setShortMessage(shortMessage);
												  notification.setRideCode(b1.getRideCode());
												  notification.setIsRead(Boolean.FALSE);
												  
												  notificationService.saveNotification(notification);
                                                                                                  //for push notification
//                                                                                                  PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
											  }
										   }
									   }
									   
								   }catch(Exception e){
									   e.printStackTrace();
								   }
							} else {
								
								String conDt="";
							    String abOperatorCode = ab.getOperatorCode();
							    String bOperatorCode = b1.getOperatorCode();
							    String toMail = "";
                                                            String contactNumber="";
						            String operatorCodes = null;
                                                            boolean SMSSt=true;
                                                            boolean MailST=true;
                                                            UserType utOtr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOperator);
                                                            
							    if(abOperatorCode != null && bOperatorCode != null ) {
							    	if(abOperatorCode.equals(bOperatorCode)) {
								    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

								    	toMail = operator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                            contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								    	}
								    	operatorCodes = abOperatorCode;
								    }else {
								    	Operator aboperator = operatorRepository.getOperatorByOperatorCode(abOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, mailNotiName);
								    	if(MailST && aboperator!=null && aboperator.getEmailId() != null && aboperator.getEmailId().length() > 0) {

								    	toMail = aboperator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, smsNotiName);
                                                                        if(SMSSt && aboperator!=null && aboperator.getContactNumber() != null && aboperator.getContactNumber().length() > 0 && aboperator.getCountryCode() != null && aboperator.getCountryCode().length() > 0) {

                                                                        contactNumber="+"+aboperator.getCountryCode()+aboperator.getContactNumber();
								    	}
								    	Operator boperator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && boperator!=null && boperator.getEmailId() != null && boperator.getEmailId().length() > 0) {
								    		if(toMail != null && toMail.length() > 0) {
								    	toMail += ","+boperator.getEmailId();
								    	}else {
									    	toMail = boperator.getEmailId();

								    	}
                                                                        }
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && boperator!=null && boperator.getContactNumber() != null && boperator.getContactNumber().length() > 0 && boperator.getCountryCode() != null && boperator.getCountryCode().length() > 0) {
								    		if(contactNumber != null && contactNumber.length() > 0) {
								    	
                                                                        contactNumber +=",+"+boperator.getCountryCode()+ boperator.getContactNumber();
								    	}else {
                                                                                contactNumber="+"+boperator.getCountryCode()+ boperator.getContactNumber();

								    	}
								    	}
								    	operatorCodes = abOperatorCode+","+bOperatorCode;
								    }
							    	
							    }else if(bOperatorCode != null){
							    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
							    	if(MailST && operator.getEmailId() != null && operator.getEmailId().length() > 0) {
							    	toMail = operator.getEmailId();
							    	}
                                                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                   contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								}
							    	operatorCodes = bOperatorCode;
							    }
                                                    
                                                            
                                                            
								
						             Organization org = orgDao.findByOrganizationCode(b1.getOrganizationCode());
						             if (org != null && org.getId() > 0) {
						                 String timezoneCode = org.getTimezone();
						                 TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
						                 if(b1.getPickUpTime()!=null){
                                                                 Date pDate = b1.getPickUpTime();
						                 pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, tz.getTimeZoneName(), GigflexConstants.dateFormatterForView);
						                 conDt=GigflexDateUtil.converDateToString(pDate);
                                                                 }
						             }
									String bodyContent = "Dear Operator "
											+ ", <br><br>Assigned booking has been rejected. Details are given below-<br><br>";
                                                                        if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                           {
                                                                           bodyContent+="Driver Name : "+d.getName()+"<br>" ;
                                                                            }
											bodyContent+="Passenger Name : "+passengerName+"<br>"+ "Pick-up Time : "
											+ conDt + "<br>" + "Pick-up Address : " + b1.getPickUpAddress()
											+ "<br>" + "Drop-off Address : " + b1.getDropOffAddress();
                                                                        
                                                                         String messageBody="Dear Operator , "+"\n"
											+ " Assigned booking has been rejected. Details are given below-";
                                                                          if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                           {
                                                                           messageBody+="\n Driver Name : "+d.getName() ;
                                                                            }
											messageBody+="\n Passenger Name : "+passengerName+"\n"+ "Pick-up Time : "
											+ conDt + "\n" + "Pick-up Address : " + b1.getPickUpAddress()
											+ "\n" + "Drop-off Address : " + b1.getDropOffAddress();

                                                                         if (toMail != null && toMail.length() > 0) {
									String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
									Map<String, String> map = new HashMap<>();
									map.put("to", toMail);
									map.put("subject", subjectRej);
									map.put("body", encodeURL);
									try { 
                                                                               
										RestTemplate restTemplate = new RestTemplate();
										ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL,
												String.class, map);
										String mailRes = response.getBody();
                                                                                 

									} catch (Exception ex) {
										ex.printStackTrace();
									}
								}
                                                                         
                                                                          try {
                                                                                if (contactNumber != null && contactNumber.length()>0) {
                                                                                    String contactArray[] = contactNumber.split(",");
                                                                                     SendMessageAPI sendmessageapi = new SendMessageAPI();
                                                                                    for (int i = 0; i <contactArray.length; i++) {
                                                                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, contactArray[i], messageBody);
                                                                                        System.out.println("====messageToken For operators=====" + messageToken);
                                                                                    }
                                                                                }
                                                                            } catch (Exception e) {
                                                                                e.printStackTrace();
                                                                            }
                                                                         
								   try {
									   if(operatorCodes != null && operatorCodes.length() > 0) {
										   String userCodes[] = operatorCodes.split(",");
										   for(String userCode : userCodes) {
											  if(userCode != null && userCode.length() > 0) {
												  Notification notification = new Notification();
												  
												  String bodyContentnoti = "Dear Operator" 
															+ ",Assigned booking has been rejected. Details are given below-";
                                                                                                  if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                                                                        {
                                                                                                                        bodyContentnoti+="Driver Name : "+d.getName()+",";
                                                                                                                        }
															bodyContentnoti+="Passenger Name : "+passengerName+","+ "Pick-up Time : "
															+ conDt + "," + "Pick-up Address : " + b1.getPickUpAddress()
															+ "," + "Drop-off Address : " + b1.getDropOffAddress();
												  shortMessage = "Assigned booking has been rejected.";
												  
												  notification.setUserCode(userCode);
												  notification.setMessage(bodyContentnoti);
												  notification.setShortMessage(shortMessage);
												  notification.setRideCode(b1.getRideCode());
												  notification.setIsRead(Boolean.FALSE);
												  
												  notificationService.saveNotification(notification);
                                                                                                  //for push notification  
                                                                                                  PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
											  }
										   }
									   }
									   
								   }catch(Exception e){
									   e.printStackTrace();
								   }
                                                                BookingRejection br=new BookingRejection();
                                                                br.setComments("Booking rejected through mail");
                                                                br.setDriverCode(ab.getDriverCode());
                                                                br.setRideCode(ab.getRideCode());
                                                                br.setIpAddress("via email");
                                                                bookingRejectionRepository.save(br);
							}
							res = "Assigned Booking Status has been changed successfully";

						} else {
							res = "Failed";
						}
					
				} else {
					res = "Failed";
				}
                                } else {

						res = "Booking Record Not Found";
					}
			} else {
				res = "Record Not Found";
			}
		} catch (Exception e) {
			res = "Exception occurred.";
		}
		return res;
	}

	@Override
	public String getAssignedBookingByDriverCode(String driverCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = assignBookingRepository.getAssignedBookingByDriverCode(driverCode, GigflexConstants.bookingStatus);

			List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                                Driver driver = driverRepository.getDriverByDriverCode(driverCode);
                                String organizationCode = driver.getOrganizationCode();
                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TIMEFORMAT);
                                 String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.CURRENCYSYMBOL);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver,driverCode, GigflexConstants.TimeZone);

                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 6) {
						Booking data = (Booking) arr[0];
						Passenger passengerData = (Passenger) arr[5];
						BookingAllResponse brwo = new BookingAllResponse();
						
						String conDt="";
                                               
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                    }

                                                }         
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                
					        brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());
                                                brwo.setCancelationComment(data.getCancelationComment());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                    AssignBooking ab=(AssignBooking) arr[4];
                                            if(ab!=null && ab.getId()>0)
                                            {
                                                if(ab.getOperatorCode()!=null && ab.getOperatorCode().length()>0)
                                                {
                                                    brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                                   Operator op=operatorRepository.getOperatorByOperatorCode(ab.getOperatorCode());
                                                   if(op!=null && op.getId()>0 && op.getOperatorName()!=null)
                                                   {
                                                      brwo.setAssignorOperatorName(op.getOperatorName());
                                                   }
                                                }
                                                
                                                if(ab.getDriverCode()!=null && ab.getDriverCode().length()>0)
                                                {
                                                    brwo.setDriverCode(ab.getDriverCode());
                                                   Driver dr=driverRepository.getDriverByDriverCode(ab.getDriverCode());
                                                   if(dr!=null && dr.getId()>0 && dr.getName()!=null)
                                                   {
                                                      brwo.setDriverName(dr.getName());
                                                        brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                                   }
                                                }
                                            }
                                            GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
                                            maplst.add(brwo);
					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAssignedBookingByDriverCode(String driverCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if(limit > 0){
			Pageable pageableRequest = PageRequest.of(page, limit);
			
			List<Object> objlst1 = assignBookingRepository.getAssignedBookingByDriverCode(driverCode, GigflexConstants.bookingStatus);
			int count = objlst1.size();
	
			List<Object> objlst = assignBookingRepository.getAssignedBookingByDriverCode(driverCode, GigflexConstants.bookingStatus,pageableRequest);
			
			List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
                        
			if (objlst != null && objlst.size() > 0) {
                                Driver driver = driverRepository.getDriverByDriverCode(driverCode);
                                String organizationCode = driver.getOrganizationCode();
                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TIMEFORMAT);
                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.CURRENCYSYMBOL);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TimeZone);

                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 6) {
						Booking data = (Booking) arr[0];
						Passenger passengerData = (Passenger) arr[5];
						BookingAllResponse brwo = new BookingAllResponse();
						
						String conDt="";
                                                
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                    }

                                                }         

                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat); 
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                
						brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());
                                                brwo.setCancelationComment(data.getCancelationComment());

						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                    AssignBooking ab=(AssignBooking) arr[4];
                                            if(ab!=null && ab.getId()>0)
                                            {
                                                if(ab.getOperatorCode()!=null && ab.getOperatorCode().length()>0)
                                                {
                                                    brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                                   Operator op=operatorRepository.getOperatorByOperatorCode(ab.getOperatorCode());
                                                   if(op!=null && op.getId()>0 && op.getOperatorName()!=null)
                                                   {
                                                      brwo.setAssignorOperatorName(op.getOperatorName());
                                                   }
                                                }
                                                
                                                if(ab.getDriverCode()!=null && ab.getDriverCode().length()>0)
                                                {
                                                    brwo.setDriverCode(ab.getDriverCode());
                                                   Driver dr=driverRepository.getDriverByDriverCode(ab.getDriverCode());
                                                   if(dr!=null && dr.getId()>0 && dr.getName()!=null)
                                                   {
                                                      brwo.setDriverName(dr.getName());
                                                        brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                                   }
                                                }
                                            }
                                            GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);
					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			}else{
	            jsonobj.put("responsecode", 400);
	        jsonobj.put("message", "Limit should not be Zero or Negative.");
	        jsonobj.put("timestamp", new Date());
	        }

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String assignBookingInProgress(AssignBookingStatus abs, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			Driver d = driverRepository.getDriverByDriverCode(abs.getDriverCode());
			if (d != null && d.getId() > 0) {

                            Booking b = bookingDao.getBookingByRideCode(abs.getRideCode());
						if (b != null && b.getId() > 0) {
							
                                                    String passengerName="";
                                                    Passenger pgr=  passengerDao.getPassengerByPassengerCode(b.getPassengerCode());
                                                    if(pgr!=null && pgr.getId()>0)
                                                     {
                                                       passengerName=pgr.getPassengerName();
                                                     }
				AssignBooking ab = assignBookingRepository
						.getAssignBookingByRideCodeAndDriverCodeForAccepted(abs.getRideCode(), abs.getDriverCode());
				if (ab != null && ab.getId() > 0) {
				b.setBookingStatus(GigflexConstants.assignedBookingInProgressStatus);
							Booking bookingRes = bookingDao.save(b);
							
							if (bookingRes != null && bookingRes.getId() > 0) {	
                                        ab.setStatus(GigflexConstants.assignedBookingInProgressStatus);
					ab.setIpAddress(ip);
					ab.setDriverCode(abs.getDriverCode());
                                        ab.setLang(bookingRes.getPickLang());
                                        ab.setLat(bookingRes.getPickLat());
					AssignBooking abres = assignBookingRepository.save(ab);
					if (abres != null && abres.getId() > 0) {

                                                                String conDt="";
								String abOperatorCode = ab.getOperatorCode();
							    String bOperatorCode = b.getOperatorCode();
							    String toMail = "";
                                                            String contactNumber="";
						            String operatorCodes = null;
                                                            boolean SMSSt=true;
                                                            boolean MailST=true;
                                                            UserType utOtr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOperator);
                                                            
							    if(abOperatorCode != null && bOperatorCode != null ) {
							    	if(abOperatorCode.equals(bOperatorCode)) {
								    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

								    	toMail = operator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                            contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								    	}
								    	operatorCodes = abOperatorCode;
								    }else {
								    	Operator aboperator = operatorRepository.getOperatorByOperatorCode(abOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, mailNotiName);
								    	if(MailST && aboperator!=null && aboperator.getEmailId() != null && aboperator.getEmailId().length() > 0) {

								    	toMail = aboperator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, smsNotiName);
                                                                        if(SMSSt && aboperator!=null && aboperator.getContactNumber() != null && aboperator.getContactNumber().length() > 0 && aboperator.getCountryCode() != null && aboperator.getCountryCode().length() > 0) {

                                                                        contactNumber="+"+aboperator.getCountryCode()+aboperator.getContactNumber();
								    	}
								    	Operator boperator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && boperator!=null && boperator.getEmailId() != null && boperator.getEmailId().length() > 0) {
								    		if(toMail != null && toMail.length() > 0) {
								    	toMail += ","+boperator.getEmailId();
								    	}else {
									    	toMail = boperator.getEmailId();

								    	}
                                                                        }
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && boperator!=null && boperator.getContactNumber() != null && boperator.getContactNumber().length() > 0 && boperator.getCountryCode() != null && boperator.getCountryCode().length() > 0) {
								    		if(contactNumber != null && contactNumber.length() > 0) {
								    	
                                                                        contactNumber +=",+"+boperator.getCountryCode()+ boperator.getContactNumber();
								    	}else {
                                                                                contactNumber="+"+boperator.getCountryCode()+ boperator.getContactNumber();

								    	}
								    	}
								    	operatorCodes = abOperatorCode+","+bOperatorCode;
								    }
							    	
							    }else if(bOperatorCode != null){
							    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
							    	if(MailST && operator.getEmailId() != null && operator.getEmailId().length() > 0) {
							    	toMail = operator.getEmailId();
							    	}
                                                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                   contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								}
							    	operatorCodes = bOperatorCode;
							    }
                                                            
							   
								   
                                                                    String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                                    {
                                                                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                                    }                

                                                                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TimeZone);

                                                                    TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                                    if (tzd != null && tzd.getId() > 0) {

                                                                        String timezone = tzd.getTimeZoneName();
                                                                        if(timezone!=null && timezone.length()>0 )
                                                                        {
                                                                             Date pDate = b.getPickUpTime();
                                                                             pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                             conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                        }

                                                                    }         
								   String bodyContent = "Dear Operator " 
									+ ", <br><br>Assigned booking is in progress. Details are given below-<br><br>";
                                                                   if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                    {
                                                                     bodyContent+="Driver Name : "+d.getName()+"<br>";
                                                                    }
									bodyContent+="Passenger Name : "+passengerName+"<br>"+ "Pick-up Time : "
									+ conDt + "<br>" + "Pick-up Address : " + b.getPickUpAddress()
									+ "<br>" + "Drop-off Address : " + b.getDropOffAddress();
                                                                   
                                                                   String messageBody = "Dear Operator, " +"\n"
									+ "Assigned booking is in progress. Details are given below-";
                                                                   if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                    {
                                                                     messageBody+="\nDriver Name : "+d.getName();
                                                                    }
									messageBody+="\n Passenger Name : "+passengerName+"\n"+ "Pick-up Time : "
									+ conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
									+ "\n" + "Drop-off Address : " + b.getDropOffAddress();
									
							if(toMail != null && toMail.length() > 0) {
//                                                            byte[] encodedbody = Base64.getEncoder().encode(bodyContent.getBytes());
//                                                            String body = new String(encodedbody);
							String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
							Map<String, String> map = new HashMap<>();
							map.put("to", toMail);
							map.put("subject", subjectInPr);
							map.put("body", encodeURL);
							try {
                                                               
								RestTemplate restTemplate = new RestTemplate();
								ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL,
										String.class, map);
								String mailRes = response.getBody();
                                                                
                                                               

							} catch (Exception ex) {
								ex.printStackTrace();
							}
							   }
                                                        
                                                          try {
                                                                                if (contactNumber != null && !contactNumber.equals("")) {
                                                                                    String contactArray[] = contactNumber.split(",");
                                                                                    SendMessageAPI sendmessageapi = new SendMessageAPI();
                                                                                    for (int i = 0; i <contactArray.length; i++) {
                                                                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, contactArray[i], messageBody);
                                                                                        System.out.println("====messageToken For operators=====" + messageToken);
                                                                                    }
                                                                                }
                                                                            } catch (Exception e) {
                                                                                e.printStackTrace();
                                                                            }
							   
							   try {
								   if(operatorCodes != null && operatorCodes.length() > 0) {
									   String userCodes[] = operatorCodes.split(",");
									   for(String userCode : userCodes) {
										  if(userCode != null && userCode.length() > 0) {
											  Notification notification = new Notification();
											  
											  String bodyContentnoti = "Dear Operator" 
														+ ",Assigned booking is in progress. Details are given below-";
                                                                                          if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                                            {
                                                                                            bodyContentnoti+="Driver Name : "+d.getName()+",";
                                                                                            }
														bodyContentnoti+="Passenger Name : "+passengerName+","+ "Pick-up Time : "
														+ conDt + "," + "Pick-up Address : " + b.getPickUpAddress()
														+ "," + "Drop-off Address : " + b.getDropOffAddress();
											  shortMessage = "Assigned booking is in progress.";
											  
											  notification.setUserCode(userCode);
											  notification.setMessage(bodyContentnoti);
											  notification.setShortMessage(shortMessage);
											  notification.setRideCode(b.getRideCode());
											  notification.setIpAddress(ip);
											  notification.setIsRead(Boolean.FALSE);
											  
											  notificationService.saveNotification(notification);
                                                                                          //for push notification  
//                                                                                          PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
										  }
									   }
								   }
								   
							   }catch(Exception e){
								   e.printStackTrace();
							   }
							    

								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Assigned Booking is in Progress.");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(abres);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Failed");
							}
                                        } else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Failed");
					}

						} else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Booking Record Not Found");
						}
					
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Booking Record Not Found");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Driver does not exist.");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();

		}
		return res;
	}

	@Override
	public String getAllValidUnAssignedBookingByDriverCodeByPage(String driverCode,int page, int limit) {
		String res = "";
		try {
			
			JSONObject jsonobj = new JSONObject();
			if(limit > 0){
			Pageable pageableRequest = PageRequest.of(page, limit);
			Date curDT = new Date();
			
			Driver driver = driverRepository.getDriverByDriverCode(driverCode);
			String operatorCode = driver.getOperatorCode();
			
			List<Object> objlst1 = assignBookingRepository.getAllValidUnAssignedBookingByOperatorCode(curDT, GigflexConstants.assignedBookingStatus,GigflexConstants.assignedBookingPublishedStatus, GigflexConstants.assignedBookingRejectedStatus, operatorCode, driverCode);
			int count = objlst1.size();
			
			
			List<Object> objlst = assignBookingRepository.getAllValidUnAssignedBookingByOperatorCodeByPage(curDT, GigflexConstants.assignedBookingStatus,GigflexConstants.assignedBookingPublishedStatus, GigflexConstants.assignedBookingRejectedStatus, operatorCode, driverCode, pageableRequest);
			
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                                String organizationCode = driver.getOrganizationCode();
                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver , driverCode, GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TIMEFORMAT);
                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.CURRENCYSYMBOL);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TimeZone);

                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt="";
                                                
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                    }

                                                }   
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat); 
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                
						brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setIsPublished(data.getIsPublished());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date curdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (curdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
			}
			if (maplst != null && maplst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			}else{
	            jsonobj.put("responsecode", 400);
	        jsonobj.put("message", "Limit should not be Zero or Negative.");
	        jsonobj.put("timestamp", new Date());
	        }

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();

		}
		return res;
	}
 
	@Override
	public String getAllValidUnAssignedBookingByDriverCode(String driverCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Date curDT = new Date();
			Driver driver = driverRepository.getDriverByDriverCode(driverCode);
			String operatorCode = driver.getOperatorCode();
			List<Object> objlst = assignBookingRepository.getAllValidUnAssignedBookingByOperatorCode(curDT, GigflexConstants.assignedBookingStatus,GigflexConstants.assignedBookingPublishedStatus, GigflexConstants.assignedBookingRejectedStatus, operatorCode, driverCode);
	
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
                                                            
                                String organizationCode = driver.getOrganizationCode();
                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TIMEFORMAT);
                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.CURRENCYSYMBOL);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TimeZone);

                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt="";
			                       
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                    }

                                                }   
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                
						brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setIsPublished(data.getIsPublished());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date curdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (curdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
			}
			if (maplst != null && maplst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();

		}
		return res;
	}

	@Override
	public String getAcceptedBookingByDriverCode(String driverCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = assignBookingRepository.getAllAcceptedBookingByDriverCode(driverCode, GigflexConstants.assignedBookingAcceptedStatus, GigflexConstants.assignedBookingInProgressStatus, GigflexConstants.assignedBookingCompletedStatus);
			List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
			if (objlst != null && objlst.size() > 0) {
                                Driver driver = driverRepository.getDriverByDriverCode(driverCode);
                                String organizationCode = driver.getOrganizationCode();
                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TIMEFORMAT);
                                 String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.CURRENCYSYMBOL);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TimeZone);

                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {
						Booking data = (Booking) arr[0];
						Passenger passengerData = (Passenger) arr[5];
						BookingAllResponse brwo = new BookingAllResponse();
						
						String conDt="";
                                                
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                    }

                                                }   
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                
						brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());
                                                brwo.setCancelationComment(data.getCancelationComment());

						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                    AssignBooking ab=(AssignBooking) arr[4];
                                            if(ab!=null && ab.getId()>0)
                                            {
                                                if(ab.getOperatorCode()!=null && ab.getOperatorCode().length()>0)
                                                {
                                                    brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                                   Operator op=operatorRepository.getOperatorByOperatorCode(ab.getOperatorCode());
                                                   if(op!=null && op.getId()>0 && op.getOperatorName()!=null)
                                                   {
                                                      brwo.setAssignorOperatorName(op.getOperatorName());
                                                   }
                                                }
                                                
                                                if(ab.getDriverCode()!=null && ab.getDriverCode().length()>0)
                                                {
                                                    brwo.setDriverCode(ab.getDriverCode());
                                                   Driver dr=driverRepository.getDriverByDriverCode(ab.getDriverCode());
                                                   if(dr!=null && dr.getId()>0 && dr.getName()!=null)
                                                   {
                                                      brwo.setDriverName(dr.getName());
                                                       brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                                   }
                                                }
                                            }
                                            GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);
					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAcceptedBookingByDriverCodeByPage(String driverCode,String status,String stratDT,String endDT, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if(limit > 0){
			Pageable pageableRequest = PageRequest.of(page, limit);
			
                        String timezone=null;
                         Date sDT=null;
                         Date eDT=null;
                         
//                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneByDriverCode(driverCode);
                                Driver driver = driverRepository.getDriverByDriverCode(driverCode);
                                
                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driver.getDriverCode(), GigflexConstants.TimeZone);
                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                if (tzd != null && tzd.getTimeZoneName() != null) {
                                    timezone = tzd.getTimeZoneName();
                                    if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0 && timezone!=null)
                                   {
                                    stratDT=stratDT+" 00:00:00";
                                    endDT=endDT+" 00:00:00";        
                        
                                    //Date sd = GigflexDateUtil.getGMTtoLocationDate(sDT,timezone, GigflexConstants.dateFormatterForView);
                                    sDT = GigflexDateUtil.convertStringDateToGMT(stratDT, timezone, GigflexConstants.dateFormatterForSave);
                                    eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.dateFormatterForSave);
                                    if (sDT == null || eDT == null) {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                "Date conversion has been failed.");
                                        return derr.toString();
                                    }
                                    Calendar cal = Calendar.getInstance();
                                    cal.setTime(eDT);
                                    cal.add(Calendar.DATE, 1);
                                    eDT = cal.getTime();
                                  }
                                }
                        
                        
                        
                        
                        
                        
                        
		//	List<Object> objlst1 = assignBookingRepository.getAllAcceptedBookingByDriverCode(driverCode, GigflexConstants.assignedBookingAcceptedStatus, GigflexConstants.assignedBookingInProgressStatus, GigflexConstants.assignedBookingCompletedStatus);
			int count = 0;
			
//			List<Object> objlst = assignBookingRepository.getAllAcceptedBookingByDriverCode(driverCode, GigflexConstants.assignedBookingAcceptedStatus, GigflexConstants.assignedBookingInProgressStatus, GigflexConstants.assignedBookingCompletedStatus, pageableRequest);
//			
                        
                        List<Object> objlstCheck =null;
                         List<Object> objlstCheckSize =null;
			                        if(status.equalsIgnoreCase("all"))
			                        {
			                          if(sDT!=null && eDT!=null)
			                          {
			                        	  objlstCheck=assignBookingRepository.getAllBookingByDriverCodeWithFilter(driverCode, sDT, eDT,pageableRequest);  
                                                          objlstCheckSize=assignBookingRepository.getAllBookingByDriverCodeWithFilter(driverCode, sDT, eDT);  
			                          }
			                          else
			                          {
			                        	  objlstCheck=assignBookingRepository.getAllBookingByDriverCodeWithFilter(driverCode,pageableRequest);  
                                                          objlstCheckSize=assignBookingRepository.getAllBookingByDriverCodeWithFilter(driverCode);  
			                          }
			                        }
			                        else
			                        {
			                            if(sDT!=null && eDT!=null)
			                          {
			                            	objlstCheck=assignBookingRepository.getAllBookingByDriverCodeWithFilter(driverCode,status, sDT, eDT,pageableRequest);
                                                        objlstCheckSize=assignBookingRepository.getAllBookingByDriverCodeWithFilter(driverCode,status, sDT, eDT);
			                          }
			                            else
			                            {
			                            	objlstCheck=assignBookingRepository.getAllBookingByDriverCodeWithFilter(driverCode,status,pageableRequest);
                                                        objlstCheckSize=assignBookingRepository.getAllBookingByDriverCodeWithFilter(driverCode,status);
			                            }
			                        }
                        if(objlstCheckSize!=null)
                        {
                           count= objlstCheckSize.size();
                        }
                        
			List<BookingAllResponseWithFilter> maplst = new ArrayList<BookingAllResponseWithFilter>();
			if (objlstCheck != null && objlstCheck.size() > 0) {
                            
                            String organizationCode = driver.getOrganizationCode();
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TIMEFORMAT);
                            String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.CURRENCYSYMBOL);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TimeZone);

                            TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            
				for (int i = 0; i < objlstCheck.size(); i++) {
					Object[] arr = (Object[]) objlstCheck.get(i);
					if (arr.length >= 6) {
						Booking data = (Booking) arr[0];
						Passenger passengerData = (Passenger) arr[5];
						BookingAllResponseWithFilter brwo = new BookingAllResponseWithFilter();
						
						  String conDt="";
//                          Organization org = organizationDao.findByOrganizationCode(data.getOrganizationCode());
//                          if (org != null && org.getId() > 0) {
//                                String timezoneCode = org.getTimezone();
//                                TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            Date pDate = data.getPickUpTime();
                            Date curdt=new Date();
                              
                            if((curdt.equals(pDate) || curdt.after(pDate)) && data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingAcceptedStatus))
                            {
                                brwo.setIsStarted(Boolean.TRUE);
                            }
                            else
                            {
                                brwo.setIsStarted(Boolean.FALSE);
                            }
                            if( curdt.after(pDate) && data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingInProgressStatus))
                            {
                                 brwo.setIsComplete(Boolean.TRUE);
                            }
                            else
                            {
                                brwo.setIsComplete(Boolean.FALSE);
                            }
                              
                              
                              
//                              pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, tz.getTimeZoneName(), GigflexConstants.dateFormatterForView);
//                              conDt=GigflexDateUtil.converDateToString(pDate);
                              
                           

                           if (tz != null && tz.getId() > 0) {

                                timezone = tz.getTimeZoneName();
                                if(timezone!=null && timezone.length()>0 )
                                {
//                                         Date pDate = data.getPickUpTime();
                                     pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                     conDt = GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                }

                            }   
                              
                              
//                          }
                           
                                        brwo.setDateFormat(dateformat);
                                        brwo.setTimeFormat(timeformat);
                                        brwo.setBookingid(data.getBookingid());
                                        brwo.setId(data.getId());
                                        brwo.setRideCode(data.getRideCode());

                                        brwo.setPassengerName(passengerData.getPassengerName());
                                        brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                        brwo.setpCountryCode(passengerData.getpCountryCode());
                                        brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                        brwo.setsCountryCode(passengerData.getsCountryCode());
                                        brwo.setPassengerCode(passengerData.getPassengerCode());

                                        brwo.setPickUpTime(conDt);
                                        brwo.setPickLat(data.getPickLat());
                                        brwo.setPickLang(data.getPickLang());
                                        brwo.setPickUpAddress(data.getPickUpAddress());
                                        brwo.setDropLat(data.getDropLat());
                                        brwo.setDropLang(data.getDropLang());
                                        brwo.setDropOffAddress(data.getDropOffAddress());
                                        brwo.setAdditionalStopPage(data.getAdditionalStopPage());
                                        brwo.setVehicleCode(data.getVehicleCode());
                                        brwo.setNoOfPassengers(data.getNoOfPassengers());
                                        brwo.setNoOfBaggage(data.getNoOfBaggage());
                                        brwo.setAdditionalComment(data.getAdditionalComment());
                                        brwo.setCustomerFare(data.getCustomerFare());
                                        brwo.setCurrencySymbol(currencySymbol);
                                        brwo.setBookingStatus(data.getBookingStatus());
                                        brwo.setPaymentOption(data.getPaymentOption());
                                        brwo.setOrganizationCode(data.getOrganizationCode());
                                        brwo.setOperatorCode(data.getOperatorCode());
                                        brwo.setIsPublished(data.getIsPublished());
                                        brwo.setCancelationComment(data.getCancelationComment());
                                        brwo.setOrganizationName((String) arr[1]);
                                        brwo.setVehicleName((String) arr[2]);
                                        brwo.setOperatorName((String) arr[3]);
                                            AssignBooking ab=(AssignBooking) arr[4];
                                    if(ab!=null && ab.getId()>0)
                                    {
                                        if(ab.getOperatorCode()!=null && ab.getOperatorCode().length()>0)
                                        {
                                            brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                           Operator op=operatorRepository.getOperatorByOperatorCode(ab.getOperatorCode());
                                           if(op!=null && op.getId()>0 && op.getOperatorName()!=null)
                                           {
                                              brwo.setAssignorOperatorName(op.getOperatorName());
                                           }
                                        }

                                        if(ab.getDriverCode()!=null && ab.getDriverCode().length()>0)
                                        {
                                            brwo.setDriverCode(ab.getDriverCode());
                                           Driver dr=driverRepository.getDriverByDriverCode(ab.getDriverCode());
                                           if(dr!=null && dr.getId()>0 && dr.getName()!=null)
                                           {
                                              brwo.setDriverName(dr.getName());
                                                brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                              
                                           }
                                        }
                                    }
                                            
                                            if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date currentdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (currentdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                            GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);
					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			}else{
	            jsonobj.put("responsecode", 400);
	        jsonobj.put("message", "Limit should not be Zero or Negative.");
	        jsonobj.put("timestamp", new Date());
	        }

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateRideCurrentLocationByRideCode(String rideCode,
			RideLocationRequest rideLocReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (rideCode != null && rideCode.trim().length() > 0
					&& rideLocReq != null) {
				if (rideLocReq.getLang() != null
						&& rideLocReq.getLang().trim().length() > 0
						&& rideLocReq.getLat() != null
						&& rideLocReq.getLat().trim().length() > 0) {

//					boolean status1 = GigflexUtility
//							.checkLatLangFormat(rideLocReq.getLat().trim());
//					boolean status2 = GigflexUtility
//							.checkLatLangFormat(rideLocReq.getLang().trim());
//					if (status1 == true && status2 == true) {

						AssignBooking ab = assignBookingRepository
								.getAssignBookingByRideCode(rideCode.trim());
						if (ab != null && ab.getId() > 0) {

							if (ab.getStatus().equalsIgnoreCase(GigflexConstants.assignedBookingInProgressStatus)) {

								ab.setLat(rideLocReq.getLat().trim());
								ab.setLang(rideLocReq.getLang().trim());
								ab.setIpAddress(ip);

								AssignBooking abRes = assignBookingRepository
										.save(ab);

								if (abRes != null && abRes.getId() > 0) {

									// kafkaService.sendDriverDocumentForUpdate(ddRes);
									jsonobj.put("responsecode", 200);
									jsonobj.put("message",
											"Current Location has been updated");
									jsonobj.put("timestamp", new Date());
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj
											.writeValueAsString(abRes);
									jsonobj.put("data", new JSONObject(Detail));
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("message",
											"Current Location updation has been failed.");
									jsonobj.put("timestamp", new Date());
								}
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("message",
										"This Ride is not in progress.");
								jsonobj.put("timestamp", new Date());
							}

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Ride Code is not valid.");
							jsonobj.put("timestamp", new Date());
						}
//					} else {
//						jsonobj.put("responsecode", 400);
//						jsonobj.put("message",
//								"Lat and Lang should be in proper format.");
//						jsonobj.put("timestamp", new Date());
//					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Lat and Lang should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String getCurrentLocationByRideCode(String rideCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (rideCode != null && rideCode.trim().length() > 0) {
				Object objlst = assignBookingRepository
						.getCurrentLocationByRideCode(rideCode);
				if (objlst != null) {

					// List<BookingResponse> maplst = new
					// ArrayList<BookingResponse>();
					// if (objlst != null && objlst.size() > 0) {
					// for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst;
					if (arr.length >= 5) {

						AssignBookingResponse brwo = new AssignBookingResponse();

						AssignBooking data = (AssignBooking) arr[0];
						Booking b = (Booking) arr[1];
                                                Passenger passengerData = (Passenger) arr[4];
						if (data.getStatus()
								.equalsIgnoreCase(
										GigflexConstants.assignedBookingInProgressStatus)
								&& data.getLat() != null
								&& data.getLang() != null) {

                                                    
							brwo.setId(data.getId());
							brwo.setAssignBookingCode(data
									.getAssignBookingCode());
							brwo.setRideCode(data.getRideCode());
                                                        
							brwo.setPassengerName(passengerData.getPassengerName());
//                                                        brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
//                                                        brwo.setpCountryCode(passengerData.getpCountryCode());
//                                                        brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
//                                                        brwo.setsCountryCode(passengerData.getsCountryCode());
                                                        brwo.setPassengerCode(passengerData.getPassengerCode());
                                                        
							brwo.setDriverCode(data.getDriverCode());
							brwo.setName((String) arr[2]);
							brwo.setOperatorCode(b.getOperatorCode());
							brwo.setOperatorName((String) arr[3]);
							brwo.setStatus(data.getStatus());
							brwo.setComments(data.getComments());
							brwo.setLat(data.getLat());
							brwo.setLang(data.getLang());

							if(data.getOperatorCode() != null){
							brwo.setAssignorOperatorCode(data.getOperatorCode());
							Operator or = operatorRepository.getOperatorByOperatorCode(data.getOperatorCode());
							if(or != null && or.getId()>0){
								brwo.setAssignorOperatorName(or.getOperatorName());
							}
							}
							// maplst.add(brwo);
							AssignBookingResponse maplst = brwo;

							// }
							// }
							// }

							if (maplst != null) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("message", "Success");
								jsonobj.put("timestamp", new Date());
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(maplst);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("responsecode", 404);
								jsonobj.put("message", "Record Not Found");
								jsonobj.put("timestamp", new Date());
							}

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "This Ride is not yet started.");
							jsonobj.put("timestamp", new Date());
						}
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Ride Code is not valid.");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();

		}
		return res;
	}

    
        
        @Override
    public String getAllLatestBookingByDriverCodeWithFilterByPage(String driverCode, List<String> status, String stratDT, String endDT, int page, int limit) {
        
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            if (limit > 0) {
                Pageable pageableRequest = PageRequest.of(page, limit);

                List<String> orderLst = new ArrayList<String>();
                        orderLst.add(GigflexConstants.assignedBookingStatus);
                        orderLst.add(GigflexConstants.assignedBookingPublishedStatus);
                        orderLst.add(GigflexConstants.assignedBookingRejectedStatus);
                        orderLst.add(GigflexConstants.assignedBookingInProgressStatus);
                        orderLst.add(GigflexConstants.bookingStatus);
                        orderLst.add(GigflexConstants.assignedBookingAcceptedStatus);
                        orderLst.add(GigflexConstants.assignedBookingCompletedStatus);
                        orderLst.add(GigflexConstants.assignedBookingCancelledStatus);
                        orderLst.add(GigflexConstants.assignedBookingExpiredStatus);
                        
                
                
                String timezone = null;
                Date sDT = null;
                Date eDT = null;

//                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneByDriverCode(driverCode);
                Driver driver = driverRepository.getDriverByDriverCode(driverCode);
                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driver.getDriverCode(), GigflexConstants.TimeZone);
                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                
                if (tzd != null && tzd.getTimeZoneName() != null) {
                    timezone = tzd.getTimeZoneName();
                    if (stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0 && timezone != null) {
                        stratDT = stratDT + " 00:00:00";
                        endDT = endDT + " 00:00:00";

                        //Date sd = GigflexDateUtil.getGMTtoLocationDate(sDT,timezone, GigflexConstants.dateFormatterForView);
                        sDT = GigflexDateUtil.convertStringDateToGMT(stratDT, timezone, GigflexConstants.dateFormatterForSave);
                        eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.dateFormatterForSave);
                        if (sDT == null || eDT == null) {
                            GigflexResponse derr = new GigflexResponse(400, new Date(),
                                    "Date conversion has been failed.");
                            return derr.toString();
                        }
                        Calendar cal = Calendar.getInstance();
                        cal.setTime(eDT);
                        cal.add(Calendar.DATE, 1);
                        eDT = cal.getTime();
                    }
                }
                int count = 0;

                List<Object> objlstCheck = null;
                List<Object> objlstCheckSize = null;

                if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                    List<String> stlst = new ArrayList<String>();
                    stlst.add(GigflexConstants.assignedBookingStatus);
                    stlst.add(GigflexConstants.assignedBookingInProgressStatus);
                    stlst.add(GigflexConstants.assignedBookingAcceptedStatus);
                    stlst.add(GigflexConstants.assignedBookingRejectedStatus);
                    stlst.add(GigflexConstants.assignedBookingChangedStatus);
                    stlst.add(GigflexConstants.bookingStatus);
                    stlst.add(GigflexConstants.assignedBookingPublishedStatus);

                    status = stlst;
                }

                if (sDT != null && eDT != null) {
                    objlstCheck = assignBookingRepository.getAllLatestBookingByDriverCodeWithFilterByPage(driverCode, status, sDT, eDT, orderLst,pageableRequest);
                    objlstCheckSize = assignBookingRepository.getAllLatestBookingByDriverCodeWithFilterByPage(driverCode, status, sDT, eDT, orderLst);
                } else {
                    objlstCheck = assignBookingRepository.getAllLatestBookingByDriverCodeWithFilterByPage(driverCode, status, orderLst, pageableRequest);
                    objlstCheckSize = assignBookingRepository.getAllLatestBookingByDriverCodeWithFilterByPage(driverCode, status,orderLst);
                }

                if (objlstCheckSize != null) {
                    count = objlstCheckSize.size();
                }
                  int assignedBooking=0;
          List<Booking> bklist= assignBookingRepository.getAllBookingByDriverCodeWithStaus(driverCode, GigflexConstants.bookingStatus);
            if(bklist!=null)
            {
            assignedBooking = bklist.size();
            }
          
                List<BookingAllResponseWithFilter> maplst = new ArrayList<BookingAllResponseWithFilter>();
                if (objlstCheck != null && objlstCheck.size() > 0) {
                    
                    String organizationCode = driver.getOrganizationCode();
                    String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.DATEFORMAT);
                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TIMEFORMAT);
                     String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.CURRENCYSYMBOL);
                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                    {
                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                    }                

                    timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TimeZone);

                    TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    for (int i = 0; i < objlstCheck.size(); i++) {
                        Object[] arr = (Object[]) objlstCheck.get(i);
                        if (arr.length >= 6) {
                            Booking data = (Booking) arr[0];
                            Passenger passengerData = (Passenger) arr[5];
                            BookingAllResponseWithFilter brwo = new BookingAllResponseWithFilter();

                            String conDt = "";
//                            Organization org = organizationDao.findByOrganizationCode(data.getOrganizationCode());
//                            if (org != null && org.getId() > 0) {
//                                String timezoneCode = org.getTimezone();
//                                TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                
                               
                                
                                Date pDate = data.getPickUpTime();
                                Date curdt = new Date();
                                if ((curdt.equals(pDate) || curdt.after(pDate)) && data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingAcceptedStatus)) {
                                    brwo.setIsStarted(Boolean.TRUE);
                                } else {
                                    brwo.setIsStarted(Boolean.FALSE);
                                }
                                if (curdt.after(pDate) && data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingInProgressStatus)) {
                                    brwo.setIsComplete(Boolean.TRUE);
                                } else {
                                    brwo.setIsComplete(Boolean.FALSE);
                                }
//                                pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, tz.getTimeZoneName(), GigflexConstants.dateFormatterForView);
//                                conDt = GigflexDateUtil.converDateToString(pDate);
                                
                                
                                if (tz != null && tz.getId() > 0) {

                                    timezone = tz.getTimeZoneName();
                                    if(timezone!=null && timezone.length()>0 )
                                    {
//                                         Date pDate = data.getPickUpTime();
                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                         conDt = GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                    }

                                }   
//                            }
                            brwo.setDateFormat(dateformat);
                            brwo.setTimeFormat(timeformat);
                            brwo.setBookingid(data.getBookingid());
                            brwo.setId(data.getId());
                            brwo.setRideCode(data.getRideCode());
                            
                            brwo.setPassengerName(passengerData.getPassengerName());
                            brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                            brwo.setpCountryCode(passengerData.getpCountryCode());
                            brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                            brwo.setsCountryCode(passengerData.getsCountryCode());
                            brwo.setPassengerCode(passengerData.getPassengerCode());

                            brwo.setPickUpTime(conDt);
                            brwo.setPickLat(data.getPickLat());
                            brwo.setPickLang(data.getPickLang());
                            brwo.setPickUpAddress(data.getPickUpAddress());
                            brwo.setDropLat(data.getDropLat());
                            brwo.setDropLang(data.getDropLang());
                            brwo.setDropOffAddress(data.getDropOffAddress());
                            brwo.setAdditionalStopPage(data.getAdditionalStopPage());
                            brwo.setVehicleCode(data.getVehicleCode());
                            brwo.setNoOfPassengers(data.getNoOfPassengers());
                            brwo.setNoOfBaggage(data.getNoOfBaggage());
                            brwo.setAdditionalComment(data.getAdditionalComment());
                            brwo.setCustomerFare(data.getCustomerFare());
                            brwo.setCurrencySymbol(currencySymbol);
                            brwo.setBookingStatus(data.getBookingStatus());
                            brwo.setPaymentOption(data.getPaymentOption());
                            brwo.setOrganizationCode(data.getOrganizationCode());
                            brwo.setOperatorCode(data.getOperatorCode());
                            brwo.setIsPublished(data.getIsPublished());
                            brwo.setCancelationComment(data.getCancelationComment());
                            
                            List<Object> additionalChargesList = additionalchargesdao.getAdditionalchargesByRideCode(data.getRideCode());
                                
                            if(additionalChargesList != null && additionalChargesList.size() > 0)
                            {
                                List<AdditionalChargesResponse>  additionalChargesResList = new  ArrayList<AdditionalChargesResponse>();
                                for(int k= 0; k <additionalChargesList.size();k++)
                                {
                                     Object[] arrAddtionalCharges = (Object[]) additionalChargesList.get(k);

                                    if (arrAddtionalCharges.length >= 2) {

                                        AdditionalChargesResponse additionalChargesres = new AdditionalChargesResponse(); 
                                        AdditionalCharges additionalChargesdata = (AdditionalCharges) arrAddtionalCharges[0];
                                        String additionalFareypeCodeName = (String) arrAddtionalCharges[1];
                                        additionalChargesres.setAdditionalFareypeCode(additionalChargesdata.getAdditionalFareypeCode()); 
                                        additionalChargesres.setAdditionalFareypeCodeName(additionalFareypeCodeName);
                                        additionalChargesres.setAmmount(additionalChargesdata.getAmmount());
                                        additionalChargesres.setQuantity(additionalChargesdata.getQuantity());
                                        additionalChargesres.setCurrencySymbol(currencySymbol); 
                                        additionalChargesResList.add(additionalChargesres);
                                    }
                                }
                                brwo.setAdditionalChargesDetails(additionalChargesResList);
                            }
                            
                            
                            brwo.setOrganizationName((String) arr[1]);
                            brwo.setVehicleName((String) arr[2]);
                            brwo.setOperatorName((String) arr[3]);
                            AssignBooking ab = (AssignBooking) arr[4];
                            if (ab != null && ab.getId() > 0) {
                                if (ab.getOperatorCode() != null && ab.getOperatorCode().length() > 0) {
                                    brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                    Operator op = operatorRepository.getOperatorByOperatorCode(ab.getOperatorCode());
                                    if (op != null && op.getId() > 0 && op.getOperatorName() != null) {
                                        brwo.setAssignorOperatorName(op.getOperatorName());
                                    }
                                }

                                if (ab.getDriverCode() != null && ab.getDriverCode().length() > 0) {
                                    brwo.setDriverCode(ab.getDriverCode());
                                    Driver dr = driverRepository.getDriverByDriverCode(ab.getDriverCode());
                                    if (dr != null && dr.getId() > 0 && dr.getName() != null) {
                                        brwo.setDriverName(dr.getName());
                                        brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                    }
                                }
                            }
                            if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date currentdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (currentdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                            GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
                            maplst.add(brwo);
                        }
                    }
                    if (maplst.size() > 0) {
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(maplst);
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("count", count);
                        jsonobj.put("assignedBookingCount",assignedBooking);
                        jsonobj.put("data", new JSONArray(Detail));
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("assignedBookingCount",assignedBooking);
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Record Not Found");
                    jsonobj.put("assignedBookingCount",assignedBooking);
                    jsonobj.put("timestamp", new Date());
                }
            } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;

    }
    
        @Override
    public String getAllLatestBookingByDriverCodeWithFilterForMobile(String driverCode,List<String> status,String stratDT,String endDT)
    {
    
            
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
          

                List<String> orderLst = new ArrayList<String>();
                orderLst.add(GigflexConstants.assignedBookingStatus);
                orderLst.add(GigflexConstants.assignedBookingPublishedStatus);
                orderLst.add(GigflexConstants.assignedBookingRejectedStatus);
                orderLst.add(GigflexConstants.assignedBookingInProgressStatus);
                orderLst.add(GigflexConstants.bookingStatus);
                orderLst.add(GigflexConstants.assignedBookingAcceptedStatus);
                orderLst.add(GigflexConstants.assignedBookingCompletedStatus);
                orderLst.add(GigflexConstants.assignedBookingCancelledStatus);
                orderLst.add(GigflexConstants.assignedBookingExpiredStatus);
                        
                
                
                String timezone = null;
                Date sDT = null;
                Date eDT = null;

//                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneByDriverCode(driverCode);
                Driver driver = driverRepository.getDriverByDriverCode(driverCode);
                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driver.getDriverCode(), GigflexConstants.TimeZone);
                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                
                if (tzd != null && tzd.getTimeZoneName() != null) {
                    timezone = tzd.getTimeZoneName();
                    if (stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0 && timezone != null) {
                        stratDT = stratDT + " 00:00:00";
                        endDT = endDT + " 00:00:00";

                        //Date sd = GigflexDateUtil.getGMTtoLocationDate(sDT,timezone, GigflexConstants.dateFormatterForView);
                        sDT = GigflexDateUtil.convertStringDateToGMT(stratDT, timezone, GigflexConstants.dateFormatterForSave);
                        eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.dateFormatterForSave);
                        if (sDT == null || eDT == null) {
                            GigflexResponse derr = new GigflexResponse(400, new Date(),
                                    "Date conversion has been failed.");
                            return derr.toString();
                        }
                        Calendar cal = Calendar.getInstance();
                        cal.setTime(eDT);
                        cal.add(Calendar.DATE, 1);
                        eDT = cal.getTime();
                    }
                }
                
                List<Object> objlstCheck = null;

                if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                    List<String> stlst = new ArrayList<String>();
                    stlst.add(GigflexConstants.assignedBookingStatus);
                    stlst.add(GigflexConstants.assignedBookingInProgressStatus);
                    stlst.add(GigflexConstants.assignedBookingAcceptedStatus);
                    stlst.add(GigflexConstants.assignedBookingRejectedStatus);
                    stlst.add(GigflexConstants.assignedBookingChangedStatus);
                    stlst.add(GigflexConstants.bookingStatus);
                    stlst.add(GigflexConstants.assignedBookingPublishedStatus);

                    status = stlst;
                }

                if (sDT != null && eDT != null) {
                  //  objlstCheck = assignBookingRepository.getAllLatestBookingByDriverCodeWithFilterByPage(driverCode, status, sDT, eDT, orderLst,pageableRequest);
                    objlstCheck = assignBookingRepository.getAllLatestBookingByDriverCodeWithFilterforMobile(driverCode, status, sDT, eDT, orderLst);
                } else {
                  //  objlstCheck = assignBookingRepository.getAllLatestBookingByDriverCodeWithFilterByPage(driverCode, status, orderLst, pageableRequest);
                    objlstCheck = assignBookingRepository.getAllLatestBookingByDriverCodeWithFilterforMobile(driverCode, status,orderLst);
                }

//                if (objlstCheckSize != null) {
//                    count = objlstCheckSize.size();
//                }
                  int assignedBooking=0;
                  String startride="";
                  String dropoffaddress="";
                  String startridestatus="";
          List<Booking> bklist= assignBookingRepository.getAllBookingByDriverCodeWithStaus(driverCode, GigflexConstants.bookingStatus);
            if(bklist!=null)
            {
            assignedBooking = bklist.size();
            }
          
                List<BookingAllResponseWithFilterforMobile> maplst = new ArrayList<BookingAllResponseWithFilterforMobile>();
                if (objlstCheck != null && objlstCheck.size() > 0) {
                    
                    String organizationCode = driver.getOrganizationCode();
                    String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.DATEFORMAT);
                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TIMEFORMAT);
                     String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.CURRENCYSYMBOL);
                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                    {
                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                    }                

                    timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TimeZone);

                    TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    for (int i = 0; i < objlstCheck.size(); i++) {
                        Object[] arr = (Object[]) objlstCheck.get(i);
                        if (arr.length >= 2) {
                            Booking data = (Booking) arr[0];
                            
                            BookingAllResponseWithFilterforMobile brwo = new BookingAllResponseWithFilterforMobile();

                            String conDt = "";
                           
                                brwo.setCurrencySymbol(currencySymbol);
                                Date pDate = data.getPickUpTime();
                                Date curdt = new Date();
                                if ((curdt.equals(pDate) || curdt.after(pDate)) && data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingAcceptedStatus)) {
                                    brwo.setIsStarted(Boolean.TRUE);
                                    startride=data.getRideCode();
                                    startridestatus=data.getBookingStatus();
                                    dropoffaddress=data.getDropOffAddress();
                                } else {
                                    brwo.setIsStarted(Boolean.FALSE);
                                }
                                if (curdt.after(pDate) && data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingInProgressStatus)) {
                                   startride=data.getRideCode();
                                    startridestatus=data.getBookingStatus();
                                    dropoffaddress=data.getDropOffAddress();
                                    brwo.setIsComplete(Boolean.TRUE);
                                } else {
                                    brwo.setIsComplete(Boolean.FALSE);
                                }
//                                pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, tz.getTimeZoneName(), GigflexConstants.dateFormatterForView);
//                                conDt = GigflexDateUtil.converDateToString(pDate);
                                
                                
                                if (tz != null && tz.getId() > 0) {

                                    timezone = tz.getTimeZoneName();
                                    if(timezone!=null && timezone.length()>0 )
                                    {
//                                         Date pDate = data.getPickUpTime();
                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                         conDt = GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                    }

                                }   
//                            }
                           
                            brwo.setBookingid(data.getBookingid());
                            brwo.setId(data.getId());
                            brwo.setRideCode(data.getRideCode());
                            
                            if(arr[1]!=null)
                            {
                            brwo.setPassengerName((String)arr[1]);
                            }
                            brwo.setPickUpTime(conDt);
                            brwo.setPickUpTimeStamp(pDate);
                            brwo.setPickLat(data.getPickLat());
                            brwo.setPickLang(data.getPickLang());
                            brwo.setPickUpAddress(data.getPickUpAddress());
                            brwo.setDropLat(data.getDropLat());
                            brwo.setDropLang(data.getDropLang());
                            brwo.setDropOffAddress(data.getDropOffAddress());
                            
                            brwo.setBookingStatus(data.getBookingStatus());
                            
                            if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                            {
                                Date currentdt=new Date();
                                Date picdt=data.getPickUpTime();
                                long diff_curdt= (currentdt.getTime()/(60 * 1000));
                                long diff_picdt= (picdt.getTime()/(60 * 1000));
                                long diff = diff_picdt - diff_curdt;
                                if(diff>0 && diff<=60)
                                {
                                    brwo.setIsFocused(Boolean.TRUE);
                                }
                                else
                                {
                                    brwo.setIsFocused(Boolean.FALSE);
                                }
                            }
                            else
                            {
                               brwo.setIsFocused(Boolean.FALSE);
                            }
                          
                            maplst.add(brwo);
                        }
                    }
                    if (maplst.size() > 0) {
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(maplst);
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("assignedBookingCount",assignedBooking);
                        jsonobj.put("startride",startride);
                        jsonobj.put("startridestatus",startridestatus);
                        jsonobj.put("dropoffaddress",dropoffaddress);
                        jsonobj.put("data", new JSONArray(Detail));
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("assignedBookingCount",assignedBooking);
                        jsonobj.put("startride",startride);
                        jsonobj.put("startridestatus",startridestatus);
                        jsonobj.put("dropoffaddress",dropoffaddress);
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Record Not Found");
                    jsonobj.put("assignedBookingCount",assignedBooking);
                    jsonobj.put("startride",startride);
                        jsonobj.put("startridestatus",startridestatus);
                        jsonobj.put("dropoffaddress",dropoffaddress);
                    jsonobj.put("timestamp", new Date());
                }
            

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;
      
    
    }
    
     @Override
     public String getAllLatestBookingByDriverCodeWithFilterForMobileByPage(String driverCode,List<String> status,String stratDT,String endDT,int page, int limit)
     {
       
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
          
                if(limit > 0){
                       
                    
                    Pageable pageableRequest = PageRequest.of(page, limit);
                
                     
                List<String> orderLst = new ArrayList<String>();
                        orderLst.add(GigflexConstants.assignedBookingStatus);
                        orderLst.add(GigflexConstants.assignedBookingPublishedStatus);
                        orderLst.add(GigflexConstants.assignedBookingRejectedStatus);
                        orderLst.add(GigflexConstants.assignedBookingInProgressStatus);
                        orderLst.add(GigflexConstants.bookingStatus);
                        orderLst.add(GigflexConstants.assignedBookingAcceptedStatus);
                        orderLst.add(GigflexConstants.assignedBookingCompletedStatus);
                        orderLst.add(GigflexConstants.assignedBookingCancelledStatus);
                        orderLst.add(GigflexConstants.assignedBookingExpiredStatus);
                        
                
                
                String timezone = null;
                Date sDT = null;
                Date eDT = null;

//                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneByDriverCode(driverCode);
                Driver driver = driverRepository.getDriverByDriverCode(driverCode);
                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driver.getDriverCode(), GigflexConstants.TimeZone);
                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                
                if (tzd != null && tzd.getTimeZoneName() != null) {
                    timezone = tzd.getTimeZoneName();
                    if (stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0 && timezone != null) {
                        stratDT = stratDT + " 00:00:00";
                        endDT = endDT + " 00:00:00";

                        //Date sd = GigflexDateUtil.getGMTtoLocationDate(sDT,timezone, GigflexConstants.dateFormatterForView);
                        sDT = GigflexDateUtil.convertStringDateToGMT(stratDT, timezone, GigflexConstants.dateFormatterForSave);
                        eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.dateFormatterForSave);
                        if (sDT == null || eDT == null) {
                            GigflexResponse derr = new GigflexResponse(400, new Date(), "Date conversion has been failed.");
                            return derr.toString();
                        }
                        Calendar cal = Calendar.getInstance();
                        cal.setTime(eDT);
                        cal.add(Calendar.DATE, 1);
                        eDT = cal.getTime();
                    }
                }
                List<Object> objlstCheck = null;
                List<Object> objlstCheckSize = null;
                int count=0;
                int totalRecord=0;
                if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                    List<String> stlst = new ArrayList<String>();
                    stlst.add(GigflexConstants.assignedBookingStatus);
                    stlst.add(GigflexConstants.assignedBookingInProgressStatus);
                    stlst.add(GigflexConstants.assignedBookingAcceptedStatus);
                    stlst.add(GigflexConstants.assignedBookingRejectedStatus);
                    stlst.add(GigflexConstants.assignedBookingChangedStatus);
                    stlst.add(GigflexConstants.bookingStatus);
                    stlst.add(GigflexConstants.assignedBookingPublishedStatus);

                    status = stlst;
                }

                if (sDT != null && eDT != null) {
                    objlstCheckSize = assignBookingRepository.getAllLatestBookingByDriverCodeWithFilterforMobile(driverCode, status, sDT, eDT, orderLst);
                    objlstCheck = assignBookingRepository.getAllLatestBookingByDriverCodeWithFilterforMobile(driverCode, status, sDT, eDT, orderLst,pageableRequest);
                } else {
                    objlstCheckSize = assignBookingRepository.getAllLatestBookingByDriverCodeWithFilterforMobile(driverCode, status, orderLst);
                    objlstCheck = assignBookingRepository.getAllLatestBookingByDriverCodeWithFilterforMobile(driverCode, status,orderLst,pageableRequest);
                }

                if (objlstCheckSize != null) {
                  count = objlstCheckSize.size();
                }
                  int assignedBooking=0;
                  String startride="";
                  String dropoffaddress="";
                  String startridestatus="";
          List<Booking> bklist= assignBookingRepository.getAllBookingByDriverCodeWithStaus(driverCode, GigflexConstants.bookingStatus);
            if(bklist!=null)
            {
            assignedBooking = bklist.size();
            }
          
                List<BookingAllResponseWithFilterforMobile> maplst = new ArrayList<BookingAllResponseWithFilterforMobile>();
                if (objlstCheck != null && objlstCheck.size() > 0) {
                    
                    String organizationCode = driver.getOrganizationCode();
                    String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.DATEFORMAT);
                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TIMEFORMAT);
                     String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.CURRENCYSYMBOL);
                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                    {
                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                    }                

                    timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TimeZone);

                    TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    for (int i = 0; i < objlstCheck.size(); i++) {
                        Object[] arr = (Object[]) objlstCheck.get(i);
                        if (arr.length >= 2) {
                            Booking data = (Booking) arr[0];
                            
                            BookingAllResponseWithFilterforMobile brwo = new BookingAllResponseWithFilterforMobile();

                            String conDt = "";
                           
                                brwo.setCurrencySymbol(currencySymbol);
                                Date pDate = data.getPickUpTime();
                                Date curdt = new Date();
                                if ((curdt.equals(pDate) || curdt.after(pDate)) && data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingAcceptedStatus)) {
                                    brwo.setIsStarted(Boolean.TRUE);
                                    startride=data.getRideCode();
                                    startridestatus=data.getBookingStatus();
                                    dropoffaddress=data.getDropOffAddress();
                                } else {
                                    startride=data.getRideCode();
                                    startridestatus=data.getBookingStatus();
                                    dropoffaddress=data.getDropOffAddress();
                                    brwo.setIsStarted(Boolean.FALSE);
                                }
                                if (curdt.after(pDate) && data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingInProgressStatus)) {
                                    brwo.setIsComplete(Boolean.TRUE);
                                } else {
                                    brwo.setIsComplete(Boolean.FALSE);
                                }
//                                pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, tz.getTimeZoneName(), GigflexConstants.dateFormatterForView);
//                                conDt = GigflexDateUtil.converDateToString(pDate);
                                
                                
                                if (tz != null && tz.getId() > 0) {

                                    timezone = tz.getTimeZoneName();
                                    if(timezone!=null && timezone.length()>0 )
                                    {
//                                         Date pDate = data.getPickUpTime();
                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                         conDt = GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                    }

                                }   
//                            }
                           
                            brwo.setBookingid(data.getBookingid());
                            brwo.setId(data.getId());
                            brwo.setRideCode(data.getRideCode());
                            
                            
                            if(arr[1]!=null)
                            {
                            brwo.setPassengerName((String)arr[1]);
                            }
                            brwo.setPickUpTime(conDt);
                            brwo.setPickUpTimeStamp(pDate);
                            brwo.setPickLat(data.getPickLat());
                            brwo.setPickLang(data.getPickLang());
                            brwo.setPickUpAddress(data.getPickUpAddress());
                            brwo.setDropLat(data.getDropLat());
                            brwo.setDropLang(data.getDropLang());
                            brwo.setDropOffAddress(data.getDropOffAddress());
                            
                            brwo.setBookingStatus(data.getBookingStatus());
                            
                            if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date currentdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (currentdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                              GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
                            maplst.add(brwo);
                        }
                    }
                    if (maplst.size() > 0) {
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(maplst);
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("count", count);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("assignedBookingCount",assignedBooking);
                        jsonobj.put("startride",startride);
                        jsonobj.put("startridestatus",startridestatus);
                        jsonobj.put("dropoffaddress",dropoffaddress);
                        jsonobj.put("data", new JSONArray(Detail));
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("assignedBookingCount",assignedBooking);
                        jsonobj.put("startride",startride);
                        jsonobj.put("startridestatus",startridestatus);
                        jsonobj.put("dropoffaddress",dropoffaddress);
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Record Not Found");
                    jsonobj.put("assignedBookingCount",assignedBooking);
                    jsonobj.put("startride",startride);
                        jsonobj.put("startridestatus",startridestatus);
                        jsonobj.put("dropoffaddress",dropoffaddress);
                    jsonobj.put("timestamp", new Date());
                }
            
 } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;
      
     }
    

    @Override
    public String getAllValidUnAssignedBookingExceptCreatorOrganizationByPage(String organizationCode, int page, int limit) {
        
       
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if(limit > 0){
                        Pageable pageableRequest = PageRequest.of(page, limit);
                        Date curDT = new Date();
            
			List<Object> objlst1 = assignBookingRepository.getAllValidUnAssignedBookingExceptCreatorOrganization(curDT,GigflexConstants.assignedBookingStatus,GigflexConstants.assignedBookingPublishedStatus,organizationCode);
			int count = objlst1.size();
			
			
			List<Object> objlst = assignBookingRepository.getAllValidUnAssignedBookingExceptCreatorOrganizationByPage(curDT,GigflexConstants.assignedBookingStatus,GigflexConstants.assignedBookingPublishedStatus,organizationCode,pageableRequest);
			
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);

                                TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);

				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt="";
                                                
                                                if (tz != null && tz.getId() > 0) {

                                                     String timezone = tz.getTimeZoneName();
                                                     if(timezone!=null && timezone.length()>0 )
                                                     {
                                                          Date pDate = data.getPickUpTime();
                                                          pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                          conDt = GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                     }

                                                 }   
                                     
                                     
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                
						brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setIsPublished(data.getIsPublished());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date curdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (curdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
			}
			if (maplst != null && maplst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			}else{
	            jsonobj.put("responsecode", 400);
	        jsonobj.put("message", "Limit should not be Zero or Negative.");
	        jsonobj.put("timestamp", new Date());
	        }

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();

		}
		return res;
	
    
    }

    @Override
    public String saveRideCurrentLocation(TrackingRideLocationReqest trackingRideLocReq, String ip) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (trackingRideLocReq != null 
					) {
				if (trackingRideLocReq.getLang() != null
                                    && trackingRideLocReq.getLang().trim().length() > 0
                                    && trackingRideLocReq.getLat() != null
                                    && trackingRideLocReq.getLat().trim().length() > 0 
                                    && trackingRideLocReq.getRideCode() != null && trackingRideLocReq.getRideCode().trim().length() > 0) {


                                    TrackingRideStatus trackingRideStatus = new TrackingRideStatus();
                                    
                                    trackingRideStatus.setLat(trackingRideLocReq.getLat().trim());
                                    trackingRideStatus.setLang(trackingRideLocReq.getLang().trim());
                                    trackingRideStatus.setIpAddress(ip);
                                    trackingRideStatus.setRideCode(trackingRideLocReq.getRideCode()); 

                                    TrackingRideStatus trackRideStatusRes = trackingRideRepository.save(trackingRideStatus);
                                    
                                    
                                   

                                    if (trackRideStatusRes != null && trackRideStatusRes.getId() > 0) {
                                        
                                            Booking bookingRes = bookingDao.getBookingByRideCode(trackRideStatusRes.getRideCode());
                                            boolean isNearestDistanceFromFropOff = false;
                                            if(bookingRes != null && bookingRes.getId() > 0) 
                                            {                                                                                               
                                                double bookingLat = Double.parseDouble(bookingRes.getDropLat());
                                                double bookingLan = Double.parseDouble(bookingRes.getDropLang());
                                                double trackLat = Double.parseDouble(trackRideStatusRes.getLat());
                                                double trackLan = Double.parseDouble(trackRideStatusRes.getLang());
                                                char unit = unitMiles;                                         
                                                double distance = distance(bookingLat,bookingLan,trackLat,trackLan,unit);   
                                                
                                                if(distance <= GigflexConstants.NEAREST_DISTANCE_MILES)
                                                {
                                                   isNearestDistanceFromFropOff = true;
                                                }
                                                else
                                                {
                                                    isNearestDistanceFromFropOff = false;
                                                }
                                            }
                                           

                                            TrackingRideLocationResponse trackRes= new TrackingRideLocationResponse();
                                            trackRes.setLang(trackRideStatusRes.getLang());
                                            trackRes.setLat(trackRideStatusRes.getLat());
                                            trackRes.setRideCode(trackRideStatusRes.getRideCode()); 
                                            trackRes.setTrackingRideStatusCode(trackRideStatusRes.getTrackingRideStatusCode()); 
                                            trackRes.setIsNearestDistanceFromFropOff(isNearestDistanceFromFropOff); 
                                            
                                            jsonobj.put("responsecode", 200);
                                            jsonobj.put("message",
                                                            "Current Location has been added");
                                            jsonobj.put("timestamp", new Date());
                                            ObjectMapper mapperObj = new ObjectMapper();
                                            String Detail = mapperObj
                                                            .writeValueAsString(trackRes);
                                            jsonobj.put("data", new JSONObject(Detail));
                                    } else {
                                            jsonobj.put("responsecode", 400);
                                            jsonobj.put("message",
                                                            "Current Location add has been failed.");
                                            jsonobj.put("timestamp", new Date());
                                    }						
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Lat ,Lang and rideCode should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

    }

    @Override
    public String getAllTrackingRideLocation() {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<TrackingRideStatus> trackingRideStatusList = trackingRideRepository.getAllTrackingRideLocation();
                                                
			if (trackingRideStatusList != null && trackingRideStatusList.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(trackingRideStatusList);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   java.util.logging.Logger.getLogger(DriverTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
                }
		return res;
         }

    @Override
    public String getTrackingLastRideLocationByRideCode(String rideCode) {
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<TrackingRideStatus> trackingRideStatusList = trackingRideRepository.getTrackingRideLocationByRideCode(rideCode);
                        
                                                
			if (trackingRideStatusList != null && trackingRideStatusList.size() > 0) {
                            
                            
                                TrackingRideStatus trackingRideStatusRes = trackingRideStatusList.get(0) ;
                                
                                Booking bookingRes = bookingDao.getBookingByRideCode(trackingRideStatusRes.getRideCode());
                                boolean isNearestDistanceFromFropOff = false;
                                if(bookingRes != null && bookingRes.getId() > 0) 
                                {                                                                                               
                                    double bookingLat = Double.parseDouble(bookingRes.getDropLat());
                                    double bookingLan = Double.parseDouble(bookingRes.getDropLang());
                                    double trackLat = Double.parseDouble(trackingRideStatusRes.getLat());
                                    double trackLan = Double.parseDouble(trackingRideStatusRes.getLang());
                                    char unit = unitMiles;                                         
                                    double distance = distance(bookingLat,bookingLan,trackLat,trackLan,unit);   

                                    if(distance <= GigflexConstants.NEAREST_DISTANCE_MILES)
                                    {
                                       isNearestDistanceFromFropOff = true;
                                    }
                                    else
                                    {
                                        isNearestDistanceFromFropOff = false;
                                    }
                                }
                                           
                                TrackingRideLocationResponse trackRes= new TrackingRideLocationResponse();
                                trackRes.setLang(trackingRideStatusRes.getLang());
                                trackRes.setLat(trackingRideStatusRes.getLat());
                                trackRes.setRideCode(trackingRideStatusRes.getRideCode()); 
                                trackRes.setTrackingRideStatusCode(trackingRideStatusRes.getTrackingRideStatusCode()); 
                                trackRes.setIsNearestDistanceFromFropOff(isNearestDistanceFromFropOff); 
                            
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(trackRes);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   java.util.logging.Logger.getLogger(DriverTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                   GigflexResponse derr = new GigflexResponse(500, new Date(),"Exception occurred.");
		   res = derr.toString();
                }
		return res;
    }

    private double distance(double lat1, double lon1, double lat2, double lon2, char unit) {
        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;

        if (unit == 'K') {
          dist = dist * 1.609344;
        }       
        return (dist);
    }
    
     private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }
     
    private double rad2deg(double rad) {
         return (rad * 180.0 / Math.PI);
    }
    
    
   public String getAllTrackingRideLocationByRideCode(String rideCode)
   {
     String res="";
      try{
          JSONObject jsonobj = new JSONObject();
          List<TrackingRideStatus>trackingRiderList=  trackingRideRepository.getallTrackingRideLocationByRideCode(rideCode);
          if(trackingRiderList!=null && trackingRiderList.size()>0)
          {
           jsonobj.put("responsecode", 200);
	   jsonobj.put("message", "Success");
	   jsonobj.put("timestamp", new Date());
	   ObjectMapper mapperObj = new ObjectMapper();
	   String Detail = mapperObj.writeValueAsString(trackingRiderList);
	   jsonobj.put("data", new JSONArray(Detail));
          }else
          {
          jsonobj.put("responsecode", 404);
	  jsonobj.put("message", "Record Not Found.");
	  jsonobj.put("timestamp", new Date());
          }
         res= jsonobj.toString();
         }catch(JSONException | JsonProcessingException ex)
         {
          GigflexResponse derr = new GigflexResponse(500, new Date(),"JSON parsing exception occurred.");
			res = derr.toString();
         }catch(Exception ex)
         {
          java.util.logging.Logger.getLogger(DriverTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                   GigflexResponse derr = new GigflexResponse(500, new Date(),"Exception occurred.");
		   res = derr.toString();
         }
      return res;
   }
    
}
