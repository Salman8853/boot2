package com.gigflex.prototype.microservices.booking.service;

import java.util.Date;
import java.util.List;

import com.gigflex.prototype.microservices.booking.dtob.BookingCompletedUpdateResponse;
import com.gigflex.prototype.microservices.booking.dtob.BookingRequest;
import com.gigflex.prototype.microservices.booking.dtob.BookingUpdateRequest;

public interface BookingService {

	public String findAllBooking();

	public String getAllBookingByPage(int page, int limit);

	public String getBookingByBookingStatus(String bookingStatus);

	public String getBookingByBookingStatusByPage(String bookingStatus, int page, int limit);

	public String saveBooking(BookingRequest bookingReq, String ip);

	public String getBookingByBookingCode(String rideCode);

	public String getBookingByRideCodeWithName(String rideCode);
        
        public String getBookingByBookingID(Long bookingid);

	public String findBookingById(Long id);

	public String updateBookingById(Long id, BookingUpdateRequest bookingReq, String ip);

	public String getBookingByOrgCode(String organizationCode);

	public String getBookingByOrgCodeByPage(String organizationCode, int page, int limit);

	public String softDeleteByBookingCode(String rideCode);

	public String softMultipleDeleteByBookingCode(List<String> rideCodeList);

	public String search(String search);

	public String bookingPublishRequest(Boolean isPublished, String ridecode, String ip);

	public String assignBookingCompleted(String rideCode, BookingCompletedUpdateResponse bcres, String ip);
	
	public String getBookingByOperatorCode(String operatorCode);

	public String getBookingByOperatorCodeByPage(String operatorCode, int page, int limit);

	public String getAllBookingByDateByPage(Date fromDT,Date toDT,int page, int limit);
	
	public String getAllBookingByDate(Date fromDT,Date toDT);
	
	public String getAllAcceptedBookingByDateByPage(Date fromDT,Date toDT,int page, int limit);
	
	public String getAllAcceptedBookingByDate(Date fromDT,Date toDT);
        
        public String  getAllBookingByOperatorCodeWithFilterByPage(String operatorCode,String status,String stratDT,String endDT,int page, int limit);

        public String  getAllLatestBookingByOperatorCodeWithFilterByPage(String operatorCode,List<String> status,String stratDT,String endDT,int page, int limit);

        public String  getAllLatestBookingByOrganizationCodeWithFilterByPage(String organizationCode,List<String> status,String stratDT,String endDT,int page, int limit);

        public String getEligibleDriverListByRideCode(String rideCode,String operatorCode);
        
        public String validatePassangerQuantity( String vehicleType, Long noofPassangers);
            
        public String validateBaggagesQuantity(String vehicleType,Long noOfBaggages);
        
        public String getFareByRideCode( String rideCode);
        
        public String getBookingDetailByrideCodeforMobile(String rideCode);
        

}
