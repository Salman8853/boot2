package com.gigflex.prototype.microservices.documentmapping.dtob;




public class DriverDocResponse {

	private Long id;

	private String driverDocumentCode;

	private String driverCode;

	private String documentCode;
	
   

	private String docValue;

	private String docExpiration;

//	private String documentType;
	private String documentName;

	private String driverName;
	
	private String dateFormat ;
        private String timeFormat;
	

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDriverDocumentCode() {
		return driverDocumentCode;
	}

	public void setDriverDocumentCode(String driverDocumentCode) {
		this.driverDocumentCode = driverDocumentCode;
	}

	public String getDriverCode() {
		return driverCode;
	}

	public void setDriverCode(String driverCode) {
		this.driverCode = driverCode;
	}

	public String getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}
	
	
	public String getDocValue() {
		return docValue;
	}

	public void setDocValue(String docValue) {
		this.docValue = docValue;
	}

    public String getDocExpiration() {
        return docExpiration;
    }

    public void setDocExpiration(String docExpiration) {
        this.docExpiration = docExpiration;
    }

	

//	public String getDocumentType() {
//		return documentType;
//	}
//
//	public void setDocumentType(String documentType) {
//		this.documentType = documentType;
//	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

        public String getDateFormat() {
            return dateFormat;
        }

        public void setDateFormat(String dateFormat) {
            this.dateFormat = dateFormat;
        }

        public String getTimeFormat() {
            return timeFormat;
        }

        public void setTimeFormat(String timeFormat) {
            this.timeFormat = timeFormat;
        }
        
        

}
