package com.gigflex.prototype.microservices.documenttypedetail.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetail;

public interface DocumentTypeDetailRepository extends JpaRepository<DocumentTypeDetail, Long>,JpaSpecificationExecutor<DocumentTypeDetail>{
	
	@Query("SELECT d,u.userTypeName FROM DocumentTypeDetail d,UserType u WHERE d.isDeleted != TRUE AND d.userTypeCode = u.userTypeCode")
	public List<Object> getAllDocumentTypeDetail();
        
        @Query("SELECT d,u.userTypeName FROM DocumentTypeDetail d,UserType u WHERE d.isDeleted != TRUE AND d.userTypeCode = u.userTypeCode AND d.userTypeCode=:userTypeCode")
	public List<Object> getAllDocumentTypeDetailByUserTypeCode(@Param("userTypeCode") String userTypeCode);
	
    	@Query("SELECT d,u.userTypeName FROM DocumentTypeDetail d,UserType u WHERE d.isDeleted != TRUE AND d.userTypeCode = u.userTypeCode")
	public List<Object> getAllDocumentTypeDetail(Pageable pageableRequest);
        
        @Query("SELECT d,u.userTypeName FROM DocumentTypeDetail d,UserType u WHERE d.isDeleted != TRUE AND d.userTypeCode = u.userTypeCode AND d.userTypeCode=:userTypeCode")
	public List<Object> getAllDocumentTypeDetailByUserTypeCode(@Param("userTypeCode") String userTypeCode,Pageable pageableRequest);
	
	@Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE AND d.documentCode = :documentCode")
	public DocumentTypeDetail getDocumentTypeDetailByDocumentCode(@Param("documentCode") String documentCode);
	
    @Query("SELECT d,u.userTypeName FROM DocumentTypeDetail d,UserType u WHERE d.isDeleted != TRUE AND d.userTypeCode = u.userTypeCode AND d.documentCode=:documentCode")
	public Object getDocumentTypeDetailByDocumentCodeWithName(@Param("documentCode") String documentCode);
	
	@Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE AND d.id = :id")
	public DocumentTypeDetail getDocumentTypeDetailById(@Param("id") Long id);
	
//	@Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE AND d.documentType = :documentType")
//	public DocumentTypeDetail getDocumentTypeDetailByDocumentType(@Param("documentType") String documentType);
	
        @Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE AND d.documentName = :documentName AND d.documentTypeCode = :documentTypeCode AND d.userTypeCode=:userTypeCode")
	public DocumentTypeDetail getDocumentTypeDetailByDocumentTypeandUserType(@Param("documentName") String documentName,@Param("documentTypeCode") String documentTypeCode, @Param("userTypeCode") String userTypeCode);
	
//	@Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE AND d.id != :id AND d.documentType = :documentType")
//	public DocumentTypeDetail getDocumentTypeDetailByIdDocumentType(@Param("id") Long id,@Param("documentType") String documentType);
        
        @Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE AND d.id != :id AND d.documentName = :documentName AND d.documentTypeCode = :documentTypeCode AND d.userTypeCode=:userTypeCode")
	public DocumentTypeDetail getDocumentTypeDetailByIdDocumentTypeandUserType(@Param("id") Long id,@Param("documentName") String documentName,@Param("documentTypeCode") String documentTypeCode, @Param("userTypeCode") String userTypeCode);

        
        @Query("SELECT d,u.userTypeName FROM DocumentTypeDetail d,UserType u WHERE d.isDeleted != TRUE AND d.userTypeCode = u.userTypeCode AND d.documentTypeCode=:documentTypeCode")
    	public List<Object> getAllDocumentTypeDetailByDocumentTypeCode(@Param("documentTypeCode") String documentTypeCode);

        @Query("SELECT d,u.userTypeName FROM DocumentTypeDetail d,UserType u WHERE d.isDeleted != TRUE AND d.userTypeCode = u.userTypeCode AND d.documentTypeCode=:documentTypeCode")
    	public List<Object> getAllDocumentTypeDetailByDocumentTypeCode(@Param("documentTypeCode") String documentTypeCode,Pageable pageableRequest);
        
        @Query("SELECT b FROM DriverDocument a, DocumentTypeDetail b WHERE a.isDeleted != TRUE AND b.documentCode = a.documentCode AND a.driverCode = :driverCode")
         public DocumentTypeDetail getDocumentTypedetailBydriverCode(@Param("driverCode")String driverCode);
}
