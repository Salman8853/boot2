/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.setting.service.impl;

import com.gigflex.prototype.microservices.setting.repository.SettingRepository;
import com.gigflex.prototype.microservices.setting.service.SettingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author nirbhay.p
 */
@Service
public class SettingServiceImpl implements SettingService{

    @Autowired
    SettingRepository settingRepository;
    
    @Override
    public String getSettinValue(String name) {
       String res=null;
       res=settingRepository.getValueByName(name);
       return res;
    }

   
}
