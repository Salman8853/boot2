/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.dtob;

import java.util.List;

/**
 *
 * @author m.salman
 */
public class DriverFullDetailRes {
    private String langauge;
    private String dob;
    private String emergencyContectNo;
    private String contectNo;
   private String name;
    private String address;
    private String city;
    private String postCode;
    private String country;
      private String image;
      private String email;
      private boolean status;
    private String latitude;
    private String longitude;
    private List<DriverDocsResponse> ddList;

    public String getLangauge() {
        return langauge;
    }

    public void setLangauge(String langauge) {
        this.langauge = langauge;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getEmergencyContectNo() {
        return emergencyContectNo;
    }

    public void setEmergencyContectNo(String emergencyContectNo) {
        this.emergencyContectNo = emergencyContectNo;
    }

    public String getContectNo() {
        return contectNo;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public void setContectNo(String contectNo) {
        this.contectNo = contectNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

  

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public List<DriverDocsResponse> getDdList() {
        return ddList;
    }

    public void setDdList(List<DriverDocsResponse> ddList) {
        this.ddList = ddList;
    }
    
    
}
