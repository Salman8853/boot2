/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.dtob;

import javax.persistence.Column;

/**
 *
 * @author nirbhay.p
 */
public class OperatorDocumentRequest {
    
    private String operatorCode;
    
    private String documentCode;
    
    private String docValue;
    
    private String docExpiration;


    public String getOperatorCode() {
        return operatorCode;
    }

    public void setOperatorCode(String operatorCode) {
        this.operatorCode = operatorCode;
    }

       

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getDocValue() {
        return docValue;
    }

    public void setDocValue(String docValue) {
        this.docValue = docValue;
    }

    public String getDocExpiration() {
        return docExpiration;
    }

    public void setDocExpiration(String docExpiration) {
        this.docExpiration = docExpiration;
    }
    
    
}
