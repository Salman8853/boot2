package com.gigflex.prototype.microservices.documentvalidationmapping.service;

import java.util.List;

import com.gigflex.prototype.microservices.documentvalidationmapping.dtob.DocumentValidationMappingRequest;


public interface DocumentValidationService {
	
	public String getAllDocumentValidationMapping();
	public String getDocumentValidationMappingById(Long id);
	public String getDocumentValidationMappingByDocumentValidationCode(String documentValidationCode);
	public String saveNewDocumentValidationMapping(DocumentValidationMappingRequest documentValidationMappingReq, String ip);
	public String updateDocumentValidationMappingById( Long id,DocumentValidationMappingRequest documentValidationMappingReq, String ip);
	public String softDeleteByDocumentValidationCode(String documentValidationCode);
    public String softMultipleDeleteByDocumentValidationCode(List<String> documentValidationCodeList);
    public String getAllDocumentValidationMappingByPgae(int page, int limit);
    public String search(String search);
    public String getDocumentValidationByDocumentCode(String documentCode);
    public String getDocumentValidationByDocumentCode(String documentCode,int page, int limit);
    public String getDocumentValidationByValidationCode(String validationCode);
    public String getDocumentValidationByValidationCode(String validationCode,int page, int limit);

    

    


}
