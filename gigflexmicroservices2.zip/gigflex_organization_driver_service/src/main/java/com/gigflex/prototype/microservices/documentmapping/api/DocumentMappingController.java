/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.api;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocumentRequest;
import com.gigflex.prototype.microservices.documentmapping.dtob.OperatorDocumentRequest;
import com.gigflex.prototype.microservices.documentmapping.repository.DriverDocumentRepository;
import com.gigflex.prototype.microservices.documentmapping.repository.OperatorDocumentRepository;
import com.gigflex.prototype.microservices.documentmapping.service.DocumentUploadService;
import com.gigflex.prototype.microservices.documentmapping.service.DriverDocumentService;
import com.gigflex.prototype.microservices.documentmapping.service.OperatorDocumentService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.TokenUtility;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

/**
 *
 * @author nirbhay.p
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class DocumentMappingController {
    
    @Autowired
    DriverDocumentService driverDocumentService;
    
    @Autowired
    DocumentUploadService documentUploadService;
    
    @Autowired
    OperatorDocumentService operatorDocumentService;
    @Autowired
    DriverDocumentRepository driverDocumentRepository;
    @Autowired   
    OperatorDocumentRepository operatorDocumentRepository;
    
                    @Autowired
        KafkaService kafkaService;
     @Autowired
        TokenUtility tokenutility;
        @GetMapping("/getAllDriverDocument")
	public String getAllDriverDocument() {
		return driverDocumentService.getAllDriverDocument();
	}
        
        @GetMapping("/getAllDriverDocumentByDriverCode/{driverCode}")
	public String getAllDriverDocumentByDriverCode(@PathVariable("driverCode") String driverCode,@RequestHeader HttpHeaders headers)
        {
              String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true"))
               {
               if(driverCode!=null && driverCode.trim().length()>0)
               {
                  return driverDocumentService.getAllDriverDocumentByDriverCode(driverCode.trim());
               }
            else
              {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Driver Code should not be blank.");
            return derr.toString();
              }
               }else
               {
               return res;
               }
	}
        
        @GetMapping("/getAllDriverDocumentByPage")
    	public String getAllDriverDocumentByPage(@RequestParam(value = "page", defaultValue = "0") int page,
                @RequestParam(value = "limit", defaultValue = "30") int limit) {

            String dd = driverDocumentService.getAllDriverDocument(page, limit);
          
            return dd;
    	}
            
            @GetMapping("/getAllDriverDocumentByDriverCodeByPage/{driverCode}")
    	public String getAllDriverDocumentByDriverCodeByPage(@PathVariable("driverCode") String driverCode,@RequestParam(value = "page", defaultValue = "0") int page,
                @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
             String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true"))
               {
                  if(driverCode!=null && driverCode.trim().length()>0)
                 {

                String dd = driverDocumentService.getAllDriverDocumentByDriverCode(driverCode.trim(), page, limit);
          
                 return dd;
                }
               else
              {
                GigflexResponse derr = new GigflexResponse(400, new Date(),"Driver Code should not be blank.");
                return derr.toString();
               }
            }else
            {
              return res; 
            }
    	
    	}
        
        @GetMapping("/getDriverDocumentByDriverDocumentCode/{driverDocumentCode}")
	public String getDriverDocumentByDriverDocumentCode(@PathVariable("driverDocumentCode") String driverDocumentCode) {
	if(driverDocumentCode!=null && driverDocumentCode.trim().length()>0)
        {	
            return driverDocumentService.getDriverDocumentByDriverDocumentCode(driverDocumentCode.trim());
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Driver Document Code should not be blank.");
            return derr.toString();
        }
	}
        
        
        @DeleteMapping("/softDeleteDriverDocumentByDriverDocumentCode/{driverDocumentCode}")
	public String softDeleteDriverDocumentByDriverDocumentCode(@PathVariable String driverDocumentCode) {
	if(driverDocumentCode!=null && driverDocumentCode.trim().length()>0)	
        {
            return driverDocumentService.softDeleteDriverDocumentByDriverDocumentCode(driverDocumentCode.trim());
        }
         else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Driver Document Code should not be blank.");
            return derr.toString();
        }
	}

	@DeleteMapping("/softMultipleDeleteDriverDocumentByDriverDocumentCode/{diverDocumentCodeList}")
	public String softMultipleDeleteDriverDocumentByDriverDocumentCode(
			@PathVariable List<String> diverDocumentCodeList) {
		if (diverDocumentCodeList != null && diverDocumentCodeList.size() > 0) {
			return driverDocumentService.softMultipleDeleteDriverDocumentByDriverDocumentCode(diverDocumentCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}
        
        
        @PostMapping("/saveDriverDocument")
	public String saveDriverDocument(@RequestBody DriverDocumentRequest driDetReq,
			HttpServletRequest request) {
            if(driDetReq!=null && driDetReq.getDriverCode()!=null && driDetReq.getDriverCode().trim().length()>0 &&
                    driDetReq.getDocumentCode()!=null &&  driDetReq.getDocumentCode().trim().length()>0 
                    && driDetReq.getDocExpiration()!=null &&  driDetReq.getDocExpiration().trim().length()>0)
            {
                driDetReq.setDocumentCode(driDetReq.getDocumentCode().trim());
                driDetReq.setDriverCode(driDetReq.getDriverCode().trim());
		String ip = request.getRemoteAddr();
		return driverDocumentService.saveDriverDocument(driDetReq, ip);
            }
            else
            {
                GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Data should not be blank.");
			return derr.toString();
            }

	}
                
        
        
        @PutMapping("/updateDriverDocument/{driverDocumentCode}")
    public String updateDriverDocument(@PathVariable String driverDocumentCode,
            @RequestBody DriverDocumentRequest driDetReq, HttpServletRequest request) {

        if (driverDocumentCode != null && driverDocumentCode.trim().length() > 0 && driDetReq != null && driDetReq.getDriverCode() != null && driDetReq.getDriverCode().trim().length() > 0
                && driDetReq.getDocumentCode() != null && driDetReq.getDocumentCode().trim().length() > 0
                && driDetReq.getDocExpiration()!=null &&  driDetReq.getDocExpiration().trim().length()>0) {
            driDetReq.setDocumentCode(driDetReq.getDocumentCode().trim());
            driDetReq.setDriverCode(driDetReq.getDriverCode().trim());
            String ip = request.getRemoteAddr();
            return driverDocumentService.updateDriverDocument(driverDocumentCode.trim(), driDetReq, ip);

        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Data should not be blank.");
            return derr.toString();
        }

    }
        
    
    
    @PostMapping("/uploadOperatorDriverDocument")
    public String uploadOperatorDriverDocument(@RequestParam("file") MultipartFile file) {
        String res = "";
        String respon = documentUploadService.storeFile(file);
        try {
            JSONObject jSONObject = new JSONObject(respon);
            if (jSONObject.has("responsecode") && jSONObject.getInt("responsecode") == 200) {

                String fileName = jSONObject.getString("filename");
                String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                        .path("/organizationdriverservice/downloadOperatorDriverDocument/")
                        .path(fileName)
                        .toUriString();
               
                JSONObject jsonobj = new JSONObject();
                jsonobj.put("responsecode", 200);
                jsonobj.put("message", "success");
                jsonobj.put("filename", fileName);
                jsonobj.put("fileurl", fileDownloadUri);
                res = jsonobj.toString();
               
            } else {
                res = respon;
            }
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;
//        return new UploadFileResponse(fileName, fileDownloadUri,
//                file.getContentType(), file.getSize());
    }

    @GetMapping("/downloadOperatorDriverDocument/{fileName}")
    public ResponseEntity<Resource> downloadDriverDocument(@PathVariable String fileName, HttpServletRequest request) {
        // Load file as Resource
        Resource resource = documentUploadService.loadUploadedDocAsResource(fileName);

        // Try to determine file's content type
        String contentType = null;
        try {
            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        // Fallback to the default content type if type could not be determined
        if (contentType == null) {
            contentType = "application/octet-stream";
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }
    
    
        
        
        
        @GetMapping("/getAllOperatorDocument")
	public String getAllOperatorDocument() {
		return operatorDocumentService.getAllOperatorDocument();
	}
        
        @GetMapping("/getAllOperatorDocumentByOperatorCode/{operatorCode}")
	public String getAllOperatorDocumentByOperatorCode(@PathVariable("operatorCode") String operatorCode,@RequestHeader HttpHeaders headers) {
             String res="";
               res=tokenutility.operatorValidationwithoutactivation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                  if(operatorCode!=null && operatorCode.trim().length()>0)
                  {
                      return operatorDocumentService.getAllOperatorDocumentByOperatorCode(operatorCode.trim());
                  }
                 else
                  {
                      GigflexResponse derr = new GigflexResponse(400, new Date(),"Operator Code should not be blank.");
                     return derr.toString();
                   }
               }else
               {
               return res;
               }    
	}
        
        @GetMapping("/getAllOperatorDocumentByPage")
	public String getAllOperatorDocumentByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String dd = operatorDocumentService.getAllOperatorDocument(page, limit);
      
        return dd;
	}
        
        @GetMapping("/getAllOperatorDocumentByOperatorCodeByPage/{operatorCode}")
	public String getAllOperatorDocumentByOperatorCodeByPage(@PathVariable("operatorCode") String operatorCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
             String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                   if(operatorCode!=null && operatorCode.trim().length()>0)
                    {
		    String dd = operatorDocumentService.getAllOperatorDocumentByOperatorCode(operatorCode.trim(),page, limit);
	      
	            return dd;
                }
              else
               {
                 GigflexResponse derr = new GigflexResponse(400, new Date(),"Operator Code should not be blank.");
               return derr.toString();
               }
               
               }else
               {
                return res;
               }
               
	
	}
        
        @GetMapping("/getOperatorDocumentByOperatorDocumentCode/{operatorDocumentCode}")
	public String getOperatorDocumentByOperatorDocumentCode(@PathVariable("operatorDocumentCode") String operatorDocumentCode) {
	if(operatorDocumentCode!=null && operatorDocumentCode.trim().length()>0)
        {	
            return operatorDocumentService.getOperatorDocumentByOperatorDocumentCode(operatorDocumentCode.trim());
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Operator Document Code should not be blank.");
            return derr.toString();
        }
	}
        
        @DeleteMapping("/softDeleteOperatorDocumentByOperatorDocumentCode/{operatorDocumentCode}")
	public String softDeleteOperatorDocumentByOperatorDocumentCode(@PathVariable String operatorDocumentCode) {
	if(operatorDocumentCode!=null && operatorDocumentCode.trim().length()>0)	
        {
            return operatorDocumentService.softDeleteOperatorDocumentByOperatorDocumentCode(operatorDocumentCode.trim());
        }
         else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Operator Document Code should not be blank.");
            return derr.toString();
        }
	}

	@DeleteMapping("/softMultipleDeleteOperatorDocumentByOperatorDocumentCode/{operatorDocumentCodeList}")
	public String softMultipleDeleteOperatorDocumentByOperatorDocumentCode(
			@PathVariable List<String> operatorDocumentCodeList) {
		if (operatorDocumentCodeList != null && operatorDocumentCodeList.size() > 0) {
			return operatorDocumentService.softMultipleDeleteOperatorDocumentByOperatorDocumentCode(operatorDocumentCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}
        
        
        
        
        
        @PostMapping("/saveOperatorDocument")
	public String saveOperatorDocument(@RequestBody OperatorDocumentRequest driDetReq,
			HttpServletRequest request) {
            if(driDetReq!=null && driDetReq.getOperatorCode()!=null && driDetReq.getOperatorCode().trim().length()>0 &&
                    driDetReq.getDocumentCode()!=null &&  driDetReq.getDocumentCode().trim().length()>0 
                    && driDetReq.getDocExpiration()!=null &&  driDetReq.getDocExpiration().trim().length()>0)
            {
                driDetReq.setDocumentCode(driDetReq.getDocumentCode().trim());
                driDetReq.setOperatorCode(driDetReq.getOperatorCode().trim());
		String ip = request.getRemoteAddr();
		return operatorDocumentService.saveOperatorDocument(driDetReq, ip);
            }
            else
            {
                GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Data should not be blank.");
			return derr.toString();
            }

	}
                
        
        
        @PutMapping("/updateOperatorDocument/{operatorDocumentCode}")
    public String updateOperatorDocument(@PathVariable String operatorDocumentCode,
            @RequestBody OperatorDocumentRequest driDetReq, HttpServletRequest request) {

        if (operatorDocumentCode != null && operatorDocumentCode.trim().length() > 0 && driDetReq != null && driDetReq.getOperatorCode()!= null && driDetReq.getOperatorCode().trim().length() > 0
                && driDetReq.getDocumentCode() != null && driDetReq.getDocumentCode().trim().length() > 0
                && driDetReq.getDocExpiration()!=null &&  driDetReq.getDocExpiration().trim().length()>0) {
            driDetReq.setDocumentCode(driDetReq.getDocumentCode().trim());
            driDetReq.setOperatorCode(driDetReq.getOperatorCode().trim());
            String ip = request.getRemoteAddr();
            return operatorDocumentService.updateOperatorDocument(operatorDocumentCode.trim(), driDetReq, ip);

        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Data should not be blank.");
            return derr.toString();
        }

    }
        
    
//     @PostMapping("/uploadOperatorDocument")
//    public String uploadOperatorDocument(@RequestParam("file") MultipartFile file,@RequestParam("operatorDocumentCode") String operatorDocumentCode) {
//        String res = "";
//        String respon = documentUploadService.storeFile(file,"operator");
//        try {
//            JSONObject jSONObject = new JSONObject(respon);
//            if (jSONObject.has("responsecode") && jSONObject.getInt("responsecode") == 200) {
//
//                String fileName = jSONObject.getString("filename");
////                String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
////                        .path("/superadminservice/downloadFile/")
////                        .path(fileName)
////                        .toUriString();
//               OperatorDocument dd= operatorDocumentRepository.getOperatorDocumentByOperatorDocumentCode(operatorDocumentCode);
//               if(dd!=null && dd.getId()>0)
//               {
//                dd.setPath(fileName);
//                OperatorDocument ddres= operatorDocumentRepository.save(dd);
//                if(ddres!=null && ddres.getId()>0)
//                {
//                kafkaService.sendOperatorDocumentForUpdate(ddres);
//                JSONObject jsonobj = new JSONObject();
//                jsonobj.put("responsecode", 200);
//                jsonobj.put("message", "success");
//                ObjectMapper mapperObj = new ObjectMapper();
//                String Detail = mapperObj.writeValueAsString(ddres);
//		jsonobj.put("data", new JSONObject(Detail));
//                jsonobj.put("timestamp", new Date());
//                res = jsonobj.toString();
//                }
//                else
//                {
//                JSONObject jsonobj = new JSONObject();
//                jsonobj.put("responsecode", 400);
//                jsonobj.put("message", "Operator Document Path has been not added.");
//                jsonobj.put("timestamp", new Date());
//                res = jsonobj.toString();
//                }
//               }
//               else
//               {
//                   JSONObject jsonobj = new JSONObject();
//                jsonobj.put("responsecode", 400);
//                jsonobj.put("message", "Operator Document Code does not exist.");
//                jsonobj.put("timestamp", new Date());
//                res = jsonobj.toString();
//               }
//            } else {
//                res = respon;
//            }
//        } catch (JSONException ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(),
//                    "JSON parsing exception occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        } catch (Exception ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(),
//                    "Exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        return res;
////        return new UploadFileResponse(fileName, fileDownloadUri,
////                file.getContentType(), file.getSize());
//    }
//
//    @GetMapping("/downloadOperatorDocument/{fileName}")
//    public ResponseEntity<Resource> downloadOperatorDocument(@PathVariable String fileName, HttpServletRequest request) {
//        // Load file as Resource
//        Resource resource = documentUploadService.loadUploadedDocAsResource(fileName,"operator");
//
//        // Try to determine file's content type
//        String contentType = null;
//        try {
//            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
//        } catch (IOException ex) {
//            ex.printStackTrace();
//        }
//
//        // Fallback to the default content type if type could not be determined
//        if (contentType == null) {
//            contentType = "application/octet-stream";
//        }
//
//        return ResponseEntity.ok()
//                .contentType(MediaType.parseMediaType(contentType))
//                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
//                .body(resource);
//    }
//    

    
    @GetMapping("/getDocumentExpirationStatusByOperatorCode/{operatorCode}")
    public String getDocumentExpirationStatusByOperatorCode(@PathVariable("operatorCode") String operatorCode,@RequestHeader HttpHeaders headers) {
        String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                if (operatorCode != null && operatorCode.trim().length() > 0) {
                   return operatorDocumentService.getDocumentExpirationStatusByOperatorCode(operatorCode);
                   }
                else{
                    GigflexResponse derr = new GigflexResponse(400, new Date(), "operatorCode Code should not be blank.");
                 return derr.toString();
                 }
               }else
               {
               return res;
               }
        
    }
        

      
    
   @GetMapping("/getDocumentExpirationByDriverCode/{driverCode}")
	public String getDocumentExpirationByDriverCode(@PathVariable("driverCode") String driverCode,@RequestHeader HttpHeaders headers) {
            String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true"))
               {
                if (driverCode != null && driverCode.trim().length() > 0) {
               return driverDocumentService.getDocumentExpirationByDriverCode(driverCode.trim());
               } else {
                     GigflexResponse derr = new GigflexResponse(400, new Date(), "Driver Code should not be blank.");
                      return derr.toString();
                 }
               }else
               {
               return res;
               }
	      
    }

}
