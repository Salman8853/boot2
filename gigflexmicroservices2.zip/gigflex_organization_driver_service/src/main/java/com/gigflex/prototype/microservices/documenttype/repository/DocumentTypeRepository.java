package com.gigflex.prototype.microservices.documenttype.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.documenttype.dtob.DocumentType;

public interface DocumentTypeRepository extends JpaRepository<DocumentType, Long>,JpaSpecificationExecutor<DocumentType>{
	
	@Query("SELECT m FROM DocumentType m WHERE m.isDeleted != TRUE")
	public List<DocumentType> getAllDocumentType();
	
	@Query("SELECT m FROM DocumentType m WHERE m.isDeleted != TRUE")
	public List<DocumentType> getAllDocumentType(Pageable pageableRequest);
	
	@Query("SELECT m FROM DocumentType m WHERE m.isDeleted != TRUE AND m.documentTypeCode = :documentTypeCode")
	public DocumentType getDocumentTypeByDocumentTypeCode(@Param("documentTypeCode") String documentTypeCode);
	
	@Query("SELECT m FROM DocumentType m WHERE m.isDeleted != TRUE AND m.id = :id")
	public DocumentType getDocumentTypeById(@Param("id") Long id);
	
	@Query("SELECT m FROM DocumentType m WHERE m.isDeleted != TRUE AND m.documentTypeName = :documentTypeName")
	public DocumentType getDocumentTypeByDocumentTypeName(@Param("documentTypeName") String documentTypeName);
	
        @Query("select d FROM DriverDocument a, DocumentTypeDetail b,Driver c,DocumentType d WHERE a.isDeleted != TRUE AND b.documentCode = a.documentCode AND a.driverCode = c.driverCode AND a.driverCode = :driverCode AND d.documentTypeCode=b.documentTypeCode")
	public DocumentType getDriverDocumentTypeByDriverCode(@Param("driverCode") String driverCode);

}
