/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.dtob;

/**
 *
 * @author m.salman
 */
public class DriverDocsResponse {
          
        private Long id;
        
	private String driverDocumentCode;

	

	private String documentCode;
	
   

	private String docValue;

	private String docExpiration;

//	private String documentType;
	private String documentName;

	private String documentType;
	private String image;
        private String email;
	private String dateFormat ;
        private String timeFormat;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDriverDocumentCode() {
        return driverDocumentCode;
    }

    public void setDriverDocumentCode(String driverDocumentCode) {
        this.driverDocumentCode = driverDocumentCode;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getDocValue() {
        return docValue;
    }

    public void setDocValue(String docValue) {
        this.docValue = docValue;
    }

    public String getDocExpiration() {
        return docExpiration;
    }

    public void setDocExpiration(String docExpiration) {
        this.docExpiration = docExpiration;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getTimeFormat() {
        return timeFormat;
    }

    public void setTimeFormat(String timeFormat) {
        this.timeFormat = timeFormat;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
	

}
