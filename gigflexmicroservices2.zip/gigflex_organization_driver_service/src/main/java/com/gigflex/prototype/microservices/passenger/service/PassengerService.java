/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.passenger.service;

/**
 *
 * @author amit.kumar
 */
public interface PassengerService {

    public String getPassengerAllPassengerList();

    public String getPassengerByOrganizationCode(String organizationCode);

    public String getPassengerByPassengerCode(String passengerCode);
    
}
