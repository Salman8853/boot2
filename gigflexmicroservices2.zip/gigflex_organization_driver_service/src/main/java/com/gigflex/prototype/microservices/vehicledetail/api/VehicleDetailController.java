package com.gigflex.prototype.microservices.vehicledetail.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.TokenUtility;
import com.gigflex.prototype.microservices.vehicledetail.dtob.SaveVehicleByDriver;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetailDriverRequest;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetailRequest;
import com.gigflex.prototype.microservices.vehicledetail.service.VehicleDetailService;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class VehicleDetailController {

	@Autowired
	public VehicleDetailService vehicleDetailService;
         @Autowired
        TokenUtility tokenutility;

	@GetMapping("/VehicleDetail/{search}")
	public String search(@PathVariable("search") String search) {
		return vehicleDetailService.search(search);
	}

	@GetMapping("/getAllVehicleDetail")
	public String getAllVehicleDetail() {
		return vehicleDetailService.getAllVehicleDetail();
	}

	@GetMapping(path = "/getVehicleDetailByPage")
	public String getVehicleDetailByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String vd = vehicleDetailService.getAllVehicleDetailByPage(page, limit);

		return vd;

	}

	@GetMapping("/getVehicleDetail/{id}")
	public String getVehicleDetail(@PathVariable Long id) {
		return vehicleDetailService.getVehicleDetailById(id);
	}

	@GetMapping("/getVehicleDetailByVehicleCode/{vehicleCode}")
	public String getVehicleDetailByVehicleCode(@PathVariable String vehicleCode) {
           
            
		return vehicleDetailService.getVehicleDetailByVehicleCodeWithName(vehicleCode);
	}

	@GetMapping("/getVehicleDetailByOrganizationCode/{organizationCode}")
	public String getVehicleDetailByOrganizationCode(
			@PathVariable String organizationCode,@RequestHeader HttpHeaders headers) {
            String res="";
               res=tokenutility.userValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
                 return vehicleDetailService.getVehicleDetailByOrganizationCode(organizationCode);
               }else
               {
               return res;
               }
		
	}

	@GetMapping(path = "/getVehicleDetailByOrganizationCodeByPage/{organizationCode}")
	public String getVehicleDetailByOrganizationCodeByPage(
			@PathVariable String organizationCode,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
               String res="";
               res=tokenutility.userValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
               return vehicleDetailService.getVehicleDetailByOrganizationCodeByPage(organizationCode,
						page, limit);
               }else
               {
               return res;
               }
	}
	
	@GetMapping("/getVehicleDetailByModelCode/{modelCode}")
	public String getVehicleDetailByModelCode(@PathVariable String modelCode) {
		return vehicleDetailService.getVehicleDetailByModelCode(modelCode);
	}

	@GetMapping(path = "/getVehicleDetailByModelCodeByPage/{modelCode}")
	public String getVehicleDetailByModelCodeByPage(
			@PathVariable String modelCode,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String vd = vehicleDetailService.getVehicleDetailByModelCodeByPage(
				modelCode, page, limit);

		return vd;

	}
	
	@GetMapping("/getVehicleDetailByDriverCode/{driverCode}")
	public String getVehicleDetailByDriverCode(@PathVariable String driverCode,@RequestHeader HttpHeaders headers) {
             String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true"))
               {
                   return vehicleDetailService.getVehicleDetailByDriverCode(driverCode);
               }else
               {
                 return res;
               }
		
	}
        @GetMapping("/getVehicleDetailByDriverCodeforMobile/{driverCode}")
	public String getVehicleDetailByDriverCodeforMobile(@PathVariable String driverCode,@RequestHeader HttpHeaders headers) {
             String res="";
             if(driverCode!=null && driverCode.trim().length()>0)
             {
              res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true"))
               {  
                     
                      return vehicleDetailService.getVehicleDetailByDriverCodeforMobile(driverCode);
                     
               }else
               {
                 return res;
               }
             }else
                    {
                     GigflexResponse derr = new GigflexResponse(400, new Date(),"driverCode  is not valid");
			return derr.toString();
                    }
          
	}
        
        @GetMapping("/getVehicleTypeDetailByDriverCode/{driverCode}")
	public String getVehicleTypeDetailByDriverCode(@PathVariable String driverCode,@RequestHeader HttpHeaders headers) {
             String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true"))
               {
                   return vehicleDetailService.getVehicleTypeDetailByDriverCode(driverCode);
               }else
               {
                 return res;
               }
		
	}

	@GetMapping(path = "/getVehicleDetailByDriverCodeByPage/{driverCode}")
	public String getVehicleDetailByDriverCodeByPage(
			@PathVariable String driverCode,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
                     String res="";
               res=tokenutility.userValidation(headers, driverCode);
               if(res.equalsIgnoreCase("true"))
               {
                  return  vehicleDetailService.getVehicleDetailByDriverCodeByPage(
				driverCode, page, limit);
               }else
               {
               return res;
               }
		
		

	}

	@PostMapping("/saveVehicleByOrganization")
	public String saveVehicleByOrganization(
			@RequestBody VehicleDetailDriverRequest vehicleDetailReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return vehicleDetailService.saveVehicleByOrganization(vehicleDetailReq, ip);

	}
	
	@PostMapping("/saveVehicleByDriver")
	public String saveVehicleByDriver(
			@RequestBody SaveVehicleByDriver vehicleDetailReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return vehicleDetailService.saveVehicleByDriver(vehicleDetailReq, ip);

	}
	
	@PostMapping("/saveVehicleDetail")
	public String saveVehicleDetail(
			@RequestBody VehicleDetailRequest vehicleDetailReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return vehicleDetailService.saveNewVehicleDetail(vehicleDetailReq, ip);

	}

	@PutMapping("/updateVehicleDetail/{id}")
	public String updateVehicleDetail(@PathVariable Long id,
			@RequestBody VehicleDetailRequest vehicleDetailReq,
			HttpServletRequest request) {

		if (id == null) {
			return "Vehicle Detail with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return vehicleDetailService.updateVehicleDetailById(id,
					vehicleDetailReq, ip);

		}

	}
	
	@PutMapping("/updateVehicleByOrganizationById/{id}")
	public String updateVehicleByOrganizationById(@PathVariable Long id,
			@RequestBody VehicleDetailDriverRequest vehicleDetailReq,
			HttpServletRequest request) {

		if (id == null) {
			return "Vehicle Detail with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return vehicleDetailService.updateVehicleByOrganizationById(id, vehicleDetailReq, ip);

		}

	}
	
	@PutMapping("/updateVehicleByDriverById/{id}")
	public String updateVehicleByDriverById(@PathVariable Long id,
			@RequestBody SaveVehicleByDriver vehicleDetailReq,
			HttpServletRequest request) {

		if (id == null) {
			return "Vehicle Detail with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return vehicleDetailService.updateVehicleByDriverById(id, vehicleDetailReq, ip);

		}

	}

	@DeleteMapping("/softDeleteVehicleDetailByVehicleCode/{vehicleCode}")
	public String softDeleteVehicleDetailByVehicleCode(
			@PathVariable String vehicleCode) {
		return vehicleDetailService.softDeleteByVehicleCode(vehicleCode);
	}

	@DeleteMapping("/softMultipleDeleteVehicleDetailByVehicleCode/{vehicleCodeList}")
	public String softMultipleDeleteByVehicleCode(
			@PathVariable List<String> vehicleCodeList) {
		if (vehicleCodeList != null && vehicleCodeList.size() > 0) {
			return vehicleDetailService
					.softMultipleDeleteByVehicleCode(vehicleCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

}
