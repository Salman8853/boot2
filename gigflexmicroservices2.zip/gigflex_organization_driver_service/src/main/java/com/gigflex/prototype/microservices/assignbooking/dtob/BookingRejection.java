/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.assignbooking.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author nirbhay.p
 */
@Entity
@Table(name = "booking_rejection")
public class BookingRejection extends CommonAttributes implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "booking_rejection_code", unique = true)
    private String bookingRejectionCode;
    
    @Column(name = "ride_code", nullable = false)
    private String rideCode;
    
    @Column(name = "driver_code")
    private String driverCode;
    
        
    @Column(name = "comments")
    private String comments;
    
    @PrePersist
    private void assignUUID() {
    	if (this.getBookingRejectionCode() == null || this.getBookingRejectionCode().length() == 0) {
           this.setBookingRejectionCode(UUID.randomUUID().toString());
    	}
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBookingRejectionCode() {
        return bookingRejectionCode;
    }

    public void setBookingRejectionCode(String bookingRejectionCode) {
        this.bookingRejectionCode = bookingRejectionCode;
    }

    public String getRideCode() {
        return rideCode;
    }

    public void setRideCode(String rideCode) {
        this.rideCode = rideCode;
    }

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

   
}
