package com.gigflex.prototype.microservices.dashboard.service;

public interface DashboardService {
	
	public String getBookingForDashboardByOperatorCode(String operatorCode);
	public String getBookingForDashboardByOrganizationCode(String organizationCode);
	public String getBookingForDashboardByDriverCode(String driverCode);


}
