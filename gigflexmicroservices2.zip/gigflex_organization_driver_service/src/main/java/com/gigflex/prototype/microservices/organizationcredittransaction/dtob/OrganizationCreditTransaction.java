/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationcredittransaction.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "organization_credit_transaction")
public class OrganizationCreditTransaction extends CommonAttributes implements Serializable{
        
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "organization_credit_transaction_code", unique = true)
    private String organizationCreditTransactionCode;
    
    @Column(name = "organization_code")
    private String organizationCode;
    
    @Column(name = "balance_amount")
    private double balanceAmount;
    
    @Column(name = "debit_amount")
    private double debitAmount;
    
    @Column(name = "credit_amount")
    private double creditAmount;
    
    @Column(name = "transaction_by")
    private String transactionBy;
    
    @Column(name = "bookingid", nullable = true)
    private Long bookingid;
    
    @Column(name = "transaction_type")
    private String transactionType;
    
    
     
     @PrePersist
    private void assignUUID() {
        if(this.getOrganizationCreditTransactionCode()==null || this.getOrganizationCreditTransactionCode().length()==0)
        {
            this.setOrganizationCreditTransactionCode(UUID.randomUUID().toString());
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
   

    public double getBalanceAmount() {
        return balanceAmount;
    }

    public void setBalanceAmount(double balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    public double getDebitAmount() {
        return debitAmount;
    }

    public void setDebitAmount(double debitAmount) {
        this.debitAmount = debitAmount;
    }

    public String getTransactionBy() {
        return transactionBy;
    }

    public void setTransactionBy(String transactionBy) {
        this.transactionBy = transactionBy;
    }

    public Long getBookingid() {
        return bookingid;
    }

    public void setBookingid(Long bookingid) {
        this.bookingid = bookingid;
    }

    public double getCreditAmount() {
        return creditAmount;
    }

    public void setCreditAmount(double creditAmount) {
        this.creditAmount = creditAmount;
    }

    public String getOrganizationCreditTransactionCode() {
        return organizationCreditTransactionCode;
    }

    public void setOrganizationCreditTransactionCode(String organizationCreditTransactionCode) {
        this.organizationCreditTransactionCode = organizationCreditTransactionCode;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }
        
}
