package com.gigflex.prototype.microservices.ridetype.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.ridetype.dtob.RideTypeRequest;
import com.gigflex.prototype.microservices.ridetype.service.RideTypeService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.TokenUtility;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class RideTypeController {

	@Autowired
	public RideTypeService rideTypeService;
          @Autowired
        TokenUtility tokenutility;
	@GetMapping("/RideType/{search}")
	public String search(@PathVariable("search") String search) {
		return rideTypeService.search(search);
	}

	@GetMapping("/getAllRideType")
	public String getAllRideType() {
		return rideTypeService.getAllRideType();
	}

	@GetMapping(path = "/getRideTypeByPage")
	public String getRideTypeByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String RideType = rideTypeService.getAllRideTypeByPgae(page,
				limit);

		return RideType;

	}

	@GetMapping("/getRideType/{id}")
	public String getRideTypeById(@PathVariable Long id) {
		return rideTypeService.getRideTypeById(id);
	}

	@GetMapping("/getAllRideTypeByOrganizationCode/{organizationCode}")
	public String getAllRideTypeByOrganizationCode(@PathVariable String organizationCode,@RequestHeader HttpHeaders headers) {
              String res="";
               res=tokenutility.orgCodeValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
               return rideTypeService.getAllRideTypeByOrganizationCode(organizationCode);
               }else
               {
               return res;
               }
		
	}
	
	@GetMapping("/getAllRideTypeByOrganizationCodeByPage/{organizationCode}")
	public String getAllRideTypeByOrganizationCodeByPage(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
             String res="";
               res=tokenutility.orgCodeValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
                 return rideTypeService.getAllRideTypeByOrganizationCode(organizationCode, page, limit);
               }else
               {
                return res;
               }
		
	
	}
	
	@GetMapping("/getRideTypeByVehicleCode/{vehicleCode}")
	public String getRideTypeByVehicleCode(@PathVariable String vehicleCode) {
		return rideTypeService.getRideTypeByVehicleCodeWithName(vehicleCode);
	}

	@GetMapping("/getFarePricing/{vehicleCode}/{miles}")
	public String getFarePricing(@PathVariable String vehicleCode,
			@PathVariable Double miles) {
		return rideTypeService.getFarePricing(vehicleCode, miles);
	}

	@GetMapping("/getFarePricingForAllRideType/{miles}/{organizationCode}")
	public String getFarePricingForAllRideType(@PathVariable Double miles,@PathVariable String organizationCode,@RequestHeader HttpHeaders headers) {
            
            String res="";
               res=tokenutility.orgCodeValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
               return rideTypeService.getFarePricingForAllRideType(miles, organizationCode);
               }else
               {
               return res;
               }
		
	}
	
	@GetMapping(path = "/getFarePricingForAllRideTypeByPage/{miles}")
	public String getFarePricingForAllRideTypeByPage(@PathVariable Double miles,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String RideType = rideTypeService.getFarePricingForAllRideTypeByPage(miles, page, limit);

		return RideType;

	}


	@PostMapping("/saveRideType")
	public String saveRideType(
			@RequestBody RideTypeRequest RideTypeReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return rideTypeService.saveNewRideType(RideTypeReq, ip);

	}

	@PutMapping("/updateRideType/{id}")
	public String updateRideType(@PathVariable Long id,
			@RequestBody RideTypeRequest RideTypeReq,
			HttpServletRequest request) {

		if (id == null) {
			return "RideType with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return rideTypeService.updateRideTypeById(id, RideTypeReq,
					ip);

		}

	}

	@DeleteMapping("/softDeleteRideTypeByVehicleCode/{vehicleCode}")
	public String softDeleteRideTypeByVehicleCode(
			@PathVariable String vehicleCode) {
		return rideTypeService.softDeleteByVehicleCode(vehicleCode);
	}

	@DeleteMapping("/softMultipleDeleteRideTypeByVehicleCode/{vehicleCodeList}")
	public String softMultipleDeleteRideTypeByVehicleCode(
			@PathVariable List<String> vehicleCodeList) {
		if (vehicleCodeList != null && vehicleCodeList.size() > 0) {
			return rideTypeService
					.softMultipleDeleteByVehicleCode(vehicleCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

}
