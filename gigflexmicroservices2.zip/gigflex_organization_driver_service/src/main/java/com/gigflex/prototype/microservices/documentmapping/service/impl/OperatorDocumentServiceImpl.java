/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentExpirationByOperator;
import com.gigflex.prototype.microservices.documentmapping.dtob.OperatorDocResponse;
import com.gigflex.prototype.microservices.documentmapping.dtob.OperatorDocument;
import com.gigflex.prototype.microservices.documentmapping.dtob.OperatorDocumentRequest;
import com.gigflex.prototype.microservices.documentmapping.repository.DriverDocumentRepository;
import com.gigflex.prototype.microservices.documentmapping.repository.OperatorDocumentRepository;
import com.gigflex.prototype.microservices.documentmapping.service.OperatorDocumentService;
import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetail;
import com.gigflex.prototype.microservices.documenttypedetail.repository.DocumentTypeDetailRepository;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.utility.GigflexDateUtil;

/**
 *
 * @author nirbhay.p
 */
@Service
public class OperatorDocumentServiceImpl implements OperatorDocumentService{

    @Autowired
    OperatorDocumentRepository operatorDocumentRepository;
    
    @Autowired
    OperatorRepository operatorRepository;
    
    @Autowired
    DocumentTypeDetailRepository documentTypeDetailRepository;
        @Autowired
        KafkaService kafkaService;
    
        @Autowired
        DriverRepository driverRepository;
       
          @Autowired
        GlobalSettingRepository globalSettingRepository;
          
         @Autowired
        LocalSettingRepository localSettingRepository;
        
        @Autowired
	private TimeZoneRepository timeZoneRepository;
        
        @Autowired
	UserTypeRepository userTypeRepository;    
        
        @Autowired
	DriverDocumentRepository driverDocumentRepository;
	
        
     
    @Override
    public String getAllOperatorDocument() {
//        String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//			List<OperatorDocument> docTypeLst = operatorDocumentRepository.getAllOperatorDocument();
//			if (docTypeLst != null && docTypeLst.size() > 0) {
//				jsonobj.put("responsecode", 200);
//				jsonobj.put("message", "Success");
//				jsonobj.put("timestamp", new Date());
//				ObjectMapper mapperObj = new ObjectMapper();
//				String Detail = mapperObj.writeValueAsString(docTypeLst);
//				jsonobj.put("data", new JSONArray(Detail));
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("message", "Record Not Found.");
//				jsonobj.put("timestamp", new Date());
//			}
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception occurred.");
//			res = derr.toString();
//		}
//                catch (Exception  ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"Exception occurred.");
//			res = derr.toString();
//		}
//		return res;
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = operatorDocumentRepository
					.getAllOperatorDocument();
			List<OperatorDocResponse> maplst = new ArrayList<OperatorDocResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						OperatorDocResponse odr = new OperatorDocResponse();

						OperatorDocument data = (OperatorDocument) arr[0];
						
						String conDt = "";

						if (data.getDocExpiration() != null) {
							TimeZoneDetail tz = operatorDocumentRepository.getTimeZoneByOperatorCode(data.getOperatorCode());
							Date docExpDate = data.getDocExpiration();
							docExpDate = GigflexDateUtil.getGMTtoLocationDate(docExpDate, tz.getTimeZoneName(),
									GigflexConstants.dateFormatterForView);
							conDt = GigflexDateUtil.converDateToString(docExpDate);
						}

						odr.setId(data.getId());
						odr.setOperatorDocumentCode(data
								.getOperatorDocumentCode());
						odr.setOperatorCode(data.getOperatorCode());
						odr.setDocumentCode(data.getDocumentCode());


//						odr.setPath(data.getPath());
						odr.setDocValue(data.getDocValue());
						odr.setDocExpiration(conDt);



						odr.setDocumentName((String) arr[1]);
						odr.setOperatorName((String) arr[2]);

						maplst.add(odr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public String getAllOperatorDocumentByOperatorCode(String operatorCode) {
//         String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//			List<OperatorDocument> docTypeLst = operatorDocumentRepository.getAllOperatorDocumentByOperatorCode(operatorCode);
//			if (docTypeLst != null && docTypeLst.size() > 0) {
//				jsonobj.put("responsecode", 200);
//				jsonobj.put("message", "Success");
//				jsonobj.put("timestamp", new Date());
//				ObjectMapper mapperObj = new ObjectMapper();
//				String Detail = mapperObj.writeValueAsString(docTypeLst);
//				jsonobj.put("data", new JSONArray(Detail));
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("message", "Record Not Found.");
//				jsonobj.put("timestamp", new Date());
//			}
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception occurred.");
//			res = derr.toString();
//		}
//                catch (Exception  ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"Exception occurred.");
//			res = derr.toString();
//		}
//		return res;
    	String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = operatorDocumentRepository.getAllOperatorDocumentByOperatorCode(operatorCode);
			List<OperatorDocResponse> maplst = new ArrayList<OperatorDocResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						OperatorDocResponse odr = new OperatorDocResponse();

						OperatorDocument data = (OperatorDocument) arr[0];
						String conDt = "";

						if (data.getDocExpiration() != null) {
							TimeZoneDetail tz = operatorDocumentRepository.getTimeZoneByOperatorCode(data.getOperatorCode());
							Date docExpDate = data.getDocExpiration();
							docExpDate = GigflexDateUtil.getGMTtoLocationDate(docExpDate, tz.getTimeZoneName(),
									GigflexConstants.dateFormatterForView);
							conDt = GigflexDateUtil.converDateToString(docExpDate);
						}

						odr.setId(data.getId());
						odr.setOperatorDocumentCode(data
								.getOperatorDocumentCode());
						odr.setOperatorCode(data.getOperatorCode());
						odr.setDocumentCode(data.getDocumentCode());

						odr.setDocValue(data.getDocValue());
						odr.setDocExpiration(conDt);


						odr.setDocumentName((String) arr[1]);
						odr.setOperatorName((String) arr[2]);

						maplst.add(odr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public String getOperatorDocumentByOperatorDocumentCode(String operatorDocumentCode) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			OperatorDocument docTypeLst = operatorDocumentRepository.getOperatorDocumentByOperatorDocumentCode(operatorDocumentCode);
			if (docTypeLst != null && docTypeLst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(docTypeLst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String softDeleteOperatorDocumentByOperatorDocumentCode(String operatorDocumentCode) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			OperatorDocument docTypeLst = operatorDocumentRepository.getOperatorDocumentByOperatorDocumentCode(operatorDocumentCode);

			if (docTypeLst != null && docTypeLst.getId() > 0) {
				docTypeLst.setIsDeleted(true);
				OperatorDocument docTypeRes = operatorDocumentRepository.save(docTypeLst);
				if (docTypeRes != null && docTypeRes.getId() > 0) {
				kafkaService.sendOperatorDocumentForUpdate(docTypeRes);
                                    jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Operator Document has been deleted successfully.");
					// kafkaService.sendRoleMasterUpdate(roleRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} 
                catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String softMultipleDeleteOperatorDocumentByOperatorDocumentCode(List<String> operatorDocumentCodeList) {
        String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String OperatorDocument : operatorDocumentCodeList) {
				if (OperatorDocument != null && OperatorDocument.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					OperatorDocument = OperatorDocument.trim();

					OperatorDocument docTypeLst = operatorDocumentRepository
							.getOperatorDocumentByOperatorDocumentCode(OperatorDocument);

					if (docTypeLst != null && docTypeLst.getId() > 0) {

						docTypeLst.setIsDeleted(true);
						OperatorDocument docTypeRes = operatorDocumentRepository.save(docTypeLst);
						if (docTypeRes != null && docTypeRes.getId() > 0) {
						kafkaService.sendOperatorDocumentForUpdate(docTypeRes);	
                                                    jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", OperatorDocument);
							jsonobj.put("message","Operator Document has been deleted successfully.");
							
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", OperatorDocument);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", OperatorDocument);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}
                } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		 catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String saveOperatorDocument(OperatorDocumentRequest driDetReq, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();

            if (driDetReq != null) {
                DocumentTypeDetail dtd = documentTypeDetailRepository.getDocumentTypeDetailByDocumentCode(driDetReq.getDocumentCode());
                if (dtd != null && dtd.getId() > 0) {
                    Operator otr = operatorRepository.getOperatorByOperatorCode(driDetReq.getOperatorCode());
                    if (otr != null && otr.getId() > 0) {
                        OperatorDocument dridoc = operatorDocumentRepository.getOperatorDocumentByOperatorCodeDocumentCode(driDetReq.getDocumentCode(), driDetReq.getOperatorCode());

                        if (dridoc != null && dridoc.getId() > 0) {
                            jsonobj.put("responsecode", 409);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Record already exist.");
                        } else {

                            OperatorDocument dd = new OperatorDocument();
//                            Date expdt=null;
//                    if(driDetReq.getDocExpiration()!=null && driDetReq.getDocExpiration().trim().length()>0)
//                    {
//                    try {
//				expdt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse( driDetReq.getDocExpiration().trim());
//                                if(expdt==null )
//                                {
//                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
//						"Plz send expiration date in correct format(yyyy-MM-dd HH:mm:ss) ");
//				return derr.toString();
//                                }
//			} catch (Exception ex) {
//				ex.printStackTrace();
//				GigflexResponse derr = new GigflexResponse(400, new Date(),
//						"Plz send expiration date in correct format(yyyy-MM-dd HH:mm:ss) ");
//				return derr.toString();
//			}
//                    }
                    	
                        Date expdt = null;
    							try {
    								expdt = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
    										.parse(driDetReq.getDocExpiration().trim());
    								if (expdt == null) {
    									GigflexResponse derr = new GigflexResponse(400, new Date(),
    											"Plz send date in correct format(" + GigflexConstants.dateFormatterForSave
    													+ ") ");
    									return derr.toString();
    								}

    							} catch (Exception ex) {
    								ex.printStackTrace();
    								GigflexResponse derr = new GigflexResponse(400, new Date(),
    										"Plz send date in correct format(" + GigflexConstants.dateFormatterForSave
    												+ ") ");
    								return derr.toString();
    							}
  String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, otr.getOrganizationCode(), GigflexConstants.TimeZone);
TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
String timezone = tz.getTimeZoneName(); 

Date docExptime = GigflexDateUtil.convertStringDateToGMT(
driDetReq.getDocExpiration().trim(), timezone,
GigflexConstants.dateFormatterForSave);
    							if (docExptime == null) {
    								GigflexResponse derr = new GigflexResponse(400, new Date(),
    										"Date conversion has been failed.");
    								return derr.toString();
    							}
                            dd.setDocExpiration(docExptime);
                            dd.setDocValue(driDetReq.getDocValue());
                            dd.setDocumentCode(driDetReq.getDocumentCode());
                            dd.setOperatorCode(driDetReq.getOperatorCode());
                            dd.setIpAddress(ip);

                            OperatorDocument ddRes = operatorDocumentRepository.save(dd);

                            if (ddRes != null && ddRes.getId() > 0) {
                                kafkaService.sendOperatorDocumentForSave(ddRes);
                                jsonobj.put("responsecode", 200);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("message", "Operator Document has been added successfully.");
                                ObjectMapper mapperObj = new ObjectMapper();
                                String Detail = mapperObj
                                        .writeValueAsString(ddRes);
                                jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                jsonobj.put("responsecode", 400);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("message", "Failed");
                            }
                        }
                    } else {
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("message", "Operator does not exist.");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("message", "Document Code is not valid.");
                    jsonobj.put("timestamp", new Date());
                }
            } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Input data is not valid.");

            }
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;
    }

    @Override
    public String updateOperatorDocument(String operatorDocumentCode, OperatorDocumentRequest driDetReq, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            DocumentTypeDetail dtd = documentTypeDetailRepository.getDocumentTypeDetailByDocumentCode(driDetReq.getDocumentCode());
            if (dtd != null && dtd.getId() > 0) {
                Operator otr = operatorRepository.getOperatorByOperatorCode(driDetReq.getOperatorCode());
                if (otr != null && otr.getId() > 0) {
                    OperatorDocument ddoc = operatorDocumentRepository.getOperatorDocumentByOperatorDocumentCode(operatorDocumentCode);
                    if (ddoc != null && ddoc.getId() > 0) {

                        OperatorDocument dd = operatorDocumentRepository
                                .getOperatorDocumentByOperatorCodeDocumentCodeNotInCode(operatorDocumentCode, driDetReq.getDocumentCode(), driDetReq.getOperatorCode());

                        if (dd != null && dd.getId() > 0) {
                            jsonobj.put("responsecode", 409);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Record already exist.");
                        } else {
//Date expdt=null;
//                    if(driDetReq.getDocExpiration()!=null && driDetReq.getDocExpiration().trim().length()>0)
//                    {
//                    try {
//				expdt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse( driDetReq.getDocExpiration().trim());
//                                if(expdt==null )
//                                {
//                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
//						"Plz send expiration date in correct format(yyyy-MM-dd HH:mm:ss) ");
//				return derr.toString();
//                                }
//			} catch (Exception ex) {
//				ex.printStackTrace();
//				GigflexResponse derr = new GigflexResponse(400, new Date(),
//						"Plz send expiration date in correct format(yyyy-MM-dd HH:mm:ss) ");
//				return derr.toString();
//			}
//                    }
                        	Date expdt = null;
							try {
								expdt = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
										.parse(driDetReq.getDocExpiration().trim());
								if (expdt == null) {
									GigflexResponse derr = new GigflexResponse(400, new Date(),
											"Plz send date in correct format(" + GigflexConstants.dateFormatterForSave
													+ ") ");
									return derr.toString();
								}

							} catch (Exception ex) {
								ex.printStackTrace();
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Plz send date in correct format(" + GigflexConstants.dateFormatterForSave
												+ ") ");
								return derr.toString();
							}
//							TimeZoneDetail tz = operatorDocumentRepository.getTimeZoneByOperatorCode(driDetReq.getOperatorCode());
//							Date docExptime = GigflexDateUtil.convertStringDateToGMT(
//									driDetReq.getDocExpiration().trim(), tz.getTimeZoneName(),
//									GigflexConstants.dateFormatterForSave);
String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, otr.getOrganizationCode(), GigflexConstants.TimeZone);
TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
String timezone = tz.getTimeZoneName(); 

Date docExptime = GigflexDateUtil.convertStringDateToGMT(
driDetReq.getDocExpiration().trim(), timezone,
GigflexConstants.dateFormatterForSave);                      
                                                        
							if (docExptime == null) {
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Date conversion has been failed.");
								return derr.toString();
							}
                            ddoc.setDocExpiration(docExptime);
                            ddoc.setDocValue(driDetReq.getDocValue());
                            ddoc.setDocumentCode(driDetReq.getDocumentCode());
                            ddoc.setOperatorCode(driDetReq.getOperatorCode());
                            ddoc.setIpAddress(ip);

                            OperatorDocument ddRes = operatorDocumentRepository.save(ddoc);
                            if (ddRes != null && ddRes.getId() > 0) {
                               kafkaService.sendOperatorDocumentForUpdate(ddRes);
                                jsonobj.put("responsecode", 200);
                                jsonobj.put("message", "Operator Document has been updated");
                                jsonobj.put("timestamp", new Date());
                                ObjectMapper mapperObj = new ObjectMapper();
                                String Detail = mapperObj.writeValueAsString(ddRes);
                                jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                jsonobj.put("responsecode", 400);
                                jsonobj.put("message", "Operator Document updation has been failed.");
                                jsonobj.put("timestamp", new Date());
                            }
                        }
                    } else {
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("message", "Operator Document Code is not valid.");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("message", "Operator does not exist.");
                    jsonobj.put("timestamp", new Date());
                }
            } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Document Code is not valid.");
                jsonobj.put("timestamp", new Date());
            }

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;
    }

	@Override
	public String getAllOperatorDocument(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
	        Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = operatorDocumentRepository
					.getAllOperatorDocument(pageableRequest);
			List<OperatorDocResponse> maplst = new ArrayList<OperatorDocResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						OperatorDocResponse odr = new OperatorDocResponse();

						OperatorDocument data = (OperatorDocument) arr[0];
						
						String conDt = "";

						if (data.getDocExpiration() != null) {
							TimeZoneDetail tz = operatorDocumentRepository.getTimeZoneByOperatorCode(data.getOperatorCode());
							Date docExpDate = data.getDocExpiration();
							docExpDate = GigflexDateUtil.getGMTtoLocationDate(docExpDate, tz.getTimeZoneName(),
									GigflexConstants.dateFormatterForView);
							conDt = GigflexDateUtil.converDateToString(docExpDate);
						}

						odr.setId(data.getId());
						odr.setOperatorDocumentCode(data
								.getOperatorDocumentCode());
						odr.setOperatorCode(data.getOperatorCode());
						odr.setDocumentCode(data.getDocumentCode());

						odr.setDocValue(data.getDocValue());
						odr.setDocExpiration(conDt);

						odr.setDocumentName((String) arr[1]);
						odr.setOperatorName((String) arr[2]);

						maplst.add(odr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllOperatorDocumentByOperatorCode(String operatorCode,
			int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
	        Pageable pageableRequest = PageRequest.of(page, limit);

			List<Object> objlst = operatorDocumentRepository.getAllOperatorDocumentByOperatorCode(operatorCode,pageableRequest);
			List<OperatorDocResponse> maplst = new ArrayList<OperatorDocResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						OperatorDocResponse odr = new OperatorDocResponse();

						OperatorDocument data = (OperatorDocument) arr[0];
						String conDt = "";

						if (data.getDocExpiration() != null) {
							TimeZoneDetail tz = operatorDocumentRepository.getTimeZoneByOperatorCode(data.getOperatorCode());
							Date docExpDate = data.getDocExpiration();
							docExpDate = GigflexDateUtil.getGMTtoLocationDate(docExpDate, tz.getTimeZoneName(),
									GigflexConstants.dateFormatterForView);
							conDt = GigflexDateUtil.converDateToString(docExpDate);
						}

						odr.setId(data.getId());
						odr.setOperatorDocumentCode(data
								.getOperatorDocumentCode());
						odr.setOperatorCode(data.getOperatorCode());
						odr.setDocumentCode(data.getDocumentCode());

						odr.setDocValue(data.getDocValue());
						odr.setDocExpiration(conDt);

						odr.setDocumentName((String) arr[1]);
						odr.setOperatorName((String) arr[2]);

						maplst.add(odr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

    @Override
    public String getDocumentExpirationStatusByOperatorCode(String operatorCode) {
        String res = "";
        try {
            DocumentExpirationByOperator documentExpirationByOperator = new DocumentExpirationByOperator();
            documentExpirationByOperator.setIsExpired(Boolean.FALSE);
            JSONObject jsonobj = new JSONObject();
            Operator operator = operatorRepository.getOperatorByOperatorCode(operatorCode);
            if (operator != null && operator.getId() > 0) {
                List<OperatorDocument> operatorDocument = operatorDocumentRepository.getOperatorDocumentExpirationByOperatorCode(operatorCode, new Date());
                if (operatorDocument != null && operatorDocument.size() > 0) {
                    documentExpirationByOperator.setIsExpired(Boolean.TRUE);
                    documentExpirationByOperator.setOperator(operator);
                }
                List<String> driverDetails = operatorDocumentRepository.getDriverExpiredDocumentDetail(new Date(), operatorCode);
                List<Driver> driversList = new ArrayList<Driver>();
                if (!driverDetails.isEmpty() && driverDetails.size() > 0) {
                    documentExpirationByOperator.setIsExpired(Boolean.TRUE);
                    for (String driverCode : driverDetails) {
                        Driver driverData = driverRepository.getDriverByDriverCode(driverCode);
                        driversList.add(driverData);
                    }
                }
                if (!driversList.isEmpty() && driversList.size() > 0) {
                    documentExpirationByOperator.setDrivers(driversList);
                }
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(documentExpirationByOperator);
                jsonobj.put("responsecode", 200);
                jsonobj.put("message", "Success");
                jsonobj.put("timestamp", new Date());
                jsonobj.put("data", new JSONObject(Detail));
            } else {
                jsonobj.put("responsecode", 404);
                jsonobj.put("message", "Operator does not exist");
                jsonobj.put("timestamp", new Date());
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
        return res;
    }
    
}
