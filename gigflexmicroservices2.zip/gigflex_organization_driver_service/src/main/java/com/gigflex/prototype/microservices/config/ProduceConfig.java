/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocument;
import com.gigflex.prototype.microservices.documentmapping.dtob.OperatorDocument;
import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetail;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.dtob.DriverRegistrationOTPDetail;
import com.gigflex.prototype.microservices.driver.dtob.Users;
import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.organization.dtob.Organization;

/**
 *
 * @author nirbhay.p
 */
@Configuration
public class ProduceConfig {
    @Bean
    public Map<String, Object> producerConfigs() {

         Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        return props;
    }
    
    
    @Bean
    public ProducerFactory<String, Users> producerFactory() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Users> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }
    
    @Bean
    public ProducerFactory<String, Driver> producerFactoryDriver() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Driver> kafkaTemplateDriver() {
        return new KafkaTemplate<>(producerFactoryDriver());
    }
    
    
    @Bean
    public ProducerFactory<String, Organization> producerFactoryOrganization() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Organization> kafkaTemplateOrganization() {
        return new KafkaTemplate<>(producerFactoryOrganization());
    }
    
    @Bean
    public ProducerFactory<String, Operator> producerFactoryOperator() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Operator> kafkaTemplateOperator() {
        return new KafkaTemplate<>(producerFactoryOperator());
    }
    
    
    @Bean
    public ProducerFactory<String, DocumentTypeDetail> producerFactoryDocumentTypeDetail() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, DocumentTypeDetail> kafkaTemplateDocumentTypeDetail() {
        return new KafkaTemplate<>(producerFactoryDocumentTypeDetail());
    }
    
    @Bean
    public ProducerFactory<String, DriverDocument> producerFactoryDriverDocument() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, DriverDocument> kafkaTemplateDriverDocument() {
        return new KafkaTemplate<>(producerFactoryDriverDocument());
    }
    
    
    @Bean
    public ProducerFactory<String, OperatorDocument> producerFactoryOperatorDocument() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, OperatorDocument> kafkaTemplateOperatorDocument() {
        return new KafkaTemplate<>(producerFactoryOperatorDocument());
    }
    
    @Bean
    public ProducerFactory<String, DriverRegistrationOTPDetail> producerFactoryDriverRegistrationToken() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, DriverRegistrationOTPDetail> kafkaTemplateDriverRegistrationToken() {
        return new KafkaTemplate<>(producerFactoryDriverRegistrationToken());
    }
    
    @Bean
    public ProducerFactory<String, Notification> producerFactoryNotifications() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Notification> kafkaNotificationsTemplate() {
        return new KafkaTemplate<>(producerFactoryNotifications());
    }
    
    
    
    
}
