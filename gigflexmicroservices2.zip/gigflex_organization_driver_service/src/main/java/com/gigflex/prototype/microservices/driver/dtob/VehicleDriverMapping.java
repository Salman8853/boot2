package com.gigflex.prototype.microservices.driver.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "vehicle_driver_mapping")
public class VehicleDriverMapping extends CommonAttributes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "vehicle_driver_code", unique = true)
	private String vehicleDriverCode;

	@Column(name = "driver_code", nullable = false)
	private String driverCode;

	@Column(name = "vehicle_code", nullable = false)
	private String vehicleCode;
	
	 @PrePersist
	    private void assignUUID() {
	        if(this.getVehicleDriverCode()==null || this.getVehicleDriverCode().length()==0)
	        {
	            this.setVehicleDriverCode(UUID.randomUUID().toString());
	        }
	    }

	public VehicleDriverMapping() {
		super();
		// TODO Auto-generated constructor stub
	}

	public VehicleDriverMapping(Long id, String vehicleDriverCode, String driverCode, String vehicleCode) {
		super();
		this.id = id;
		this.vehicleDriverCode = vehicleDriverCode;
		this.driverCode = driverCode;
		this.vehicleCode = vehicleCode;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVehicleDriverCode() {
		return vehicleDriverCode;
	}

	public void setVehicleDriverCode(String vehicleDriverCode) {
		this.vehicleDriverCode = vehicleDriverCode;
	}

	public String getDriverCode() {
		return driverCode;
	}

	public void setDriverCode(String driverCode) {
		this.driverCode = driverCode;
	}

	public String getVehicleCode() {
		return vehicleCode;
	}

	public void setVehicleCode(String vehicleCode) {
		this.vehicleCode = vehicleCode;
	}
	
	

}
