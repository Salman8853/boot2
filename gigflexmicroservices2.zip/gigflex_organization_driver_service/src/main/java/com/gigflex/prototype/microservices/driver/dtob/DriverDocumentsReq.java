/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.dtob;

/**
 *
 * @author m.salman
 */
public class DriverDocumentsReq {
    private String driverDocumentCode;
    private String documentCode;
    private String docValue;

    private String docExpiration;
   

    public String getDriverDocumentCode() {
        return driverDocumentCode;
    }

    public void setDriverDocumentCode(String driverDocumentCode) {
        this.driverDocumentCode = driverDocumentCode;
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getDocValue() {
        return docValue;
    }

    public void setDocValue(String docValue) {
        this.docValue = docValue;
    }

  

    public String getDocExpiration() {
        return docExpiration;
    }

    public void setDocExpiration(String docExpiration) {
        this.docExpiration = docExpiration;
    }

    
    
}
