package com.gigflex.prototype.microservices.globalridetype.api;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.globalridetype.dtob.GlobalRideTypeRequest;
import com.gigflex.prototype.microservices.globalridetype.service.GlobalRideTypeService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class GlobalRideTypeController {
	
	@Autowired
	private GlobalRideTypeService globalRideTypeService;
	
	@GetMapping(path="/getAllGlobalRideTypeByPage")
    public String getAllGlobalRideTypeByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String grt = globalRideTypeService.getAllGlobalRideType(page, limit);
      
        return grt;
       
    }
	
	@GetMapping(path="/getAllGlobalRideType")
    public String getAllGlobalRideType() {

        return globalRideTypeService.getAllGlobalRideType();
      
        
       
    }
	
	@PostMapping("/createGlobalRideType")
	public String createGlobalRideType(
			 @RequestBody GlobalRideTypeRequest globalRideTypeReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return globalRideTypeService.saveNewGlobalRideType(globalRideTypeReq, ip);

	}

	
    @GetMapping("/getGlobalRideTypeByGlobalRideCode/{globalRideCode}")
	public String getGlobalRideTypeByGlobalRideCode(@PathVariable String globalRideCode) {
		return globalRideTypeService.getGlobalRideTypeByGlobalRideCode(globalRideCode);
	}
   @GetMapping(path="/getAllGlobalRideTypeByPageByorganizationCode/{organizationCode}")
    public String getAllGlobalRideTypeByPageByorgCode(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String grt = globalRideTypeService.getAllGlobalRideTypeByorganizationCode(organizationCode,page, limit);
      
        return grt;
       
    }  
     @GetMapping("/getGlobalRideTypeByGlobalRideCodewithorgCode/{globalRideCode}/{organizationCode}")
	public String getGlobalRideTypeByGlobalRideCodewithorgCode(@PathVariable String globalRideCode,@PathVariable String organizationCode) {
		return globalRideTypeService.getGlobalRideTypeByGlobalRideCodewithorgCode(globalRideCode,organizationCode);
	}
        
        @GetMapping(path="/getAllGlobalRideTypeByorgCode/{organizationCode}")
        public String getAllGlobalRideTypeByorgCode(@PathVariable String organizationCode ) {

        return globalRideTypeService.getAllGlobalRideTypeByorgCode(organizationCode);
    }
        
}
