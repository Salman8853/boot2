package com.gigflex.prototype.microservices.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocument;
import com.gigflex.prototype.microservices.documentmapping.dtob.OperatorDocument;
import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetail;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.dtob.DriverRegistrationOTPDetail;
import com.gigflex.prototype.microservices.driver.dtob.Users;
import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.notifications.config.Notifications;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.organization.dtob.Organization;



@Service
public class KafkaService {
     
     @Autowired
     private KafkaTemplate<String, Driver> kafkaDriverTemplate;
     
     @Autowired
     private KafkaTemplate<String, Organization> kafkaOrganizationTemplate; 
                 
     @Autowired
     private KafkaTemplate<String, Operator> kafkaOperatorTemplate;
     
     @Autowired
     private KafkaTemplate<String, Users> kafkaDriverForUserTemplate;
     
     @Autowired
     private KafkaTemplate<String, DocumentTypeDetail> kafkaDocumentTypeDetailTemplate;
     
     @Autowired
     private KafkaTemplate<String, DriverDocument> kafkaDriverDocumentTemplate;
     
     @Autowired
     private KafkaTemplate<String, OperatorDocument> kafkaOperatorDocumentTemplate;
     
     @Autowired
     private KafkaTemplate<String, DriverRegistrationOTPDetail> kafkaDriverRegistrationOTPTemplate;
     
     @Autowired
     private KafkaTemplate<String, Notification> kafkaNotificationsTemplate;
     
     
    String kafkaTopicForDriver = "AddNewDriverFromDriverOrg";
    String kafkaTopicForOrganization = "UpdateOrganizationFromDriverOrg";
    String kafkaTopicForUsersUpdate = "UpdateUsersFromDriverOrg";
    String kafkaTopicDriverUpdate = "UpdateDriverFromDriverOrg";
    String kafkaTopicToAddDriverInUser = "AddDriverInUserRegistration";
    
   String kafkaTopicForAddDocumentTypeDetail = "AddDocumentTypeDetail";
   String kafkaTopicForUpdateDocumentTypeDetail = "UpdateDocumentTypeDetail";
   
   String kafkaTopicForAddDriverDocument = "AddDriverDocument";
   String kafkaTopicForUpdateDriverDocument = "UpdateDriverDocument";
   
   String kafkaTopicForAddOperatorDocument = "AddOperatorDocument";
   String kafkaTopicForUpdateOperatorDocument = "UpdateOperatorDocument";

   String kafkaTopicForDriverRegistrationOTP = "AddDriverRegistrationOTPDetail";

   String kafkaTopicForUpdateOperator = "UpdateOperatorFromDriverOrg";
   
   String kafkaTopicForSendNotifications = "AddNewNotification";

   public void sendOrganizationForUpdate(Organization message){
       kafkaOrganizationTemplate.send(kafkaTopicForOrganization, message);
    } 
   
    public void sendDriverForSave(Driver message){
       kafkaDriverTemplate.send(kafkaTopicForDriver, message);
    }
    public void sendDriverForUpdate(Driver message){
       kafkaDriverTemplate.send(kafkaTopicDriverUpdate, message);
    }
    
    public void sendOperatorForUpdate(Operator message){
       kafkaOperatorTemplate.send(kafkaTopicForUpdateOperator, message);
    }
    
    public void sendDriverToUser(Users message){
       kafkaDriverForUserTemplate.send(kafkaTopicToAddDriverInUser, message);
    }
    
    public void sendUpdateUser(Users message){
       kafkaDriverForUserTemplate.send(kafkaTopicForUsersUpdate, message);
    }
    
    public void sendDocumentTypeDetailForSave(DocumentTypeDetail message){
       kafkaDocumentTypeDetailTemplate.send(kafkaTopicForAddDocumentTypeDetail, message);
    }
    public void sendDocumentTypeDetailForUpdate(DocumentTypeDetail message){
       kafkaDocumentTypeDetailTemplate.send(kafkaTopicForUpdateDocumentTypeDetail, message);
    }
    
    
     public void sendDriverDocumentForSave(DriverDocument message){
       kafkaDriverDocumentTemplate.send(kafkaTopicForAddDriverDocument, message);
    }
    public void sendDriverDocumentForUpdate(DriverDocument message){
       kafkaDriverDocumentTemplate.send(kafkaTopicForUpdateDriverDocument, message);
    }
    
     public void sendOperatorDocumentForSave(OperatorDocument message){
       kafkaOperatorDocumentTemplate.send(kafkaTopicForAddOperatorDocument, message);
    }
    public void sendOperatorDocumentForUpdate(OperatorDocument message){
       kafkaOperatorDocumentTemplate.send(kafkaTopicForUpdateOperatorDocument, message);
    }
    public void sendDriverRegistrationOTP(DriverRegistrationOTPDetail message){
       kafkaDriverRegistrationOTPTemplate.send(kafkaTopicForDriverRegistrationOTP, message);
    }
    
    public void sendNotifications(Notification message){
    	kafkaNotificationsTemplate.send(kafkaTopicForSendNotifications, message);
     }
}
