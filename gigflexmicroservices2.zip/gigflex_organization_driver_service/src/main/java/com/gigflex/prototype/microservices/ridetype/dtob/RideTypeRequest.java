package com.gigflex.prototype.microservices.ridetype.dtob;


public class RideTypeRequest {
	
    private String vehicleName;
    
    private Double baseRate;
    
    private Double ratePerMile;
    
    private String organizationCode;
    
     private String globalRidetypeCode;

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public Double getBaseRate() {
		return baseRate;
	}

	public void setBaseRate(Double baseRate) {
		this.baseRate = baseRate;
	}

	public Double getRatePerMile() {
		return ratePerMile;
	}

	public void setRatePerMile(Double ratePerMile) {
		this.ratePerMile = ratePerMile;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

    public String getGlobalRidetypeCode() {
        return globalRidetypeCode;
    }

    public void setGlobalRidetypeCode(String globalRidetypeCode) {
        this.globalRidetypeCode = globalRidetypeCode;
    }
    
    

}
