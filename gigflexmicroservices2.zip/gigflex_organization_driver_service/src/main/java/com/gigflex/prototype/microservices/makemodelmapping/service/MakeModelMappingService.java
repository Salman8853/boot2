package com.gigflex.prototype.microservices.makemodelmapping.service;

import java.util.List;


import com.gigflex.prototype.microservices.makemodelmapping.dtob.MakeModelMappingRequest;

public interface MakeModelMappingService {
	
	public String getAllMakeModelMapping();
	public String getMakeModelMappingById(Long id);
	public String saveNewMakeModelMapping(MakeModelMappingRequest makeModelMapReq, String ip);
	public String updateMakeModelMappingById(Long id,MakeModelMappingRequest makeModelMapReq, String ip);
	public String softDeleteMakeModelMappingByModelCode(String modelCode);
    public String softMultipleDeleteByModelCode(List<String> modelCodeList);
    public String getAllMakeModelMappingByPage(int page, int limit);
    public String search(String search);
	public String getByModelCode(String modelCode);

    public String getModelByMakeCode(String makeCode);
    public String getModelByMakeCodeByPage(String makeCode,int page, int limit);


}
