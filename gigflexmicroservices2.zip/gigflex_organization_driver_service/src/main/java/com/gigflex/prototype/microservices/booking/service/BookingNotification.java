/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.booking.service;

import java.util.Date;

/**
 *
 * @author nirbhay.p
 */
public interface BookingNotification {
   
    
	public void sendNotification();
        
        public void setExpired();
        
        public void sendDocumentExpiryNotification();

	public String getAllAcceptedUpcomingBooking();

	public String getAllAcceptedUpcomingBookingByPage(int page, int limit);

	public String getAllAcceptedUpcomingBookingByOperatorCode(String operatorCode);

	public String getAllAcceptedUpcomingBookingByOperatorCodeByPage(String operatorCode, int page, int limit);

        public String getAllAcceptedUpcomingBookingByOrganizationCodeByPage(String organizationCode, int page, int limit);
//    public String getAllAcceptedUpcomingBookingByDriverCode(String driverCode);

//    public String getAllAcceptedUpcomingBookingByDriverCodeByPage(String driverCode,int page, int limit);
//    
	public String sendUpcomingBookingNotificationMail(String rideCode);
        public String sendUpcomingBookingNotificationSMS(String rideCode);

	public String getAllAcceptedUpcomingBookingByOperatorCodeByDate(String operatorCode, Date fromDT, Date toDT);

	public String getAllAcceptedUpcomingBookingByOperatorCodeByDateByPage(String operatorCode, Date fromDT, Date toDT,
			int page, int limit);
        public String sendMessageForUsers(String appKey, String appSecret,String url,String phoneNumber,String message);
}
