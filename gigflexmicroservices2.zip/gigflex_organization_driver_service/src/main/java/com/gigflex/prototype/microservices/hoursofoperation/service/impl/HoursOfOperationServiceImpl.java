/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.hoursofoperation.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBooking;
import com.gigflex.prototype.microservices.assignbooking.repository.AssignBookingRepository;
import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.booking.notification.SendNotification;
import com.gigflex.prototype.microservices.booking.repository.BookingDao;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.hoursofoperation.dtob.HoursOfOperation;
import com.gigflex.prototype.microservices.hoursofoperation.dtob.HoursOfOperationRequest;
import com.gigflex.prototype.microservices.hoursofoperation.dtob.HoursOfOperationResponse;
import com.gigflex.prototype.microservices.hoursofoperation.repository.HoursOfOperationDao;
import com.gigflex.prototype.microservices.hoursofoperation.service.HoursOfOperationService;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.utility.GigflexDateUtil;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */
@Service
public class HoursOfOperationServiceImpl implements HoursOfOperationService{

    private static final Logger LOG = LoggerFactory.getLogger(HoursOfOperationServiceImpl.class);
    @Autowired
    private HoursOfOperationDao hoursOfOperationDao;
    
    @Autowired
    private DriverRepository driverRepository;
     
    @Autowired
    GlobalSettingRepository globalSettingRepository;
    
    @Autowired
    LocalSettingRepository localSettingRepository;
    
    @Autowired
    UserTypeRepository utr;
    
    @Autowired
    BookingDao bookingDao;
    
    @Autowired
    AssignBookingRepository   assignBookingDao;
    
    @Autowired
    OperatorRepository operatorDao;
    
    @Value("${email.service.url}")
    private String mailServiceURL ;
//    "http://18.223.158.6:8091/superadminservice/sendEmail/to/{to}/subject/{subject}/body/{body}";
    
    @Value("${email.hoursofoperation.vehiclechange.subject}")
    private String subject;
    
    @Override
    public String findAllHoursOfOperation() {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        List<Object> objList = hoursOfOperationDao.getAllHoursOfOperation();
                        List<HoursOfOperationResponse> hoursOfOperationResponseList = new ArrayList<HoursOfOperationResponse>();


                        if(objList != null && objList.size() > 0)
                        {
                            
                            for(int i =0;i<objList.size();i++)
                           {
                                Object[] arr = (Object[]) objList.get(i);
                                if (arr.length >= 3) {
                                HoursOfOperation hoursOfOperationData = (HoursOfOperation) arr[0];
                                String vehicleType = (String) arr[1];
                                String vehicleTypeName = (String) arr[2];

                                String timeformat = GigflexConstants.HH_MM_SS;
                                Driver driver = driverRepository.getDriverByDriverCode(hoursOfOperationData.getDriverCode());
                                String organizationCode = driver.getOrganizationCode();   

                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);

                                if(timeformat!=null && timeformat.trim().length()>0)
                               {
                                    timeformat=timeformat.trim();
                               }
                               else
                               {
                                   timeformat = GigflexConstants.HH_MM_SS;
                               }
                               
                               HoursOfOperationResponse hoursOfOperationRes = new HoursOfOperationResponse();
                               hoursOfOperationRes.setId(hoursOfOperationData.getId()); 
                               hoursOfOperationRes.setHoursOfOperationCode(hoursOfOperationData.getHoursOfOperationCode()); 
                               hoursOfOperationRes.setDayCode(hoursOfOperationData.getDayCode());
                               hoursOfOperationRes.setVehicleCode(hoursOfOperationData.getVehicleCode()); 
                               hoursOfOperationRes.setDriverCode(hoursOfOperationData.getDriverCode()); 
                               driver = driverRepository.getDriverByDriverCode(hoursOfOperationData.getDriverCode());
                               if(driver != null)
                               {
                                   hoursOfOperationRes.setDriverName(driver.getName()); 
                               }                           

                               Date fromTime = GigflexDateUtil.convertStringToDate(hoursOfOperationData.getFromTime(), GigflexConstants.HH_MM_SS); 
                               if(fromTime != null )
                               {
                                   hoursOfOperationRes.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
                               }
                               else
                               {
                                   hoursOfOperationRes.setFromTime("");
                               }                                 

                               Date toTime = GigflexDateUtil.convertStringToDate(hoursOfOperationData.getToTime(), GigflexConstants.HH_MM_SS); 

                               if(toTime != null)
                               {
                                   hoursOfOperationRes.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
                               }
                               else
                               {
                                   hoursOfOperationRes.setToTime("");
                               }                                                              

                               hoursOfOperationRes.setVehicleType(vehicleType);
                               hoursOfOperationRes.setVehicleTypeName(vehicleTypeName); 

                               hoursOfOperationResponseList.add(hoursOfOperationRes);

                              }
                               
                            }
                        }
                        else
                        {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("message", "Record Not Found.");
                                jsonobj.put("timestamp", new Date());
                        }
                        
			if (hoursOfOperationResponseList != null && hoursOfOperationResponseList.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(hoursOfOperationResponseList);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
                        ex.printStackTrace();
                        LOG.info(ex.toString()); 
		} catch (Exception ex) {
                   
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
                        ex.printStackTrace();
                        LOG.info(ex.toString()); 
            }
		return res;
    }
    
    @Override
    public String findHoursOfOperationByDriverCode(String drivercode) {
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        if(drivercode != null && drivercode.trim().length() > 0)
                        {
                        
                            List<Object> objList = hoursOfOperationDao.getHoursOfOperationByDriverCode(drivercode);
                            List<HoursOfOperationResponse> hoursOfOperationResponseList = new ArrayList<HoursOfOperationResponse>();
                            

                            if(objList != null && objList.size() > 0)
                            {
                                String timeformat = GigflexConstants.HH_MM_SS;
                                Driver driver = driverRepository.getDriverByDriverCode(drivercode);
                                String organizationCode = driver.getOrganizationCode();   

                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);

                                if(timeformat!=null && timeformat.trim().length()>0)
                               {
                                    timeformat=timeformat.trim();
                               }
                               else
                               {
                                   timeformat = GigflexConstants.HH_MM_SS;
                                   
                               }
                            
                            
                             for(int i =0;i<objList.size();i++)
                            {
                                
                                Object[] arr = (Object[]) objList.get(i);
                                if (arr.length >= 3) {
                                HoursOfOperation hoursOfOperationData = (HoursOfOperation) arr[0];
                                String vehicleType = (String) arr[1];
                                String vehicleTypeName = (String) arr[2];
                                
                                HoursOfOperationResponse hoursOfOperationRes = new HoursOfOperationResponse();
                                hoursOfOperationRes.setId(hoursOfOperationData.getId()); 
                                hoursOfOperationRes.setHoursOfOperationCode(hoursOfOperationData.getHoursOfOperationCode()); 
                                hoursOfOperationRes.setDayCode(hoursOfOperationData.getDayCode());
                                hoursOfOperationRes.setVehicleCode(hoursOfOperationData.getVehicleCode()); 
                                hoursOfOperationRes.setDriverCode(hoursOfOperationData.getDriverCode()); 
                                driver = driverRepository.getDriverByDriverCode(hoursOfOperationData.getDriverCode());
                                if(driver != null)
                                {
                                    hoursOfOperationRes.setDriverName(driver.getName()); 
                                }                           
                                                             
                                Date fromTime = GigflexDateUtil.convertStringToDate(hoursOfOperationData.getFromTime(), GigflexConstants.HH_MM_SS); 
                                if(fromTime != null )
                                {
                                    hoursOfOperationRes.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
                                }
                                else
                                {
                                    hoursOfOperationRes.setFromTime("");
                                }                                 
                                                               
                                Date toTime = GigflexDateUtil.convertStringToDate(hoursOfOperationData.getToTime(), GigflexConstants.HH_MM_SS); 

                                if(toTime != null)
                                {
                                    hoursOfOperationRes.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
                                }
                                else
                                {
                                    hoursOfOperationRes.setToTime("");
                                }                                                              
                               
                                hoursOfOperationRes.setVehicleType(vehicleType);
                                hoursOfOperationRes.setVehicleTypeName(vehicleTypeName); 

                                hoursOfOperationResponseList.add(hoursOfOperationRes);

                               }
                               
                            }
                        }
                        else
                        {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("message", "Record Not Found.");
                                jsonobj.put("timestamp", new Date());
                        }
                        
			if (hoursOfOperationResponseList != null && hoursOfOperationResponseList.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(hoursOfOperationResponseList);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
                        
                        
                        }
                        else
                        {
                            
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Record Not Found.");
                            jsonobj.put("timestamp", new Date());
                            
                        }
                        
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
                        ex.printStackTrace();
                        LOG.info(ex.toString()); 
		} catch (Exception ex) {
                   
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
                        ex.printStackTrace();
                        LOG.info(ex.toString()); 
            }
		return res;
    }

    @Override
    public String findHoursOfOperationByHoursOfOperationCode(String hoursOfOperationCode) {
       
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        if(hoursOfOperationCode != null && hoursOfOperationCode.trim().length() > 0)
                        {
                        
                            Object obj = hoursOfOperationDao.getHoursOfOperationByHoursOfOperationCode(hoursOfOperationCode);
                            HoursOfOperationResponse hoursOfOperationRes = null;
                            
                            if(obj != null )
                            {
                               
                            
                                Object[] arr = (Object[]) obj;
                                 
                                if (arr.length >= 3) {
                                    
                                    HoursOfOperation hoursOfOperationData = (HoursOfOperation) arr[0];
                                    String vehicleType = (String) arr[1];
                                    String vehicleTypeName = (String) arr[2];
                                
                                    String timeformat = GigflexConstants.HH_MM_SS;
                                    Driver driver = driverRepository.getDriverByDriverCode(hoursOfOperationData.getDriverCode());
                                    String organizationCode = driver.getOrganizationCode();   

                                    timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);

                                    if(timeformat!=null && timeformat.trim().length()>0)
                                    {
                                         timeformat=timeformat.trim();
                                    }
                                    else
                                    {
                                        timeformat = GigflexConstants.HH_MM_SS;

                                    }
                                    
                                
                                    hoursOfOperationRes = new HoursOfOperationResponse();
                                    hoursOfOperationRes.setId(hoursOfOperationData.getId()); 
                                    hoursOfOperationRes.setHoursOfOperationCode(hoursOfOperationData.getHoursOfOperationCode()); 
                                    hoursOfOperationRes.setDayCode(hoursOfOperationData.getDayCode());
                                    hoursOfOperationRes.setVehicleCode(hoursOfOperationData.getVehicleCode()); 
                                    hoursOfOperationRes.setDriverCode(hoursOfOperationData.getDriverCode()); 
                                    driver = driverRepository.getDriverByDriverCode(hoursOfOperationData.getDriverCode());
                                    if(driver != null)
                                    {
                                        hoursOfOperationRes.setDriverName(driver.getName()); 
                                    }                           
                                                             
                                    Date fromTime = GigflexDateUtil.convertStringToDate(hoursOfOperationData.getFromTime(), GigflexConstants.HH_MM_SS); 
                                    if(fromTime != null )
                                    {
                                        hoursOfOperationRes.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
                                    }
                                    else
                                    {
                                        hoursOfOperationRes.setFromTime("");
                                    }                                 

                                    Date toTime = GigflexDateUtil.convertStringToDate(hoursOfOperationData.getToTime(), GigflexConstants.HH_MM_SS); 

                                    if(toTime != null)
                                    {
                                        hoursOfOperationRes.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
                                    }
                                    else
                                    {
                                        hoursOfOperationRes.setToTime("");
                                    }                                                              

                                    hoursOfOperationRes.setVehicleType(vehicleType);
                                    hoursOfOperationRes.setVehicleTypeName(vehicleTypeName);  
                               }
                               
                            
                        }
                        else
                        {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("message", "Record Not Found.");
                                jsonobj.put("timestamp", new Date());
                        }
                        
			if (hoursOfOperationRes != null && hoursOfOperationRes.getId()> 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(hoursOfOperationRes);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
                        
                        
                        }
                        else
                        {
                            
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Record Not Found.");
                            jsonobj.put("timestamp", new Date());
                            
                        }
                        
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
                        ex.printStackTrace();
                        LOG.info(ex.toString()); 
		} catch (Exception ex) {
                   java.util.logging.Logger.getLogger(HoursOfOperationServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
                    res = derr.toString();
                    ex.printStackTrace();
                    LOG.info(ex.toString()); 
            }
		return res;
    }

    @Override
    public String findHoursOfOperationByDriverCodeAndDayCode(String drivercode, Integer dayCode) {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        if(drivercode != null && drivercode.trim().length() > 0 && dayCode != null)
                        {
                        
                            Object obj = hoursOfOperationDao.getHoursOfOperationByDriverCodeAndDayCode(drivercode,dayCode);
                            HoursOfOperationResponse hoursOfOperationRes = null;
                            
                            if(obj != null )
                            {
                               
                            
                                Object[] arr = (Object[]) obj;
                                 
                                if (arr.length >= 3) {
                                    
                                    HoursOfOperation hoursOfOperationData = (HoursOfOperation) arr[0];
                                    String vehicleType = (String) arr[1];
                                    String vehicleTypeName = (String) arr[2];
                                
                                    String timeformat = GigflexConstants.HH_MM_SS;
                                    Driver driver = driverRepository.getDriverByDriverCode(hoursOfOperationData.getDriverCode());
                                    String organizationCode = driver.getOrganizationCode();   

                                    timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);

                                    if(timeformat!=null && timeformat.trim().length()>0)
                                    {
                                         timeformat=timeformat.trim();
                                    }
                                    else
                                    {
                                        timeformat = GigflexConstants.HH_MM_SS;

                                    }
                                    
                                
                                    hoursOfOperationRes = new HoursOfOperationResponse();
                                    hoursOfOperationRes.setId(hoursOfOperationData.getId()); 
                                    hoursOfOperationRes.setHoursOfOperationCode(hoursOfOperationData.getHoursOfOperationCode()); 
                                    hoursOfOperationRes.setDayCode(hoursOfOperationData.getDayCode());
                                    hoursOfOperationRes.setVehicleCode(hoursOfOperationData.getVehicleCode()); 
                                    hoursOfOperationRes.setDriverCode(hoursOfOperationData.getDriverCode()); 
                                    driver = driverRepository.getDriverByDriverCode(hoursOfOperationData.getDriverCode());
                                    if(driver != null)
                                    {
                                        hoursOfOperationRes.setDriverName(driver.getName()); 
                                    }                           
                                                             
                                    Date fromTime = GigflexDateUtil.convertStringToDate(hoursOfOperationData.getFromTime(), GigflexConstants.HH_MM_SS); 
                                    if(fromTime != null )
                                    {
                                        hoursOfOperationRes.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
                                    }
                                    else
                                    {
                                        hoursOfOperationRes.setFromTime("");
                                    }                                 

                                    Date toTime = GigflexDateUtil.convertStringToDate(hoursOfOperationData.getToTime(), GigflexConstants.HH_MM_SS); 

                                    if(toTime != null)
                                    {
                                        hoursOfOperationRes.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
                                    }
                                    else
                                    {
                                        hoursOfOperationRes.setToTime("");
                                    }                                                              

                                   hoursOfOperationRes.setVehicleType(vehicleType);
                                   hoursOfOperationRes.setVehicleTypeName(vehicleTypeName); 
                               }
                               
                            
                        }
                        else
                        {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("message", "Record Not Found.");
                                jsonobj.put("timestamp", new Date());
                        }
                        
			if (hoursOfOperationRes != null && hoursOfOperationRes.getId()> 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(hoursOfOperationRes);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
                        
                        
                        }
                        else
                        {
                            
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Record Not Found.");
                            jsonobj.put("timestamp", new Date());
                            
                        }
                        
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
                        ex.printStackTrace();
                        LOG.info(ex.toString()); 
		} catch (Exception ex) {
                   java.util.logging.Logger.getLogger(HoursOfOperationServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
                        ex.printStackTrace();
                        LOG.info(ex.toString()); 
            }
		return res;
    }

   

    @Override
    public String saveHoursOfOperation(HoursOfOperationRequest hoursOfOperationReq, String ip) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (hoursOfOperationReq != null) {
                                                        
                            
			if (hoursOfOperationReq.getDriverCode()!=null && hoursOfOperationReq.getDriverCode().trim().length() > 0
                                && hoursOfOperationReq.getFromTime()!= null &&  hoursOfOperationReq.getFromTime().trim().length() > 0 
                                && hoursOfOperationReq.getToTime()!= null && hoursOfOperationReq.getToTime().trim().length() >0
                                && hoursOfOperationReq.getVehicleCode() != null && hoursOfOperationReq.getVehicleCode().trim().length() > 0
                                && hoursOfOperationReq.getDayCode() != null && hoursOfOperationReq.getDayCode()>0 &&  hoursOfOperationReq.getDayCode() < 8) {
                                       
                            
                               if(!GigflexDateUtil.isDate(hoursOfOperationReq.getFromTime().trim(), GigflexConstants.HH_MM_SS))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send From time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                               }
                               
                               if(!GigflexDateUtil.isDate(hoursOfOperationReq.getToTime().trim(), GigflexConstants.HH_MM_SS))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send To time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                               }
                                                           
                                
                               if(hoursOfOperationReq.getFromTime().trim().length() > 0)
                               {
                                   String strFromTime = hoursOfOperationReq.getFromTime();
                                   
                                   Date fromTime = GigflexDateUtil.convertStringToDate(strFromTime, GigflexConstants.HH_MM_SS); 
                                   if(fromTime == null)
                                   {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send from time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                                   }
                               }
                                
                               
                               if(hoursOfOperationReq.getToTime().trim().length() > 0)
                               {
                                   String strToTime = hoursOfOperationReq.getToTime();
                                   
                                   Date toTime = GigflexDateUtil.convertStringToDate(strToTime, GigflexConstants.HH_MM_SS); 
                                   if(toTime == null)
                                   {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send to time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                                   }
                               }
                                
                            HoursOfOperation checkAlreadyExist = hoursOfOperationDao.getHoursByDriverCodeAndDayCode(hoursOfOperationReq.getDriverCode(),hoursOfOperationReq.getDayCode());
                               
                            if( !(checkAlreadyExist != null && checkAlreadyExist.getId()> 0)) 
                            {
                                
                                Calendar calCurTime = Calendar.getInstance();
                                Date curFromTime = calCurTime.getTime();                                
                                int currentDay = calCurTime.get(Calendar.DAY_OF_WEEK);
                                
                                calCurTime.add(Calendar.HOUR_OF_DAY, 2);                           
                                Date curToTime = calCurTime.getTime();
                                
                                if(currentDay == hoursOfOperationReq.getDayCode())
                                {                                    
                                    List<Booking> bookingList = bookingDao.getAssignedBookingListByDriverCodeAndBetweenCurrntTime(hoursOfOperationReq.getDriverCode() ,curFromTime,curToTime,GigflexConstants.bookingStatus, GigflexConstants.assignedBookingAcceptedStatus,GigflexConstants.assignedBookingInProgressStatus);

                                    if(bookingList != null && bookingList.size() > 0)
                                    {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                        "Add of Hours of Operation is not allowed for given time period.");
                                        return derr.toString();
                                    }
                                }
                                
                                
                                HoursOfOperation hoursOfOperation = new HoursOfOperation();

                                hoursOfOperation.setIpAddress(ip);                            
                                hoursOfOperation.setDriverCode(hoursOfOperationReq.getDriverCode());
                                hoursOfOperation.setDayCode(hoursOfOperationReq.getDayCode());
                                hoursOfOperation.setVehicleCode(hoursOfOperationReq.getVehicleCode());
                                hoursOfOperation.setFromTime(hoursOfOperationReq.getFromTime());
                                hoursOfOperation.setToTime(hoursOfOperationReq.getToTime());  

                                HoursOfOperation hoursOfOperationRes = hoursOfOperationDao.save(hoursOfOperation);

                                if (hoursOfOperationRes != null && hoursOfOperationRes.getId() > 0) {
                                        jsonobj.put("responsecode", 200);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message",
                                                        "Hours Of Operation has been added successfully.");
                                        ObjectMapper mapperObj = new ObjectMapper();
                                        String Detail = mapperObj.writeValueAsString(hoursOfOperationRes);
                                        jsonobj.put("data", new JSONObject(Detail));
                                } else {

                                        jsonobj.put("responsecode", 400);
                                        jsonobj.put("timestamp", new Date());                                
                                        jsonobj.put("message", "Failed");
                                }
				
                            }
                            else
                            {
                                jsonobj.put("responsecode", 409);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("message", "Driver Code with Day Code already exist.");
                            }
                        
                        } else {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("message", "Driver Code , From Time , To Time,Vehicle Code & Day Code should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
                        ex.printStackTrace();
                        LOG.info(ex.toString());
		}
		return res;
        
    }

    @Override
    public String updateHoursOfOperationByHoursOfOperationCode(String hoursOfOperationCode, HoursOfOperationRequest hoursOfOperationReq, String ip) {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if ( hoursOfOperationCode != null && hoursOfOperationCode.trim().length() > 0 && hoursOfOperationReq != null) {
                            
				if (hoursOfOperationReq.getDriverCode()!=null && hoursOfOperationReq.getDriverCode().trim().length() > 0
                                && hoursOfOperationReq.getFromTime()!= null &&  hoursOfOperationReq.getFromTime().trim().length() > 0 
                                && hoursOfOperationReq.getToTime()!= null && hoursOfOperationReq.getToTime().trim().length() >0
                                && hoursOfOperationReq.getVehicleCode() != null && hoursOfOperationReq.getVehicleCode().trim().length() > 0
                                && hoursOfOperationReq.getDayCode() != null && hoursOfOperationReq.getDayCode()>0 &&  hoursOfOperationReq.getDayCode() < 8) {
                                    

                                if(!GigflexDateUtil.isDate(hoursOfOperationReq.getFromTime().trim(), GigflexConstants.HH_MM_SS))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send From time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                               }
                               
                               if(!GigflexDateUtil.isDate(hoursOfOperationReq.getToTime().trim(), GigflexConstants.HH_MM_SS))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send To time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                               }
                                                                
                                    
                                if(hoursOfOperationReq.getFromTime().trim().length() > 0)
                                {
                                      String strFromTime = hoursOfOperationReq.getFromTime();

                                      Date fromTime = GigflexDateUtil.convertStringToDate(strFromTime, GigflexConstants.HH_MM_SS); 
                                      if(fromTime == null)
                                      {
                                           GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                   "Plz send from time in correct format("+GigflexConstants.HH_MM_SS+") ");
                                                   return derr.toString();
                                      }
                                      else
                                      {
                                          strFromTime = GigflexDateUtil.convertDateToString(fromTime, GigflexConstants.HH_MM_SS) ;
                                          hoursOfOperationReq.setFromTime(strFromTime); 
                                      }
                                      
                                      
                                }
                            
                                    if(hoursOfOperationReq.getToTime().trim().length() > 0)
                                   {
                                       String strToTime = hoursOfOperationReq.getToTime();

                                       Date toTime = GigflexDateUtil.convertStringToDate(strToTime, GigflexConstants.HH_MM_SS); 
                                       if(toTime == null)
                                       {
                                            GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                    "Plz send to time in correct format("+GigflexConstants.HH_MM_SS+") ");
                                                    return derr.toString();
                                       }
                                       else
                                      {
                                          strToTime = GigflexDateUtil.convertDateToString(toTime, GigflexConstants.HH_MM_SS) ;
                                          hoursOfOperationReq.setToTime(strToTime); 
                                      }
                                   }
                                    
                                    HoursOfOperation checkAlreadyExist = hoursOfOperationDao.getHoursByDriverCodeDayCodeAndNotForHoursOfOperationCode(hoursOfOperationReq.getDriverCode(),hoursOfOperationReq.getDayCode(),hoursOfOperationCode);
                                
                                     if( !(checkAlreadyExist != null && checkAlreadyExist.getId() > 0))
                                     {
					HoursOfOperation hoursOfOperationInDb = hoursOfOperationDao.getHoursByHoursOfOperationCode(hoursOfOperationCode); 
					if (hoursOfOperationInDb != null && hoursOfOperationInDb.getId() > 0) {
                                            
                                                Calendar calCurTime = Calendar.getInstance();
                                                Date curFromTime = calCurTime.getTime();                                
                                                int currentDay = calCurTime.get(Calendar.DAY_OF_WEEK);

                                                calCurTime.add(Calendar.HOUR_OF_DAY, 2);                           
                                                Date curToTime = calCurTime.getTime();

                                                if(currentDay == hoursOfOperationReq.getDayCode())
                                                {                                    
                                                    List<Booking> bookingList = bookingDao.getAssignedBookingListByDriverCodeAndBetweenCurrntTime(hoursOfOperationReq.getDriverCode() ,curFromTime,curToTime,GigflexConstants.bookingStatus, GigflexConstants.assignedBookingAcceptedStatus,GigflexConstants.assignedBookingInProgressStatus);

                                                    if(bookingList != null && bookingList.size() > 0)
                                                    {
                                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                        "Updation of Hours of Operation is not allowed for given time period.");
                                                        return derr.toString();
                                                    }
                                                }

                                                boolean isVehicleUpdated = false;
                                                boolean isTimeChanged = false;
						if( !hoursOfOperationInDb.getVehicleCode().equals(hoursOfOperationReq.getVehicleCode())) 
                                                {
                                                    isVehicleUpdated = true;
                                                }
                                                
                                                if( !(hoursOfOperationInDb.getFromTime().trim().equals(hoursOfOperationReq.getFromTime().trim())) || !(hoursOfOperationInDb.getToTime().trim().equals(hoursOfOperationReq.getToTime().trim())) ) 
                                                {
                                                    isTimeChanged = true;
                                                }
                                                
                                                hoursOfOperationInDb.setIpAddress(ip);                            
                                                hoursOfOperationInDb.setDriverCode(hoursOfOperationReq.getDriverCode());
                                                hoursOfOperationInDb.setDayCode(hoursOfOperationReq.getDayCode());
                                                hoursOfOperationInDb.setVehicleCode(hoursOfOperationReq.getVehicleCode());
                                                hoursOfOperationInDb.setFromTime(hoursOfOperationReq.getFromTime());
                                                hoursOfOperationInDb.setToTime(hoursOfOperationReq.getToTime());  

						HoursOfOperation hoursOfOperationRes = hoursOfOperationDao.save(hoursOfOperationInDb);
						if (hoursOfOperationRes != null && hoursOfOperationRes.getId() > 0) {
                                                    
                                                    if(isVehicleUpdated)
                                                    {                                                        
                                                        List<Booking> bookingList = bookingDao.getAssignedAndAcceptedBookingListByDriverCode(hoursOfOperationInDb.getDriverCode(),GigflexConstants.bookingStatus, GigflexConstants.assignedBookingAcceptedStatus);
                                                        
                                                        if(bookingList != null && bookingList.size() > 0)
                                                        {
                                                            for(Booking booking : bookingList)
                                                            {
                                                                String rideCode = booking.getRideCode();

                                                                Booking bookingRes = bookingDao.getBookingByRideCode(rideCode);
                                                                AssignBooking assignBookingRes = assignBookingDao.getAssignBookingByRideCode(rideCode);
                                                                if(bookingRes != null && bookingRes.getId() > 0 && assignBookingRes != null && assignBookingRes.getId() > 0)
                                                                {
                                                                    String bookingOperatorCode = bookingRes.getOperatorCode();

                                                                    bookingRes.setBookingStatus(GigflexConstants.assignedBookingStatus); 
                                                                    Booking bookingSaveRes = bookingDao.save(bookingRes);

                                                                    String assignBookingOperatorCode = assignBookingRes.getOperatorCode();
                                                                    assignBookingRes.setStatus(GigflexConstants.assignedBookingStatus); 
                                                                    assignBookingRes.setDriverCode(null);  
                                                                    AssignBooking assignBookingSaveRes = assignBookingDao.save(assignBookingRes); 

                                                                    String email = "";
                                                                    if(bookingOperatorCode.equals(assignBookingOperatorCode))
                                                                    {
                                                                      Operator operatorRs =  operatorDao.getOperatorByOperatorCode(bookingOperatorCode);
                                                                      if(operatorRs != null && operatorRs.getId()> 0 )
                                                                      {
                                                                          email = operatorRs.getEmailId();
                                                                      }

                                                                    }
                                                                    else
                                                                    {
                                                                        Operator operatorBookingRs =  operatorDao.getOperatorByOperatorCode(bookingOperatorCode);
                                                                        Operator operatorAssignBookingRs =  operatorDao.getOperatorByOperatorCode(assignBookingOperatorCode);

                                                                        if(operatorBookingRs != null )
                                                                        {
                                                                            email=operatorBookingRs.getEmailId();
                                                                        }


                                                                        if(operatorAssignBookingRs != null )
                                                                        {
                                                                            if(email.trim().length() > 0)
                                                                            {
                                                                                email=email+","+operatorAssignBookingRs.getEmailId();
                                                                            }
                                                                            else
                                                                            {
                                                                                email=operatorAssignBookingRs.getEmailId();
                                                                            }                                                        
                                                                        }
                                                                    }
                                                                    //code for email
                                                                     String bodyContent = "For booking id : "+bookingRes.getBookingid()+" driver has changed vehicle so booking status for assigned/accepted  booking is reset as pending.Please reassign this booking.<br>";
                                                                     SendNotification sn = new SendNotification();

                                                                     if (email != null && email.length() > 0) { 
                                                                        String response=  sn.sendMail(email, subject, bodyContent, mailServiceURL);
                                                                        LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                                                                      } 
                                                               }
                                                           }
                                                       }
                                                        
                                                    }
                                                    else if(isTimeChanged)
                                                    {
                                                        
                                                         List<Booking> bookingList = bookingDao.getAssignedAndAcceptedBookingListByDriverCode(hoursOfOperationInDb.getDriverCode(),GigflexConstants.bookingStatus, GigflexConstants.assignedBookingAcceptedStatus);
                                                        
                                                        if(bookingList != null && bookingList.size() > 0)
                                                        {
                                                            for(Booking booking : bookingList)
                                                            {
                                                                Date pickupDate = booking.getPickUpTime();
                                                                Date dropOffDate = booking.getDropOffTime();
                                                                
                                                                Calendar calPickupDate = Calendar.getInstance();

                                                                calPickupDate.setTime(pickupDate);
                                                                int pickupDay = calPickupDate.get(Calendar.DAY_OF_WEEK);
                                                                
                                                                if(pickupDay != hoursOfOperationReq.getDayCode())
                                                                {
                                                                    continue;
                                                                }
                                                                
                                                                String pickupTime = GigflexDateUtil.convertDateToString(pickupDate, GigflexConstants.HH_MM_SS);
                                                                String droupupTime = GigflexDateUtil.convertDateToString(dropOffDate, GigflexConstants.HH_MM_SS);
                                                                
                                                                Date pickupTimeDt = GigflexDateUtil.convertStringToDate(pickupTime, GigflexConstants.HH_MM_SS);
                                                                Date droupupTimeDt = GigflexDateUtil.convertStringToDate(droupupTime, GigflexConstants.HH_MM_SS);
                                                                
                                                                Date fromTimeDt = GigflexDateUtil.convertStringToDate(hoursOfOperationReq.getFromTime(), GigflexConstants.HH_MM_SS);
                                                                Date toTimeDt = GigflexDateUtil.convertStringToDate(hoursOfOperationReq.getToTime(), GigflexConstants.HH_MM_SS);
                                                                if( pickupTimeDt.after(fromTimeDt) && droupupTimeDt.before(toTimeDt) ) 
                                                                {
                                                                   continue; 
                                                                }
                                                                
                                                                String rideCode = booking.getRideCode();

                                                                Booking bookingRes = bookingDao.getBookingByRideCode(rideCode);
                                                                AssignBooking assignBookingRes = assignBookingDao.getAssignBookingByRideCode(rideCode);
                                                                if(bookingRes != null && bookingRes.getId() > 0 && assignBookingRes != null && assignBookingRes.getId() > 0)
                                                                {
                                                                    String bookingOperatorCode = bookingRes.getOperatorCode();

                                                                    bookingRes.setBookingStatus(GigflexConstants.assignedBookingStatus); 
                                                                    Booking bookingSaveRes = bookingDao.save(bookingRes);

                                                                    String assignBookingOperatorCode = assignBookingRes.getOperatorCode();
                                                                    assignBookingRes.setStatus(GigflexConstants.assignedBookingStatus); 
                                                                    assignBookingRes.setDriverCode(null);  
                                                                    AssignBooking assignBookingSaveRes = assignBookingDao.save(assignBookingRes); 

                                                                    String email = "";
                                                                    if(bookingOperatorCode.equals(assignBookingOperatorCode))
                                                                    {
                                                                      Operator operatorRs =  operatorDao.getOperatorByOperatorCode(bookingOperatorCode);
                                                                      if(operatorRs != null && operatorRs.getId()> 0 )
                                                                      {
                                                                          email = operatorRs.getEmailId();
                                                                      }

                                                                    }
                                                                    else
                                                                    {
                                                                        Operator operatorBookingRs =  operatorDao.getOperatorByOperatorCode(bookingOperatorCode);
                                                                        Operator operatorAssignBookingRs =  operatorDao.getOperatorByOperatorCode(assignBookingOperatorCode);

                                                                        if(operatorBookingRs != null )
                                                                        {
                                                                            email=operatorBookingRs.getEmailId();
                                                                        }


                                                                        if(operatorAssignBookingRs != null )
                                                                        {
                                                                            if(email.trim().length() > 0)
                                                                            {
                                                                                email=email+","+operatorAssignBookingRs.getEmailId();
                                                                            }
                                                                            else
                                                                            {
                                                                                email=operatorAssignBookingRs.getEmailId();
                                                                            }                                                        
                                                                        }
                                                                    }
                                                                    //code for email
                                                                     String changeType = "";
                                                                     if(isVehicleUpdated)
                                                                     {
                                                                         changeType = " vehicle ";
                                                                     }
                                                                     else
                                                                     {
                                                                         changeType = " hours of operation time ";
                                                                     }
                                                                    
                                                                    
                                                                     String bodyContent = "For booking id : "+bookingRes.getBookingid()+" driver has changed "+changeType+" so booking status for assigned/accepted  booking is reset as pending.Please reassign this booking.<br>";
                                                                     SendNotification sn = new SendNotification();

                                                                     if (email != null && email.length() > 0) { 
                                                                        String response=  sn.sendMail(email, subject, bodyContent, mailServiceURL);
                                                                        LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                                                                      } 
                                                               }
                                                           }
                                                       }
                                                        
                                                        
                                                    }
                                                    
                                                    
                                                    
                                                    jsonobj.put("responsecode", 200);
                                                    jsonobj.put("message",
                                                                    "Hours Of Operation updation has been done");
                                                    jsonobj.put("timestamp", new Date());
                                                    ObjectMapper mapperObj = new ObjectMapper();
                                                    String Detail = mapperObj
                                                                    .writeValueAsString(hoursOfOperationRes); 
                                                    jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Hours Of Operation updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Hours Of Operation ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
                                        
                                }
                                else {
                                   jsonobj.put("responsecode", 409);
                                   jsonobj.put("timestamp", new Date());
                                   jsonobj.put("message", "Driver Code with Day Code already exist.");
				}
                                     
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Driver Code , From Time , To Time,Vehicle Code & Day Code should not be blank");

				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.info(ex.toString()); 
		}
		return res;
    }
    
     @Override
    public String cancelHoursOfOperationByHoursOfOperationCode(String hoursOfOperationCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			HoursOfOperation hoursOfOperationInDb =hoursOfOperationDao.getHoursByHoursOfOperationCode(hoursOfOperationCode); 
			if (hoursOfOperationInDb != null && hoursOfOperationInDb.getId() > 0) {

                                hoursOfOperationInDb.setIsDeleted(true);                                
                                HoursOfOperation hoursOfOperationRes = hoursOfOperationDao.save(hoursOfOperationInDb);
                                if (hoursOfOperationRes != null && hoursOfOperationRes.getId() > 0) {
                                        jsonobj.put("responsecode", 200);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message",
                                                        "Hours Of Operation cancelled successfully.");
                                        // kafkaService.
                                } else {
                                        jsonobj.put("responsecode", 400);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Failed");
                                }
                        }

			else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
                    GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
                    res = derr.toString();
                    ex.printStackTrace();
                 LOG.error("Error in cancelHoursOfOperationByHoursOfOperationCode>>>>>>", ex);
                }catch(org.springframework.orm.jpa.JpaSystemException ex)
                {
                    GigflexResponse derr = new GigflexResponse(401, new Date(), GigUtil.getRootException(ex));
                    res = derr.toString();
                    ex.printStackTrace();
		} catch (Exception ex) {
		 ex.printStackTrace();
                  LOG.error("Error in cancelHoursOfOperationByHoursOfOperationCode>>>>>>", ex);	
                    GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String cancelMultipleHoursOfOperationByHoursOfOperationCode(List<String> hoursOfOperationCodeList) {
        String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String hoursOfOperationCode : hoursOfOperationCodeList) {
				if (hoursOfOperationCode != null && hoursOfOperationCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					hoursOfOperationCode = hoursOfOperationCode.trim();

					HoursOfOperation hoursOfOperationInDb =hoursOfOperationDao.getHoursByHoursOfOperationCode(hoursOfOperationCode);

					if (hoursOfOperationInDb != null && hoursOfOperationInDb.getId() > 0) {
						
						try{
							hoursOfOperationInDb.setIsDeleted(true);                                                        
							HoursOfOperation hoursOfOperationRes = hoursOfOperationDao.save(hoursOfOperationInDb);
							if (hoursOfOperationRes != null && hoursOfOperationRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", hoursOfOperationCode);
								jsonobj.put("message",
										"Hours Of Operation cancelled successfully.");
								// kafkaService.sendUseronUpdate(usersDataRes);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", hoursOfOperationCode);
								jsonobj.put("message", "Failed");
							}
						}catch(org.springframework.orm.jpa.JpaSystemException ex){
							jsonobj.put("responsecode", 500);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", hoursOfOperationCode);
							jsonobj.put("message",  GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", hoursOfOperationCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple cancel failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
                        ex.printStackTrace();
                        LOG.info(ex.toString()); 
		}
		return res;
    }

    
    
    
    
}
