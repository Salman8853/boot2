package com.gigflex.prototype.microservices.driver.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.util.SearchCriteria;



public class DriverSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public DriverSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public DriverSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<Driver> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<Driver>> specs = new ArrayList<Specification<Driver>>();
        for (SearchCriteria param : params) {
            specs.add(new DriverSpecification(param));
        }
 
        Specification<Driver> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
