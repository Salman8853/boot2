package com.gigflex.prototype.microservices.documenttype.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.documenttype.dtob.DocumentTypeRequest;
import com.gigflex.prototype.microservices.documenttype.service.DocumentTypeService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class DocumentTypeController {

	@Autowired
	public DocumentTypeService DocumentTypeService;

	@GetMapping("/DocumentType/{search}")
	public String search(@PathVariable("search") String search) {
		return DocumentTypeService.search(search);
	}

	@GetMapping("/getAllDocumentType")
	public String getAllDocumentType() {
		return DocumentTypeService.getAllDocumentType();
	}

	@GetMapping(path = "/getDocumentTypeByPage")
	public String getDocumentTypeByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String DocumentType = DocumentTypeService.getAllDocumentTypeByPgae(page, limit);

		return DocumentType;

	}

	@GetMapping("/getDocumentType/{id}")
	public String getDocumentTypeById(@PathVariable Long id) {
		return DocumentTypeService.getDocumentTypeById(id);
	}

	@GetMapping("/getDocumentTypeByDocumentTypeCode/{documentTypeCode}")
	public String getDocumentTypeByDocumentTypeCode(@PathVariable String documentTypeCode) {
		return DocumentTypeService.getDocumentTypeByDocumentTypeCode(documentTypeCode);
	}

	@PostMapping("/saveDocumentType")
	public String saveDocumentType(@RequestBody DocumentTypeRequest DocumentTypeReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return DocumentTypeService.saveNewDocumentType(DocumentTypeReq, ip);

	}

	@PutMapping("/updateDocumentType/{id}")
	public String updateDocumentType(@PathVariable Long id,
			@RequestBody DocumentTypeRequest DocumentTypeReq, HttpServletRequest request) {

		if (id == null) {
			return "DocumentType with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return DocumentTypeService.updateDocumentTypeById(id, DocumentTypeReq, ip);

		}

	}

	@DeleteMapping("/softDeleteDocumentTypeByDocumentTypeCode/{documentTypeCode}")
	public String softDeleteDocumentTypeByDocumentTypeCode(
			@PathVariable String documentTypeCode) {
		return DocumentTypeService.softDeleteByDocumentTypeCode(documentTypeCode);
	}

	@DeleteMapping("/softMultipleDeleteByDocumentTypeCode/{documentTypeCodeList}")
	public String softMultipleDeleteByDocumentTypeCode(
			@PathVariable List<String> documentTypeCodeList) {
		if (documentTypeCodeList != null && documentTypeCodeList.size() > 0) {
			return DocumentTypeService
					.softMultipleDeleteByDocumentTypeCode(documentTypeCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

}
