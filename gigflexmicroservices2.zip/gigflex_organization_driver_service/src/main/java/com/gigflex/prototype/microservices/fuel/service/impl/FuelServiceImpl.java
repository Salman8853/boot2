package com.gigflex.prototype.microservices.fuel.service.impl;

import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.fuel.dtob.Fuel;
import com.gigflex.prototype.microservices.fuel.dtob.FuelRequest;
import com.gigflex.prototype.microservices.fuel.repository.FuelDao;

import com.gigflex.prototype.microservices.fuel.search.FuelSpecificationsBuilder;
import com.gigflex.prototype.microservices.fuel.service.FuelService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

@Service
public class FuelServiceImpl implements FuelService {

	@Autowired
	private FuelDao fuelDao;

	@Override
	public String updateFuelById(Long id, FuelRequest fuelReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && fuelReq != null) {

				if ((fuelReq.getFuelTypename() != null && fuelReq.getFuelTypename().trim().length() > 0)) {
					Fuel fuelInDb = fuelDao.getFuelById(id);

					if (fuelInDb != null && fuelInDb.getId() > 0) {

						Fuel fuel = fuelInDb;

						if (!(fuelReq.getFuelTypename().equals(fuel.getFuelTypeName()))) {

							Fuel fuellst = fuelDao.getFuelByFuelName(fuelReq.getFuelTypename());

							if (fuellst != null && fuellst.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Fuel name already exists");
							} else {

								fuel.setFuelTypeName(fuelReq.getFuelTypename());
								fuel.setIpAddress(ip);

								Fuel fuelRes = fuelDao.save(fuel);
								if (fuelRes != null && fuelRes.getId() > 0) {
									jsonobj.put("responsecode", 200);
									jsonobj.put("message", "Fuel updation has been done");
									jsonobj.put("timestamp", new Date());
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj.writeValueAsString(fuelRes);
									jsonobj.put("data", new JSONObject(Detail));
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("message", "Fuel updation has been failed.");
									jsonobj.put("timestamp", new Date());
								}
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Old Fuel name and New Fuel name should be different.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Fuel ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Fuel type name should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String findAllFuel() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Fuel> fuellst = fuelDao.getAllFuel();

			if (fuellst != null && fuellst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(fuellst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllFuelByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<Fuel> fuellst = fuelDao.getAllFuel(pageableRequest);
                        int count=0;
                        List<Fuel> cntlst = fuelDao.getAllFuel();
                        if(cntlst!=null)
                        {
                        count=cntlst.size();
                        }
			if (fuellst != null && fuellst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(fuellst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String findFuelById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Fuel fuellst = fuelDao.getFuelById(id);

			if (fuellst != null && fuellst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(fuellst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveFuel(FuelRequest fuelReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (fuelReq != null) {

				if ((fuelReq.getFuelTypename() != null && fuelReq.getFuelTypename().trim().length() > 0)) {
					Fuel fuellst = fuelDao.getFuelByFuelName(fuelReq.getFuelTypename());

					if (fuellst != null && fuellst.getId() > 0) {
						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Fuel name already exists");
					} else {
						Fuel fuel = new Fuel();

						fuel.setFuelTypeName(fuelReq.getFuelTypename());
						fuel.setIpAddress(ip);

						Fuel fuelRes = fuelDao.save(fuel);

						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());

						if (fuelRes != null && fuelRes.getId() > 0) {

							jsonobj.put("message", "Fuel has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(fuelRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("message", "Failed");
						}
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Fuel type name should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getFuelByFuelCode(String fuelTypeCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			
			Fuel fuellst = fuelDao.getFuelByFuelCode(fuelTypeCode);
			
			if (fuellst != null && fuellst.getId() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(fuellst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByFuelCode(String fuelTypeCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Fuel fuellst = fuelDao.getFuelByFuelCode(fuelTypeCode);
			

			if (fuellst != null && fuellst.getId() > 0) {
				fuellst.setIsDeleted(true);
				Fuel fuelRes = fuelDao.save(fuellst);
				if (fuelRes != null && fuelRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());

					jsonobj.put("message",
							"Fuel deleted successfully.");

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByFuelCode(List<String> fuelTypeCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String fuelTypeCode : fuelTypeCodeList) {
				if (fuelTypeCode != null && fuelTypeCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					Fuel fuellst = fuelDao.getFuelByFuelCode(fuelTypeCode);
					

					if (fuellst != null && fuellst.getId() > 0) {
						fuellst.setIsDeleted(true);
						Fuel fuelRes = fuelDao.save(fuellst);
						if (fuelRes != null && fuelRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());

							jsonobj.put("message",
									"Fuel deleted successfully.");

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("fuelTypeCode", fuelTypeCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("fuelTypeCode", fuelTypeCode);
						jsonobj.put("message", "Record Not Found");
					}

					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				FuelSpecificationsBuilder builder = new FuelSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<Fuel> spec = builder.build();
                                if(spec!=null){
				List<Fuel> FuelLst = fuelDao.findAll(spec);
				if (FuelLst != null
						&& FuelLst.size() > 0) {
					for (Fuel dept : FuelLst) {
						if (dept.getIsDeleted() != null
								&& dept.getIsDeleted() != true) {

							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(dept);
							JSONObject jsonobjNew = new JSONObject();
							jsonobjNew.put("Fuel", new JSONObject(
									Detail));
							jarr.add(jsonobjNew);

						}

					}
					if (jarr.size() > 0) {

						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", jarr);
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}}
                                else{
                                   jsonobj.put("responsecode", 400);
				   jsonobj.put("message", "Record Not Found!");
				   jsonobj.put("timestamp", new Date()); 
                                }
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;

	}

}
