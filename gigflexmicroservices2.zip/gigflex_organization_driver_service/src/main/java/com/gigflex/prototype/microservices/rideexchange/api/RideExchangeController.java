/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.rideexchange.api;

import com.gigflex.prototype.microservices.rideexchange.service.RideExchangeService;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author amit.kumar
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class RideExchangeController {
    
    @Autowired
    public RideExchangeService rideExchangeService;
    
    @GetMapping("/getAllRideExchange")
    public String getAllRideExchange() {
            return rideExchangeService.findAllAllRideExchange();
    }
    
    @GetMapping("/getLastBalanceOfRideExcahange")
    public String getLastBalanceOfRideExcahange() {
            return rideExchangeService.findLastBalanceOfRideExcahange();
    }
    
    
    @GetMapping("/getRideExcahangeByRideCode/{rideCode}")
    public String getRideExcahangeByRideCode(@PathVariable String rideCode,@RequestHeader HttpHeaders headers) {
            return rideExchangeService.findRideExcahangeByRideCode(rideCode);
    }
    
   @GetMapping("/getRideExcahangeBetweenDates/{stratDT}/{endDT}")
    public String getRideExcahangeBetweenDates(@PathVariable String startDT,@PathVariable String endDT,@RequestHeader HttpHeaders headers) {
         
            if( startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(startDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

                } catch (Exception ex) {
                        ex.printStackTrace();
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
                        return derr.toString();
                }
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "End Date must be after Start Date.");
                        return derr.toString();
                   }
                }
                
            }
            else {
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Start Date and End Date should not be blank.");
                        return derr.toString();
                }
				
                return rideExchangeService.getRideExcahangeBetweenDates(startDT.trim(), endDT.trim());
           
         
	}
    
}
