package com.gigflex.prototype.microservices.vehicledetail.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.booking.repository.BookingDao;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.dtob.VehicleDriverMapping;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.driver.repository.VehicleDriverMappingRepository;
import com.gigflex.prototype.microservices.fuel.dtob.Fuel;
import com.gigflex.prototype.microservices.fuel.repository.FuelDao;
import com.gigflex.prototype.microservices.makemodelmapping.dtob.MakeModelMapping;
import com.gigflex.prototype.microservices.makemodelmapping.repository.MakeModelMappingRepository;
import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.notification.service.NotificationService;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationDao;
import com.gigflex.prototype.microservices.ridetype.dtob.RideType;
import com.gigflex.prototype.microservices.ridetype.repository.RideTypeRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.utility.GigflexDateUtil;
import com.gigflex.prototype.microservices.vehicledetail.dtob.SaveVehicleByDriver;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetail;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetailDriverRequest;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetailDriverResponse;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetailRequest;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetailResponse;
import com.gigflex.prototype.microservices.vehicledetail.repository.VehicleDetailRepository;
import com.gigflex.prototype.microservices.vehicledetail.search.VehicleDetailSpecificationsBuilder;
import com.gigflex.prototype.microservices.vehicledetail.service.VehicleDetailService;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.globalridetype.dtob.GlobalRideType;
import com.gigflex.prototype.microservices.globalridetype.repository.GlobalRideTypeRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.hoursofoperation.dtob.HoursOfOperation;
import com.gigflex.prototype.microservices.hoursofoperation.repository.HoursOfOperationDao;
import com.gigflex.prototype.microservices.maketype.dtob.MakeType;
import com.gigflex.prototype.microservices.maketype.repository.MakeTypeRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.utility.PushNotification;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetailDriverResponseforMobile;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleTypeDetailDriverResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

@Service
public class VehicleDetailServiceImpl implements VehicleDetailService {

    private static final Logger LOG = LoggerFactory.getLogger(VehicleDetailServiceImpl.class);
    @Autowired
    KafkaService kafkaService;
	
    @Autowired
    private NotificationService notificationService;

	@Autowired
	VehicleDetailRepository vehicleDetailDao;

	@Autowired
	OrganizationDao orgDao;

	@Autowired
	FuelDao fuelDao;

	@Autowired
	DriverRepository driverDao;
	
	@Autowired
	OperatorRepository operatorDao;

	@Autowired
	private TimeZoneRepository timeZoneRepository;

	@Autowired
	private BookingDao bookingDao;

	@Autowired
	VehicleDriverMappingRepository vehDriverDao;

	@Autowired
	MakeModelMappingRepository mmmDao;
	
	@Autowired
	RideTypeRepository rideTypeDao;
        @Autowired
        MakeTypeRepository makeTypeRepository;
        
        @Autowired
        GlobalSettingRepository globalSettingRepository;
    
        @Autowired
        LocalSettingRepository localSettingRepository;
        
        @Autowired
	UserTypeRepository userTypeDao;
        
        @Autowired
        HoursOfOperationDao hoursOfOperationDao;
        
        @Value("${notification.deviceid}")
        private String deviceId;
        
        @Value("${notification.fcm.url}")
        private String FMCurl;  
        
        @Value("${notification.fcm.authkey}")
        private String authKey;

	
    private String shortMessage;
    
    @Autowired
    GlobalRideTypeRepository globalRideTypeRepository;
	@Override
	public String getAllVehicleDetail() {
		// String res = "";
		// try {
		// JSONObject jsonobj = new JSONObject();
		// List<VehicleDetail> vehicleDetailst = vehicleDetailDao
		// .getAllVehicleDetail();
		//
		// if (vehicleDetailst != null && vehicleDetailst.size() > 0) {
		// jsonobj.put("responsecode", 200);
		// jsonobj.put("message", "Success");
		// jsonobj.put("timestamp", new Date());
		// ObjectMapper mapperObj = new ObjectMapper();
		// String Detail = mapperObj.writeValueAsString(vehicleDetailst);
		// jsonobj.put("data", new JSONArray(Detail));
		// } else {
		// jsonobj.put("responsecode", 404);
		// jsonobj.put("message", "Record Not Found.");
		// jsonobj.put("timestamp", new Date());
		// }
		// res = jsonobj.toString();
		// } catch (JSONException | JsonProcessingException ex) {
		// GigflexResponse derr = new GigflexResponse(500, new Date(),
		// "JSON parsing exception occurred.");
		// res = derr.toString();
		// }
		// return res;

		String res = "";
		try {
			
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = vehicleDetailDao.getAllVehicleDetail();
			List<VehicleDetailResponse> maplst = new ArrayList<VehicleDetailResponse>();
			if (objlst != null && objlst.size() > 0) {
                                                       
			for (int i = 0; i < objlst.size(); i++) {
                        Object[] arr = (Object[]) objlst.get(i);
                        if (arr.length >= 4) {
                        Date regExpDate=null;
			Date licExpDate=null;
			String conDtRegExp = "";
			String conDtLicExp = "";
                        Date insurExpDate=null;
			String conDtInsurExp = "";
                        Date vehicleMOTExpDate=null;
			String conDtVehicleMOTExp = "";
                        Date hireAgreementDocExpDate=null;
			String conDtHireAgreementDocExp = "";
                        String dateformat = "";
                        String timeformat = "";
                        String timezoneCode = "";
                        TimeZoneDetail tz = null;
                        String timezone = "";
                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                        VehicleDetailResponse vd = new VehicleDetailResponse();

                        VehicleDetail data = (VehicleDetail) arr[0];

                        VehicleDriverMapping vdm = new VehicleDriverMapping();


                        if (data.getOrganizationCode() != null) {
                                regExpDate = data.getRegistrationExpiryDate();
                                licExpDate = data.getLicenseExpiryDate();
                                insurExpDate = data.getInsuranceExpiryDate();
                                vehicleMOTExpDate = data.getVehicleMOTExpiryDate();
                                hireAgreementDocExpDate = data.getHireAgreementDocExpiryDate();
                                Organization org = orgDao.findByOrganizationCode(data.getOrganizationCode());
                                if (org != null && org.getId() > 0) {

//								String timezoneCode = org.getTimezone();


                                        dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                        timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                        {
                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                        }                

                                        timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TimeZone);
                                        tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                        timezone = tz.getTimeZoneName(); 

                                        if(timezone!=null && timezone.length()>0 )
                                        {

                                             if (regExpDate != null) {
                                                 regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                                 conDtRegExp = GigflexDateUtil.convertDateToString(regExpDate,dtFormat);
                                             }                                                                     
                                             if (licExpDate != null) {
                                                     licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                                     conDtLicExp = GigflexDateUtil.convertDateToString(licExpDate,dtFormat);
                                             }                             
                                             if (insurExpDate != null) {
                                                     insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                                     conDtInsurExp = GigflexDateUtil.convertDateToString(insurExpDate,dtFormat);
                                             }

                                             if (vehicleMOTExpDate != null) {
                                                     vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                                     conDtVehicleMOTExp = GigflexDateUtil.convertDateToString(vehicleMOTExpDate,dtFormat);
                                             }
                                             if (hireAgreementDocExpDate != null) {
                                                     hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate,timezone,dtFormat);
                                                     conDtHireAgreementDocExp = GigflexDateUtil.convertDateToString(hireAgreementDocExpDate,dtFormat);
                                             }
                                        }

                                }						

                                vd.setOrganizationCode(data.getOrganizationCode());
                                vd.setOrganizationName(org.getOrganizationName());
                            }else {

                                   String driverCode = (String) arr[1];

                                   Driver driver = driverDao.getDriverByDriverCode(driverCode);
                                   String organizationCode = driver.getOrganizationCode();                                                

                                   dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                                   timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                                   if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                   {
                                       dtFormat=dateformat.trim()+" "+timeformat.trim();
                                   }                

                                   timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations,organizationCode, GigflexConstants.TimeZone);

                                   tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                   timezone = tz.getTimeZoneName();
                                   
                                   if(timezone!=null && timezone.length()>0 )
                                    { 
                                        if (regExpDate != null) {
                                           regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                           conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                        }						
                                        if (licExpDate != null) {
                                                licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                                conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                        }


                                        if (insurExpDate != null) {
                                                insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate,  timezone,dtFormat);
                                                conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                        }

                                        if (vehicleMOTExpDate != null) {
                                                vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate,  timezone,dtFormat);
                                                conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                        }


                                        if (hireAgreementDocExpDate != null) {
                                                hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate,  timezone,dtFormat);
                                                conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                        }
                                    }

                                   


                           }
                            vd.setRegistrationExpiryDate(conDtRegExp);
                            vd.setLicenseExpiryDate(conDtLicExp);
                            vd.setInsuranceExpiryDate(conDtInsurExp);
                            vd.setVehicleMOTExpiryDate(conDtVehicleMOTExp);
                            vd.setHireAgreementDocExpiryDate(conDtHireAgreementDocExp);

                            vd.setDateFormat(dateformat);
                            vd.setTimeFormat(timeformat);
                            vd.setId(data.getId());
                            vd.setVehicleCode(data.getVehicleCode());
                            vd.setVehicleYear(data.getVehicleYear());
                            vd.setInitialMileage(data.getInitialMileage());
                            vd.setVehicleImage(data.getVehicleImage());
                            vd.setInService(data.getInService());
                            vd.setColor(data.getColor());
                            vd.setVin(data.getVin());
                            vd.setLicensePlate(data.getLicensePlate());
                            vd.setLicensePlateDoc(data.getLicensePlateDoc());
                            vd.setInsurance(data.getInsurance());
                            vd.setInsuranceDoc(data.getInsuranceDoc());
                            vd.setVehicleLogbookDoc(data.getVehicleLogbookDoc());
                            vd.setVehicleMOTDoc(data.getVehicleMOTDoc());
                            vd.setHireAgreementDoc(data.getHireAgreementDoc());
                            vd.setPassengerQuantity(data.getPassengerQuantity());
                            vd.setBaggageQuantity(data.getBaggageQuantity());
                            vd.setAirCondition(data.getAirCondition());
                            vd.setAutomaticTransmission(data.getAutomaticTransmission());
                            vd.setSateliteNavigation(data.getSateliteNavigation());
                            vd.setRegistrationNumber(data.getRegistrationNumber());
                            vd.setModelCode(data.getModelCode());
                            vd.setModelName((String) arr[2]);
                            vd.setFuelTypeCode(data.getFuelTypeCode());
                            vd.setFuelTypeName((String) arr[3]);
                            vd.setVehicleTypeCode(data.getVehicleType());

                            RideType rideType = rideTypeDao.getRideTypeByVehicleCode(data.getVehicleType());
                            if(rideType != null && rideType.getId() > 0) {
                                    vd.setVehicleTypeName(rideType.getVehicleName());
                            }

                            vd.setMakeCode(data.getMakeCode());
                            MakeType mt=makeTypeRepository.getMakeTypeByVehicleCode(data.getMakeCode());
                            if(mt != null && mt.getId() > 0) {
                                    vd.setMakeName(mt.getVehicleName());
                            }
               // dro.setVehicleCode(data.getVehicleCode());

                            Driver driver = driverDao.getDriverByDriverCode((String) arr[1]);
                            if (driver != null && driver.getId() > 0) {
                                    vd.setDriverCode(driver.getDriverCode());
                                    vd.setDriverName(driver.getName());
                            }

                            maplst.add(vd);

                      }
                    }
                    if (maplst.size() > 0) {
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(maplst);
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("message", "Success");
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("data", new JSONArray(Detail));
                    } else {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Record Not Found");
                            jsonobj.put("timestamp", new Date());
                    }
                } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                }

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;

	}

	@Override
	public String getVehicleDetailById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			VehicleDetail vehicleDetailst = vehicleDetailDao.getVehicleDetailById(id);
                        Date regExpDate=null;			
			String conDtRegExp = "";
                        Date licExpDate=null;
			String conDtLicExp = "";
                        Date insurExpDate=null;
			String conDtInsurExp = "";
                        Date vehicleMOTExpDate=null;
			String conDtVehicleMOTExp = "";
                        Date hireAgreementDocExpDate=null;
			String conDtHireAgreementDocExp = "";    
                        String dateformat = "";
                        String timeformat = "";
                        String timezoneCode ="";
                        TimeZoneDetail tz = null;
                        String timezone = "";
                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                        if(vehicleDetailst != null && vehicleDetailst.getId() > 0)
                        {
                            VehicleDetailResponse vd = new VehicleDetailResponse();                            
                            regExpDate = vehicleDetailst.getRegistrationExpiryDate();
                            licExpDate = vehicleDetailst.getLicenseExpiryDate();
                            insurExpDate = vehicleDetailst.getInsuranceExpiryDate();
                            vehicleMOTExpDate = vehicleDetailst.getVehicleMOTExpiryDate();
                            hireAgreementDocExpDate = vehicleDetailst.getHireAgreementDocExpiryDate();
                            if (vehicleDetailst.getOrganizationCode() != null) {
                                
                                dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, vehicleDetailst.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, vehicleDetailst.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, vehicleDetailst.getOrganizationCode(), GigflexConstants.TimeZone);
                                tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                timezone = tz.getTimeZoneName(); 
                                if(timezone!=null && timezone.length()>0 )
                                {                                     
                                     if (regExpDate != null) {

                                         regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                         conDtRegExp = GigflexDateUtil.convertDateToString(regExpDate,dtFormat);
                                     }                                    
                                     if (licExpDate != null) {
                                             licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                             conDtLicExp = GigflexDateUtil.convertDateToString(licExpDate,dtFormat);
                                     }
                                     
                                     if (insurExpDate != null) {
                                             insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                             conDtInsurExp = GigflexDateUtil.convertDateToString(insurExpDate,dtFormat);
                                     }
                                     
                                     if (vehicleMOTExpDate != null) {
                                             vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                             conDtVehicleMOTExp = GigflexDateUtil.convertDateToString(vehicleMOTExpDate,dtFormat);
                                     }

                                     
                                     if (hireAgreementDocExpDate != null) {
                                             hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate,timezone,dtFormat);
                                             conDtHireAgreementDocExp = GigflexDateUtil.convertDateToString(hireAgreementDocExpDate,dtFormat);
                                     }
                                 }                                
                            }
                            else
                            {
                                VehicleDriverMapping  vdm = vehDriverDao.getVehicleDriverMappingByVehicleCode(vehicleDetailst.getVehicleCode());
                                if(vdm != null && vdm.getId() >0)
                                {
                                    String driverCode = vdm.getDriverCode();                                

                                    Driver driver = driverDao.getDriverByDriverCode(driverCode);
                                    String organizationCode = driver.getOrganizationCode();

                                    dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                                    timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                    {
                                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                                    }                

                                    timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations,organizationCode, GigflexConstants.TimeZone);

                                    tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                    timezone = tz.getTimeZoneName();

                                    if(timezone!=null && timezone.length()>0 )
                                    {                                       
                                            if (regExpDate != null) {
                                                    regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                                    conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                            }

                                            if (licExpDate != null) {
                                                    licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone, dtFormat);
                                                    conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                            }

                                            if (insurExpDate != null) {
                                                    insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone, dtFormat);
                                                    conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                            }                                        
                                            if (vehicleMOTExpDate != null) {
                                                    vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate,timezone, dtFormat);
                                                    conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                            }

                                            if (hireAgreementDocExpDate != null) {
                                                    hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate,timezone, dtFormat);
                                                    conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                            }
                                    }                   
                                }
                                            
                            }
                            
                            vd.setRegistrationExpiryDate(conDtRegExp);
                            vd.setLicenseExpiryDate(conDtLicExp);
                            vd.setInsuranceExpiryDate(conDtInsurExp);
                            vd.setVehicleMOTExpiryDate(conDtVehicleMOTExp);
                            vd.setHireAgreementDocExpiryDate(conDtHireAgreementDocExp);
                            
                            vd.setDateFormat(dateformat);
                            vd.setTimeFormat(timeformat);
                            vd.setId(vehicleDetailst.getId());
                            vd.setVehicleCode(vehicleDetailst.getVehicleCode());
                            vd.setVehicleYear(vehicleDetailst.getVehicleYear());
                            vd.setInitialMileage(vehicleDetailst.getInitialMileage());
                            vd.setVehicleImage(vehicleDetailst.getVehicleImage());
                            vd.setInService(vehicleDetailst.getInService());
                            vd.setColor(vehicleDetailst.getColor());
                            vd.setVin(vehicleDetailst.getVin());
                            vd.setLicensePlate(vehicleDetailst.getLicensePlate());
                            vd.setLicensePlateDoc(vehicleDetailst.getLicensePlateDoc());
                            vd.setInsurance(vehicleDetailst.getInsurance());
                            vd.setInsuranceDoc(vehicleDetailst.getInsuranceDoc());
                            vd.setVehicleLogbookDoc(vehicleDetailst.getVehicleLogbookDoc());
                            vd.setVehicleMOTDoc(vehicleDetailst.getVehicleMOTDoc());
                            vd.setHireAgreementDoc(vehicleDetailst.getHireAgreementDoc());
                            vd.setPassengerQuantity(vehicleDetailst.getPassengerQuantity());
                            vd.setBaggageQuantity(vehicleDetailst.getBaggageQuantity());
                            vd.setAirCondition(vehicleDetailst.getAirCondition());
                            vd.setAutomaticTransmission(vehicleDetailst.getAutomaticTransmission());
                            vd.setSateliteNavigation(vehicleDetailst.getSateliteNavigation());
                            vd.setRegistrationNumber(vehicleDetailst.getRegistrationNumber());
                            vd.setModelCode(vehicleDetailst.getModelCode());
//                            vd.setModelName((String) arr[2]);
                            vd.setFuelTypeCode(vehicleDetailst.getFuelTypeCode());
//                            vd.setFuelTypeName((String) arr[3]);
                            vd.setVehicleTypeCode(vehicleDetailst.getVehicleType());
                            
                            RideType rideType = rideTypeDao.getRideTypeByVehicleCode(vehicleDetailst.getVehicleType());
                            if(rideType != null && rideType.getId() > 0) {
                                    vd.setVehicleTypeName(rideType.getVehicleName());
                            }

                            vd.setMakeCode(vehicleDetailst.getMakeCode());
                            MakeType mt=makeTypeRepository.getMakeTypeByVehicleCode(vehicleDetailst.getMakeCode());
                            if(mt != null && mt.getId() > 0) {
                                    vd.setMakeName(mt.getVehicleName());
                            }                            
                            
                            if (vd != null && vd.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(vd);
				jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("message", "Record Not Found");
                                    jsonobj.put("timestamp", new Date());

                            }
                            
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
                        }
                        
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
                        LOG.error("Exception is occurred.",e);
		}
		return res;
	}

	@Override
	public String getVehicleDetailByVehicleCode(String vehicleCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			VehicleDetail vehicleDetailst = vehicleDetailDao.getVehicleDetailByVehicleCode(vehicleCode);
                        
                        Date regExpDate=null;			
			String conDtRegExp = "";
                        Date licExpDate=null;
			String conDtLicExp = "";
                        Date insurExpDate=null;
			String conDtInsurExp = "";
                        Date vehicleMOTExpDate=null;
			String conDtVehicleMOTExp = "";
                        Date hireAgreementDocExpDate=null;
			String conDtHireAgreementDocExp = "";    
                        String dateformat = "";
                        String timeformat = "";
                        String timezoneCode ="";
                        TimeZoneDetail tz = null;
                        String timezone = "";
                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                        if(vehicleDetailst != null && vehicleDetailst.getId() > 0)
                        {
                            VehicleDetailResponse vd = new VehicleDetailResponse();                            
                            regExpDate = vehicleDetailst.getRegistrationExpiryDate();
                            licExpDate = vehicleDetailst.getLicenseExpiryDate();
                            insurExpDate = vehicleDetailst.getInsuranceExpiryDate();
                            vehicleMOTExpDate = vehicleDetailst.getVehicleMOTExpiryDate();
                            hireAgreementDocExpDate = vehicleDetailst.getHireAgreementDocExpiryDate();
                            if (vehicleDetailst.getOrganizationCode() != null) {
                                
                                dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, vehicleDetailst.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, vehicleDetailst.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, vehicleDetailst.getOrganizationCode(), GigflexConstants.TimeZone);
                                tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                timezone = tz.getTimeZoneName(); 
                                if(timezone!=null && timezone.length()>0 )
                                {                                     
                                     if (regExpDate != null) {

                                         regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                         conDtRegExp = GigflexDateUtil.convertDateToString(regExpDate,dtFormat);
                                     }                                    
                                     if (licExpDate != null) {
                                             licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                             conDtLicExp = GigflexDateUtil.convertDateToString(licExpDate,dtFormat);
                                     }
                                     
                                     if (insurExpDate != null) {
                                             insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                             conDtInsurExp = GigflexDateUtil.convertDateToString(insurExpDate,dtFormat);
                                     }
                                     
                                     if (vehicleMOTExpDate != null) {
                                             vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                             conDtVehicleMOTExp = GigflexDateUtil.convertDateToString(vehicleMOTExpDate,dtFormat);
                                     }

                                     
                                     if (hireAgreementDocExpDate != null) {
                                             hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate,timezone,dtFormat);
                                             conDtHireAgreementDocExp = GigflexDateUtil.convertDateToString(hireAgreementDocExpDate,dtFormat);
                                     }
                                 }                                
                            }
                            else
                            {
                                VehicleDriverMapping  vdm = vehDriverDao.getVehicleDriverMappingByVehicleCode(vehicleDetailst.getVehicleCode());
                                if(vdm != null && vdm.getId() >0)
                                {
                                    String driverCode = vdm.getDriverCode();                                

                                    Driver driver = driverDao.getDriverByDriverCode(driverCode);
                                    String organizationCode = driver.getOrganizationCode();

                                    dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                                    timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                    {
                                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                                    }                

                                    timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations,organizationCode, GigflexConstants.TimeZone);

                                    tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                    timezone = tz.getTimeZoneName();

                                    if(timezone!=null && timezone.length()>0 )
                                    {                                       
                                            if (regExpDate != null) {
                                                    regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                                    conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                            }

                                            if (licExpDate != null) {
                                                    licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone, dtFormat);
                                                    conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                            }

                                            if (insurExpDate != null) {
                                                    insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone, dtFormat);
                                                    conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                            }                                        
                                            if (vehicleMOTExpDate != null) {
                                                    vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate,timezone, dtFormat);
                                                    conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                            }

                                            if (hireAgreementDocExpDate != null) {
                                                    hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate,timezone, dtFormat);
                                                    conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                            }
                                    }                   
                                }
                                            
                            }
                            
                            vd.setRegistrationExpiryDate(conDtRegExp);
                            vd.setLicenseExpiryDate(conDtLicExp);
                            vd.setInsuranceExpiryDate(conDtInsurExp);
                            vd.setVehicleMOTExpiryDate(conDtVehicleMOTExp);
                            vd.setHireAgreementDocExpiryDate(conDtHireAgreementDocExp);
                            
                            vd.setDateFormat(dateformat);
                            vd.setTimeFormat(timeformat);
                            vd.setId(vehicleDetailst.getId());
                            vd.setVehicleCode(vehicleDetailst.getVehicleCode());
                            vd.setVehicleYear(vehicleDetailst.getVehicleYear());
                            vd.setInitialMileage(vehicleDetailst.getInitialMileage());
                            vd.setVehicleImage(vehicleDetailst.getVehicleImage());
                            vd.setInService(vehicleDetailst.getInService());
                            vd.setColor(vehicleDetailst.getColor());
                            vd.setVin(vehicleDetailst.getVin());
                            vd.setLicensePlate(vehicleDetailst.getLicensePlate());
                            vd.setLicensePlateDoc(vehicleDetailst.getLicensePlateDoc());
                            vd.setInsurance(vehicleDetailst.getInsurance());
                            vd.setInsuranceDoc(vehicleDetailst.getInsuranceDoc());
                            vd.setVehicleLogbookDoc(vehicleDetailst.getVehicleLogbookDoc());
                            vd.setVehicleMOTDoc(vehicleDetailst.getVehicleMOTDoc());
                            vd.setHireAgreementDoc(vehicleDetailst.getHireAgreementDoc());
                            vd.setPassengerQuantity(vehicleDetailst.getPassengerQuantity());
                            vd.setBaggageQuantity(vehicleDetailst.getBaggageQuantity());
                            vd.setAirCondition(vehicleDetailst.getAirCondition());
                            vd.setAutomaticTransmission(vehicleDetailst.getAutomaticTransmission());
                            vd.setSateliteNavigation(vehicleDetailst.getSateliteNavigation());
                            vd.setRegistrationNumber(vehicleDetailst.getRegistrationNumber());
                            vd.setModelCode(vehicleDetailst.getModelCode());
//                            vd.setModelName((String) arr[2]);
                            vd.setFuelTypeCode(vehicleDetailst.getFuelTypeCode());
//                            vd.setFuelTypeName((String) arr[3]);
                            vd.setVehicleTypeCode(vehicleDetailst.getVehicleType());
                            
                            RideType rideType = rideTypeDao.getRideTypeByVehicleCode(vehicleDetailst.getVehicleType());
                            if(rideType != null && rideType.getId() > 0) {
                                    vd.setVehicleTypeName(rideType.getVehicleName());
                            }

                            vd.setMakeCode(vehicleDetailst.getMakeCode());
                            MakeType mt=makeTypeRepository.getMakeTypeByVehicleCode(vehicleDetailst.getMakeCode());
                            if(mt != null && mt.getId() > 0) {
                                    vd.setMakeName(mt.getVehicleName());
                            }                            
                            
                            if (vd != null && vd.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(vd);
				jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("message", "Record Not Found");
                                    jsonobj.put("timestamp", new Date());

                            }
                            
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
                        }
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String saveNewVehicleDetail(VehicleDetailRequest vehicleDetailReq, String ip) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (vehicleDetailReq != null) {

				if ( vehicleDetailReq.getLicenseExpiryDate().trim().length() > 0
						&& vehicleDetailReq.getLicenseExpiryDate() != null
						&& vehicleDetailReq.getLicenseExpiryDate().trim().length() > 0
						&& vehicleDetailReq.getLicenseExpiryDate() != null) {

					Date registrationExpiryDate = null;
					Date licenseExpiryDate = null;
                                        
                        Date vehicleMOTExpDate=null;
			Date insurExpDate=null;
                        Date hireAgreementDocExpDate=null;
			
//					Date currentTime = null;
					try {
                                            if(vehicleDetailReq.getInsuranceExpiryDate()!=null && vehicleDetailReq.getInsuranceExpiryDate().trim().length()>0)
                                            {
                                                insurExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getInsuranceExpiryDate().trim());
						if (insurExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send InsuranceExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
                                            
                                            if(vehicleDetailReq.getHireAgreementDocExpiryDate()!=null && vehicleDetailReq.getHireAgreementDocExpiryDate().trim().length()>0)
                                            {
                                                hireAgreementDocExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getHireAgreementDocExpiryDate().trim());
						if (hireAgreementDocExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send HireAgreementDocExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
                                            
                                            if(vehicleDetailReq.getVehicleMOTExpiryDate()!=null && vehicleDetailReq.getVehicleMOTExpiryDate().trim().length()>0)
                                            {
                                                vehicleMOTExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getVehicleMOTExpiryDate().trim());
						if (vehicleMOTExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send VehicleMOTExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
						registrationExpiryDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getRegistrationExpiryDate().trim());
						if (registrationExpiryDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send registrationExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
						licenseExpiryDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getLicenseExpiryDate().trim());
						if (licenseExpiryDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send licenseExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}

					} catch (Exception ex) {
						ex.printStackTrace();
						GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send registrationExpiryDate, HireAgreementDocExpiryDate, VehicleMOTExpiryDate, InsuranceExpiryDate and licenseExpiryDate in correct format("
										+ GigflexConstants.dateFormatterForSave + ") ");
						return derr.toString();
					}
					Organization org = orgDao.findByOrganizationCode(vehicleDetailReq.getOrganizationCode());

					String timezoneCode = org.getTimezone();
					TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
					Date regExpDate = GigflexDateUtil.convertStringDateToGMT(
							vehicleDetailReq.getRegistrationExpiryDate().trim(), tz.getTimeZoneName(),
							GigflexConstants.dateFormatterForSave);
					Date licExpDate = GigflexDateUtil.convertStringDateToGMT(
							vehicleDetailReq.getLicenseExpiryDate().trim(), tz.getTimeZoneName(),
							GigflexConstants.dateFormatterForSave);
					if (regExpDate == null || licExpDate == null) {
						GigflexResponse derr = new GigflexResponse(400, new Date(), "Date conversion has been failed.");
						return derr.toString();
					}
					Date currentTime = new Date();
                                            Calendar cal = Calendar.getInstance();
                                            cal.setTime(currentTime);
                                            cal.add(Calendar.DATE, -1);
                                            currentTime = cal.getTime();
//					Organization org = orgDao.findByOrganizationCode(vehicleDetailReq.getOrganizationCode());
					if (org != null && org.getId() > 0) {

						Fuel fuel = fuelDao.getFuelByFuelCode(vehicleDetailReq.getFuelTypeCode());
						if (fuel != null && fuel.getId() > 0) {
							
							
							RideType rideType = rideTypeDao.getRideTypeByVehicleCode(vehicleDetailReq.getVehicleType());
							if (rideType != null && rideType.getId() > 0) {

							MakeModelMapping mmm = mmmDao
									.getMakeModelMappingByModelCode(vehicleDetailReq.getModelCode());
							if (mmm != null && mmm.getId() > 0) {

//								VehicleDetail vdcr = vehicleDetailDao.getVehicleDetailByOrgCodeAndVehicleName(
//										vehicleDetailReq.getOrganizationCode(), vehicleDetailReq.getVehicleName());
//								if (vdcr != null && vdcr.getId() > 0) {
//									jsonobj.put("responsecode", 409);
//									jsonobj.put("timestamp", new Date());
//									jsonobj.put("message", "Record already exist.");
//								} else {

									if (registrationExpiryDate.after(currentTime)) {

										if (licenseExpiryDate.after(currentTime)) {

											VehicleDetail vd = new VehicleDetail();

//											vd.setVehicleName(vehicleDetailReq.getVehicleName());
//											vd.setAbbrevationName(vehicleDetailReq.getAbbrevationName());
											vd.setVehicleType(vehicleDetailReq.getVehicleType());
											vd.setVehicleYear(vehicleDetailReq.getVehicleYear());
											vd.setInitialMileage(vehicleDetailReq.getInitialMileage());
											vd.setVehicleImage(vehicleDetailReq.getVehicleImage());
											vd.setRegistrationExpiryDate(regExpDate);
											vd.setInService(vehicleDetailReq.getInService());
//											vd.setVehicleEngineType(vehicleDetailReq.getVehicleEngineType());
//											vd.setVehicleHorsePower(vehicleDetailReq.getVehicleHorsePower());
											vd.setColor(vehicleDetailReq.getColor());
											vd.setVin(vehicleDetailReq.getVin());
											vd.setLicensePlate(vehicleDetailReq.getLicensePlate());
											vd.setLicenseExpiryDate(licExpDate);
											//vd.setVehicleGroup(vehicleDetailReq.getVehicleGroup());
											vd.setPassengerQuantity(vehicleDetailReq.getPassengerQuantity());
											vd.setBaggageQuantity(vehicleDetailReq.getBaggageQuantity());
											//vd.setDoorsQuantity(vehicleDetailReq.getDoorsQuantity());
											vd.setAirCondition(vehicleDetailReq.getAirCondition());
											vd.setAutomaticTransmission(vehicleDetailReq.getAutomaticTransmission());
											vd.setFuelTypeCode(vehicleDetailReq.getFuelTypeCode());
											vd.setSateliteNavigation(vehicleDetailReq.getSateliteNavigation());
											vd.setOrganizationCode(vehicleDetailReq.getOrganizationCode());
											vd.setModelCode(vehicleDetailReq.getModelCode());
                                                                                        vd.setLicensePlateDoc(vehicleDetailReq.getLicensePlateDoc());
                                                                                        vd.setInsurance(vehicleDetailReq.getInsurance());
                                                                                        vd.setInsuranceDoc(vehicleDetailReq.getInsuranceDoc());
                                                                                        if(vehicleDetailReq.getInsuranceExpiryDate()!=null && vehicleDetailReq.getInsuranceExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date insuranceExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getInsuranceExpiryDate().trim(), tz.getTimeZoneName(),
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setInsuranceExpiryDate(insuranceExpiryDate);
                                                                                        }
                                                                                        vd.setVehicleLogbookDoc(vehicleDetailReq.getVehicleLogbookDoc());
                                                                                        vd.setVehicleMOTDoc(vehicleDetailReq.getVehicleMOTDoc());
                                                                                        if(vehicleDetailReq.getVehicleMOTExpiryDate()!=null && vehicleDetailReq.getVehicleMOTExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date vehicleMOTExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getVehicleMOTExpiryDate().trim(), tz.getTimeZoneName(),
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setVehicleMOTExpiryDate(vehicleMOTExpiryDate);
                                                                                        }
                                                                                        vd.setHireAgreementDoc(vehicleDetailReq.getHireAgreementDoc());
                                                                                        if(vehicleDetailReq.getHireAgreementDocExpiryDate()!=null && vehicleDetailReq.getHireAgreementDocExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date hireAgreementDocExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getHireAgreementDocExpiryDate().trim(), tz.getTimeZoneName(),
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setHireAgreementDocExpiryDate(hireAgreementDocExpiryDate);
                                                                                        }
                                                                                        vd.setRegistrationNumber(vehicleDetailReq.getRegistrationNumber());
                                                                                        vd.setMakeCode(vehicleDetailReq.getMakeCode());
											vd.setIpAddress(ip);

											VehicleDetail vdRes = vehicleDetailDao.save(vd);
											jsonobj.put("responsecode", 200);
											jsonobj.put("timestamp", new Date());
											if (vdRes != null && vdRes.getId() > 0) {
												jsonobj.put("message", "Vehicle Detail has been added successfully.");
												ObjectMapper mapperObj = new ObjectMapper();
												String Detail = mapperObj.writeValueAsString(vdRes);
												jsonobj.put("data", new JSONObject(Detail));
											}

											else {
												jsonobj.put("message", "Failed");

											}
										} else {
											jsonobj.put("responsecode", 404);
											jsonobj.put("timestamp", new Date());
											jsonobj.put("message", "License Expiry Date must be after current date");
										}
									} else {
										jsonobj.put("responsecode", 404);
										jsonobj.put("timestamp", new Date());
										jsonobj.put("message", "Registration Expiry Date must be after current date");
									}
								//}
							} else {
								jsonobj.put("message", "Model Code Not Found.");
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
							}
						} else {
							jsonobj.put("message", "Vehicle Type Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
						} else {
							jsonobj.put("message", "Fuel Type Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("message", "Organization Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String updateVehicleDetailById(Long id, VehicleDetailRequest vehicleDetailReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (id > 0 && vehicleDetailReq != null) {
				if ( vehicleDetailReq.getLicenseExpiryDate().trim().length() > 0
						&& vehicleDetailReq.getLicenseExpiryDate() != null
						&& vehicleDetailReq.getLicenseExpiryDate().trim().length() > 0
						&& vehicleDetailReq.getLicenseExpiryDate() != null) {

					VehicleDetail vdInDb = vehicleDetailDao.getVehicleDetailById(id);
					if (vdInDb != null && vdInDb.getId() > 0) {

						Date registrationExpiryDate = null;
						Date licenseExpiryDate = null;
						Date vehicleMOTExpDate=null;
			Date insurExpDate=null;
                        Date hireAgreementDocExpDate=null;
			
//					Date currentTime = null;
					try {
                                            if(vehicleDetailReq.getInsuranceExpiryDate()!=null && vehicleDetailReq.getInsuranceExpiryDate().trim().length()>0)
                                            {
                                                insurExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getInsuranceExpiryDate().trim());
						if (insurExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send InsuranceExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
                                            
                                            if(vehicleDetailReq.getHireAgreementDocExpiryDate()!=null && vehicleDetailReq.getHireAgreementDocExpiryDate().trim().length()>0)
                                            {
                                                hireAgreementDocExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getHireAgreementDocExpiryDate().trim());
						if (hireAgreementDocExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send HireAgreementDocExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
                                            
                                            if(vehicleDetailReq.getVehicleMOTExpiryDate()!=null && vehicleDetailReq.getVehicleMOTExpiryDate().trim().length()>0)
                                            {
                                                vehicleMOTExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getVehicleMOTExpiryDate().trim());
						if (vehicleMOTExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send VehicleMOTExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
							registrationExpiryDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
									.parse(vehicleDetailReq.getRegistrationExpiryDate().trim());
							if (registrationExpiryDate == null) {
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Plz send registrationExpiryDate in correct format("
												+ GigflexConstants.dateFormatterForSave + ") ");
								return derr.toString();
							}
							licenseExpiryDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
									.parse(vehicleDetailReq.getLicenseExpiryDate().trim());
							if (licenseExpiryDate == null) {
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Plz send licenseExpiryDate in correct format("
												+ GigflexConstants.dateFormatterForSave + ") ");
								return derr.toString();
							}

						} catch (Exception ex) {
							ex.printStackTrace();
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send registrationExpiryDate, HireAgreementDocExpiryDate, VehicleMOTExpiryDate, InsuranceExpiryDate and licenseExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
						Organization org = orgDao.findByOrganizationCode(vehicleDetailReq.getOrganizationCode());

						String timezoneCode = org.getTimezone();
						TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
						Date regExpDate = GigflexDateUtil.convertStringDateToGMT(
								vehicleDetailReq.getRegistrationExpiryDate().trim(), tz.getTimeZoneName(),
								GigflexConstants.dateFormatterForSave);
						Date licExpDate = GigflexDateUtil.convertStringDateToGMT(
								vehicleDetailReq.getLicenseExpiryDate().trim(), tz.getTimeZoneName(),
								GigflexConstants.dateFormatterForSave);
						if (regExpDate == null && licExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Date conversion has been failed.");
							return derr.toString();
						}
						Date currentTime = new Date();
                                            Calendar cal = Calendar.getInstance();
                                            cal.setTime(currentTime);
                                            cal.add(Calendar.DATE, -1);
                                            currentTime = cal.getTime();

//						Organization org = orgDao.findByOrganizationCode(vehicleDetailReq.getOrganizationCode());
						if (org != null && org.getId() > 0) {

							Fuel fuel = fuelDao.getFuelByFuelCode(vehicleDetailReq.getFuelTypeCode());
							if (fuel != null && fuel.getId() > 0) {
								
								RideType rideType = rideTypeDao.getRideTypeByVehicleCode(vehicleDetailReq.getVehicleType());
								if (rideType != null && rideType.getId() > 0) {

								MakeModelMapping mmm = mmmDao
										.getMakeModelMappingByModelCode(vehicleDetailReq.getModelCode());
								if (mmm != null && mmm.getId() > 0) {

//									VehicleDetail vdcr = vehicleDetailDao.getVehicleDetailByIdOrgCodeAndVehicleName(id,
//											vehicleDetailReq.getOrganizationCode(), vehicleDetailReq.getVehicleName());
//									if (vdcr != null && vdcr.getId() > 0) {
//										jsonobj.put("responsecode", 409);
//										jsonobj.put("timestamp", new Date());
//										jsonobj.put("message", "Record already exist.");
//									} else {

										if (registrationExpiryDate.after(currentTime)) {

											if (licenseExpiryDate.after(currentTime)) {

												VehicleDetail vd = vdInDb;

												//vd.setVehicleName(vehicleDetailReq.getVehicleName());
												//vd.setAbbrevationName(vehicleDetailReq.getAbbrevationName());
												vd.setVehicleType(vehicleDetailReq.getVehicleType());
												vd.setVehicleYear(vehicleDetailReq.getVehicleYear());
												vd.setInitialMileage(vehicleDetailReq.getInitialMileage());
												vd.setVehicleImage(vehicleDetailReq.getVehicleImage());
												vd.setRegistrationExpiryDate(regExpDate);
												vd.setInService(vehicleDetailReq.getInService());
												//vd.setVehicleEngineType(vehicleDetailReq.getVehicleEngineType());
												//vd.setVehicleHorsePower(vehicleDetailReq.getVehicleHorsePower());
												vd.setColor(vehicleDetailReq.getColor());
												vd.setVin(vehicleDetailReq.getVin());
												vd.setLicensePlate(vehicleDetailReq.getLicensePlate());
												vd.setLicenseExpiryDate(licExpDate);
												//vd.setVehicleGroup(vehicleDetailReq.getVehicleGroup());
												vd.setPassengerQuantity(vehicleDetailReq.getPassengerQuantity());
												vd.setBaggageQuantity(vehicleDetailReq.getBaggageQuantity());
												//vd.setDoorsQuantity(vehicleDetailReq.getDoorsQuantity());
												vd.setAirCondition(vehicleDetailReq.getAirCondition());
												vd.setAutomaticTransmission(
														vehicleDetailReq.getAutomaticTransmission());
												vd.setFuelTypeCode(vehicleDetailReq.getFuelTypeCode());
												vd.setSateliteNavigation(vehicleDetailReq.getSateliteNavigation());
												vd.setOrganizationCode(vehicleDetailReq.getOrganizationCode());
												vd.setModelCode(vehicleDetailReq.getModelCode());

                                                                                                vd.setLicensePlateDoc(vehicleDetailReq.getLicensePlateDoc());
                                                                                        vd.setInsurance(vehicleDetailReq.getInsurance());
                                                                                        vd.setInsuranceDoc(vehicleDetailReq.getInsuranceDoc());
                                                                                        if(vehicleDetailReq.getInsuranceExpiryDate()!=null && vehicleDetailReq.getInsuranceExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date insuranceExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getInsuranceExpiryDate().trim(), tz.getTimeZoneName(),
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setInsuranceExpiryDate(insuranceExpiryDate);
                                                                                        }
                                                                                        vd.setVehicleLogbookDoc(vehicleDetailReq.getVehicleLogbookDoc());
                                                                                        vd.setVehicleMOTDoc(vehicleDetailReq.getVehicleMOTDoc());
                                                                                        if(vehicleDetailReq.getVehicleMOTExpiryDate()!=null && vehicleDetailReq.getVehicleMOTExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date vehicleMOTExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getVehicleMOTExpiryDate().trim(), tz.getTimeZoneName(),
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setVehicleMOTExpiryDate(vehicleMOTExpiryDate);
                                                                                        }
                                                                                        vd.setHireAgreementDoc(vehicleDetailReq.getHireAgreementDoc());
                                                                                        if(vehicleDetailReq.getHireAgreementDocExpiryDate()!=null && vehicleDetailReq.getHireAgreementDocExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date hireAgreementDocExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getHireAgreementDocExpiryDate().trim(), tz.getTimeZoneName(),
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setHireAgreementDocExpiryDate(hireAgreementDocExpiryDate);
                                                                                        }
                                                                                        vd.setRegistrationNumber(vehicleDetailReq.getRegistrationNumber());
                                                                                        vd.setMakeCode(vehicleDetailReq.getMakeCode());
												vd.setIpAddress(ip);

												VehicleDetail vdRes = vehicleDetailDao.save(vd);
												if (vdRes != null && vdRes.getId() > 0) {
													jsonobj.put("responsecode", 200);
													jsonobj.put("message", "Vehicle Detail updation has been done");
													jsonobj.put("timestamp", new Date());
													ObjectMapper mapperObj = new ObjectMapper();
													String Detail = mapperObj.writeValueAsString(vdRes);
													jsonobj.put("data", new JSONObject(Detail));

												} else {
													jsonobj.put("responsecode", 400);
													jsonobj.put("message", "Vehicle Detail updation has been failed.");
													jsonobj.put("timestamp", new Date());
												}

											} else {
												jsonobj.put("responsecode", 404);
												jsonobj.put("timestamp", new Date());
												jsonobj.put("message",
														"License Expiry Date must be after current date");
											}
										} else {
											jsonobj.put("responsecode", 404);
											jsonobj.put("timestamp", new Date());
											jsonobj.put("message",
													"Registration Expiry Date must be after current date");
										}
									//}
								} else {
									jsonobj.put("message", "Model Code Not Found.");
									jsonobj.put("responsecode", 400);
									jsonobj.put("timestamp", new Date());
								}
								} else {
									jsonobj.put("message", "Vehicle Type Code Not Found.");
									jsonobj.put("responsecode", 400);
									jsonobj.put("timestamp", new Date());
								}
							} else {
								jsonobj.put("message", "Fuel Type Code Not Found.");
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
							}

						} else {
							jsonobj.put("message", "Organization Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Vehicle Detail Id is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String softDeleteByVehicleCode(String vehicleCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			VehicleDetail vdlst = vehicleDetailDao.getVehicleDetailByVehicleCode(vehicleCode);

			if (vdlst != null && vdlst.getId() > 0) {
				vdlst.setIsDeleted(true);
				VehicleDetail vdRes = vehicleDetailDao.save(vdlst);

				if (vdRes != null && vdRes.getId() > 0) {

					VehicleDriverMapping vehDri = vehDriverDao
							.getVehicleDriverMappingByVehicleCode(vdRes.getVehicleCode());
					if (vehDri != null && vehDri.getId() > 0) {
						vehDri.setIsDeleted(true);

						VehicleDriverMapping vehDriverRes = vehDriverDao.save(vehDri);
						if (vehDriverRes != null && vehDriverRes.getId() > 0) {
//                                                    try {
//                                                        Driver dr = driverDao.getDriverByDriverCode(vehDri.getDriverCode());
//                                                        if (dr != null && dr.getId() > 0) {
//                                                            if (dr.getFleetSize() != null && dr.getFleetSize() > 0) {
//                                                                dr.setFleetSize(dr.getFleetSize() - 1);
//                                                            } else {
//                                                                dr.setFleetSize(0);
//                                                            }
//                                                            driverDao.save(dr);
//                                                        }
//                                                    } catch (Exception exp) {
//                                                        exp.printStackTrace();
//                                                    }
                                                    jsonobj.put("responsecode", 200);
                                                    jsonobj.put("timestamp", new Date());
                                                    jsonobj.put("message", "Vehicle Detail deleted successfully.");
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Failed");
						} // kafkaService.sendRoleMasterUpdate(roleRes);
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}

			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByVehicleCode(List<String> vehicleCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String vehicleCode : vehicleCodeList) {
				if (vehicleCode != null && vehicleCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					vehicleCode = vehicleCode.trim();

					VehicleDetail vdlst = vehicleDetailDao.getVehicleDetailByVehicleCode(vehicleCode);

					if (vdlst != null && vdlst.getId() > 0) {

						vdlst.setIsDeleted(true);
						VehicleDetail vdRes = vehicleDetailDao.save(vdlst);
						if (vdRes != null && vdRes.getId() > 0) {

							VehicleDriverMapping vehDri = vehDriverDao
									.getVehicleDriverMappingByVehicleCode(vdRes.getVehicleCode());
							if (vehDri != null && vehDri.getId() > 0) {
								vehDri.setIsDeleted(true);

								VehicleDriverMapping vehDriverRes = vehDriverDao.save(vehDri);
								if (vehDriverRes != null && vehDriverRes.getId() > 0) {
//                                                                    try {
//                                                        Driver dr = driverDao.getDriverByDriverCode(vehDri.getDriverCode());
//                                                        if (dr != null && dr.getId() > 0) {
//                                                            if (dr.getFleetSize() != null && dr.getFleetSize() > 0) {
//                                                                dr.setFleetSize(dr.getFleetSize() - 1);
//                                                            } else {
//                                                                dr.setFleetSize(0);
//                                                            }
//                                                            driverDao.save(dr);
//                                                        }
//                                                    } catch (Exception exp) {
//                                                        exp.printStackTrace();
//                                                    }

									jsonobj.put("responsecode", 200);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("code", vehicleCode);
									jsonobj.put("message", "Vehicle Detail deleted successfully.");
									// kafkaService.se
								}
							else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", vehicleCode);
								jsonobj.put("message", "Failed");
							}
							
						} else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", vehicleCode);
							jsonobj.put("message", "Record Not Found");
						}
						}else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", vehicleCode);
							jsonobj.put("message", "Failed");
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);

				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String getAllVehicleDetailByPage(int page, int limit) {
		

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if(limit > 0){

				
				
                        Pageable pageableRequest = PageRequest.of(page, limit);

                        List<Object> objlst1 = vehicleDetailDao.getAllVehicleDetail();
                        int count = objlst1.size();

                        List<Object> objlst = vehicleDetailDao.getAllVehicleDetail(pageableRequest);
                        List<VehicleDetailResponse> maplst = new ArrayList<VehicleDetailResponse>();
                        if (objlst != null && objlst.size() > 0) {
                                for (int i = 0; i < objlst.size(); i++) {
                                        Object[] arr = (Object[]) objlst.get(i);
                                        if (arr.length >= 4) {

                        Date regExpDate=null;
			Date licExpDate=null;
			String conDtRegExp = "";
			String conDtLicExp = "";
                        Date insurExpDate=null;
			String conDtInsurExp = "";
                        Date vehicleMOTExpDate=null;
			String conDtVehicleMOTExp = "";
                        Date hireAgreementDocExpDate=null;
			String conDtHireAgreementDocExp = "";
                        String dateformat = "";
                        String timeformat = "";
                        String timezoneCode = "";
                        TimeZoneDetail tz = null;
                        String timezone = "";
                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                        VehicleDetailResponse vd = new VehicleDetailResponse();

                        VehicleDetail data = (VehicleDetail) arr[0];

                        VehicleDriverMapping vdm = new VehicleDriverMapping();
                         
			regExpDate = data.getRegistrationExpiryDate();	
                        licExpDate = data.getLicenseExpiryDate();
                        insurExpDate = data.getInsuranceExpiryDate();
                        vehicleMOTExpDate = data.getVehicleMOTExpiryDate();
                        hireAgreementDocExpDate = data.getHireAgreementDocExpiryDate();
                        if (data.getOrganizationCode() != null) {
                                Organization org = orgDao.findByOrganizationCode(data.getOrganizationCode());
                                if (org != null && org.getId() > 0) {
                                        
                                        dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                        timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                        {
                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                        }                

                                        timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TimeZone);
                                        tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                        timezone = tz.getTimeZoneName(); 

                                        if(timezone!=null && timezone.length()>0 )
                                        { 
                                                if (regExpDate != null) {
                                                    regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                                    conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                                }                                        
                                                if (licExpDate != null) {
                                                        licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate,timezone,dtFormat);
                                                        conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                                }

                                                if (insurExpDate != null) {
                                                        insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                                        conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                                }


                                                if (vehicleMOTExpDate != null) {
                                                        vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                                        conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                                }


                                                if (hireAgreementDocExpDate != null) {
                                                        hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate, timezone,dtFormat);
                                                        conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                                }
                                            
                                        }
                                       
                                }
                                
                                vd.setOrganizationCode(data.getOrganizationCode());
                                vd.setOrganizationName(org.getOrganizationName());
                        }else {

//                            tz = timeZoneRepository
//                                            .getTimeZoneByDriverCode((String) arr[1]); 
                            
                            String driverCode = (String) arr[1];

                            Driver driver = driverDao.getDriverByDriverCode(driverCode);
                            String organizationCode = driver.getOrganizationCode();      
                            
                            dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                            timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);
                            tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            timezone = tz.getTimeZoneName(); 
                            
                            if(timezone!=null && timezone.length()>0 )
                            { 
                                    if (regExpDate != null) {
                                       regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                       conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                    }                            
                                    if (licExpDate != null) {
                                            licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                            conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                    }


                                    if (insurExpDate != null) {
                                            insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                            conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                    }

                                    if (vehicleMOTExpDate != null) {
                                            vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                            conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                    }

                                    if (hireAgreementDocExpDate != null) {
                                            hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate, timezone,dtFormat);
                                            conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                    }
                            }
                           
                    }
                             
			    vd.setRegistrationExpiryDate(conDtRegExp);
                            vd.setLicenseExpiryDate(conDtLicExp);
                            vd.setInsuranceExpiryDate(conDtInsurExp);
                            vd.setVehicleMOTExpiryDate(conDtVehicleMOTExp);
                            vd.setHireAgreementDocExpiryDate(conDtHireAgreementDocExp);
                                
                            vd.setDateFormat(dateformat);
                            vd.setTimeFormat(timeformat);
                            vd.setId(data.getId());
                            vd.setVehicleCode(data.getVehicleCode());
                            vd.setVehicleYear(data.getVehicleYear());
                            vd.setInitialMileage(data.getInitialMileage());
                            vd.setVehicleImage(data.getVehicleImage());
                            vd.setInService(data.getInService());
                            vd.setColor(data.getColor());
                            vd.setVin(data.getVin());
                            vd.setLicensePlate(data.getLicensePlate());
                            vd.setLicensePlateDoc(data.getLicensePlateDoc());
                            vd.setInsurance(data.getInsurance());
                            vd.setInsuranceDoc(data.getInsuranceDoc());
                            vd.setVehicleLogbookDoc(data.getVehicleLogbookDoc());
                            vd.setVehicleMOTDoc(data.getVehicleMOTDoc());
                            vd.setHireAgreementDoc(data.getHireAgreementDoc());
                            vd.setPassengerQuantity(data.getPassengerQuantity());
                            vd.setBaggageQuantity(data.getBaggageQuantity());
                            vd.setAirCondition(data.getAirCondition());
                            vd.setAutomaticTransmission(data.getAutomaticTransmission());
                            vd.setSateliteNavigation(data.getSateliteNavigation());
                            vd.setRegistrationNumber(data.getRegistrationNumber());
                            vd.setModelCode(data.getModelCode());
                            vd.setModelName((String) arr[2]);
                            vd.setFuelTypeCode(data.getFuelTypeCode());
                            vd.setFuelTypeName((String) arr[3]);
                            vd.setVehicleTypeCode(data.getVehicleType());

                            RideType rideType = rideTypeDao.getRideTypeByVehicleCode(data.getVehicleType());
                            if(rideType != null && rideType.getId() > 0) {
                                    vd.setVehicleTypeName(rideType.getVehicleName());
                            }

                            vd.setMakeCode(data.getMakeCode());
                            MakeType mt=makeTypeRepository.getMakeTypeByVehicleCode(data.getMakeCode());
                            if(mt != null && mt.getId() > 0) {
                                    vd.setMakeName(mt.getVehicleName());
                            }
       // dro.setVehicleCode(data.getVehicleCode());

                            Driver driver = driverDao.getDriverByDriverCode((String) arr[1]);
                            if (driver != null && driver.getId() > 0) {
                                    vd.setDriverCode(driver.getDriverCode());
                                    vd.setDriverName(driver.getName());
                            }

                            maplst.add(vd);

                    }
                    }
                    if (maplst.size() > 0) {
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(maplst);
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("message", "Success");
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("count", count);
                            jsonobj.put("data", new JSONArray(Detail));
                    } else {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Record Not Found");
                            jsonobj.put("timestamp", new Date());
                    }
                } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                }
           }else{
                jsonobj.put("responsecode", 400);
	        jsonobj.put("message", "Limit should not be Zero or Negative.");
	        jsonobj.put("timestamp", new Date());
	        }

				res = jsonobj.toString();
			} catch (JSONException ex) {
				GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
				res = derr.toString();
				ex.printStackTrace();
                                LOG.error("JSON parsing exception is occurred.",ex); 
			} catch (Exception ex) {
				GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
				res = derr.toString();
				ex.printStackTrace();
                                LOG.error("Exception is occurred.",ex);
			}
			return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				VehicleDetailSpecificationsBuilder builder = new VehicleDetailSpecificationsBuilder();
				Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
				}

				Specification<VehicleDetail> spec = builder.build();
				if (spec != null) {
					List<VehicleDetail> VehicleDetailLst = vehicleDetailDao.findAll(spec);
					if (VehicleDetailLst != null && VehicleDetailLst.size() > 0) {
						for (VehicleDetail dept : VehicleDetailLst) {
							if (dept.getIsDeleted() != null && dept.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(dept);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("VehicleDetail", new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		}
		return res;

	}

	@Override
	public String getVehicleDetailByOrganizationCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = vehicleDetailDao.getVehicleDetailByOrgCode(organizationCode);
			List<VehicleDetailResponse> maplst = new ArrayList<VehicleDetailResponse>();
			if (objlst != null && objlst.size() > 0) {

				Organization org = orgDao.findByOrganizationCode(organizationCode);
				if (org != null && org.getId() > 0) {
                                        
                                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
//					String timezoneCode = org.getTimezone();
//					TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                        {
                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                        }                

                                        String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);
                                        TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                        String timezone = tz.getTimeZoneName();                              
                                        
					for (int i = 0; i < objlst.size(); i++) {
                                            Object[] arr = (Object[]) objlst.get(i);
                                            if (arr.length >= 5) {

                                                VehicleDetailResponse vd = new VehicleDetailResponse();
                                                String conDtRegExp = "";
                                                String conDtLicExp = "";
                                                Date insurExpDate=null;
                                                String conDtInsurExp = "";
                                                Date vehicleMOTExpDate=null;
                                                String conDtVehicleMOTExp = "";
                                                Date hireAgreementDocExpDate=null;
                                                String conDtHireAgreementDocExp = "";
                                                VehicleDetail data = (VehicleDetail) arr[0];
                                                
                                                if(timezone!=null && timezone.length()>0 )
                                                { 
                                                    Date regExpDate = data.getRegistrationExpiryDate();
                                                    if (regExpDate != null) {
                                                            regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                                            conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                                    }
                                                    Date licExpDate = data.getLicenseExpiryDate();
                                                    if (licExpDate != null) {
                                                            licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                                            conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                                    }


                                                    insurExpDate = data.getInsuranceExpiryDate();
                                                    if (insurExpDate != null) {
                                                            insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                                            conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                                    }
                                                    vehicleMOTExpDate = data.getVehicleMOTExpiryDate();
                                                    if (vehicleMOTExpDate != null) {
                                                            vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                                            conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                                    }

                                                    hireAgreementDocExpDate = data.getHireAgreementDocExpiryDate();
                                                    if (hireAgreementDocExpDate != null) {
                                                            hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate, tz.getTimeZoneName(),
                                                                            GigflexConstants.dateFormatterForView);
                                                            conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                                    }
                                                }
                                                
                                                vd.setRegistrationExpiryDate(conDtRegExp);
                                                vd.setLicenseExpiryDate(conDtLicExp);
                                                vd.setInsuranceExpiryDate(conDtInsurExp);
                                                vd.setVehicleMOTExpiryDate(conDtVehicleMOTExp);
                                                vd.setHireAgreementDocExpiryDate(conDtHireAgreementDocExp);

                                                vd.setDateFormat(dateformat);
                                                vd.setTimeFormat(timeformat);
                                                vd.setId(data.getId());
						vd.setVehicleCode(data.getVehicleCode());
						vd.setVehicleYear(data.getVehicleYear());
						vd.setInitialMileage(data.getInitialMileage());
						vd.setVehicleImage(data.getVehicleImage());
						vd.setInService(data.getInService());
						vd.setColor(data.getColor());
						vd.setVin(data.getVin());
						vd.setLicensePlate(data.getLicensePlate());
                                                vd.setLicensePlateDoc(data.getLicensePlateDoc());
                                                vd.setInsurance(data.getInsurance());
                                                vd.setInsuranceDoc(data.getInsuranceDoc());
                                                vd.setVehicleLogbookDoc(data.getVehicleLogbookDoc());
                                                vd.setVehicleMOTDoc(data.getVehicleMOTDoc());
                                                vd.setHireAgreementDoc(data.getHireAgreementDoc());
						vd.setPassengerQuantity(data.getPassengerQuantity());
						vd.setBaggageQuantity(data.getBaggageQuantity());
						vd.setAirCondition(data.getAirCondition());
						vd.setAutomaticTransmission(data.getAutomaticTransmission());
						vd.setSateliteNavigation(data.getSateliteNavigation());
                                                vd.setRegistrationNumber(data.getRegistrationNumber());
						vd.setOrganizationCode(data.getOrganizationCode());
                                                vd.setOrganizationName((String) arr[1]);
                                                vd.setModelCode(data.getModelCode());
                                                vd.setModelName((String) arr[2]);
                                                vd.setFuelTypeCode(data.getFuelTypeCode());
                                                vd.setFuelTypeName((String) arr[3]);

                                                vd.setVehicleTypeCode(data.getVehicleType());

                                                RideType rideType = rideTypeDao.getRideTypeByVehicleCode(data.getVehicleType());
                                                if(rideType != null && rideType.getId() > 0) {
                                                        vd.setVehicleTypeName(rideType.getVehicleName());
                                                }

                                                vd.setMakeCode(data.getMakeCode());
                                                MakeType mt=makeTypeRepository.getMakeTypeByVehicleCode(data.getMakeCode());
                                                if(mt != null && mt.getId() > 0) {
							vd.setMakeName(mt.getVehicleName());
						}
							
							Driver driver = driverDao.getDriverByDriverCode((String) arr[4]);
							if (driver != null && driver.getId() > 0) {
								vd.setDriverCode(driver.getDriverCode());
								vd.setDriverName(driver.getName());
							}
							maplst.add(vd);

						}
					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;

	}

	@Override
	public String getVehicleDetailByOrganizationCodeByPage(String organizationCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if(limit > 0){
			Pageable pageableRequest = PageRequest.of(page, limit);
			
			List<Object> objlst1 = vehicleDetailDao.getVehicleDetailByOrgCode(organizationCode);
			int count = objlst1.size();
			
			List<Object> objlst = vehicleDetailDao.getVehicleDetailByOrgCode(organizationCode, pageableRequest);
			List<VehicleDetailResponse> maplst = new ArrayList<VehicleDetailResponse>();
			if (objlst != null && objlst.size() > 0) {

				Organization org = orgDao.findByOrganizationCode(organizationCode);
				if (org != null && org.getId() > 0) {
					 String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
//					String timezoneCode = org.getTimezone();
//					TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                        {
                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                        }                

                                        String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);
                                        TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                        String timezone = tz.getTimeZoneName();  

					for (int i = 0; i < objlst.size(); i++) {
                                            Object[] arr = (Object[]) objlst.get(i);
                                            if (arr.length >= 5) {

                                                VehicleDetailResponse vd = new VehicleDetailResponse();
                                                String conDtRegExp = "";
                                                String conDtLicExp = "";
                                                Date insurExpDate=null;
                                                String conDtInsurExp = "";
                                                Date vehicleMOTExpDate=null;
                                                String conDtVehicleMOTExp = "";
                                                Date hireAgreementDocExpDate=null;
                                                String conDtHireAgreementDocExp = "";
                                                VehicleDetail data = (VehicleDetail) arr[0];
                                                 if(timezone!=null && timezone.length()>0 )
                                                {
                                                    Date regExpDate = data.getRegistrationExpiryDate();
                                                    if (regExpDate != null) {
                                                        regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                                        conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                                    }
                                                    Date licExpDate = data.getLicenseExpiryDate();
                                                    if (licExpDate != null) {
                                                        licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate,timezone,dtFormat);
                                                        conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                                    }


                                                    insurExpDate = data.getInsuranceExpiryDate();
                                                    if (insurExpDate != null) {
                                                        insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                                        conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                                    }
                                                    vehicleMOTExpDate = data.getVehicleMOTExpiryDate();
                                                    if (vehicleMOTExpDate != null) {
                                                        vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                                        conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                                    }

                                                    hireAgreementDocExpDate = data.getHireAgreementDocExpiryDate();
                                                    if (hireAgreementDocExpDate != null) {
                                                        hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate, timezone,dtFormat);
                                                        conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                                    }

                                                }

                                                vd.setRegistrationExpiryDate(conDtRegExp);
                                                vd.setLicenseExpiryDate(conDtLicExp);
                                                vd.setInsuranceExpiryDate(conDtInsurExp);
                                                vd.setVehicleMOTExpiryDate(conDtVehicleMOTExp);
                                                vd.setHireAgreementDocExpiryDate(conDtHireAgreementDocExp);

                                                vd.setDateFormat(dateformat);
                                                vd.setTimeFormat(timeformat);
                                                vd.setId(data.getId());
						vd.setVehicleCode(data.getVehicleCode());
						vd.setVehicleYear(data.getVehicleYear());
						vd.setInitialMileage(data.getInitialMileage());
						vd.setVehicleImage(data.getVehicleImage());
						vd.setInService(data.getInService());
						vd.setColor(data.getColor());
						vd.setVin(data.getVin());
						vd.setLicensePlate(data.getLicensePlate());
                                                vd.setLicensePlateDoc(data.getLicensePlateDoc());
                                                vd.setInsurance(data.getInsurance());
                                                vd.setInsuranceDoc(data.getInsuranceDoc());
                                                vd.setVehicleLogbookDoc(data.getVehicleLogbookDoc());
                                                vd.setVehicleMOTDoc(data.getVehicleMOTDoc());
                                                vd.setHireAgreementDoc(data.getHireAgreementDoc());
						vd.setPassengerQuantity(data.getPassengerQuantity());
						vd.setBaggageQuantity(data.getBaggageQuantity());
						vd.setAirCondition(data.getAirCondition());
						vd.setAutomaticTransmission(data.getAutomaticTransmission());
						vd.setSateliteNavigation(data.getSateliteNavigation());
                                                vd.setRegistrationNumber(data.getRegistrationNumber());
						vd.setOrganizationCode(data.getOrganizationCode());
                                                vd.setOrganizationName((String) arr[1]);
                                                vd.setModelCode(data.getModelCode());
                                                vd.setModelName((String) arr[2]);
                                                vd.setFuelTypeCode(data.getFuelTypeCode());
                                                vd.setFuelTypeName((String) arr[3]);

                                                vd.setVehicleTypeCode(data.getVehicleType());

                                                RideType rideType = rideTypeDao.getRideTypeByVehicleCode(data.getVehicleType());
                                                if(rideType != null && rideType.getId() > 0) {
                                                        vd.setVehicleTypeName(rideType.getVehicleName());
                                                }

                                                vd.setMakeCode(data.getMakeCode());
                                                MakeType mt=makeTypeRepository.getMakeTypeByVehicleCode(data.getMakeCode());
                                                if(mt != null && mt.getId() > 0) {
							vd.setMakeName(mt.getVehicleName());
						}
							
							Driver driver = driverDao.getDriverByDriverCode((String) arr[4]);
							if (driver != null && driver.getId() > 0) {
								vd.setDriverCode(driver.getDriverCode());
								vd.setDriverName(driver.getName());
							}
							maplst.add(vd);

						}
					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			}else{
	            jsonobj.put("responsecode", 400);
	        jsonobj.put("message", "Limit should not be Zero or Negative.");
	        jsonobj.put("timestamp", new Date());
	        }

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;

	}

	@Override
	public String getVehicleDetailByVehicleCodeWithName(String vehicleCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Object objlst = vehicleDetailDao.getVehicleDetailByVehicleCodeWithName(vehicleCode);
			if (objlst != null ) {
//				for (int i = 0; i < objlst.size(); i++) {
			Object[] arr = (Object[]) objlst;
			if (arr.length >= 4) {
                        Date regExpDate=null;
			Date licExpDate=null;
			String conDtRegExp = "";
			String conDtLicExp = "";
                        Date insurExpDate=null;
			String conDtInsurExp = "";
                        Date vehicleMOTExpDate=null;
			String conDtVehicleMOTExp = "";
                        Date hireAgreementDocExpDate=null;
			String conDtHireAgreementDocExp = "";
                        String dateformat = "";
                        String timeformat = "";
                        String timezoneCode = "";
                        TimeZoneDetail tz = null;
                        String timezone = "";
                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                        
                        VehicleDetailResponse vd = new VehicleDetailResponse();

                        VehicleDetail data = (VehicleDetail) arr[0];

                        VehicleDriverMapping vdm = new VehicleDriverMapping();

                        regExpDate = data.getRegistrationExpiryDate();
                        licExpDate = data.getLicenseExpiryDate();
                        insurExpDate = data.getInsuranceExpiryDate();
                        vehicleMOTExpDate = data.getVehicleMOTExpiryDate();
                        hireAgreementDocExpDate = data.getHireAgreementDocExpiryDate();	
                        if (data.getOrganizationCode() != null) {
                            
                              Organization org = orgDao.findByOrganizationCode(data.getOrganizationCode());
                              if (org != null && org.getId() > 0) {
                                    
                                    
                                        dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                        timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                        {
                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                        }                

                                        timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TimeZone);
                                        tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                        timezone = tz.getTimeZoneName(); 

                                       if(timezone!=null && timezone.length()>0 )
                                        { 

                                             if (regExpDate != null) {
                                                regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                                conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                                }

                                                if (licExpDate != null) {
                                                        licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                                        conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                                }


                                                if (insurExpDate != null) {
                                                        insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                                        conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                                }


                                                if (vehicleMOTExpDate != null) {
                                                        vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                                        conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                                }


                                                if (hireAgreementDocExpDate != null) {
                                                        hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate, timezone,dtFormat);
                                                        conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                                }
                                        }
                                       
                                }
                                vd.setOrganizationCode(data.getOrganizationCode());
                                vd.setOrganizationName(org.getOrganizationName());
                        }else {

//                                TimeZoneDetail tz = timeZoneRepository
//                                                .getTimeZoneByDriverCode((String) arr[1]);
                                                 
                                String driverCode = (String) arr[1];

                                Driver driver = driverDao.getDriverByDriverCode(driverCode);
                                String organizationCode = driver.getOrganizationCode();                                                

                                dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations,organizationCode, GigflexConstants.TimeZone);

                                tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                timezone = tz.getTimeZoneName();

                                if(timezone!=null && timezone.length()>0 )
                                { 
                                    if (regExpDate != null) {
                                        regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                        conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                    }

                                    if (licExpDate != null) {
                                            licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                            conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                    }

                                    if (insurExpDate != null) {
                                            insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                            conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                    }

                                    if (vehicleMOTExpDate != null) {
                                            vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                            conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                    }

                                    if (hireAgreementDocExpDate != null) {
                                            hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate, timezone,dtFormat);
                                            conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                    }

                                }
                                
                            }

                                vd.setRegistrationExpiryDate(conDtRegExp);
                                vd.setLicenseExpiryDate(conDtLicExp);
                                vd.setInsuranceExpiryDate(conDtInsurExp);
                                vd.setVehicleMOTExpiryDate(conDtVehicleMOTExp);
                                vd.setHireAgreementDocExpiryDate(conDtHireAgreementDocExp);

                                vd.setDateFormat(dateformat);
                                vd.setTimeFormat(timeformat);
                                vd.setId(data.getId());
                                vd.setVehicleCode(data.getVehicleCode());
                                vd.setVehicleYear(data.getVehicleYear());
                                vd.setInitialMileage(data.getInitialMileage());
                                vd.setVehicleImage(data.getVehicleImage());
                                vd.setInService(data.getInService());
                                vd.setColor(data.getColor());
                                vd.setVin(data.getVin());
                                vd.setLicensePlate(data.getLicensePlate());
                                vd.setLicensePlateDoc(data.getLicensePlateDoc());
                                vd.setInsurance(data.getInsurance());
                                vd.setInsuranceDoc(data.getInsuranceDoc());
                                vd.setVehicleLogbookDoc(data.getVehicleLogbookDoc());
                                vd.setVehicleMOTDoc(data.getVehicleMOTDoc());
                                vd.setHireAgreementDoc(data.getHireAgreementDoc());
                                vd.setPassengerQuantity(data.getPassengerQuantity());
                                vd.setBaggageQuantity(data.getBaggageQuantity());
                                vd.setAirCondition(data.getAirCondition());
                                vd.setAutomaticTransmission(data.getAutomaticTransmission());
                                vd.setSateliteNavigation(data.getSateliteNavigation());
                                vd.setRegistrationNumber(data.getRegistrationNumber());
                                vd.setModelCode(data.getModelCode());
                                vd.setModelName((String) arr[2]);
                                vd.setFuelTypeCode(data.getFuelTypeCode());
                                vd.setFuelTypeName((String) arr[3]);
                                vd.setVehicleTypeCode(data.getVehicleType());

                                RideType rideType = rideTypeDao.getRideTypeByVehicleCode(data.getVehicleType());
                                if(rideType != null && rideType.getId() > 0) {
                                        vd.setVehicleTypeName(rideType.getVehicleName());
                                }

                                vd.setMakeCode(data.getMakeCode());
                                MakeType mt=makeTypeRepository.getMakeTypeByVehicleCode(data.getMakeCode());
                                if(mt != null && mt.getId() > 0) {
                                        vd.setMakeName(mt.getVehicleName());
                                }
                       // dro.setVehicleCode(data.getVehicleCode());

                            Driver driver = driverDao.getDriverByDriverCode((String) arr[1]);
                            if (driver != null && driver.getId() > 0) {
                                    vd.setDriverCode(driver.getDriverCode());
                                    vd.setDriverName(driver.getName());
                            }

                            VehicleDetailResponse maplst = vd;

//						maplst.add(vd);

//					}
//				}
				if (maplst != null) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                       } else {
                               jsonobj.put("responsecode", 404);
                               jsonobj.put("message", "Record Not Found");
                               jsonobj.put("timestamp", new Date());
                       }
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String getVehicleDetailByModelCode(String modelCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = vehicleDetailDao.getVehicleDetailByModelCode(modelCode);
			List<VehicleDetailResponse> maplst = new ArrayList<VehicleDetailResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
                                            Date regExpDate=null;
			Date licExpDate=null;
			String conDtRegExp = "";
			String conDtLicExp = "";
                        Date insurExpDate=null;
			String conDtInsurExp = "";
                        Date vehicleMOTExpDate=null;
			String conDtVehicleMOTExp = "";
                        Date hireAgreementDocExpDate=null;
			String conDtHireAgreementDocExp = "";
                        String dateformat = "";
                        String timeformat = "";
                        String timezoneCode = "";
                        TimeZoneDetail tz = null;
                        String timezone = "";
                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                        
                        VehicleDetailResponse vd = new VehicleDetailResponse();

                        VehicleDetail data = (VehicleDetail) arr[0];

                        VehicleDriverMapping vdm = new VehicleDriverMapping();

						
                        if (data.getOrganizationCode() != null) {
                            regExpDate = data.getRegistrationExpiryDate();
                            licExpDate = data.getLicenseExpiryDate();
                            insurExpDate = data.getInsuranceExpiryDate();
                            vehicleMOTExpDate = data.getVehicleMOTExpiryDate();
                            hireAgreementDocExpDate = data.getHireAgreementDocExpiryDate();
                             
                            Organization org = orgDao.findByOrganizationCode(data.getOrganizationCode());
                            if (org != null && org.getId() > 0) {
                                    dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                    timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                    {
                                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                                    }                

                                    timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TimeZone);
                                    tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                    timezone = tz.getTimeZoneName(); 


                                    if(timezone!=null && timezone.length()>0 )
                                    { 
                                        if (regExpDate != null) {
                                           regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                           conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                        }

                                        if (licExpDate != null) {
                                                licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                                conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                        }


                                        if (insurExpDate != null) {
                                                insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                                conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                        }


                                        if (vehicleMOTExpDate != null) {
                                                vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                                conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                        }


                                        if (hireAgreementDocExpDate != null) {
                                                hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate, timezone,dtFormat);
                                                conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                        }
                                    }
                                   
                                   
                                }

                                vd.setOrganizationCode(data.getOrganizationCode());
                                vd.setOrganizationName(org.getOrganizationName());
                        }else {
						
                                String driverCode = (String) arr[1];

                                Driver driver = driverDao.getDriverByDriverCode(driverCode);
                                String organizationCode = driver.getOrganizationCode();                                                

                                dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations,organizationCode, GigflexConstants.TimeZone);

                                tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                timezone = tz.getTimeZoneName();
                                
                                if(timezone!=null && timezone.length()>0 )
                                { 

                                        if (regExpDate != null) {
                                           regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                           conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                        }

                                        if (licExpDate != null) {
                                                licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                                conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                        }

                                        if (vehicleMOTExpDate != null) {
                                                vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                                conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                        }

                                        if (insurExpDate != null) {
                                                insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                                conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                        }


                                        if (hireAgreementDocExpDate != null) {
                                                hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate, timezone,dtFormat);
                                                conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                        }
                                }
                               

			}
						
                                vd.setRegistrationExpiryDate(conDtRegExp);
                                vd.setLicenseExpiryDate(conDtLicExp);
                                vd.setInsuranceExpiryDate(conDtInsurExp);
                                vd.setVehicleMOTExpiryDate(conDtVehicleMOTExp);
                                vd.setHireAgreementDocExpiryDate(conDtHireAgreementDocExp);

                                vd.setDateFormat(dateformat);
                                vd.setTimeFormat(timeformat);
                                vd.setId(data.getId());
                                vd.setVehicleCode(data.getVehicleCode());
                                vd.setVehicleYear(data.getVehicleYear());
                                vd.setInitialMileage(data.getInitialMileage());
                                vd.setVehicleImage(data.getVehicleImage());
                                vd.setInService(data.getInService());
                                vd.setColor(data.getColor());
                                vd.setVin(data.getVin());
                                vd.setLicensePlate(data.getLicensePlate());
                                vd.setLicensePlateDoc(data.getLicensePlateDoc());
                                vd.setInsurance(data.getInsurance());
                                vd.setInsuranceDoc(data.getInsuranceDoc());
                                vd.setVehicleLogbookDoc(data.getVehicleLogbookDoc());
                                vd.setVehicleMOTDoc(data.getVehicleMOTDoc());
                                vd.setHireAgreementDoc(data.getHireAgreementDoc());
                                vd.setPassengerQuantity(data.getPassengerQuantity());
                                vd.setBaggageQuantity(data.getBaggageQuantity());
                                vd.setAirCondition(data.getAirCondition());
                                vd.setAutomaticTransmission(data.getAutomaticTransmission());
                                vd.setSateliteNavigation(data.getSateliteNavigation());
                                vd.setRegistrationNumber(data.getRegistrationNumber());
                                vd.setModelCode(data.getModelCode());
                                vd.setModelName((String) arr[2]);
                                vd.setFuelTypeCode(data.getFuelTypeCode());
                                vd.setFuelTypeName((String) arr[3]);
                                vd.setVehicleTypeCode(data.getVehicleType());
						
                                RideType rideType = rideTypeDao.getRideTypeByVehicleCode(data.getVehicleType());
                                if(rideType != null && rideType.getId() > 0) {
                                        vd.setVehicleTypeName(rideType.getVehicleName());
                                }

                                vd.setMakeCode(data.getMakeCode());
                                MakeType mt=makeTypeRepository.getMakeTypeByVehicleCode(data.getMakeCode());
                                if(mt != null && mt.getId() > 0) {
                                        vd.setMakeName(mt.getVehicleName());
                                }
           // dro.setVehicleCode(data.getVehicleCode());

                                Driver driver = driverDao.getDriverByDriverCode((String) arr[1]);
                                if (driver != null && driver.getId() > 0) {
                                        vd.setDriverCode(driver.getDriverCode());
                                        vd.setDriverName(driver.getName());
                                }

                                maplst.add(vd);

					

                        }
                    }
                    if (maplst.size() > 0) {
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(maplst);
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("message", "Success");
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("data", new JSONArray(Detail));
                    } else {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Record Not Found");
                            jsonobj.put("timestamp", new Date());
                    }
                    } else {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Record Not Found");
                            jsonobj.put("timestamp", new Date());
                    }

                    res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;

	}

	@Override
	public String getVehicleDetailByModelCodeByPage(String modelCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
			List<Object> objlstCheck = vehicleDetailDao.getVehicleDetailByModelCode(modelCode);
			int count = objlstCheck.size();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = vehicleDetailDao.getVehicleDetailByModelCode(modelCode, pageableRequest);
			List<VehicleDetailResponse> maplst = new ArrayList<VehicleDetailResponse>();
			if (objlst != null && objlst.size() > 0) {
                        for (int i = 0; i < objlst.size(); i++) {
                        Object[] arr = (Object[]) objlst.get(i);
                        if (arr.length >= 4) {
                        Date regExpDate=null;
			Date licExpDate=null;
			String conDtRegExp = "";
			String conDtLicExp = "";
                        Date insurExpDate=null;
			String conDtInsurExp = "";
                        Date vehicleMOTExpDate=null;
			String conDtVehicleMOTExp = "";
                        Date hireAgreementDocExpDate=null;
			String conDtHireAgreementDocExp = "";
                        String dateformat = "";
                        String timeformat = "";
                        String timezoneCode = "";
                        TimeZoneDetail tz = null;
                        String timezone = "";
                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                        
                        VehicleDetailResponse vd = new VehicleDetailResponse();

                        VehicleDetail data = (VehicleDetail) arr[0];

                        VehicleDriverMapping vdm = new VehicleDriverMapping();

						
                        if (data.getOrganizationCode() != null) {
                            regExpDate = data.getRegistrationExpiryDate();
                            licExpDate = data.getLicenseExpiryDate();
                            insurExpDate = data.getInsuranceExpiryDate();
                            vehicleMOTExpDate = data.getVehicleMOTExpiryDate();
                            hireAgreementDocExpDate = data.getHireAgreementDocExpiryDate();
                            Organization org = orgDao.findByOrganizationCode(data.getOrganizationCode());
                            
                        if (org != null && org.getId() > 0) {
                            dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                            timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TimeZone);
                            tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            timezone = tz.getTimeZoneName(); 


                            if(timezone!=null && timezone.length()>0 )
                            { 
                                if (regExpDate != null) {
                                        regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate,timezone,dtFormat);
                                        conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                }

                                if (licExpDate != null) {
                                        licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                        conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                }

                                if (insurExpDate != null) {
                                        insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                        conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                }

                                if (vehicleMOTExpDate != null) {
                                        vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate,timezone,dtFormat);
                                        conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                }
                                if (hireAgreementDocExpDate != null) {
                                        hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate, timezone,dtFormat);
                                        conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                }

                            }

								
                          }
							

                            vd.setOrganizationCode(data.getOrganizationCode());
                            vd.setOrganizationName(org.getOrganizationName());
                    }else {

                            String driverCode = (String) arr[1];

                            Driver driver = driverDao.getDriverByDriverCode(driverCode);
                            String organizationCode = driver.getOrganizationCode();                                                

                            dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                            timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations,organizationCode, GigflexConstants.TimeZone);

                            tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            timezone = tz.getTimeZoneName();
                            
                            if (regExpDate != null) {
                                    regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                    conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                            }
                           
                            if (licExpDate != null) {
                                    licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                    conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                            }

                           
                            if (insurExpDate != null) {
                                    insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                    conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                            }

                            if (vehicleMOTExpDate != null) {
                                    vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                    conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                            }


                            if (hireAgreementDocExpDate != null) {
                                    hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate, timezone,dtFormat);
                                    conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                            }

                    }
                            vd.setRegistrationExpiryDate(conDtRegExp);
                            vd.setLicenseExpiryDate(conDtLicExp);
                            vd.setInsuranceExpiryDate(conDtInsurExp);
                            vd.setVehicleMOTExpiryDate(conDtVehicleMOTExp);
                            vd.setHireAgreementDocExpiryDate(conDtHireAgreementDocExp);

                            vd.setDateFormat(dateformat);
                            vd.setTimeFormat(timeformat);
                            vd.setId(data.getId());
                            vd.setVehicleCode(data.getVehicleCode());
                            vd.setVehicleYear(data.getVehicleYear());
                            vd.setInitialMileage(data.getInitialMileage());
                            vd.setVehicleImage(data.getVehicleImage());
                            vd.setInService(data.getInService());
                            vd.setColor(data.getColor());
                            vd.setVin(data.getVin());
                            vd.setLicensePlate(data.getLicensePlate());
                            vd.setLicensePlateDoc(data.getLicensePlateDoc());
                            vd.setInsurance(data.getInsurance());
                            vd.setInsuranceDoc(data.getInsuranceDoc());
                            vd.setVehicleLogbookDoc(data.getVehicleLogbookDoc());
                            vd.setVehicleMOTDoc(data.getVehicleMOTDoc());
                            vd.setHireAgreementDoc(data.getHireAgreementDoc());
                            vd.setPassengerQuantity(data.getPassengerQuantity());
                            vd.setBaggageQuantity(data.getBaggageQuantity());
                            vd.setAirCondition(data.getAirCondition());
                            vd.setAutomaticTransmission(data.getAutomaticTransmission());
                            vd.setSateliteNavigation(data.getSateliteNavigation());
                            vd.setRegistrationNumber(data.getRegistrationNumber());
                            vd.setModelCode(data.getModelCode());
                            vd.setModelName((String) arr[2]);
                            vd.setFuelTypeCode(data.getFuelTypeCode());
                            vd.setFuelTypeName((String) arr[3]);
                            vd.setVehicleTypeCode(data.getVehicleType());
						
                            RideType rideType = rideTypeDao.getRideTypeByVehicleCode(data.getVehicleType());
                            if(rideType != null && rideType.getId() > 0) {
                                    vd.setVehicleTypeName(rideType.getVehicleName());
                            }

                            vd.setMakeCode(data.getMakeCode());
                            MakeType mt=makeTypeRepository.getMakeTypeByVehicleCode(data.getMakeCode());
                            if(mt != null && mt.getId() > 0) {
                                    vd.setMakeName(mt.getVehicleName());
                            }
       // dro.setVehicleCode(data.getVehicleCode());

                            Driver driver = driverDao.getDriverByDriverCode((String) arr[1]);
                            if (driver != null && driver.getId() > 0) {
                                    vd.setDriverCode(driver.getDriverCode());
                                    vd.setDriverName(driver.getName());
                            }

                            maplst.add(vd);

                    }
            }
                if (maplst.size() > 0) {
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(maplst);
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("count", count);
                        jsonobj.put("data", new JSONArray(Detail));
                } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                }
                } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                }
                    } else {
                            jsonobj.put("responsecode", 400);
                            jsonobj.put("message", "Limit should not be Zero or Negative.");
                            jsonobj.put("timestamp", new Date());
                    }
                    res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String saveVehicleByOrganization(VehicleDetailDriverRequest vehicleDetailReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (vehicleDetailReq != null) {

				if ( vehicleDetailReq.getLicenseExpiryDate() != null
						&& vehicleDetailReq.getLicenseExpiryDate().trim().length() > 0

						&& vehicleDetailReq.getLicenseExpiryDate() != null
						&& vehicleDetailReq.getLicenseExpiryDate().trim().length() > 0

						&& vehicleDetailReq.getOrganizationCode() != null
						&& vehicleDetailReq.getOrganizationCode().trim().length() > 0

						&& vehicleDetailReq.getModelCode() != null
						&& vehicleDetailReq.getModelCode().trim().length() > 0

						&& vehicleDetailReq.getDriverCode() != null
						&& vehicleDetailReq.getDriverCode().trim().length() > 0) {

					Date registrationExpiryDate = null;
					Date licenseExpiryDate = null;
                        Date vehicleMOTExpDate=null;
			Date insurExpDate=null;
                        Date hireAgreementDocExpDate=null;
			
//					Date currentTime = null;
					try {
                                            if(vehicleDetailReq.getInsuranceExpiryDate()!=null && vehicleDetailReq.getInsuranceExpiryDate().trim().length()>0)
                                            {
                                                insurExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getInsuranceExpiryDate().trim());
						if (insurExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send InsuranceExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
                                            
                                            if(vehicleDetailReq.getHireAgreementDocExpiryDate()!=null && vehicleDetailReq.getHireAgreementDocExpiryDate().trim().length()>0)
                                            {
                                                hireAgreementDocExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getHireAgreementDocExpiryDate().trim());
						if (hireAgreementDocExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send HireAgreementDocExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
                                            
                                            if(vehicleDetailReq.getVehicleMOTExpiryDate()!=null && vehicleDetailReq.getVehicleMOTExpiryDate().trim().length()>0)
                                            {
                                                vehicleMOTExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getVehicleMOTExpiryDate().trim());
						if (vehicleMOTExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send VehicleMOTExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
						registrationExpiryDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getRegistrationExpiryDate().trim());
						if (registrationExpiryDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send registrationExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
						licenseExpiryDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getLicenseExpiryDate().trim());
						if (licenseExpiryDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send licenseExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}

					} catch (Exception ex) {
						ex.printStackTrace();
						GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send registrationExpiryDate, HireAgreementDocExpiryDate, VehicleMOTExpiryDate, InsuranceExpiryDate and licenseExpiryDate in correct format("
										+ GigflexConstants.dateFormatterForSave + ") ");
						return derr.toString();
					}
					Organization org = orgDao.findByOrganizationCode(vehicleDetailReq.getOrganizationCode());
					if (org != null && org.getId() > 0) {

						String timezoneCode = org.getTimezone();
						TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
						Date regExpDate = GigflexDateUtil.convertStringDateToGMT(
								vehicleDetailReq.getRegistrationExpiryDate().trim(), tz.getTimeZoneName(),
								GigflexConstants.dateFormatterForSave);
						Date licExpDate = GigflexDateUtil.convertStringDateToGMT(
								vehicleDetailReq.getLicenseExpiryDate().trim(), tz.getTimeZoneName(),
								GigflexConstants.dateFormatterForSave);
						if (regExpDate == null || licExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Date conversion has been failed.");
							return derr.toString();
						}
						Date currentTime = new Date();
                                            Calendar cal = Calendar.getInstance();
                                            cal.setTime(currentTime);
                                            cal.add(Calendar.DATE, -1);
                                            currentTime = cal.getTime();
//					Organization org = orgDao.findByOrganizationCode(vehicleDetailReq.getOrganizationCode());
//					if (org != null && org.getId() > 0) {

						Fuel fuel = fuelDao.getFuelByFuelCode(vehicleDetailReq.getFuelTypeCode());
						if (fuel != null && fuel.getId() > 0) {

							MakeModelMapping mmm = mmmDao
									.getMakeModelMappingByModelCode(vehicleDetailReq.getModelCode());
							if (mmm != null && mmm.getId() > 0) {

								Driver driver = driverDao.getDriverByDriverCode(vehicleDetailReq.getDriverCode());
								if (driver != null && driver.getId() > 0) {

//									VehicleDetail vdcr = vehicleDetailDao.getVehicleDetailByOrgCodeAndVehicleName(
//											vehicleDetailReq.getOrganizationCode(), vehicleDetailReq.getVehicleName());
//									if (vdcr != null && vdcr.getId() > 0) {
//										jsonobj.put("responsecode", 409);
//										jsonobj.put("timestamp", new Date());
//										jsonobj.put("message", "Record already exist.");
//									} else {

										if (registrationExpiryDate.after(currentTime)) {

											if (licenseExpiryDate.after(currentTime)) {

												VehicleDetail vd = new VehicleDetail();

												//vd.setVehicleName(vehicleDetailReq.getVehicleName());
												//vd.setAbbrevationName(vehicleDetailReq.getAbbrevationName());
												vd.setVehicleType(vehicleDetailReq.getVehicleType());
												vd.setVehicleYear(vehicleDetailReq.getVehicleYear());
												vd.setInitialMileage(vehicleDetailReq.getInitialMileage());
												vd.setVehicleImage(vehicleDetailReq.getVehicleImage());
												vd.setRegistrationExpiryDate(regExpDate);
												vd.setInService(vehicleDetailReq.getInService());
												//vd.setVehicleEngineType(vehicleDetailReq.getVehicleEngineType());
												//vd.setVehicleHorsePower(vehicleDetailReq.getVehicleHorsePower());
												vd.setColor(vehicleDetailReq.getColor());
												vd.setVin(vehicleDetailReq.getVin());
												vd.setLicensePlate(vehicleDetailReq.getLicensePlate());
												vd.setLicenseExpiryDate(licExpDate);
												//vd.setVehicleGroup(vehicleDetailReq.getVehicleGroup());
												vd.setPassengerQuantity(vehicleDetailReq.getPassengerQuantity());
												vd.setBaggageQuantity(vehicleDetailReq.getBaggageQuantity());
												//vd.setDoorsQuantity(vehicleDetailReq.getDoorsQuantity());
												vd.setAirCondition(vehicleDetailReq.getAirCondition());
												vd.setAutomaticTransmission(
														vehicleDetailReq.getAutomaticTransmission());
												vd.setFuelTypeCode(vehicleDetailReq.getFuelTypeCode());
												vd.setSateliteNavigation(vehicleDetailReq.getSateliteNavigation());
												vd.setOrganizationCode(vehicleDetailReq.getOrganizationCode());
												vd.setModelCode(vehicleDetailReq.getModelCode());
//										vd.setDriverCode(vehicleDetailReq.getDriverCode());
                                                                                                vd.setLicensePlateDoc(vehicleDetailReq.getLicensePlateDoc());
                                                                                        vd.setInsurance(vehicleDetailReq.getInsurance());
                                                                                        vd.setInsuranceDoc(vehicleDetailReq.getInsuranceDoc());
                                                                                        if(vehicleDetailReq.getInsuranceExpiryDate()!=null && vehicleDetailReq.getInsuranceExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date insuranceExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getInsuranceExpiryDate().trim(), tz.getTimeZoneName(),
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setInsuranceExpiryDate(insuranceExpiryDate);
                                                                                        }
                                                                                        vd.setVehicleLogbookDoc(vehicleDetailReq.getVehicleLogbookDoc());
                                                                                        vd.setVehicleMOTDoc(vehicleDetailReq.getVehicleMOTDoc());
                                                                                        if(vehicleDetailReq.getVehicleMOTExpiryDate()!=null && vehicleDetailReq.getVehicleMOTExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date vehicleMOTExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getVehicleMOTExpiryDate().trim(), tz.getTimeZoneName(),
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setVehicleMOTExpiryDate(vehicleMOTExpiryDate);
                                                                                        }
                                                                                        vd.setHireAgreementDoc(vehicleDetailReq.getHireAgreementDoc());
                                                                                        if(vehicleDetailReq.getHireAgreementDocExpiryDate()!=null && vehicleDetailReq.getHireAgreementDocExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date hireAgreementDocExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getHireAgreementDocExpiryDate().trim(), tz.getTimeZoneName(),
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setHireAgreementDocExpiryDate(hireAgreementDocExpiryDate);
                                                                                        }
                                                                                        vd.setRegistrationNumber(vehicleDetailReq.getRegistrationNumber());
                                                                                        vd.setMakeCode(vehicleDetailReq.getMakeCode());

												vd.setIpAddress(ip);

												VehicleDetail vdRes = vehicleDetailDao.save(vd);
												jsonobj.put("responsecode", 200);
												jsonobj.put("timestamp", new Date());
												if (vdRes != null && vdRes.getId() > 0) {

													Driver driverlst = driver;
													if (driverlst != null && driverlst.getId() > 0) {

														VehicleDriverMapping vehDriver = new VehicleDriverMapping();
														vehDriver.setVehicleCode(vdRes.getVehicleCode());
														vehDriver.setDriverCode(vehicleDetailReq.getDriverCode());

														vehDriver.setIpAddress(ip);

														VehicleDriverMapping vehDriverRes = vehDriverDao
																.save(vehDriver);

														if (vehDriverRes != null && vehDriverRes.getId() > 0) {
															jsonobj.put("responsecode", 200);
															jsonobj.put("message",
																	"Vehicle has been assigned to Organization and Driver");
															jsonobj.put("timestamp", new Date());
															ObjectMapper mapperObj = new ObjectMapper();
															String Detail = mapperObj.writeValueAsString(vdRes);
															jsonobj.put("data", new JSONObject(Detail));
															
															 try {
                               									 
                             									List<Driver> driverLst = driverDao.getDriverByOrganizationCode(vehicleDetailReq.getOrganizationCode());
                             									List<Operator> operator = operatorDao.getOperatorByOrganizationCode(vehicleDetailReq.getOrganizationCode());
                             									if(driverLst != null && driverLst.size() > 0 ){
                             										for(Driver dr : driverLst){
                             										
                             									Notification notification = new Notification();

                             									String bodyContent = "Dear Driver"
                             											+ ",Vehicle has been created by organization.";
                             										
                             									shortMessage = "Vehicle has been created by organization.";

                             									notification.setUserCode(dr.getDriverCode());
                             									notification.setIpAddress(ip);
                             									notification.setMessage(bodyContent);
                             									notification.setShortMessage(shortMessage);
                             									notification.setIsRead(Boolean.FALSE);

                             									notificationService.saveNotification(notification);
                                                                                                
                                                                                                //for push notification
                                                                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
                             									}
                             										
                             									}
                             									if(operator != null && operator.size() > 0){
                             										for(Operator or : operator){
                                 										
                                     									Notification notification = new Notification();

                                     									String bodyContent = "Dear Operator"
                                     											+ ",Vehicle has been created by organization.";
                                     											
                                     									shortMessage = "Vehicle has been created by organization.";

                                     									notification.setUserCode(or.getOperatorCode());
                                     									notification.setIpAddress(ip);
                                     									notification.setMessage(bodyContent);
                                     									notification.setShortMessage(shortMessage);
                                     									notification.setIsRead(Boolean.FALSE);

                                     									notificationService.saveNotification(notification);
                                                                                                        //for push notification
                                                                                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
                                     									}
                             									}
                             									
                             								}

                             								catch (Exception e) {
                             									e.printStackTrace();
                             								}
															
															
//                                                                                                                try {
//                                                                                                                    List<VehicleDriverMapping> mvlst = vehDriverDao.getVehicleDriverMappingByDriverCode(driverlst.getDriverCode());
//                                                                                                                    if (mvlst != null && mvlst.size() > 0) {
//                                                                                                                        driverlst.setFleetSize(mvlst.size());
//                                                                                                                    } else {
//                                                                                                                        driverlst.setFleetSize(0);
//                                                                                                                    }
//                                                                                                                    driverDao.save(driverlst);
//                                                                                                                } catch (Exception exp) {
//                                                                                                                    exp.printStackTrace();
//                                                                                                                }
//					                                    kafkaService.sendDriverForUpdate(driverRes);
                                                                                                            } else {
                                                                                                                jsonobj.put("responsecode", 400);
                                                                                                                jsonobj.put("message", "Assign activity has been failed.");
                                                                                                                jsonobj.put("timestamp", new Date());
                                                                                                            }

													} else {
														jsonobj.put("responsecode", 400);
														jsonobj.put("message", "Driver code is not valid.");
														jsonobj.put("timestamp", new Date());
													}
												} else {
													jsonobj.put("message", "Vehicle Creation Failed");
												}
											} else {
												jsonobj.put("responsecode", 404);
												jsonobj.put("timestamp", new Date());
												jsonobj.put("message",
														"License Expiry Date must be after current date");
											}
										} else {
											jsonobj.put("responsecode", 404);
											jsonobj.put("timestamp", new Date());
											jsonobj.put("message",
													"Registration Expiry Date must be after current date");
										}
									//}
								} else {
									jsonobj.put("message", "Driver Code Not Found.");
									jsonobj.put("responsecode", 400);
									jsonobj.put("timestamp", new Date());
								}
							} else {
								jsonobj.put("message", "Model Code Not Found.");
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
							}
						} else {
							jsonobj.put("message", "Fuel Type Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("message", "Organization Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String updateVehicleByOrganizationById(Long id, VehicleDetailDriverRequest vehicleDetailReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (id > 0 && vehicleDetailReq != null) {
				if ( vehicleDetailReq.getLicenseExpiryDate() != null
						&& vehicleDetailReq.getLicenseExpiryDate().trim().length() > 0

						&& vehicleDetailReq.getLicenseExpiryDate() != null
						&& vehicleDetailReq.getLicenseExpiryDate().trim().length() > 0

						&& vehicleDetailReq.getOrganizationCode() != null
						&& vehicleDetailReq.getOrganizationCode().trim().length() > 0

						&& vehicleDetailReq.getModelCode() != null
						&& vehicleDetailReq.getModelCode().trim().length() > 0

						&& vehicleDetailReq.getDriverCode() != null
						&& vehicleDetailReq.getDriverCode().trim().length() > 0) {

					VehicleDetail vdInDb = vehicleDetailDao.getVehicleDetailById(id);
					if (vdInDb != null && vdInDb.getId() > 0) {

						Date registrationExpiryDate = null;
						Date licenseExpiryDate = null;
                        Date vehicleMOTExpDate=null;
			Date insurExpDate=null;
                        Date hireAgreementDocExpDate=null;
			
//					Date currentTime = null;
					try {
                                            if(vehicleDetailReq.getInsuranceExpiryDate()!=null && vehicleDetailReq.getInsuranceExpiryDate().trim().length()>0)
                                            {
                                                insurExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getInsuranceExpiryDate().trim());
						if (insurExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send InsuranceExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
                                            
                                            if(vehicleDetailReq.getHireAgreementDocExpiryDate()!=null && vehicleDetailReq.getHireAgreementDocExpiryDate().trim().length()>0)
                                            {
                                                hireAgreementDocExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getHireAgreementDocExpiryDate().trim());
						if (hireAgreementDocExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send HireAgreementDocExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
                                            
                                            if(vehicleDetailReq.getVehicleMOTExpiryDate()!=null && vehicleDetailReq.getVehicleMOTExpiryDate().trim().length()>0)
                                            {
                                                vehicleMOTExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getVehicleMOTExpiryDate().trim());
						if (vehicleMOTExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send VehicleMOTExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
							registrationExpiryDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
									.parse(vehicleDetailReq.getRegistrationExpiryDate().trim());
							if (registrationExpiryDate == null) {
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Plz send registrationExpiryDate in correct format("
												+ GigflexConstants.dateFormatterForSave + ") ");
								return derr.toString();
							}
							licenseExpiryDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
									.parse(vehicleDetailReq.getLicenseExpiryDate().trim());
							if (licenseExpiryDate == null) {
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Plz send licenseExpiryDate in correct format("
												+ GigflexConstants.dateFormatterForSave + ") ");
								return derr.toString();
							}

						} catch (Exception ex) {
							ex.printStackTrace();
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send registrationExpiryDate, HireAgreementDocExpiryDate, VehicleMOTExpiryDate, InsuranceExpiryDate and licenseExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
						Organization org = orgDao.findByOrganizationCode(vehicleDetailReq.getOrganizationCode());
						if (org != null && org.getId() > 0) {

							String timezoneCode = org.getTimezone();
							TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
							Date regExpDate = GigflexDateUtil.convertStringDateToGMT(
									vehicleDetailReq.getRegistrationExpiryDate().trim(), tz.getTimeZoneName(),
									GigflexConstants.dateFormatterForSave);
							Date licExpDate = GigflexDateUtil.convertStringDateToGMT(
									vehicleDetailReq.getLicenseExpiryDate().trim(), tz.getTimeZoneName(),
									GigflexConstants.dateFormatterForSave);
							if (regExpDate == null && licExpDate == null) {
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Date conversion has been failed.");
								return derr.toString();
							}
							Date currentTime = new Date();
                                            Calendar cal = Calendar.getInstance();
                                            cal.setTime(currentTime);
                                            cal.add(Calendar.DATE, -1);
                                            currentTime = cal.getTime();

//						Organization org = orgDao.findByOrganizationCode(vehicleDetailReq.getOrganizationCode());
//						if (org != null && org.getId() > 0) {

							Fuel fuel = fuelDao.getFuelByFuelCode(vehicleDetailReq.getFuelTypeCode());
							if (fuel != null && fuel.getId() > 0) {

								MakeModelMapping mmm = mmmDao
										.getMakeModelMappingByModelCode(vehicleDetailReq.getModelCode());
								if (mmm != null && mmm.getId() > 0) {

									Driver driver = driverDao.getDriverByDriverCode(vehicleDetailReq.getDriverCode());
									if (driver != null && driver.getId() > 0) {

//										VehicleDetail vdcr = vehicleDetailDao.getVehicleDetailByIdOrgCodeAndVehicleName(
//												id, vehicleDetailReq.getOrganizationCode(),
//												vehicleDetailReq.getVehicleName());
//										if (vdcr != null && vdcr.getId() > 0) {
//											jsonobj.put("responsecode", 409);
//											jsonobj.put("timestamp", new Date());
//											jsonobj.put("message", "Record already exist.");
//										} else {

											if (registrationExpiryDate.after(currentTime)) {

												if (licenseExpiryDate.after(currentTime)) {

													VehicleDetail vd = vdInDb;

													//vd.setVehicleName(vehicleDetailReq.getVehicleName());
													//vd.setAbbrevationName(vehicleDetailReq.getAbbrevationName());
													vd.setVehicleType(vehicleDetailReq.getVehicleType());
													vd.setVehicleYear(vehicleDetailReq.getVehicleYear());
													vd.setInitialMileage(vehicleDetailReq.getInitialMileage());
													vd.setVehicleImage(vehicleDetailReq.getVehicleImage());
													vd.setRegistrationExpiryDate(regExpDate);
													vd.setInService(vehicleDetailReq.getInService());
													//vd.setVehicleEngineType(vehicleDetailReq.getVehicleEngineType());
													//vd.setVehicleHorsePower(vehicleDetailReq.getVehicleHorsePower());
													vd.setColor(vehicleDetailReq.getColor());
													vd.setVin(vehicleDetailReq.getVin());
													vd.setLicensePlate(vehicleDetailReq.getLicensePlate());
													vd.setLicenseExpiryDate(licExpDate);
													//vd.setVehicleGroup(vehicleDetailReq.getVehicleGroup());
													vd.setPassengerQuantity(vehicleDetailReq.getPassengerQuantity());
													vd.setBaggageQuantity(vehicleDetailReq.getBaggageQuantity());
													//vd.setDoorsQuantity(vehicleDetailReq.getDoorsQuantity());
													vd.setAirCondition(vehicleDetailReq.getAirCondition());
													vd.setAutomaticTransmission(
															vehicleDetailReq.getAutomaticTransmission());
													vd.setFuelTypeCode(vehicleDetailReq.getFuelTypeCode());
													vd.setSateliteNavigation(vehicleDetailReq.getSateliteNavigation());
													vd.setOrganizationCode(vehicleDetailReq.getOrganizationCode());
													vd.setModelCode(vehicleDetailReq.getModelCode());
//											vd.setDriverCode(vehicleDetailReq.getDriverCode());
                                                                                                        vd.setLicensePlateDoc(vehicleDetailReq.getLicensePlateDoc());
                                                                                        vd.setInsurance(vehicleDetailReq.getInsurance());
                                                                                        vd.setInsuranceDoc(vehicleDetailReq.getInsuranceDoc());
                                                                                        if(vehicleDetailReq.getInsuranceExpiryDate()!=null && vehicleDetailReq.getInsuranceExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date insuranceExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getInsuranceExpiryDate().trim(), tz.getTimeZoneName(),
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setInsuranceExpiryDate(insuranceExpiryDate);
                                                                                        }
                                                                                        vd.setVehicleLogbookDoc(vehicleDetailReq.getVehicleLogbookDoc());
                                                                                        vd.setVehicleMOTDoc(vehicleDetailReq.getVehicleMOTDoc());
                                                                                        if(vehicleDetailReq.getVehicleMOTExpiryDate()!=null && vehicleDetailReq.getVehicleMOTExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date vehicleMOTExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getVehicleMOTExpiryDate().trim(), tz.getTimeZoneName(),
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setVehicleMOTExpiryDate(vehicleMOTExpiryDate);
                                                                                        }
                                                                                        vd.setHireAgreementDoc(vehicleDetailReq.getHireAgreementDoc());
                                                                                        if(vehicleDetailReq.getHireAgreementDocExpiryDate()!=null && vehicleDetailReq.getHireAgreementDocExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date hireAgreementDocExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getHireAgreementDocExpiryDate().trim(), tz.getTimeZoneName(),
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setHireAgreementDocExpiryDate(hireAgreementDocExpiryDate);
                                                                                        }
                                                                                        vd.setRegistrationNumber(vehicleDetailReq.getRegistrationNumber());
                                                                                        vd.setMakeCode(vehicleDetailReq.getMakeCode());
													vd.setIpAddress(ip);

													VehicleDetail vdRes = vehicleDetailDao.save(vd);
													if (vdRes != null && vdRes.getId() > 0) {

														Driver driverlst = driver;
														if (driverlst != null && driverlst.getId() > 0) {
															VehicleDriverMapping vehDriver = new VehicleDriverMapping();
															VehicleDriverMapping vehDri = vehDriverDao
																	.getVehicleDriverMappingByVehicleCode(
																			vdRes.getVehicleCode());
															if (vehDri != null && vehDri.getId() > 0) {

																vehDri.setDriverCode(vehicleDetailReq.getDriverCode());

																VehicleDriverMapping vehDriverRes = vehDriverDao
																		.save(vehDri);

																if (vehDriverRes != null && vehDriverRes.getId() > 0) {

																	jsonobj.put("responsecode", 200);
																	jsonobj.put("message",
																			"Vehicle Detail updation has been done");
																	jsonobj.put("timestamp", new Date());
																	ObjectMapper mapperObj = new ObjectMapper();
																	String Detail = mapperObj.writeValueAsString(vdRes);
																	jsonobj.put("data", new JSONObject(Detail));
//												kafkaService.sendDriverForUpdate(vehDriverRes);

																} else {
																	jsonobj.put("responsecode", 400);
																	jsonobj.put("message",
																			"Vehicle Detail updation has been failed.");
																	jsonobj.put("timestamp", new Date());
																}
															} else {
																vehDriver.setVehicleCode(vdRes.getVehicleCode());
																vehDriver.setDriverCode(
																		vehicleDetailReq.getDriverCode());

																vehDriver.setIpAddress(ip);

																VehicleDriverMapping vehDriverRes = vehDriverDao
																		.save(vehDriver);

																if (vehDriverRes != null && vehDriverRes.getId() > 0) {

																	jsonobj.put("responsecode", 200);
																	jsonobj.put("message",
																			"Vehicle Detail updation has been done");
																	jsonobj.put("timestamp", new Date());
																	ObjectMapper mapperObj = new ObjectMapper();
																	String Detail = mapperObj.writeValueAsString(vdRes);
																	jsonobj.put("data", new JSONObject(Detail));
																} else {
																	jsonobj.put("responsecode", 400);
																	jsonobj.put("message",
																			"Vehicle Detail updation has been failed.");
																	jsonobj.put("timestamp", new Date());
																}
															}
//                                                                                                                        try {
//                                                                                                                    List<VehicleDriverMapping> mvlst = vehDriverDao.getVehicleDriverMappingByDriverCode(driverlst.getDriverCode());
//                                                                                                                    if (mvlst != null && mvlst.size() > 0) {
//                                                                                                                        driverlst.setFleetSize(mvlst.size());
//                                                                                                                    } else {
//                                                                                                                        driverlst.setFleetSize(0);
//                                                                                                                    }
//                                                                                                                    driverDao.save(driverlst);
//                                                                                                                } catch (Exception exp) {
//                                                                                                                    exp.printStackTrace();
//                                                                                                                }
														} else {
															jsonobj.put("responsecode", 400);
															jsonobj.put("message", "Driver code is not valid.");
															jsonobj.put("timestamp", new Date());
														}
													} else {
                                                                                                            jsonobj.put("responsecode", 400);
													    jsonobj.put("timestamp", new Date());
														jsonobj.put("message", "Vehicle Updation Failed");
													}

												} else {
													jsonobj.put("responsecode", 404);
													jsonobj.put("timestamp", new Date());
													jsonobj.put("message",
															"License Expiry Date must be after current date");
												}
											} else {
												jsonobj.put("responsecode", 404);
												jsonobj.put("timestamp", new Date());
												jsonobj.put("message",
														"Registration Expiry Date must be after current date");
											}
										//}
									} else {
										jsonobj.put("message", "Driver Code Not Found.");
										jsonobj.put("responsecode", 400);
										jsonobj.put("timestamp", new Date());
									}
								} else {
									jsonobj.put("message", "Model Code Not Found.");
									jsonobj.put("responsecode", 400);
									jsonobj.put("timestamp", new Date());
								}
							} else {
								jsonobj.put("message", "Fuel Type Code Not Found.");
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
							}

						} else {
							jsonobj.put("message", "Organization Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Vehicle Detail Id is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex); 
		}
		return res;

	}

	@Override
	public String getVehicleDetailByDriverCode(String driverCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = vehicleDetailDao.getVehicleDetailByDriverCode(driverCode);
			List<VehicleDetailDriverResponse> maplst = new ArrayList<VehicleDetailDriverResponse>();
			if (objlst != null && objlst.size() > 0) {
                            String dateformat = "";
                            String timeformat = "";
                            String timezoneCode = "";
                            TimeZoneDetail tz = null;
                            String timezone = "";
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                            
                            Driver driver = driverDao.getDriverByDriverCode(driverCode);
                            String organizationCode = driver.getOrganizationCode();   
                            
                            
                            dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                            timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);
                            tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            timezone = tz.getTimeZoneName(); 
                            
                            
                            
                        for (int i = 0; i < objlst.size(); i++) {
                        Object[] arr = (Object[]) objlst.get(i);
                        if (arr.length >= 4) {

                            VehicleDetailDriverResponse vd = new VehicleDetailDriverResponse();


                            Date regExpDate=null;
                            Date licExpDate=null;
                            String conDtRegExp = "";
                            String conDtLicExp = "";
                            Date insurExpDate=null;
                            String conDtInsurExp = "";
                            Date vehicleMOTExpDate=null;
                            String conDtVehicleMOTExp = "";
                            Date hireAgreementDocExpDate=null;
                            String conDtHireAgreementDocExp = "";
                            VehicleDetail data = (VehicleDetail) arr[0];


                            VehicleDriverMapping vdm = new VehicleDriverMapping();

                            if(timezone!=null && timezone.length()>0 )
                            { 
                                regExpDate = data.getRegistrationExpiryDate();
                                if (regExpDate != null) {
                                        regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                        conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                }
                                licExpDate = data.getLicenseExpiryDate();
                                if (licExpDate != null) {
                                        licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                        conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                }

                                insurExpDate = data.getInsuranceExpiryDate();
                                if (insurExpDate != null) {
                                        insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                        conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                }

                                vehicleMOTExpDate = data.getVehicleMOTExpiryDate();
                                if (vehicleMOTExpDate != null) {
                                        vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                        conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                }

                                hireAgreementDocExpDate = data.getHireAgreementDocExpiryDate();
                                if (hireAgreementDocExpDate != null) {
                                        hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate,timezone,dtFormat);
                                        conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                }

                            }
                            

                       
                        vd.setRegistrationExpiryDate(conDtRegExp);
                        vd.setLicenseExpiryDate(conDtLicExp);
                        vd.setInsuranceExpiryDate(conDtInsurExp);
                        vd.setVehicleMOTExpiryDate(conDtVehicleMOTExp);
                        vd.setHireAgreementDocExpiryDate(conDtHireAgreementDocExp);

                        vd.setDateFormat(dateformat);
                        vd.setTimeFormat(timeformat);
                        vd.setId(data.getId());
                        vd.setVehicleCode(data.getVehicleCode());
                        vd.setVehicleYear(data.getVehicleYear());
                        vd.setInitialMileage(data.getInitialMileage());
                        vd.setVehicleImage(data.getVehicleImage());
                        vd.setInService(data.getInService());
                        vd.setColor(data.getColor());
                        vd.setVin(data.getVin());
                        vd.setLicensePlate(data.getLicensePlate());
                        vd.setLicensePlateDoc(data.getLicensePlateDoc());
                        vd.setInsurance(data.getInsurance());
                        vd.setInsuranceDoc(data.getInsuranceDoc());
                        vd.setVehicleLogbookDoc(data.getVehicleLogbookDoc());
                        vd.setVehicleMOTDoc(data.getVehicleMOTDoc());
                        vd.setHireAgreementDoc(data.getHireAgreementDoc());
                        vd.setPassengerQuantity(data.getPassengerQuantity());
                        vd.setBaggageQuantity(data.getBaggageQuantity());
                        vd.setAirCondition(data.getAirCondition());
                        vd.setAutomaticTransmission(data.getAutomaticTransmission());
                        vd.setSateliteNavigation(data.getSateliteNavigation());
                        vd.setRegistrationNumber(data.getRegistrationNumber());
                        vd.setModelCode(data.getModelCode());
                        vd.setModelName((String) arr[2]);
                        vd.setFuelTypeCode(data.getFuelTypeCode());
                        vd.setFuelTypeName((String) arr[3]);
                        vd.setVehicleTypeCode(data.getVehicleType());

                        RideType rideType = rideTypeDao.getRideTypeByVehicleCode(data.getVehicleType());
                        if(rideType != null && rideType.getId() > 0) {
                                vd.setVehicleTypeName(rideType.getVehicleName());
                        }

                        vd.setMakeCode(data.getMakeCode());
                        MakeType mt=makeTypeRepository.getMakeTypeByVehicleCode(data.getMakeCode());
                        if(mt != null && mt.getId() > 0) {
                                vd.setMakeName(mt.getVehicleName());
                        }
                           // dro.setVehicleCode(data.getVehicleCode());
                            
                        driver = driverDao.getDriverByDriverCode((String) arr[1]);
                        if (driver != null && driver.getId() > 0) {
                                vd.setDriverCode(driver.getDriverCode());
                                vd.setDriverName(driver.getName());
                        }
                        
                        
                        Calendar calPickupDate = Calendar.getInstance();
                        int dayCode = calPickupDate.get(Calendar.DAY_OF_WEEK);
                        HoursOfOperation  hoursOfOperation=   hoursOfOperationDao.getHoursByDriverCodeAndDayCode(driverCode, dayCode); 
                        if(hoursOfOperation != null &&  hoursOfOperation.getVehicleCode().equals(data.getVehicleCode()))
                        {
                          vd.setIsdefaultvehicleCode(true);
                        }
                        else
                        {
                           vd.setIsdefaultvehicleCode(false);
                        }
                        
                        maplst.add(vd);

                }
                    }
                if (maplst.size() > 0) {
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(maplst);
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("data", new JSONArray(Detail));
                } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                }
                } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                }

                res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}
         @Override
          public String getVehicleDetailByDriverCodeforMobile(String driverCode)
          {
           String res="";
                  try {
			JSONObject jsonobj = new JSONObject();
                        List<VehicleDetailDriverResponseforMobile> vdList=new ArrayList();
			List<Object> objlst = vehicleDetailDao.getVehicleDetailByDriverCodeforMobile(driverCode);
			
			if (objlst != null && objlst.size() > 0) {
                        
                        for (int i = 0; i < objlst.size(); i++) {
                        Object[] arr = (Object[]) objlst.get(i);
                        if (arr.length >= 2) {

                        VehicleDetailDriverResponseforMobile vd = new VehicleDetailDriverResponseforMobile();

                            VehicleDetail data = (VehicleDetail) arr[0];


                       
                      
                      
                        vd.setId(data.getId());
                        vd.setVehicleCode(data.getVehicleCode());
                        vd.setVehicleYear(data.getVehicleYear());
                        
                        vd.setVehicleImage(data.getVehicleImage());
                       
                        vd.setLicensePlate(data.getLicensePlate());
                      
                        vd.setInsurance(data.getInsurance());
                    
                     
                        vd.setVehicleTypeCode(data.getVehicleType());

                        GlobalRideType grideType = globalRideTypeRepository.getGlobalRideTypeByGlobalRideCode(data.getVehicleType());
                        if(grideType != null && grideType.getId() > 0) {
                          vd.setVehicleTypeName(grideType.getVehicleName());
                        }

                        vd.setModelName((String)arr[1]);
                     
                        Calendar calPickupDate = Calendar.getInstance();
                        int dayCode = calPickupDate.get(Calendar.DAY_OF_WEEK);
                        HoursOfOperation  hoursOfOperation=   hoursOfOperationDao.getHoursByDriverCodeAndDayCode(driverCode, dayCode); 
                        if(hoursOfOperation != null &&  hoursOfOperation.getVehicleCode().equals(data.getVehicleCode()))
                        {
                          vd.setIsdefaultvehicleCode(true);
                        }
                        else
                        {
                           vd.setIsdefaultvehicleCode(false);
                        }
                        
                        vdList.add(vd);

                }
                    }
                if (vdList.size() > 0) {
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(vdList);
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("data", new JSONArray(Detail));
                } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                }
                } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                }
          
                res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
             return res;      
          }
        
        @Override
        public String getVehicleTypeDetailByDriverCode(String driverCode) {
            
            String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = vehicleDetailDao.getVehicleTypeDetailByDriverCode(driverCode);
			List<VehicleTypeDetailDriverResponse> vehicleTypeDetailList = new ArrayList<>(); 
			if (objlst != null && objlst.size() > 0) {
                            
                            
                            for (int i = 0; i < objlst.size(); i++) {
                                Object[] arr = (Object[]) objlst.get(i);
                                if (arr.length >= 3) {

                                    VehicleTypeDetailDriverResponse vtd = new VehicleTypeDetailDriverResponse();

                                    String vehicleCode = (String) arr[0];
                                    String vehicleTypeCode = (String) arr[1];
                                    String vehicleTypeName = (String) arr[2];

                                    vtd.setVehicleCode(vehicleCode);
                                    vtd.setVehicleTypeCode(vehicleTypeCode);
                                    vtd.setVehicleTypeName(vehicleTypeName);

                                    vehicleTypeDetailList.add(vtd);

                                }
                             }
                                if (vehicleTypeDetailList.size() > 0) {
                                        ObjectMapper mapperObj = new ObjectMapper();
                                        String Detail = mapperObj.writeValueAsString(vehicleTypeDetailList);
                                        jsonobj.put("responsecode", 200);
                                        jsonobj.put("message", "Success");
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("data", new JSONArray(Detail));
                                } else {
                                        jsonobj.put("responsecode", 404);
                                        jsonobj.put("message", "Record Not Found");
                                        jsonobj.put("timestamp", new Date());
                                }
                        } else {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("message", "Record Not Found");
                                jsonobj.put("timestamp", new Date());
                        }

                        res = jsonobj.toString();
                        } catch (JSONException ex) {
                                GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
                                res = derr.toString();
                                ex.printStackTrace();
                                LOG.error("JSON parsing exception is occurred.",ex); 
                        } catch (Exception ex) {
                                GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
                                res = derr.toString();
                                ex.printStackTrace();
                                LOG.error("Exception is occurred.",ex);
                        }
                        return res;
        }


	@Override
	public String getVehicleDetailByDriverCodeByPage(String driverCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
			List<Object> objlstCheck = vehicleDetailDao.getVehicleDetailByDriverCode(driverCode);

			int count = objlstCheck.size();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = vehicleDetailDao.getVehicleDetailByDriverCode(driverCode, pageableRequest);
			List<VehicleDetailDriverResponse> maplst = new ArrayList<VehicleDetailDriverResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                            String dateformat = "";
                            String timeformat = "";
                            String timezoneCode = "";
                            TimeZoneDetail tz = null;
                            String timezone = "";
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;

                            Driver driver = driverDao.getDriverByDriverCode(driverCode);
                            String organizationCode = driver.getOrganizationCode();   


                            dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                            timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);
                            tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            timezone = tz.getTimeZoneName();   
                            
                            
                            
                            
                        for (int i = 0; i < objlst.size(); i++) {
                            Object[] arr = (Object[]) objlst.get(i);
                            if (arr.length >= 4) {

                            VehicleDetailDriverResponse vd = new VehicleDetailDriverResponse();


                            Date regExpDate=null;
                            Date licExpDate=null;
                            String conDtRegExp = "";
                            String conDtLicExp = "";
                            Date insurExpDate=null;
                            String conDtInsurExp = "";
                            Date vehicleMOTExpDate=null;
                            String conDtVehicleMOTExp = "";
                            Date hireAgreementDocExpDate=null;
                            String conDtHireAgreementDocExp = "";

                            VehicleDetail data = (VehicleDetail) arr[0];

                            VehicleDriverMapping vdm = new VehicleDriverMapping();
                            if(timezone!=null && timezone.length()>0 )
                            {
                                regExpDate = data.getRegistrationExpiryDate();
                                if (regExpDate != null) {
                                        regExpDate = GigflexDateUtil.getGMTtoLocationDate(regExpDate, timezone,dtFormat);
                                        conDtRegExp = GigflexDateUtil.converDateToString(regExpDate);
                                }
                                licExpDate = data.getLicenseExpiryDate();
                                if (licExpDate != null) {
                                        licExpDate = GigflexDateUtil.getGMTtoLocationDate(licExpDate, timezone,dtFormat);
                                        conDtLicExp = GigflexDateUtil.converDateToString(licExpDate);
                                }

                                insurExpDate = data.getInsuranceExpiryDate();
                                if (insurExpDate != null) {
                                        insurExpDate = GigflexDateUtil.getGMTtoLocationDate(insurExpDate, timezone,dtFormat);
                                        conDtInsurExp = GigflexDateUtil.converDateToString(insurExpDate);
                                }

                                vehicleMOTExpDate = data.getVehicleMOTExpiryDate();
                                if (vehicleMOTExpDate != null) {
                                        vehicleMOTExpDate = GigflexDateUtil.getGMTtoLocationDate(vehicleMOTExpDate, timezone,dtFormat);
                                        conDtVehicleMOTExp = GigflexDateUtil.converDateToString(vehicleMOTExpDate);
                                }

                                hireAgreementDocExpDate = data.getHireAgreementDocExpiryDate();
                                if (hireAgreementDocExpDate != null) {
                                        hireAgreementDocExpDate = GigflexDateUtil.getGMTtoLocationDate(hireAgreementDocExpDate, timezone,dtFormat);
                                        conDtHireAgreementDocExp = GigflexDateUtil.converDateToString(hireAgreementDocExpDate);
                                }
                            }
                                                            
                            vd.setRegistrationExpiryDate(conDtRegExp);
                            vd.setLicenseExpiryDate(conDtLicExp);
                            vd.setInsuranceExpiryDate(conDtInsurExp);
                            vd.setVehicleMOTExpiryDate(conDtVehicleMOTExp);
                            vd.setHireAgreementDocExpiryDate(conDtHireAgreementDocExp);

                            vd.setDateFormat(dateformat);
                            vd.setTimeFormat(timeformat);
                            vd.setId(data.getId());
                            vd.setVehicleCode(data.getVehicleCode());
                            vd.setVehicleYear(data.getVehicleYear());
                            vd.setInitialMileage(data.getInitialMileage());
                            vd.setVehicleImage(data.getVehicleImage());
                            vd.setInService(data.getInService());
                            vd.setColor(data.getColor());
                            vd.setVin(data.getVin());
                            vd.setLicensePlate(data.getLicensePlate());
                            vd.setLicensePlateDoc(data.getLicensePlateDoc());
                            vd.setInsurance(data.getInsurance());
                            vd.setInsuranceDoc(data.getInsuranceDoc());
                            vd.setVehicleLogbookDoc(data.getVehicleLogbookDoc());
                            vd.setVehicleMOTDoc(data.getVehicleMOTDoc());
                            vd.setHireAgreementDoc(data.getHireAgreementDoc());
                            vd.setPassengerQuantity(data.getPassengerQuantity());
                            vd.setBaggageQuantity(data.getBaggageQuantity());
                            vd.setAirCondition(data.getAirCondition());
                            vd.setAutomaticTransmission(data.getAutomaticTransmission());
                            vd.setSateliteNavigation(data.getSateliteNavigation());
                            vd.setRegistrationNumber(data.getRegistrationNumber());
                            vd.setModelCode(data.getModelCode());
                            vd.setModelName((String) arr[2]);
                            vd.setFuelTypeCode(data.getFuelTypeCode());
                            vd.setFuelTypeName((String) arr[3]);
                            vd.setVehicleTypeCode(data.getVehicleType());

                            GlobalRideType rideType = rideTypeDao.getRideTypeByVehicleCodeForGlobal(data.getVehicleType());
                            if(rideType != null && rideType.getId() > 0) {
                                    vd.setVehicleTypeName(rideType.getVehicleName());
                            }

                            vd.setMakeCode(data.getMakeCode());
                            MakeType mt=makeTypeRepository.getMakeTypeByVehicleCode(data.getMakeCode());
                            if(mt != null && mt.getId() > 0) {
                                    vd.setMakeName(mt.getVehicleName());
                            }
                               // dro.setVehicleCode(data.getVehicleCode());

                            driver = driverDao.getDriverByDriverCode((String) arr[1]);
                            if (driver != null && driver.getId() > 0) {
                                    vd.setDriverCode(driver.getDriverCode());
                                    vd.setDriverName(driver.getName());
                            }
                            
                            Calendar calPickupDate = Calendar.getInstance();
                            int dayCode = calPickupDate.get(Calendar.DAY_OF_WEEK);
                            
                            HoursOfOperation  hoursOfOperation=   hoursOfOperationDao.getHoursByDriverCodeAndDayCode(driverCode, dayCode); 
                            if(hoursOfOperation != null &&  hoursOfOperation.getVehicleCode().equals(data.getVehicleCode()))
                            {
                              vd.setIsdefaultvehicleCode(true);
                            }
                            else
                            {
                               vd.setIsdefaultvehicleCode(false);
                            }
                        

                            maplst.add(vd);

                    }
               }
                if (maplst.size() > 0) {
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(maplst);
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("count", count);
                        jsonobj.put("data", new JSONArray(Detail));
                } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                }
            } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Record Not Found");
                    jsonobj.put("timestamp", new Date());
            }
            } else {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("message", "Limit should not be Zero or Negative.");
                    jsonobj.put("timestamp", new Date());
            }

                    res = jsonobj.toString();
            } catch (JSONException ex) {
                    GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
                    res = derr.toString();
                    ex.printStackTrace();
                    LOG.error("JSON parsing exception is occurred.",ex); 
            } catch (Exception ex) {
                    GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
                    res = derr.toString();
                    ex.printStackTrace();
                    LOG.error("Exception is occurred.",ex);
            }
            return res;
	}

	@Override
	public String saveVehicleByDriver(SaveVehicleByDriver vehicleDetailReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (vehicleDetailReq != null) {

				if ( vehicleDetailReq.getLicenseExpiryDate() != null
						&& vehicleDetailReq.getLicenseExpiryDate().trim().length() > 0

						&& vehicleDetailReq.getLicenseExpiryDate() != null
						&& vehicleDetailReq.getLicenseExpiryDate().trim().length() > 0

						&& vehicleDetailReq.getModelCode() != null
						&& vehicleDetailReq.getModelCode().trim().length() > 0

						&& vehicleDetailReq.getDriverCode() != null
						&& vehicleDetailReq.getDriverCode().trim().length() > 0) {

					Date registrationExpiryDate = null;
					Date licenseExpiryDate = null;
                                        Date vehicleMOTExpDate=null;
                                        Date insurExpDate=null;
                                        Date hireAgreementDocExpDate=null;
			
//					Date currentTime = null;
					try {
                                            if(vehicleDetailReq.getInsuranceExpiryDate()!=null && vehicleDetailReq.getInsuranceExpiryDate().trim().length()>0)
                                            {
                                                insurExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getInsuranceExpiryDate().trim());
						if (insurExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send InsuranceExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
                                            
                                            if(vehicleDetailReq.getHireAgreementDocExpiryDate()!=null && vehicleDetailReq.getHireAgreementDocExpiryDate().trim().length()>0)
                                            {
                                                hireAgreementDocExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getHireAgreementDocExpiryDate().trim());
						if (hireAgreementDocExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send HireAgreementDocExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
                                            
                                            if(vehicleDetailReq.getVehicleMOTExpiryDate()!=null && vehicleDetailReq.getVehicleMOTExpiryDate().trim().length()>0)
                                            {
                                                vehicleMOTExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getVehicleMOTExpiryDate().trim());
						if (vehicleMOTExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send VehicleMOTExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
						registrationExpiryDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getRegistrationExpiryDate().trim());
						if (registrationExpiryDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send registrationExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
						licenseExpiryDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getLicenseExpiryDate().trim());
						if (licenseExpiryDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send licenseExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}

					} catch (Exception ex) {
						ex.printStackTrace();
						GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send registrationExpiryDate, HireAgreementDocExpiryDate, VehicleMOTExpiryDate, InsuranceExpiryDate and licenseExpiryDate in correct format("
										+ GigflexConstants.dateFormatterForSave + ") ");
						return derr.toString();
					}                                        
                                                Driver driver = driverDao.getDriverByDriverCode(vehicleDetailReq.getDriverCode());
                                                Date regExpDate = null;
                                                Date licExpDate = null;
                                                TimeZoneDetail tz;
                                                String timezone ="";
                                                if(driver != null && driver.getId() > 0)
                                                {
                                                    String organizationCode = driver.getOrganizationCode(); 
                                                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);
                                                    tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                                   
                                                    if(tz != null)
                                                    {
                                                            timezone = tz.getTimeZoneName(); 
                                                            regExpDate = GigflexDateUtil.convertStringDateToGMT(
                                                                            vehicleDetailReq.getRegistrationExpiryDate().trim(),timezone,
                                                                            GigflexConstants.dateFormatterForSave);
                                                            licExpDate = GigflexDateUtil.convertStringDateToGMT(
                                                                            vehicleDetailReq.getLicenseExpiryDate().trim(), timezone,
                                                                            GigflexConstants.dateFormatterForSave);
                                                    }
                                                   
                                                }
					
					if (regExpDate == null || licExpDate == null) {
						GigflexResponse derr = new GigflexResponse(400, new Date(), "Date conversion has been failed.");
						return derr.toString();
					}
					Date currentTime = new Date();
                                        Calendar cal = Calendar.getInstance();
                                        cal.setTime(currentTime);
                                        cal.add(Calendar.DATE, -1);
                                        currentTime = cal.getTime();

					Fuel fuel = fuelDao.getFuelByFuelCode(vehicleDetailReq.getFuelTypeCode());
					if (fuel != null && fuel.getId() > 0) {

						MakeModelMapping mmm = mmmDao.getMakeModelMappingByModelCode(vehicleDetailReq.getModelCode());
						if (mmm != null && mmm.getId() > 0) {

							
							if (driver != null && driver.getId() > 0) {

//								VehicleDetail vdcr = vehicleDetailDao.getVehicleDetailByDriverCodeAndVehicleName(
//										vehicleDetailReq.getDriverCode(), vehicleDetailReq.getVehicleName());
//								if (vdcr != null && vdcr.getId() > 0) {
//									jsonobj.put("responsecode", 409);
//									jsonobj.put("timestamp", new Date());
//									jsonobj.put("message", "Record already exist.");
//								} else {

									if (registrationExpiryDate.after(currentTime)) {

										if (licenseExpiryDate.after(currentTime)) {

											VehicleDetail vd = new VehicleDetail();

											//vd.setVehicleName(vehicleDetailReq.getVehicleName());
											//vd.setAbbrevationName(vehicleDetailReq.getAbbrevationName());
											vd.setVehicleType(vehicleDetailReq.getVehicleType());
											vd.setVehicleYear(vehicleDetailReq.getVehicleYear());
											vd.setInitialMileage(vehicleDetailReq.getInitialMileage());
											vd.setVehicleImage(vehicleDetailReq.getVehicleImage());
											vd.setRegistrationExpiryDate(regExpDate);
											vd.setInService(vehicleDetailReq.getInService());
											//vd.setVehicleEngineType(vehicleDetailReq.getVehicleEngineType());
											//vd.setVehicleHorsePower(vehicleDetailReq.getVehicleHorsePower());
											vd.setColor(vehicleDetailReq.getColor());
											vd.setVin(vehicleDetailReq.getVin());
											vd.setLicensePlate(vehicleDetailReq.getLicensePlate());
											vd.setLicenseExpiryDate(licExpDate);
											//vd.setVehicleGroup(vehicleDetailReq.getVehicleGroup());
											vd.setPassengerQuantity(vehicleDetailReq.getPassengerQuantity());
											vd.setBaggageQuantity(vehicleDetailReq.getBaggageQuantity());
											//vd.setDoorsQuantity(vehicleDetailReq.getDoorsQuantity());
											vd.setAirCondition(vehicleDetailReq.getAirCondition());
											vd.setAutomaticTransmission(vehicleDetailReq.getAutomaticTransmission());
											vd.setFuelTypeCode(vehicleDetailReq.getFuelTypeCode());
											vd.setSateliteNavigation(vehicleDetailReq.getSateliteNavigation());
											vd.setModelCode(vehicleDetailReq.getModelCode());
                                                                                        vd.setLicensePlateDoc(vehicleDetailReq.getLicensePlateDoc());
                                                                                        vd.setInsurance(vehicleDetailReq.getInsurance());
                                                                                        vd.setInsuranceDoc(vehicleDetailReq.getInsuranceDoc());
                                                                                        if(vehicleDetailReq.getInsuranceExpiryDate()!=null && vehicleDetailReq.getInsuranceExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date insuranceExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getInsuranceExpiryDate().trim(), timezone,
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setInsuranceExpiryDate(insuranceExpiryDate);
                                                                                        }
                                                                                        vd.setVehicleLogbookDoc(vehicleDetailReq.getVehicleLogbookDoc());
                                                                                        vd.setVehicleMOTDoc(vehicleDetailReq.getVehicleMOTDoc());
                                                                                        if(vehicleDetailReq.getVehicleMOTExpiryDate()!=null && vehicleDetailReq.getVehicleMOTExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date vehicleMOTExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getVehicleMOTExpiryDate().trim(), timezone,
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setVehicleMOTExpiryDate(vehicleMOTExpiryDate);
                                                                                        }
                                                                                        vd.setHireAgreementDoc(vehicleDetailReq.getHireAgreementDoc());
                                                                                        if(vehicleDetailReq.getHireAgreementDocExpiryDate()!=null && vehicleDetailReq.getHireAgreementDocExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date hireAgreementDocExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getHireAgreementDocExpiryDate().trim(), timezone,
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setHireAgreementDocExpiryDate(hireAgreementDocExpiryDate);
                                                                                        }
                                                                                        vd.setRegistrationNumber(vehicleDetailReq.getRegistrationNumber());
                                                                                        vd.setMakeCode(vehicleDetailReq.getMakeCode());
											vd.setIpAddress(ip);

											VehicleDetail vdRes = vehicleDetailDao.save(vd);
											jsonobj.put("responsecode", 200);
											jsonobj.put("timestamp", new Date());
											if (vdRes != null && vdRes.getId() > 0) {

												Driver driverlst = driver;
												if (driverlst != null && driverlst.getId() > 0) {

													VehicleDriverMapping vehDriver = new VehicleDriverMapping();
													vehDriver.setVehicleCode(vdRes.getVehicleCode());
													vehDriver.setDriverCode(vehicleDetailReq.getDriverCode());

													vehDriver.setIpAddress(ip);

													VehicleDriverMapping vehDriverRes = vehDriverDao.save(vehDriver);

													if (vehDriverRes != null && vehDriverRes.getId() > 0) {
														jsonobj.put("responsecode", 200);
														jsonobj.put("message", "Vehicle has been assigned to driver");
														jsonobj.put("timestamp", new Date());
														ObjectMapper mapperObj = new ObjectMapper();
														String Detail = mapperObj.writeValueAsString(vdRes);
														jsonobj.put("data", new JSONObject(Detail));
//                                                                                                                try {
//                                                                                                                    List<VehicleDriverMapping> mvlst = vehDriverDao.getVehicleDriverMappingByDriverCode(driverlst.getDriverCode());
//                                                                                                                    if (mvlst != null && mvlst.size() > 0) {
//                                                                                                                        driverlst.setFleetSize(mvlst.size());
//                                                                                                                    } else {
//                                                                                                                        driverlst.setFleetSize(0);
//                                                                                                                    }
//                                                                                                                    driverDao.save(driverlst);
//                                                                                                                } catch (Exception exp) {
//                                                                                                                    exp.printStackTrace();
//                                                                                                                }
//					                                    kafkaService.sendDriverForUpdate(driverRes);
														
														try {

															Notification notification = new Notification();

															String bodyContent = "Dear Operator"
																	+ ",Vehicle has been assign to driver."
																	+ "Driver Name : " + driverlst.getName();
															shortMessage = "Vehicle has been assign to driver.";

															notification.setUserCode(driverlst.getOperatorCode());
															notification.setMessage(bodyContent);
															notification.setUserType("All");
															notification.setShortMessage(shortMessage);
															notification.setIsRead(Boolean.FALSE);
															notification.setIpAddress(ip);

															notificationService.saveNotification(notification);
                                                                                                                        //for push notification
                                                                                                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);

														}

														catch (Exception e) {
															e.printStackTrace();
														}
													} else {
														jsonobj.put("responsecode", 400);
														jsonobj.put("message", "Assign activity has been failed.");
														jsonobj.put("timestamp", new Date());
													}

												} else {
													jsonobj.put("responsecode", 400);
													jsonobj.put("message", "Driver code is not valid.");
													jsonobj.put("timestamp", new Date());
												}
											} else {
												jsonobj.put("message", "Vehicle Creation Failed");
											}
										} else {
											jsonobj.put("responsecode", 404);
											jsonobj.put("timestamp", new Date());
											jsonobj.put("message", "License Expiry Date must be after current date");
										}
									} else {
										jsonobj.put("responsecode", 404);
										jsonobj.put("timestamp", new Date());
										jsonobj.put("message", "Registration Expiry Date must be after current date");
									}
								//}
							} else {
								jsonobj.put("message", "Driver Code Not Found.");
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
							}
						} else {
							jsonobj.put("message", "Model Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("message", "Fuel Type Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String updateVehicleByDriverById(Long id, SaveVehicleByDriver vehicleDetailReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (id > 0 && vehicleDetailReq != null) {
				if (vehicleDetailReq.getLicenseExpiryDate() != null
						&& vehicleDetailReq.getLicenseExpiryDate().trim().length() > 0

						&& vehicleDetailReq.getLicenseExpiryDate() != null
						&& vehicleDetailReq.getLicenseExpiryDate().trim().length() > 0

						&& vehicleDetailReq.getModelCode() != null
						&& vehicleDetailReq.getModelCode().trim().length() > 0

						&& vehicleDetailReq.getDriverCode() != null
						&& vehicleDetailReq.getDriverCode().trim().length() > 0) {

					VehicleDetail vdInDb = vehicleDetailDao.getVehicleDetailById(id);
					if (vdInDb != null && vdInDb.getId() > 0) {

						Date registrationExpiryDate = null;
						Date licenseExpiryDate = null;
                                                Date vehicleMOTExpDate=null;
                                                Date insurExpDate=null;
                                                Date hireAgreementDocExpDate=null;
			
//					Date currentTime = null;
					try {
                                            if(vehicleDetailReq.getInsuranceExpiryDate()!=null && vehicleDetailReq.getInsuranceExpiryDate().trim().length()>0)
                                            {
                                                insurExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getInsuranceExpiryDate().trim());
						if (insurExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send InsuranceExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
                                            
                                            if(vehicleDetailReq.getHireAgreementDocExpiryDate()!=null && vehicleDetailReq.getHireAgreementDocExpiryDate().trim().length()>0)
                                            {
                                                hireAgreementDocExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getHireAgreementDocExpiryDate().trim());
						if (hireAgreementDocExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send HireAgreementDocExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
                                            
                                            if(vehicleDetailReq.getVehicleMOTExpiryDate()!=null && vehicleDetailReq.getVehicleMOTExpiryDate().trim().length()>0)
                                            {
                                                vehicleMOTExpDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
								.parse(vehicleDetailReq.getVehicleMOTExpiryDate().trim());
						if (vehicleMOTExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send VehicleMOTExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}
                                            }
							registrationExpiryDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
									.parse(vehicleDetailReq.getRegistrationExpiryDate().trim());
							if (registrationExpiryDate == null) {
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Plz send registrationExpiryDate in correct format("
												+ GigflexConstants.dateFormatterForSave + ") ");
								return derr.toString();
							}
							licenseExpiryDate = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
									.parse(vehicleDetailReq.getLicenseExpiryDate().trim());
							if (licenseExpiryDate == null) {
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Plz send licenseExpiryDate in correct format("
												+ GigflexConstants.dateFormatterForSave + ") ");
								return derr.toString();
							}

						} catch (Exception ex) {
							ex.printStackTrace();
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send registrationExpiryDate, HireAgreementDocExpiryDate, VehicleMOTExpiryDate, InsuranceExpiryDate and licenseExpiryDate in correct format("
											+ GigflexConstants.dateFormatterForSave + ") ");
							return derr.toString();
						}

//						TimeZoneDetail tz = timeZoneRepository
//								.getTimeZoneByDriverCode(vehicleDetailReq.getDriverCode());
                                                
                                                Driver driver = driverDao.getDriverByDriverCode(vehicleDetailReq.getDriverCode());
                                                Date regExpDate = null;
                                                Date licExpDate = null;
                                                TimeZoneDetail tz;
                                                String timezone ="";
                                                if(driver != null && driver.getId() > 0)
                                                {
                                                    String organizationCode = driver.getOrganizationCode(); 
                                                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);
                                                    tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                                   
                                                    if(tz != null)
                                                    {
                                                            timezone = tz.getTimeZoneName(); 
                                                            regExpDate = GigflexDateUtil.convertStringDateToGMT(
                                                                            vehicleDetailReq.getRegistrationExpiryDate().trim(),timezone,
                                                                            GigflexConstants.dateFormatterForSave);
                                                            licExpDate = GigflexDateUtil.convertStringDateToGMT(
                                                                            vehicleDetailReq.getLicenseExpiryDate().trim(), timezone,
                                                                            GigflexConstants.dateFormatterForSave);
                                                    }
                                                   
                                                }
                                                
						if (regExpDate == null && licExpDate == null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Date conversion has been failed.");
							return derr.toString();
						}
                                                Date currentTime = new Date();
                                                Calendar cal = Calendar.getInstance();
                                                cal.setTime(currentTime);
                                                cal.add(Calendar.DATE, -1);
                                                currentTime = cal.getTime();

						Fuel fuel = fuelDao.getFuelByFuelCode(vehicleDetailReq.getFuelTypeCode());
						if (fuel != null && fuel.getId() > 0) {

							MakeModelMapping mmm = mmmDao
									.getMakeModelMappingByModelCode(vehicleDetailReq.getModelCode());
							if (mmm != null && mmm.getId() > 0) {

//								driver = driverDao.getDriverByDriverCode(vehicleDetailReq.getDriverCode());
								if (driver != null && driver.getId() > 0) {

//									VehicleDetail vdcr = vehicleDetailDao.getVehicleDetailByIdDriverCodeAndVehicleName(
//											id, vehicleDetailReq.getDriverCode(), vehicleDetailReq.getVehicleName());
//									if (vdcr != null && vdcr.getId() > 0) {
//										jsonobj.put("responsecode", 409);
//										jsonobj.put("timestamp", new Date());
//										jsonobj.put("message", "Record already exist.");
//									} else {

										if (registrationExpiryDate.after(currentTime)) {

											if (licenseExpiryDate.after(currentTime)) {

                                                                                        VehicleDetail vd = vdInDb;

                                                                                        //vd.setVehicleName(vehicleDetailReq.getVehicleName());
                                                                                        //vd.setAbbrevationName(vehicleDetailReq.getAbbrevationName());
                                                                                        vd.setVehicleType(vehicleDetailReq.getVehicleType());
                                                                                        vd.setVehicleYear(vehicleDetailReq.getVehicleYear());
                                                                                        vd.setInitialMileage(vehicleDetailReq.getInitialMileage());
                                                                                        vd.setVehicleImage(vehicleDetailReq.getVehicleImage());
                                                                                        vd.setRegistrationExpiryDate(regExpDate);
                                                                                        vd.setInService(vehicleDetailReq.getInService());
                                                                                        //vd.setVehicleEngineType(vehicleDetailReq.getVehicleEngineType());
                                                                                        //vd.setVehicleHorsePower(vehicleDetailReq.getVehicleHorsePower());
                                                                                        vd.setColor(vehicleDetailReq.getColor());
                                                                                        vd.setVin(vehicleDetailReq.getVin());
                                                                                        vd.setLicensePlate(vehicleDetailReq.getLicensePlate());
                                                                                        vd.setLicenseExpiryDate(licExpDate);
                                                                                        //vd.setVehicleGroup(vehicleDetailReq.getVehicleGroup());
                                                                                        vd.setPassengerQuantity(vehicleDetailReq.getPassengerQuantity());
                                                                                        vd.setBaggageQuantity(vehicleDetailReq.getBaggageQuantity());
                                                                                        //vd.setDoorsQuantity(vehicleDetailReq.getDoorsQuantity());
                                                                                        vd.setAirCondition(vehicleDetailReq.getAirCondition());
                                                                                        vd.setAutomaticTransmission(
                                                                                                        vehicleDetailReq.getAutomaticTransmission());
                                                                                        vd.setFuelTypeCode(vehicleDetailReq.getFuelTypeCode());
                                                                                        vd.setSateliteNavigation(vehicleDetailReq.getSateliteNavigation());
                                                                                        vd.setModelCode(vehicleDetailReq.getModelCode());
                                                                                        vd.setLicensePlateDoc(vehicleDetailReq.getLicensePlateDoc());
                                                                                        vd.setInsurance(vehicleDetailReq.getInsurance());
                                                                                        vd.setInsuranceDoc(vehicleDetailReq.getInsuranceDoc());
                                                                                    if(vehicleDetailReq.getInsuranceExpiryDate()!=null && vehicleDetailReq.getInsuranceExpiryDate().trim().length()>0)
                                                                                    {
                                                                                        Date insuranceExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getInsuranceExpiryDate().trim(), timezone,
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setInsuranceExpiryDate(insuranceExpiryDate);
                                                                                    }
                                                                                        vd.setVehicleLogbookDoc(vehicleDetailReq.getVehicleLogbookDoc());
                                                                                        vd.setVehicleMOTDoc(vehicleDetailReq.getVehicleMOTDoc());
                                                                                        if(vehicleDetailReq.getVehicleMOTExpiryDate()!=null && vehicleDetailReq.getVehicleMOTExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date vehicleMOTExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getVehicleMOTExpiryDate().trim(), timezone,
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setVehicleMOTExpiryDate(vehicleMOTExpiryDate);
                                                                                        }
                                                                                        vd.setHireAgreementDoc(vehicleDetailReq.getHireAgreementDoc());
                                                                                        if(vehicleDetailReq.getHireAgreementDocExpiryDate()!=null && vehicleDetailReq.getHireAgreementDocExpiryDate().trim().length()>0)
                                                                                        {
                                                                                        Date hireAgreementDocExpiryDate = GigflexDateUtil.convertStringDateToGMT(
                                                                                        vehicleDetailReq.getHireAgreementDocExpiryDate().trim(), timezone,
                                                                                        GigflexConstants.dateFormatterForSave);
                                                                                        vd.setHireAgreementDocExpiryDate(hireAgreementDocExpiryDate);
                                                                                        }
                                                                                        vd.setRegistrationNumber(vehicleDetailReq.getRegistrationNumber());
                                                                                        vd.setMakeCode(vehicleDetailReq.getMakeCode());
												vd.setIpAddress(ip);

												VehicleDetail vdRes = vehicleDetailDao.save(vd);
												if (vdRes != null && vdRes.getId() > 0) {

													Driver driverlst = driver;
													if (driverlst != null && driverlst.getId() > 0) {
														VehicleDriverMapping vehDriver = new VehicleDriverMapping();
														VehicleDriverMapping vehDri = vehDriverDao
																.getVehicleDriverMappingByVehicleCode(
																		vdRes.getVehicleCode());
														if (vehDri != null && vehDri.getId() > 0) {

															vehDri.setDriverCode(vehicleDetailReq.getDriverCode());

															VehicleDriverMapping vehDriverRes = vehDriverDao
																	.save(vehDri);

															if (vehDriverRes != null && vehDriverRes.getId() > 0) {

																jsonobj.put("responsecode", 200);
																jsonobj.put("message",
																		"Vehicle Detail updation has been done");
																jsonobj.put("timestamp", new Date());
																ObjectMapper mapperObj = new ObjectMapper();
																String Detail = mapperObj.writeValueAsString(vdRes);
																jsonobj.put("data", new JSONObject(Detail));
//												kafkaService.sendDriverForUpdate(vehDriverRes);
																
																try {

																	Notification notification = new Notification();

																	String bodyContent = "Dear Operator"
																			+ ",Vehicle has been updated by driver."
																			+ "Driver Name : " + driverlst.getName();
																	shortMessage = "Vehicle has been updated.";

																	notification.setUserCode(driverlst.getOperatorCode());
																	notification.setMessage(bodyContent);
																	notification.setUserType("All");
																	notification.setShortMessage(shortMessage);
																	notification.setIsRead(Boolean.FALSE);
																	notification.setIpAddress(ip);

																	notificationService.saveNotification(notification);
                                                                                                                                        //for push notification
                                                                                                                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);

																}

																catch (Exception e) {
																	e.printStackTrace();
																}

															} else {
																jsonobj.put("responsecode", 400);
																jsonobj.put("message",
																		"Vehicle Detail updation has been failed.");
																jsonobj.put("timestamp", new Date());
															}
														} else {

															vehDriver.setVehicleCode(vdRes.getVehicleCode());
															vehDriver.setDriverCode(vehicleDetailReq.getDriverCode());

															vehDriver.setIpAddress(ip);

															VehicleDriverMapping vehDriverRes = vehDriverDao
																	.save(vehDriver);

															if (vehDriverRes != null && vehDriverRes.getId() > 0) {

																jsonobj.put("responsecode", 200);
																jsonobj.put("message",
																		"Vehicle Detail updation has been done");
																jsonobj.put("timestamp", new Date());
																ObjectMapper mapperObj = new ObjectMapper();
																String Detail = mapperObj.writeValueAsString(vdRes);
																jsonobj.put("data", new JSONObject(Detail));
															} else {
																jsonobj.put("responsecode", 400);
																jsonobj.put("message",
																		"Vehicle Detail updation has been failed.");
																jsonobj.put("timestamp", new Date());
															}
														}
                                                                                                                
//                                                                                                                try {
//                                                                                                                    List<VehicleDriverMapping> mvlst = vehDriverDao.getVehicleDriverMappingByDriverCode(driverlst.getDriverCode());
//                                                                                                                    if (mvlst != null && mvlst.size() > 0) {
//                                                                                                                        driverlst.setFleetSize(mvlst.size());
//                                                                                                                    } else {
//                                                                                                                        driverlst.setFleetSize(0);
//                                                                                                                    }
//                                                                                                                    driverDao.save(driverlst);
//                                                                                                                } catch (Exception exp) {
//                                                                                                                    exp.printStackTrace();
//                                                                                                                }
                                                                                                                
                                                                                                                
													} else {
														jsonobj.put("responsecode", 400);
														jsonobj.put("message", "Driver code is not valid.");
														jsonobj.put("timestamp", new Date());
													}
												} else {
													jsonobj.put("message", "Vehicle Updation Failed");
												}

											} else {
												jsonobj.put("responsecode", 404);
												jsonobj.put("timestamp", new Date());
												jsonobj.put("message",
														"License Expiry Date must be after current date");
											}
										} else {
											jsonobj.put("responsecode", 404);
											jsonobj.put("timestamp", new Date());
											jsonobj.put("message",
													"Registration Expiry Date must be after current date");
										}
									//}
								} else {
									jsonobj.put("message", "Driver Code Not Found.");
									jsonobj.put("responsecode", 400);
									jsonobj.put("timestamp", new Date());
								}
							} else {
								jsonobj.put("message", "Model Code Not Found.");
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
							}
						} else {
							jsonobj.put("message", "Fuel Type Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Vehicle Detail Id is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

   
}
