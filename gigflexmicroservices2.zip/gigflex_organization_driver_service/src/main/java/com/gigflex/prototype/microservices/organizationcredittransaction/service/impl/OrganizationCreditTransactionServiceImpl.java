/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationcredittransaction.service.impl;

import com.gigflex.prototype.microservices.organizationcredittransaction.service.OrganizationCreditTransactionService;
import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransaction;
import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransactionRequest;
import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransactionResponse;
import com.gigflex.prototype.microservices.organizationcredittransaction.repository.OrganizationCreditTransactionRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransactionSummaryResponse;
import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationTransactionDetailsResponse;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.utility.GigflexDateUtil;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */
@Service
public class OrganizationCreditTransactionServiceImpl implements OrganizationCreditTransactionService{
    
    private static final Logger LOG = LoggerFactory.getLogger(OrganizationCreditTransactionServiceImpl.class);
    
    @Autowired
    OrganizationCreditTransactionRepository organizationCreditTransactionRepository;
    
    @Autowired
    OrganizationRepository organizationDao;
    
    @Autowired
    GlobalSettingRepository globalSettingRepository;
    
    @Autowired
    LocalSettingRepository localSettingRepository;

    @Autowired
    UserTypeRepository userTypeDao;
    
    @Autowired
    private TimeZoneRepository timeZoneRepository;    

    @Override
    public String findAllOrganizationCreditTransactions() {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<OrganizationCreditTransaction> objlst = organizationCreditTransactionRepository.getAllOrganizationCreditTransactions();
			List<OrganizationCreditTransactionResponse> maplst = new ArrayList<OrganizationCreditTransactionResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
				for (int i = 0; i < objlst.size(); i++) {
                                    
                                    String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                    TimeZoneDetail tzd = null;
                                    OrganizationCreditTransaction oprRes = objlst.get(i);
                                    OrganizationCreditTransactionResponse opr = new OrganizationCreditTransactionResponse();
                                 
                                    opr.setId(oprRes.getId());
                                    opr.setOrganizationCreditTransactionCode(oprRes.getOrganizationCreditTransactionCode());
                                    opr.setOrganizationCode(oprRes.getOrganizationCode());
                                    if(oprRes.getOrganizationCode() != null && oprRes.getOrganizationCode().trim().length() > 0)
                                    {
                                        Organization org = organizationDao.findByOrganizationCode(oprRes.getOrganizationCode().trim());
                                        if(org != null)
                                        {
                                            String organizationCode = org.getOrganizationCode();
                                            String organizationName = org.getOrganizationName();
                                            opr.setOrganizationName(organizationName);                                             
                                            
                                            String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                            
                                            if(currencySymbol != null )
                                            {
                                                opr.setCurrencySymbol(currencySymbol); 
                                            }
                                            
                                           
                                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);

                                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                            {
                                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                                            }                

                                            String timeznCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);

                                            tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timeznCode);

                                            opr.setDateFormat(dateformat);
                                            opr.setTimeFormat(timeformat); 
                                           
                                            
                                        }
                                    }       
                                    
                                    String transactionDt = "";

                                    Date transactionDate = oprRes.getCreatedAt();
                                    if(transactionDate != null && transactionDate.toString().trim().length() > 0)
                                    {
                                        if (tzd != null && tzd.getId() > 0) {

                                            String timezone = tzd.getTimeZoneName();
                                            if(timezone!=null && timezone.length()>0 )
                                            {                              
                                                transactionDate = GigflexDateUtil.getGMTtoLocationDate(transactionDate, timezone, dtFormat);
                                                transactionDt=GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                                            }
                                        } 
                                        else
                                        {
                                            transactionDt = GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                                        }
                                    }
                                    
                                    opr.setTransactionDate(transactionDt);
                                    opr.setBookingid(oprRes.getBookingid());
                                    String strBalanceAmount = String.format("%.2f",oprRes.getBalanceAmount());
                                    opr.setBalanceAmount(strBalanceAmount);
                                    String strDebitAmount = String.format("%.2f",oprRes.getDebitAmount());
                                    opr.setDebitAmount(strDebitAmount);
                                    String strCreditAmount = String.format("%.2f",oprRes.getCreditAmount());
                                    opr.setCreditAmount(strCreditAmount);
                                    opr.setTransactionBy(oprRes.getTransactionBy()); 
                                    opr.setTransactionType(oprRes.getTransactionType()); 
                                    
                                    maplst.add(opr);

					
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
                        
		}
		return res;
    }

    @Override
    public String getLastTransactionBalanceByOrganizationCode(String organizationCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        Organization org = organizationDao.findByOrganizationCode(organizationCode);
                        if (org != null && org.getId() > 0 ) {
                            String organizationName = org.getOrganizationName();
                            List<OrganizationCreditTransaction> objlst = organizationCreditTransactionRepository.getLastTransactionBalanceByOrganizationCode(organizationCode);

                            if (objlst != null && objlst.size() > 0) {
                            
                            OrganizationCreditTransaction oprRes = objlst.get(0);
                            OrganizationCreditTransactionResponse ogr = new OrganizationCreditTransactionResponse();

                            String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                            
                            if(currencySymbol != null )
                            {
                                ogr.setCurrencySymbol(currencySymbol); 
                            }
                            
                            
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);

                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            String timeznCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);

                            TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timeznCode);
                            
                            
                            String transactionDt = "";

                            Date transactionDate = oprRes.getCreatedAt();
                            if(transactionDate != null && transactionDate.toString().trim().length() > 0)
                            {
                                if (tzd != null && tzd.getId() > 0) {

                                    String timezone = tzd.getTimeZoneName();
                                    if(timezone!=null && timezone.length()>0 )
                                    {                              
                                        transactionDate = GigflexDateUtil.getGMTtoLocationDate(transactionDate, timezone, dtFormat);
                                        transactionDt=GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                                    }
                                } 
                                else
                                {
                                    transactionDt = GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                                }
                            }
                            
                            ogr.setDateFormat(dateformat);
                            ogr.setTimeFormat(timeformat); 
                            ogr.setTransactionDate(transactionDt); 
                            ogr.setId(oprRes.getId());
                            ogr.setOrganizationCreditTransactionCode(oprRes.getOrganizationCreditTransactionCode());
                            ogr.setOrganizationCode(oprRes.getOrganizationCode());
                            ogr.setBookingid(oprRes.getBookingid());
                            String strBalanceAmount = String.format("%.2f",oprRes.getBalanceAmount());
                            ogr.setBalanceAmount(strBalanceAmount);
                            String strDebitAmount = String.format("%.2f",oprRes.getDebitAmount());
                            ogr.setDebitAmount(strDebitAmount);
                            String strCreditAmount = String.format("%.2f",oprRes.getCreditAmount());
                            ogr.setCreditAmount(strCreditAmount);
                            ogr.setTransactionBy(oprRes.getTransactionBy()); 
                            ogr.setTransactionType(oprRes.getTransactionType()); 
                            ogr.setOrganizationName(organizationName); 
                                    
                            if (ogr != null && ogr.getId() > 0) {
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(ogr);
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("message", "Success");
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("message", "Record Not Found");
                                    jsonobj.put("timestamp", new Date());
                            }
                            } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("message", "Record Not Found");
                                    jsonobj.put("timestamp", new Date());
                            }
                        } else {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Organization does not exist.");
                            jsonobj.put("timestamp", new Date());
                        }

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
    }
    
    
    @Override
    public String getTransactionDetailsByOrganizationCodeAndBetweenDates(String organizationCode, String startDT, String endDT) {
        
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            Organization org = organizationDao.findByOrganizationCode(organizationCode);
            if (org != null && org.getId() > 0 ) {
                   
                Date fromdate = null;
                Date toDate = null;
                String organizationName = org.getOrganizationName();

                fromdate = GigflexDateUtil.convertStringToDate(startDT.trim(), GigflexConstants.YYYY_MM_DD);
                toDate =   GigflexDateUtil.convertStringToDate(endDT.trim(), GigflexConstants.YYYY_MM_DD);
                
                if(fromdate == null )
                {
                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "Plz send date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
                                    return derr.toString();
                }
                
                
                if(toDate == null )
                {
                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "Plz send date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
                                    return derr.toString();
                }

                if(fromdate.after(toDate)) 
                {
                     GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "From date should be less than todate ");
                                    return derr.toString();
                }
                   
                
                
                startDT = startDT.trim()+" "+"00:00:00";
                fromdate = GigflexDateUtil.convertStringToDate(startDT, GigflexConstants.YYYY_MM_DD_HH_MM_SS);
                
                endDT = endDT.trim()+" "+"23:59:59";
                toDate = GigflexDateUtil.convertStringToDate(endDT, GigflexConstants.YYYY_MM_DD_HH_MM_SS);
                                
                List<OrganizationCreditTransaction> objlst = organizationCreditTransactionRepository.getTransactionDetailsByOrganizationCodeAndBetweenDates(organizationCode,toDate,fromdate);
                       
                List<OrganizationTransactionDetailsResponse> maplst = new ArrayList<OrganizationTransactionDetailsResponse>();
                if (objlst != null && objlst.size() > 0) {
                        
                    String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);

                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                    {
                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                    }                

                    String timeznCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);

                    TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timeznCode);
                        
                    String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                                                
                    for (int i = 0; i < objlst.size(); i++) {
                        
                        OrganizationCreditTransaction   orgTransaction = objlst.get(i);
                        OrganizationTransactionDetailsResponse otdRes = new OrganizationTransactionDetailsResponse();
                        String transactionDt = "";

                        Date transactionDate = orgTransaction.getCreatedAt();
                        if(transactionDate != null && transactionDate.toString().trim().length() > 0)
                        {
                            if (tzd != null && tzd.getId() > 0) {

                                String timezone = tzd.getTimeZoneName();
                                if(timezone!=null && timezone.length()>0 )
                                {                              
                                    transactionDate = GigflexDateUtil.getGMTtoLocationDate(transactionDate, timezone, dtFormat);
                                    transactionDt=GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                                }
                            } 
                            else
                            {
                                transactionDt = GigflexDateUtil.convertDateToString(transactionDate, dtFormat);
                            }
                        }
                        
                        if(currencySymbol != null )
                        {
                            otdRes.setCurrencySymbol(currencySymbol); 
                        }
                        
                        otdRes.setDateFormat(dateformat); 
                        otdRes.setTimeFormat(timeformat); 
                        
                        otdRes.setId(orgTransaction.getId());
                        otdRes.setOrganizationCreditTransactionCode(orgTransaction.getOrganizationCreditTransactionCode());
                        otdRes.setOrganizationCode(orgTransaction.getOrganizationCode());
                        otdRes.setBookingid(orgTransaction.getBookingid());
                        String strBalanceAmount = String.format("%.2f",orgTransaction.getBalanceAmount());
                        otdRes.setBalanceAmount(strBalanceAmount);
                        String strDebitAmount = String.format("%.2f",orgTransaction.getDebitAmount());
                        otdRes.setDebitAmount(strDebitAmount);
                        String strCreditAmount = String.format("%.2f",orgTransaction.getCreditAmount());
                        otdRes.setCreditAmount(strCreditAmount);
                        otdRes.setTransactionBy(orgTransaction.getTransactionBy()); 
                        otdRes.setTransactionType(orgTransaction.getTransactionType()); 
                        otdRes.setTransactionDate(transactionDt); 
                        otdRes.setOrganizationName(organizationName);

                        maplst.add(otdRes);

                    }
                    }
                    if (maplst != null && maplst.size() > 0) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());                      
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(maplst);
                        jsonobj.put("data", new JSONArray(Detail));
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Organization does not exist.");
                    jsonobj.put("timestamp", new Date());
                }
            
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;

    }
    
     @Override
    public String getSummaryOfTransactionDetailsByOrgCodeAndBetweenDates(String organizationCode, String startDT, String endDT) {
        
         String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            Organization org = organizationDao.findByOrganizationCode(organizationCode);
            if (org != null && org.getId() > 0 ) {
                   
                Date fromdate = null;
                Date toDate = null;
                String organizationName = org.getOrganizationName();
                double totalDebitAmount = 0.0;
                double totalCreditAmount = 0.0;
                double currentBalance = 0.0;
               
                fromdate = GigflexDateUtil.convertStringToDate(startDT.trim(), GigflexConstants.YYYY_MM_DD);
                toDate =   GigflexDateUtil.convertStringToDate(endDT.trim(), GigflexConstants.YYYY_MM_DD);
                
                if(fromdate == null )
                {
                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "Plz send date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
                                    return derr.toString();
                }
                
                
                if(toDate == null )
                {
                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "Plz send date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
                                    return derr.toString();
                }

                if(fromdate.after(toDate)) 
                {
                     GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "From date should be less than todate ");
                                    return derr.toString();
                }
                                   
                startDT = startDT.trim()+" "+"00:00:00";
                fromdate = GigflexDateUtil.convertStringToDate(startDT, GigflexConstants.YYYY_MM_DD_HH_MM_SS);
                
                endDT = endDT.trim()+" "+"23:59:59";
                toDate = GigflexDateUtil.convertStringToDate(endDT, GigflexConstants.YYYY_MM_DD_HH_MM_SS);
                
                
                List<OrganizationCreditTransaction> objlst = organizationCreditTransactionRepository.getTransactionDetailsByOrganizationCodeAndBetweenDates(organizationCode,toDate,fromdate);
                OrganizationCreditTransactionSummaryResponse octSummaryRes = null;
                if (objlst != null && objlst.size() > 0) {
                        
                    octSummaryRes = new OrganizationCreditTransactionSummaryResponse(); 
                    for (int i = 0; i < objlst.size(); i++) {
                        
                        OrganizationCreditTransaction   orgTransaction = objlst.get(i);
                        totalDebitAmount = totalDebitAmount+orgTransaction.getDebitAmount();
                        totalCreditAmount =totalCreditAmount+orgTransaction.getCreditAmount();
                    }
                    
                    List<OrganizationCreditTransaction> orgCtList = organizationCreditTransactionRepository.getLastTransactionBalanceByOrganizationCode(organizationCode);
                    String strCurrentBalance ="";
                    if (orgCtList != null && orgCtList.size() > 0) {
                            
                        OrganizationCreditTransaction oprRes = orgCtList.get(0);
                        currentBalance = oprRes.getBalanceAmount();
                        strCurrentBalance = String.format("%.2f",currentBalance);
                   
                    }
                    
                    String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                            
                    if(currencySymbol != null )
                    {
                        octSummaryRes.setCurrencySymbol(currencySymbol); 
                    }
                    
                    String strTotalCreditAmount = String.format("%.2f",totalCreditAmount);
                    String strTotalDebitAmount = String.format("%.2f",totalDebitAmount);
                    octSummaryRes.setOrganizationCode(organizationCode); 
                    octSummaryRes.setOrganizationName(organizationName); 
                    octSummaryRes.setTotalCreditAmount(strTotalCreditAmount); 
                    octSummaryRes.setTotalDebitAmount(strTotalDebitAmount); 
                    octSummaryRes.setCurrentBalance(strCurrentBalance); 
                    
                }
                if (octSummaryRes != null ) { 
                    jsonobj.put("responsecode", 200);
                    jsonobj.put("message", "Success");
                    jsonobj.put("timestamp", new Date());                      
                    ObjectMapper mapperObj = new ObjectMapper();
                    String Detail = mapperObj.writeValueAsString(octSummaryRes);
                    jsonobj.put("data", new JSONObject(Detail));
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Record Not Found");
                    jsonobj.put("timestamp", new Date());
                }
            } else {
                jsonobj.put("responsecode", 404);
                jsonobj.put("message", "Organization does not exist.");
                jsonobj.put("timestamp", new Date());
            }
            
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;
    }

    
    

    @Override
    public String saveOrganizationCreditTransaction(OrganizationCreditTransactionRequest organizationReq, String ip) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (organizationReq != null) {

				if (organizationReq.getOrganizationCode() != null && organizationReq.getOrganizationCode().trim().length() > 0 
                                        && organizationReq.getAmount() != null && organizationReq.getAmount() > 0.0                                         
                                        && organizationReq.isIsCreditable() != null ) {

					Organization ogr = organizationDao.findByOrganizationCode(organizationReq.getOrganizationCode());
					if (ogr != null && ogr.getId() > 0) {

                                            
                                                List<OrganizationCreditTransaction> objlst = organizationCreditTransactionRepository.getLastTransactionBalanceByOrganizationCode(organizationReq.getOrganizationCode());
                                                OrganizationCreditTransaction oct = new OrganizationCreditTransaction();
                                                if(objlst != null && objlst.size() > 0)
                                                {
                                                   OrganizationCreditTransaction octRes = objlst.get(0);
                                                   double balanceAmount = octRes.getBalanceAmount();
                                                   
                                                    if(organizationReq.isIsCreditable())
                                                    {
                                                        oct.setBalanceAmount(organizationReq.getAmount()+balanceAmount); 
                                                        oct.setCreditAmount(organizationReq.getAmount()); 
                                                        oct.setTransactionType(GigflexConstants.TRANSACTION_TYPE_CREDIT); 
                                                    }
                                                    else
                                                    {
                                                        oct.setBalanceAmount(balanceAmount-organizationReq.getAmount()); 
                                                        oct.setDebitAmount(organizationReq.getAmount()); 
                                                        oct.setTransactionType(GigflexConstants.TRANSACTION_TYPE_DEBIT);
                                                    }
                                                   
                                                }
                                                else
                                                {
                                                    oct.setBalanceAmount(organizationReq.getAmount()); 
                                                    if(organizationReq.isIsCreditable())
                                                    {
                                                        oct.setCreditAmount(organizationReq.getAmount());  
                                                        oct.setBalanceAmount(organizationReq.getAmount());
                                                        oct.setTransactionType(GigflexConstants.TRANSACTION_TYPE_CREDIT); 
                                                    }
                                                    else
                                                    {
                                                       GigflexResponse derr = new GigflexResponse(500, new Date(), "No balance available for Debit.");
                                                       return res = derr.toString();
                                                    }
                                                    
                                                }
						
                                                oct.setOrganizationCode(organizationReq.getOrganizationCode()); 
                                                oct.setTransactionBy(GigflexConstants.USER_TYPE_SUPER_ADMIN); 
						oct.setIpAddress(ip);

						OrganizationCreditTransaction organizationCreditTransactionRes = organizationCreditTransactionRepository.save(oct);

						if (organizationCreditTransactionRes != null && organizationCreditTransactionRes.getId() > 0) {
                                                        jsonobj.put("responsecode", 200);
                                                        jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Credit for Organization has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(organizationCreditTransactionRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
                                                        jsonobj.put("responsecode", 400);
                                                        jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Organization Code not found.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
    }


    
    
    
}
