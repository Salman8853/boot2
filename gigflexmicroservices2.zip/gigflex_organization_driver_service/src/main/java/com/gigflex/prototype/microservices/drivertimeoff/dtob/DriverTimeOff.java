/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.drivertimeoff.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "driver_timeoff")
public class DriverTimeOff extends CommonAttributes implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "drivertimeoff_code", unique = true)
    private String driverTimeoffCode;

    public DriverTimeOff() {
    }
    
            
    @PrePersist
    private void assignUUID() {
        if (this.getDriverTimeoffCode() == null || this.getDriverTimeoffCode().length() == 0) {
           this.setDriverTimeoffCode(UUID.randomUUID().toString());
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    @Column(name = "organization_code")
    private String organizationCode;
     
    @Column(name = "driver_code", nullable = false)
    private String driverCode;
    
    @Column(name = "created_by")
    private String createdBy;
            
    @Column(name = "fromdate", columnDefinition = "DATE")
    private Date fromDate;

    @Column(name = "todate", columnDefinition = "DATE")
    private Date toDate;    
    
    @Column(name = "fromtime")
    private String fromTime;
            
    @Column(name = "totime")
    private String toTime;      
    
    @Column(name = "cancel_reason")
    private String cancelReason;    
    
    @Column(name = "reason")
    private String reason;
    
    @Column(name = "fromtimeoffdate", columnDefinition = "DATETIME")
    private Date fromTimeOffDate;

    @Column(name = "totimeoffdate", columnDefinition = "DATETIME")
    private Date toTimeOffDate;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }    
    
   

    public DriverTimeOff(Long id,String driverTimeoffCode,String organizationCode, String driverCode,String createdBy,
            Date fromDate, Date toDate,String fromTime,String toTime,Date fromTimeOffDate,Date toTimeOffDate,String cancelReason,String reason) {
            super();
            this.id = id;
            this.driverTimeoffCode = driverTimeoffCode;
            this.organizationCode = organizationCode;
            this.driverCode = driverCode;
            this.createdBy = createdBy;
            this.fromDate = fromDate;
            this.toDate = toDate;
            this.fromTime = fromTime;
            this.toTime = toTime;
            this.cancelReason = cancelReason;
            this.reason = reason;
            this.fromTimeOffDate = fromTimeOffDate;
            this.toTimeOffDate = toTimeOffDate;
    }

    public Date getFromTimeOffDate() {
        return fromTimeOffDate;
    }

    public void setFromTimeOffDate(Date fromTimeOffDate) {
        this.fromTimeOffDate = fromTimeOffDate;
    }

    public Date getToTimeOffDate() {
        return toTimeOffDate;
    }

    public void setToTimeOffDate(Date toTimeOffDate) {
        this.toTimeOffDate = toTimeOffDate;
    }

    
    
    public String getDriverTimeoffCode() {
        return driverTimeoffCode;
    }

    public void setDriverTimeoffCode(String driverTimeoffCode) {
        this.driverTimeoffCode = driverTimeoffCode;
    }

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }
    
    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }
    
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public String getCancelReason() {
        return cancelReason;
    }

    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }
        
    @Override
    public String toString() {
            return "DriverTimeOff [id=" + id + ", driverTimeoffCode=" +driverTimeoffCode+", organizationCode=" + organizationCode +", driverCode=" + driverCode + ", createdBy=" + organizationCode +", fromDate=" + fromDate
                            + ", toDate=" + toDate + ", fromTime=" + fromTime +", toTime=" + toTime +", fromTimeOffDate=" + fromTimeOffDate +", toTimeOffDate=" + toTimeOffDate +",cancelReason=" + cancelReason + ", reason=" + reason +"]";
    }
    
}
