package com.gigflex.prototype.microservices.makemodelmapping.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.makemodelmapping.dtob.MakeModelMapping;

public interface MakeModelMappingRepository extends JpaRepository<MakeModelMapping, Long>,JpaSpecificationExecutor<MakeModelMapping>{
	
//	@Query("SELECT m FROM MakeModelMapping m WHERE m.isDeleted != TRUE")
//	public List<MakeModelMapping> getAllMakeModelMapping();
//	
//	@Query("SELECT m FROM MakeModelMapping m WHERE m.isDeleted != TRUE")
//	public List<MakeModelMapping> getAllMakeModelMapping(Pageable pageableRequest);
	
	@Query("SELECT m,mt.vehicleName FROM MakeModelMapping m,MakeType mt WHERE m.isDeleted != TRUE AND m.makeCode = mt.vehicleCode")
	public List<Object> getAllMakeModelMapping();
	
	@Query("SELECT m,mt.vehicleName FROM MakeModelMapping m,MakeType mt WHERE m.isDeleted != TRUE AND m.makeCode = mt.vehicleCode")
	public List<Object> getAllMakeModelMapping(Pageable pageableRequest);
	
	@Query("SELECT m,mt.vehicleName FROM MakeModelMapping m,MakeType mt WHERE m.isDeleted != TRUE AND m.makeCode = mt.vehicleCode AND m.modelCode = :modelCode")
	public Object getByModelCode(@Param("modelCode") String modelCode);
	
	@Query("SELECT m,mt.vehicleName FROM MakeModelMapping m,MakeType mt WHERE m.isDeleted != TRUE AND m.makeCode = mt.vehicleCode AND m.makeCode = :makeCode")
	public List<Object> getModelByMakeCode(@Param("makeCode") String makeCode);
	
	@Query("SELECT m,mt.vehicleName FROM MakeModelMapping m,MakeType mt WHERE m.isDeleted != TRUE AND m.makeCode = mt.vehicleCode AND m.makeCode = :makeCode")
	public List<Object> getModelByMakeCode(@Param("makeCode") String makeCode,Pageable pageableRequest);
	
	@Query("SELECT m FROM MakeModelMapping m WHERE m.isDeleted != TRUE AND m.modelCode = :modelCode")
	public MakeModelMapping getMakeModelMappingByModelCode(@Param("modelCode") String modelCode);
	
	@Query("SELECT m FROM MakeModelMapping m WHERE m.isDeleted != TRUE AND m.id = :id")
	public MakeModelMapping getMakeModelMappingById(@Param("id") Long id);
	
	@Query("SELECT m FROM MakeModelMapping m WHERE m.isDeleted != TRUE AND m.makeCode = :makeCode AND m.modelName = :modelName")
	public MakeModelMapping getMakeModelMappingByMakeCodeAndModelName(@Param("makeCode") String makeCode,@Param("modelName") String modelName);
	
	@Query("SELECT m FROM MakeModelMapping m WHERE m.isDeleted != TRUE AND m.id != :id AND m.makeCode = :makeCode AND m.modelName = :modelName")
	public MakeModelMapping getMakeModelMappingByIdMakeCodeAndModelName(@Param("id") Long id,@Param("makeCode") String makeCode,@Param("modelName") String modelCode);


}
