/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.booking.notification;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 *
 * @author nirbhay.p
 */
@Component
public class SendNotification {
   
    public String sendMail(String to, String subject, String body, String mailServiceURL) {
        String mailRes = "false";
        try {
            String encodeURL = URLEncoder.encode(body, "UTF-8");
            Map<String, String> map = new HashMap<>();
            map.put("to", to);
            map.put("subject", subject);
            map.put("body", encodeURL);

            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL,String.class, map);
            mailRes = response.getBody();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return mailRes;

    }
    
    
    public String sendMailWithCC(String to,String cc, String subject, String body, String mailServiceURLCC) {
        String mailRes = "false";
        try {
            String encodeURL = URLEncoder.encode(body, "UTF-8");
            Map<String, String> map = new HashMap<>();
            map.put("to", to);
            map.put("cc", cc);
            map.put("subject", subject);
            map.put("body", encodeURL);

            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURLCC,String.class, map);
            mailRes = response.getBody();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return mailRes;

    }
}
