package com.gigflex.prototype.microservices.documenttype.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "document_type")
public class DocumentType extends CommonAttributes implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "document_type_code", unique = true)
	private String documentTypeCode;

	@Column(name = "document_type_name", nullable = false)
	private String documentTypeName;

	@PrePersist
	private void assignUUID() {
		if (this.getDocumentTypeCode() == null
				|| this.getDocumentTypeCode().length() == 0) {
			this.setDocumentTypeCode((UUID.randomUUID().toString()));
		}
	}

	public DocumentType() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DocumentType(Long id, String documentTypeCode, String documentTypeName) {
		super();
		this.id = id;
		this.documentTypeCode = documentTypeCode;
		this.documentTypeName = documentTypeName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocumentTypeCode() {
		return documentTypeCode;
	}

	public void setDocumentTypeCode(String documentTypeCode) {
		this.documentTypeCode = documentTypeCode;
	}

	public String getDocumentTypeName() {
		return documentTypeName;
	}

	public void setDocumentTypeName(String documentTypeName) {
		this.documentTypeName = documentTypeName;
	}

	

}
