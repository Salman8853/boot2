/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.additionalfaretype.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.additionalfaretype.dtob.AdditionalFareType;
import com.gigflex.prototype.microservices.additionalfaretype.dtob.AdditionalFareTypeReq;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gigflex.prototype.microservices.additionalfaretype.repository.AdditionalFareTypeRepository;
import com.gigflex.prototype.microservices.additionalfaretype.service.AdditionalFareTypeService;

/**
 *
 * @author m.salman
 */
@Service
public class AdditionalFareTypeServiceImpl implements  AdditionalFareTypeService{
     @Autowired
     AdditionalFareTypeRepository additionalfaretyperepository;
     
    
    @Override
    public String  saveAdditionalfaretypedetail(  AdditionalFareTypeReq additionalfarereq)
    {  String res="";
        JSONObject jsonobj=new JSONObject();
      try{
       AdditionalFareType afatetype=new AdditionalFareType();
                     afatetype.setName(additionalfarereq.getName());
         AdditionalFareType aft=additionalfaretyperepository.save(afatetype);
         if(aft!=null && aft.getId()>0)
         {
            jsonobj.put("responsecode", 200);
	    jsonobj.put("message", "Record save succesfully");
	    jsonobj.put("timestamp", new Date());

         }else
         {
            jsonobj.put("responsecode", 404);
	    jsonobj.put("message", "Record Not Found");
	    jsonobj.put("timestamp", new Date());
         }
        res=jsonobj.toString();
       }catch(Exception ex)
      {
          GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
      }
       return res;
    }
     @Override
     public String getAlladditionalfaretypedetail()
     {  String res="";
         try{
          
        JSONObject jsonobj=new JSONObject();
         List<AdditionalFareType>cft=additionalfaretyperepository.findAll();
         if(cft!=null && cft.size()>0)
         {
         jsonobj.put("responsecode", 200);
	jsonobj.put("timestamp", new Date());
	jsonobj.put("message", "OK");
        ObjectMapper mapperObj = new ObjectMapper();
	String Detail = mapperObj.writeValueAsString(cft);
        jsonobj.put("data", new JSONArray(Detail) );
         }else
         {
        jsonobj.put("responsecode", 404);
	jsonobj.put("timestamp", new Date());
	jsonobj.put("message", "Data not found");
         }
        res =jsonobj.toString();
        }catch(Exception ex)
        {
           GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
        }
     return res;
     }
      @Override
      public String getadditionalfaretypByAfc(String additionalFareTypeCode)
      {
         String res="";
           try{
             JSONObject jsonobj=new JSONObject();
           AdditionalFareType cft=additionalfaretyperepository.getAdditionalFareTypeByafCode(additionalFareTypeCode);
             if(cft!=null && cft.getId()>0)
             {
               jsonobj.put("responsecode", 200);
	       jsonobj.put("timestamp", new Date());
	       jsonobj.put("message", "OK");
               ObjectMapper mapperObj = new ObjectMapper();
	       String Detail = mapperObj.writeValueAsString(cft);
               jsonobj.put("data", new JSONObject(Detail) );
             }else
             {
                jsonobj.put("responsecode", 404);
	        jsonobj.put("timestamp", new Date());
	        jsonobj.put("message", "Data not found");
             }
             res =jsonobj.toString();
           }catch(Exception ex)
           {
              GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
           }
           
       return res;
      }
      public String updateadditionalfaretypByAfc(String additionalFareTypeCode,AdditionalFareTypeReq req)
      {  String res="";
          try
          {
            JSONObject jsonobj=new JSONObject();   
         AdditionalFareType aft= additionalfaretyperepository.getAdditionalFareTypeByafCode(additionalFareTypeCode);
           if(aft!=null && aft.getId()>0)
           {
             aft.setName(req.getName());
             AdditionalFareType aftt=   additionalfaretyperepository.save(aft);
                   if(aftt!=null && aftt.getId()>0)
                   {
                     jsonobj.put("responsecode", 200);
	             jsonobj.put("timestamp", new Date());
	             jsonobj.put("message", "Record Updated Successfully"); 
                   }else
                   {
                     jsonobj.put("responsecode", 404);
	             jsonobj.put("timestamp", new Date());
	             jsonobj.put("message", " Record Not updated");
                   }
             
           }else
           {
                     jsonobj.put("responsecode", 404);
	             jsonobj.put("timestamp", new Date());
	             jsonobj.put("message", " Record Not  Found");
           }
          res =jsonobj.toString();  
          }catch(Exception ex)
          {
                 GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
          }
        return res;  
      }
      @Override
       public String softdeleteadditionalfaretypeByAfc(String additionalFareTypeCode)
       {
            String res="";
            try
            {
                JSONObject jsonobj = new JSONObject();
                AdditionalFareType cft=additionalfaretyperepository.getAdditionalFareTypeByafCode(additionalFareTypeCode);
                 if(cft!=null && cft.getId()>0)
                 {
                     cft.setIsDeleted(Boolean.TRUE);
                     AdditionalFareType cftt= additionalfaretyperepository.save(cft);
                  if(cftt!=null && cftt.getId()>0)
                   {
                    jsonobj.put("responsecode", 200);
		    jsonobj.put("timestamp", new Date());
		    jsonobj.put("message", "Record deleted successfully.");
                   }else
                   {
                  jsonobj.put("responsecode", 400);
	          jsonobj.put("timestamp", new Date());
		  jsonobj.put("message", "Failed");
                   }
                 }else
                 {
                        jsonobj.put("responsecode", 404);
			jsonobj.put("timestamp", new Date());
			jsonobj.put("message", "Record Not Found");
                 }
              res =jsonobj.toString();      
            }catch(Exception ex)
            {
              	GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
                        ex.printStackTrace();
			res = derr.toString();
            }
             return res;
       }
}
