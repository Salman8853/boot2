/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.setting.repository;

import com.gigflex.prototype.microservices.setting.dtob.Setting;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface SettingRepository extends JpaRepository<Setting, Long>{
    @Query("select sett.settingValue from Setting sett where  sett.settingName= :settingName")
    public String getValueByName(@Param("settingName") String settingName);
}
