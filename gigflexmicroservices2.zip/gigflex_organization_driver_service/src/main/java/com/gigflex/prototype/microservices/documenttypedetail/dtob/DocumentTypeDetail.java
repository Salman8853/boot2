package com.gigflex.prototype.microservices.documenttypedetail.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "documenttypedetail")
public class DocumentTypeDetail extends CommonAttributes implements Serializable{
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "doc_code", unique = true)
    private String documentCode;
    
//    @Column(name = "doc_type", nullable = false)
//    private String documentType;
    
    @Column(name = "document_type_code", nullable = false)
    private String documentTypeCode;
    
    @Column(name = "user_type_code")
    private String userTypeCode;
    
    @Column(name = "doc_name", nullable = false)
    private String documentName;
    
    @Column(name = "regex")
    private String regex;
    
    @PrePersist
    private void assignUUID() {
        if(this.getDocumentCode()==null || this.getDocumentCode().length()==0)
        {
            this.setDocumentCode((UUID.randomUUID().toString()));
        }
    }
    
    

    public String getDocumentName() {
		return documentName;
	}



	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

    
    public String getUserTypeCode() {
		return userTypeCode;
	}



	public void setUserTypeCode(String userTypeCode) {
		this.userTypeCode = userTypeCode;
	}



	public DocumentTypeDetail() {
		// TODO Auto-generated constructor stub
	}


	public DocumentTypeDetail(Long id, String documentCode, String documentTypeCode, String userTypeCode,
			String documentName, String regex) {
		super();
		this.id = id;
		this.documentCode = documentCode;
		this.documentTypeCode = documentTypeCode;
		this.userTypeCode = userTypeCode;
		this.documentName = documentName;
		this.regex = regex;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}

	public String getDocumentTypeCode() {
		return documentTypeCode;
	}



	public void setDocumentTypeCode(String documentTypeCode) {
		this.documentTypeCode = documentTypeCode;
	}



	public String getRegex() {
		return regex;
	}



	public void setRegex(String regex) {
		this.regex = regex;
	}
//    
    

}
