package com.gigflex.prototype.microservices.validation.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.validation.dtob.ValidationRequest;
import com.gigflex.prototype.microservices.validation.service.ValidationService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class ValidationController {

	@Autowired
	public ValidationService validationService;

	@GetMapping("/validation/{search}")
	public String search(@PathVariable("search") String search) {
		return validationService.search(search);
	}

	@GetMapping("/getAllValidation")
	public String getAllValidation() {
		return validationService.getAllValidation();
	}

	@GetMapping(path = "/getValidationByPage")
	public String getValidationByPage(@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String Validation = validationService.getAllValidationByPgae(page, limit);

		return Validation;

	}

	@GetMapping("/getValidationById/{id}")
	public String getValidationById(@PathVariable Long id) {
		return validationService.getValidationById(id);
	}

	@GetMapping("/getValidationByValidationCode/{validationCode}")
	public String getValidationByValidationCode(@PathVariable String validationCode) {
		return validationService.getValidationByValidationCode(validationCode);
	}

	@PostMapping("/saveValidation")
	public String saveValidation(@RequestBody ValidationRequest validationReq, HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return validationService.saveNewValidation(validationReq, ip);

	}

	@PutMapping("/updateValidation/{id}")
	public String updateValidation(@PathVariable Long id, @RequestBody ValidationRequest validationReq,
			HttpServletRequest request) {

		if (id == null) {
			return "Validation with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return validationService.updateValidationById(id, validationReq, ip);

		}

	}

	@DeleteMapping("/softDeleteValidationByValidationCode/{validationCode}")
	public String softDeleteValidationByValidationCode(@PathVariable String validationCode) {
		return validationService.softDeleteByValidationCode(validationCode);
	}

	@DeleteMapping("/softMultipleDeleteByValidationCode/{validationCodeList}")
	public String softMultipleDeleteByValidationCode(@PathVariable List<String> validationCodeList) {
		if (validationCodeList != null && validationCodeList.size() > 0) {
			return validationService.softMultipleDeleteByValidationCode(validationCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
			return derr.toString();
		}

	}

}
