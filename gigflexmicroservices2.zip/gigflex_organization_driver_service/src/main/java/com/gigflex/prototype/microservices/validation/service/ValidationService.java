package com.gigflex.prototype.microservices.validation.service;

import java.util.List;

import com.gigflex.prototype.microservices.validation.dtob.ValidationRequest;



public interface ValidationService {
	
	public String getAllValidation();
	public String getValidationById(Long id);
	public String getValidationByValidationCode(String validationCode);
	public String saveNewValidation(ValidationRequest validationReq, String ip);
	public String updateValidationById( Long id,ValidationRequest validationReq, String ip);
	public String softDeleteByValidationCode(String validationCode);
    public String softMultipleDeleteByValidationCode(List<String> validationCodeList);
    public String getAllValidationByPgae(int page, int limit);
    public String search(String search);

}
