/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.assignbooking.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author nirbhay.p
 */
@Entity
@Table(name = "assign_booking")
public class AssignBooking extends CommonAttributes implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "assign_booking_code", unique = true)
    private String assignBookingCode;
    
    @Column(name = "ride_code", nullable = false)
    private String rideCode;
    
    @Column(name = "driver_code")
    private String driverCode;
    
    @Column(name = "operator_code")
    private String operatorCode;
    
    @Column(name = "status")
    private String status;
    
    @Column(name = "comments")
    private String comments;
    
    @Column(name = "lat")
	private String lat;
    
	@Column(name = "lang")
	private String lang;
        
        @Column(name = "organization_code")
	private String organizationCode;
    
    @PrePersist
    private void assignUUID() {
    	if (this.getAssignBookingCode() == null || this.getAssignBookingCode().length() == 0) {
           this.setAssignBookingCode(UUID.randomUUID().toString());
    	}
    }

    public String getLat() {
		return lat;
	}





	public void setLat(String lat) {
		this.lat = lat;
	}





	public String getLang() {
		return lang;
	}





	public void setLang(String lang) {
		this.lang = lang;
	}





	public String getComments() {
		return comments;
	}



	public void setComments(String comments) {
		this.comments = comments;
	}



	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAssignBookingCode() {
        return assignBookingCode;
    }

    public void setAssignBookingCode(String assignBookingCode) {
        this.assignBookingCode = assignBookingCode;
    }

    public String getRideCode() {
        return rideCode;
    }

    public void setRideCode(String rideCode) {
        this.rideCode = rideCode;
    }

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }

    public String getOperatorCode() {
        return operatorCode;
    }

    public void setOperatorCode(String operatorCode) {
        this.operatorCode = operatorCode;
    }

   
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }
}
