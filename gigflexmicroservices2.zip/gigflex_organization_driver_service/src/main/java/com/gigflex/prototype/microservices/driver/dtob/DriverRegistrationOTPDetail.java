/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author Abhishek
 */
@Entity
@Table(name = "driverregistrationotpdetal")
public class DriverRegistrationOTPDetail extends CommonAttributes implements Serializable {
       @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
       
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "token_id", unique = true)
    private String tokenID;  
    
    @Column(name = "email_id")
    private String emailID;
    
    @Column(name = "registration_status")
    private Boolean registrationStatus;

    public DriverRegistrationOTPDetail() {
    }
    
    public DriverRegistrationOTPDetail(Long id, String tokenID, String emailID, Boolean registrationStatus) {
        this.id = id;
        this.tokenID = tokenID;
        this.emailID = emailID;
        this.registrationStatus = registrationStatus;
    }

    
     @PrePersist
    private void assignUUID() {
        if(this.getTokenID()==null || this.getTokenID().length()==0)
        {
            this.setTokenID(UUID.randomUUID().toString());
        }
    }
    
    
    
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTokenID() {
        return tokenID;
    }

    public void setTokenID(String tokenID) {
        this.tokenID = tokenID;
    }

    public String getEmailID() {
        return emailID;
    }

    public void setEmailID(String emailID) {
        this.emailID = emailID;
    }

    public Boolean getRegistrationStatus() {
        return registrationStatus;
    }

    public void setRegistrationStatus(Boolean registrationStatus) {
        this.registrationStatus = registrationStatus;
    }
    
    
    
}
