package com.gigflex.prototype.microservices.ridetype.repository;

import com.gigflex.prototype.microservices.globalridetype.dtob.GlobalRideType;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.ridetype.dtob.RideType;


public interface RideTypeRepository extends JpaRepository<RideType, Long>,JpaSpecificationExecutor<RideType> {
	
	@Query("SELECT m,org.organizationName FROM RideType m,Organization org WHERE m.isDeleted != TRUE AND m.organizationCode = org.organizationCode")
	public List<Object> getAllRideTypeWithName();
	
	@Query("SELECT m,org.organizationName FROM RideType m,Organization org WHERE m.isDeleted != TRUE AND m.organizationCode = org.organizationCode")
	public List<Object> getAllRideTypeWithName(Pageable pageableRequest);
	
	@Query("SELECT m,org.organizationName FROM RideType m,Organization org WHERE m.isDeleted != TRUE AND m.organizationCode = org.organizationCode AND m.organizationCode = :organizationCode")
	public List<Object> getAllRideTypeByOrganizationCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
	
	@Query("SELECT m,org.organizationName FROM RideType m,Organization org WHERE m.isDeleted != TRUE AND m.organizationCode = org.organizationCode AND m.organizationCode = :organizationCode")
	public List<Object> getAllRideTypeByOrganizationCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT m FROM RideType m WHERE m.isDeleted != TRUE")
	public List<RideType> getAllRideType();
	
	@Query("SELECT m FROM RideType m,Organization o WHERE m.isDeleted != TRUE AND m.organizationCode = o.organizationCode AND m.organizationCode = :organizationCode")
	public List<RideType> getAllRideTypeForFare(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT m FROM RideType m WHERE m.isDeleted != TRUE")
	public List<RideType> getAllRideType(Pageable pageableRequest);
	
	@Query("SELECT m FROM RideType m WHERE m.isDeleted != TRUE AND m.vehicleCode = :vehicleCode")
	public RideType getRideTypeByVehicleCode(@Param("vehicleCode") String vehicleCode);
        
        @Query("SELECT m FROM GlobalRideType m WHERE m.isDeleted != TRUE AND m.globalRideCode = :vehicleCode")
	public GlobalRideType getRideTypeByVehicleCodeForGlobal(@Param("vehicleCode") String vehicleCode);
        
        @Query("SELECT g FROM GlobalRideType g, RideType m WHERE m.isDeleted != TRUE AND g.isDeleted != TRUE AND g.globalRideCode=m.globalRidetypeCode AND m.vehicleCode = :vehicleCode")
	public GlobalRideType getGlobalRideTypeByVehicleCode(@Param("vehicleCode") String vehicleCode);
	
//	@Query("SELECT m,org.organizationName FROM RideType m,Organization org WHERE m.isDeleted != TRUE AND m.organizationCode = org.organizationCode AND m.vehicleCode = :vehicleCode")
//	public List<Object> getRideTypeByVehicleCodeWithName(@Param("vehicleCode") String vehicleCode);
	
	@Query("SELECT m,org.organizationName FROM RideType m,Organization org WHERE m.isDeleted != TRUE AND m.organizationCode = org.organizationCode AND m.vehicleCode = :vehicleCode")
	public Object getRideTypeByVehicleCodeWithName(@Param("vehicleCode") String vehicleCode);
	
	
	@Query("SELECT m FROM RideType m WHERE m.isDeleted != TRUE AND m.id = :id")
	public RideType getRideTypeById(@Param("id") Long id);
        
	
	@Query("SELECT m FROM RideType m WHERE m.isDeleted != TRUE AND m.vehicleName = :vehicleName AND m.organizationCode = :organizationCode")
	public RideType getRideTypeByVehicleNameAndOrganizationCode(@Param("vehicleName") String vehicleName,@Param("organizationCode") String organizationCode);
	
	@Query("SELECT m FROM RideType m WHERE m.isDeleted != TRUE AND m.id != :id AND m.vehicleName = :vehicleName AND m.organizationCode = :organizationCode")
	public RideType getRideTypeByIdVehicleNameAndOrganizationCode(@Param("id") Long id,@Param("vehicleName") String vehicleName,@Param("organizationCode") String organizationCode);


}
