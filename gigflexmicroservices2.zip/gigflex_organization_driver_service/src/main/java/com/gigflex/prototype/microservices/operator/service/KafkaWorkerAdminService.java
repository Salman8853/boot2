package com.gigflex.prototype.microservices.operator.service;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.driver.dtob.Users;
import com.gigflex.prototype.microservices.operator.repository.UserRepository;




@Service
public class KafkaWorkerAdminService {
	
	
@Autowired
    UserRepository userRepository;
	
    private static final Logger LOG = LoggerFactory.getLogger(KafkaWorkerAdminService.class);

	
    
    @KafkaListener(topics = "NewAdmin")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			Users user = objectMapper.readValue(message, Users.class);
			Users userres = new Users();
            userres.setEmail(user.getEmail());
            userres.setEmailLinkExpiredAt(user.getEmailLinkExpiredAt());
            userres.setIpAddress(user.getIpAddress());
            userres.setIsActive(user.getIsActive());
            userres.setIsAdmin(user.getIsAdmin());
            userres.setIsOwner(user.getIsOwner());
            userres.setIsVerified(user.getIsVerified());
            userres.setName(user.getName());
            userres.setUserCode(user.getUserCode());
            userres.setUserName(user.getUserName());
            userres.setIsDeleted(user.getIsDeleted());
            userres.setPassword(user.getPassword());
            userRepository.save(userres);
			
		} catch (JsonParseException e) {
			LOG.error("In KafkaWorkerAdminService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaWorkerAdminService >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaWorkerAdminService >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaWorkerAdminService >>>>", e);
		}
    }
    
   
	
	
}