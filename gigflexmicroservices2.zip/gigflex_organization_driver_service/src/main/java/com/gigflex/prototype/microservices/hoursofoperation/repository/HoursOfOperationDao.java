/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.hoursofoperation.repository;

import com.gigflex.prototype.microservices.hoursofoperation.dtob.HoursOfOperation;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface HoursOfOperationDao extends JpaRepository<HoursOfOperation,Long>,JpaSpecificationExecutor<HoursOfOperation>{

    @Query("SELECT ho,vd.vehicleType,grt.vehicleName FROM HoursOfOperation ho, VehicleDetail vd,GlobalRideType grt WHERE ho.isDeleted != TRUE AND vd.isDeleted != TRUE AND grt.isDeleted != TRUE AND ho.vehicleCode = vd.vehicleCode AND ho.driverCode = :driverCode AND vd.vehicleType = grt.globalRideCode")
    public List<Object> getHoursOfOperationByDriverCode(@Param("driverCode") String driverCode);

    @Query("SELECT ho,vd.vehicleType,grt.vehicleName FROM HoursOfOperation ho, VehicleDetail vd,GlobalRideType grt WHERE ho.isDeleted != TRUE AND vd.isDeleted != TRUE AND grt.isDeleted != TRUE AND ho.vehicleCode = vd.vehicleCode AND ho.hoursOfOperationCode = :hoursOfOperationCode AND vd.vehicleType = grt.globalRideCode")
    public Object getHoursOfOperationByHoursOfOperationCode(@Param("hoursOfOperationCode") String hoursOfOperationCode);

    @Query("SELECT ho,vd.vehicleType,grt.vehicleName FROM HoursOfOperation ho, VehicleDetail vd,GlobalRideType grt WHERE ho.isDeleted != TRUE AND vd.isDeleted != TRUE AND ho.vehicleCode = vd.vehicleCode AND ho.driverCode = :driverCode AND ho.dayCode = :dayCode AND vd.vehicleType = grt.globalRideCode")
    public Object getHoursOfOperationByDriverCodeAndDayCode(@Param("driverCode") String driverCode,@Param("dayCode") Integer dayCode);

    @Query("SELECT ho FROM HoursOfOperation ho WHERE ho.isDeleted != TRUE AND ho.hoursOfOperationCode = :hoursOfOperationCode")
    public HoursOfOperation getHoursByHoursOfOperationCode(@Param("hoursOfOperationCode") String hoursOfOperationCode);

    @Query("SELECT ho FROM HoursOfOperation ho WHERE ho.isDeleted != TRUE AND ho.driverCode = :driverCode AND ho.dayCode = :dayCode")
    public HoursOfOperation getHoursByDriverCodeAndDayCode(@Param("driverCode") String driverCode,@Param("dayCode") Integer dayCode);

    @Query("SELECT ho FROM HoursOfOperation ho WHERE ho.isDeleted != TRUE AND ho.driverCode = :driverCode AND ho.dayCode = :dayCode AND ho.hoursOfOperationCode != :hoursOfOperationCode")
    public HoursOfOperation getHoursByDriverCodeDayCodeAndNotForHoursOfOperationCode(@Param("driverCode") String driverCode,@Param("dayCode") Integer dayCode,@Param("hoursOfOperationCode") String hoursOfOperationCode);

    @Query("SELECT ho,vd.vehicleType,grt.vehicleName FROM HoursOfOperation ho, VehicleDetail vd,GlobalRideType grt WHERE ho.isDeleted != TRUE AND vd.isDeleted != TRUE AND grt.isDeleted != TRUE AND ho.vehicleCode = vd.vehicleCode AND vd.vehicleType = grt.globalRideCode")
    public List<Object> getAllHoursOfOperation();
    
}
