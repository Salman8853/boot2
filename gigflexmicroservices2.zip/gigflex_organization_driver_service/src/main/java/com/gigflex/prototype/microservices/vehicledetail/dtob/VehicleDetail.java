package com.gigflex.prototype.microservices.vehicledetail.dtob;

import java.io.Serializable;
import java.time.Year;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "vehicledetail")
public class VehicleDetail extends CommonAttributes implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "vehicle_code", unique = true)
	private String vehicleCode;

//	@Column(name = "vehicle_name", nullable = false)
//	private String vehicleName;

//	@Column(name = "abbrev_name", nullable = false)
//	private String abbrevationName;

	@Column(name = "vehicle_type", nullable = false)
	private String vehicleType;

	@Column(name = "vehicle_year")
	private Long vehicleYear;

	@Column(name = "initail_mileage")
	private Double initialMileage;

	@Column(name = "vehicle_image", nullable = false)
	private String vehicleImage;

	@Column(name = "registration_expiry_date", columnDefinition = "DATETIME")
	private Date registrationExpiryDate;

	@Column(name = "inservice")
	private Boolean inService;

//	@Column(name = "vehicle_engine_type", nullable = false)
//	private String vehicleEngineType;

//	@Column(name = "vehicle_horse_power")
//	private String vehicleHorsePower;

	@Column(name = "color")
	private String color;

	@Column(name = "vin")
	private String vin;

	@Column(name = "licenseplate")
	private String licensePlate;
        
        @Column(name = "licenseplate_doc")
	private String licensePlateDoc;

	@Column(name = "license_expiry_date", columnDefinition = "DATETIME")
	private Date licenseExpiryDate;
        
        
        
        @Column(name = "insurance")
	private String insurance;
        
        @Column(name = "insurance_doc")
	private String insuranceDoc;

	@Column(name = "insurance_expiry_date", columnDefinition = "DATETIME")
	private Date insuranceExpiryDate;
        
        @Column(name = "vehicle_logbook_doc")
	private String vehicleLogbookDoc;                   
        
        @Column(name = "vehicle_mot_doc")
	private String vehicleMOTDoc;

	@Column(name = "vehicle_mot_expiry_date", columnDefinition = "DATETIME")
	private Date vehicleMOTExpiryDate;
        
        
        @Column(name = "hire_agreement_doc")
	private String hireAgreementDoc;

	@Column(name = "hire_agreement_expiry_date", columnDefinition = "DATETIME")
	private Date hireAgreementDocExpiryDate;

//	@Column(name = "vehicle_group", nullable = false)
//	private String vehicleGroup;

	@Column(name = "passenger_quantity")
	private Long passengerQuantity;

	@Column(name = "baggage_quantity")
	private Long baggageQuantity;

//	@Column(name = "doors_quantity")
//	private Long doorsQuantity;

	@Column(name = "aircondition")
	private Boolean airCondition;

	@Column(name = "automatic_transmission")
	private Boolean automaticTransmission;

	@Column(name = "fueltype_code", nullable = false)
	private String fuelTypeCode;

	@Column(name = "satelite_navigation")
	private Boolean sateliteNavigation;

	@Column(name = "organization_code")
	private String organizationCode;

	@Column(name = "model_code", nullable = false)
	private String modelCode;
        
        
        @Column(name = "registration_number", nullable = false)
	private String registrationNumber;
        
        @Column(name = "make_code", nullable = false)
	private String makeCode;
        
        
        
	
//	@Column(name = "driver_code", nullable = false)
//	private String driverCode; 

	@PrePersist
	private void assignUUID() {
		if (this.getVehicleCode() == null || this.getVehicleCode().length() == 0) {
			this.setVehicleCode((UUID.randomUUID().toString()));
		}
	}

	public VehicleDetail() {
		// TODO Auto-generated constructor stub
	}

//	public String getDriverCode() {
//		return driverCode;
//	}
//
//	public void setDriverCode(String driverCode) {
//		this.driverCode = driverCode;
//	}

	public String getModelCode() {
		return modelCode;
	}

	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVehicleCode() {
		return vehicleCode;
	}

	public void setVehicleCode(String vehicleCode) {
		this.vehicleCode = vehicleCode;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public Long getVehicleYear() {
		return vehicleYear;
	}

	public void setVehicleYear(Long vehicleYear) {
		this.vehicleYear = vehicleYear;
	}

	public Double getInitialMileage() {
		return initialMileage;
	}

	public void setInitialMileage(Double initialMileage) {
		this.initialMileage = initialMileage;
	}

	public String getVehicleImage() {
		return vehicleImage;
	}

	public void setVehicleImage(String vehicleImage) {
		this.vehicleImage = vehicleImage;
	}

	public Date getRegistrationExpiryDate() {
		return registrationExpiryDate;
	}

	public void setRegistrationExpiryDate(Date registrationExpiryDate) {
		this.registrationExpiryDate = registrationExpiryDate;
	}

	public Boolean getInService() {
		return inService;
	}

	public void setInService(Boolean inService) {
		this.inService = inService;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public String getLicensePlate() {
		return licensePlate;
	}

	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}

	public Date getLicenseExpiryDate() {
		return licenseExpiryDate;
	}

	public void setLicenseExpiryDate(Date licenseExpiryDate) {
		this.licenseExpiryDate = licenseExpiryDate;
	}

	public Long getPassengerQuantity() {
		return passengerQuantity;
	}

	public void setPassengerQuantity(Long passengerQuantity) {
		this.passengerQuantity = passengerQuantity;
	}

	public Long getBaggageQuantity() {
		return baggageQuantity;
	}

	public void setBaggageQuantity(Long baggageQuantity) {
		this.baggageQuantity = baggageQuantity;
	}

	public Boolean getAirCondition() {
		return airCondition;
	}

	public void setAirCondition(Boolean airCondition) {
		this.airCondition = airCondition;
	}

	public Boolean getAutomaticTransmission() {
		return automaticTransmission;
	}

	public void setAutomaticTransmission(Boolean automaticTransmission) {
		this.automaticTransmission = automaticTransmission;
	}

	public String getFuelTypeCode() {
		return fuelTypeCode;
	}

	public void setFuelTypeCode(String fuelTypeCode) {
		this.fuelTypeCode = fuelTypeCode;
	}

	public Boolean getSateliteNavigation() {
		return sateliteNavigation;
	}

	public void setSateliteNavigation(Boolean sateliteNavigation) {
		this.sateliteNavigation = sateliteNavigation;
	}

    public String getLicensePlateDoc() {
        return licensePlateDoc;
    }

    public void setLicensePlateDoc(String licensePlateDoc) {
        this.licensePlateDoc = licensePlateDoc;
    }

    public String getInsurance() {
        return insurance;
    }

    public void setInsurance(String insurance) {
        this.insurance = insurance;
    }

    public String getInsuranceDoc() {
        return insuranceDoc;
    }

    public void setInsuranceDoc(String insuranceDoc) {
        this.insuranceDoc = insuranceDoc;
    }

    public Date getInsuranceExpiryDate() {
        return insuranceExpiryDate;
    }

    public void setInsuranceExpiryDate(Date insuranceExpiryDate) {
        this.insuranceExpiryDate = insuranceExpiryDate;
    }

    public String getVehicleLogbookDoc() {
        return vehicleLogbookDoc;
    }

    public void setVehicleLogbookDoc(String vehicleLogbookDoc) {
        this.vehicleLogbookDoc = vehicleLogbookDoc;
    }

    public String getVehicleMOTDoc() {
        return vehicleMOTDoc;
    }

    public void setVehicleMOTDoc(String vehicleMOTDoc) {
        this.vehicleMOTDoc = vehicleMOTDoc;
    }

    public Date getVehicleMOTExpiryDate() {
        return vehicleMOTExpiryDate;
    }

    public void setVehicleMOTExpiryDate(Date vehicleMOTExpiryDate) {
        this.vehicleMOTExpiryDate = vehicleMOTExpiryDate;
    }

    public String getHireAgreementDoc() {
        return hireAgreementDoc;
    }

    public void setHireAgreementDoc(String hireAgreementDoc) {
        this.hireAgreementDoc = hireAgreementDoc;
    }

    public Date getHireAgreementDocExpiryDate() {
        return hireAgreementDocExpiryDate;
    }

    public void setHireAgreementDocExpiryDate(Date hireAgreementDocExpiryDate) {
        this.hireAgreementDocExpiryDate = hireAgreementDocExpiryDate;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getMakeCode() {
        return makeCode;
    }

    public void setMakeCode(String makeCode) {
        this.makeCode = makeCode;
    }

}
