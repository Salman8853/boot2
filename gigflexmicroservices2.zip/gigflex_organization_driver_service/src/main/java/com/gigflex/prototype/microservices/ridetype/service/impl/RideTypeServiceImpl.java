package com.gigflex.prototype.microservices.ridetype.service.impl;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.globalridetype.dtob.GlobalRideType;
import com.gigflex.prototype.microservices.globalridetype.repository.GlobalRideTypeRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.notification.service.NotificationService;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;

import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.ridetype.dtob.RideType;
import com.gigflex.prototype.microservices.ridetype.dtob.RideTypeRateResponse;
import com.gigflex.prototype.microservices.ridetype.dtob.RideTypeRequest;
import com.gigflex.prototype.microservices.ridetype.dtob.RideTypeResponse;
import com.gigflex.prototype.microservices.ridetype.repository.RideTypeRepository;
import com.gigflex.prototype.microservices.ridetype.search.RideTypeSpecificationsBuilder;
import com.gigflex.prototype.microservices.ridetype.service.RideTypeService;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.utility.PushNotification;
import org.springframework.beans.factory.annotation.Value;

@Service
public class RideTypeServiceImpl implements RideTypeService {

	@Autowired
	private RideTypeRepository rideTypeDao;
	
	@Autowired
	private OrganizationRepository orgDao;
	
        @Autowired
        GlobalRideTypeRepository globalRideTypeRepository;

	@Autowired
        private NotificationService notificationService;

	@Autowired
	DriverRepository driverDao;
	
	@Autowired
	OperatorRepository operatorDao;
        
          @Autowired
        GlobalSettingRepository globalSettingRepository;
    
        @Autowired
        LocalSettingRepository localSettingRepository;
        
        @Autowired
	UserTypeRepository userTypeDao;
	
	  private String shortMessage;

        @Value("${notification.deviceid}")
        private String deviceId;
        
        @Value("${notification.fcm.url}")
        private String FMCurl;  
        
        @Value("${notification.fcm.authkey}")
        private String authKey;

	@Override
	public String getAllRideType() {
    	String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
		
			List<Object> objlst = rideTypeDao.getAllRideTypeWithName();
			List<RideTypeResponse> maplst = new ArrayList<RideTypeResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {
						
						RideTypeResponse rtr = new RideTypeResponse();

						RideType data = (RideType) arr[0];
						 String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
						rtr.setId(data.getId());
						rtr.setVehicleCode(data.getVehicleCode());
						rtr.setVehicleName(data.getVehicleName());
						rtr.setBaseRate(data.getBaseRate());
						rtr.setRatePerMile(data.getRatePerMile());
                                                rtr.setCurrencySymbol(currencySymbol);
						rtr.setOrganizationCode(data.getOrganizationCode());
	
						rtr.setOrganizationName((String) arr[1]);
                                                if(data.getGlobalRidetypeCode()!=null && data.getGlobalRidetypeCode().length()>0)
                                                {
                                                rtr.setGlobalRidetypeCode(data.getGlobalRidetypeCode());
                                                GlobalRideType grt=globalRideTypeRepository.getGlobalRideTypeByGlobalRideCode(data.getGlobalRidetypeCode());
                                                if(grt!=null && grt.getId()>0 && grt.getVehicleName()!=null)
                                                {
                                                   rtr.setGlobalRidetypeName(grt.getVehicleName());
                                                }
                                                }
						
						maplst.add(rtr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getRideTypeById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			RideType vehTypelst = rideTypeDao.getRideTypeById(id);
			if (vehTypelst != null && vehTypelst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(vehTypelst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getRideTypeByVehicleCode(String vehicleCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			RideType vehTypelst = rideTypeDao
					.getRideTypeByVehicleCode(vehicleCode);

			if (vehTypelst != null && vehTypelst.getId() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(vehTypelst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String saveNewRideType(RideTypeRequest RideTypeReq,
			String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (RideTypeReq != null) {

				if ((RideTypeReq.getVehicleName() != null && RideTypeReq
						.getVehicleName().trim().length() > 0)
						&& (RideTypeReq.getBaseRate() != null && RideTypeReq.getBaseRate() > 0)
						&& (RideTypeReq.getRatePerMile() != null && RideTypeReq.getRatePerMile() > 0) 
                                        && (RideTypeReq.getOrganizationCode() != null && RideTypeReq.getOrganizationCode().trim().length() > 0)
                                        && (RideTypeReq.getGlobalRidetypeCode() != null && RideTypeReq.getGlobalRidetypeCode().trim().length() > 0) ) {

					 RideType rideType = rideTypeDao
					 .getRideTypeByVehicleNameAndOrganizationCode(
							 RideTypeReq.getVehicleName(),
							 RideTypeReq.getOrganizationCode());
					 if (rideType != null && rideType.getId() > 0) {
					 jsonobj.put("responsecode", 409);
					 jsonobj.put("timestamp", new Date());
					 jsonobj.put("message", "Record already exist.");
					 } else {
					
					Organization org = orgDao.findByOrganizationCode(RideTypeReq.getOrganizationCode());
					if (org != null && org.getId() > 0) {

					RideType vehTypelst = new RideType();

					vehTypelst.setOrganizationCode(RideTypeReq.getOrganizationCode());
					vehTypelst.setVehicleName(RideTypeReq.getVehicleName());
					vehTypelst.setBaseRate(RideTypeReq.getBaseRate());
					vehTypelst.setRatePerMile(RideTypeReq.getRatePerMile());
					vehTypelst.setIsGlobal(false);
                                        vehTypelst.setGlobalRidetypeCode(RideTypeReq.getGlobalRidetypeCode());
					vehTypelst.setIpAddress(ip);

					RideType vehTypeRes = rideTypeDao.save(vehTypelst);

					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());

					if (vehTypeRes != null && vehTypeRes.getId() > 0) {

						jsonobj.put("message",
								"Ride Type has been added successfully.");
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj
								.writeValueAsString(vehTypeRes);
						jsonobj.put("data", new JSONObject(Detail));
						

						 try {
								 
								List<Driver> driverLst = driverDao.getDriverByOrganizationCode(RideTypeReq.getOrganizationCode());
								List<Operator> operator = operatorDao.getOperatorByOrganizationCode(RideTypeReq.getOrganizationCode());
								if(driverLst != null && driverLst.size() > 0 ){
									for(Driver dr : driverLst){
									
								Notification notification = new Notification();

								String bodyContent = "Dear Driver"
										+ ",Ride Type has been added by organization.";
									
								shortMessage = "Ride Type has been added by organization.";

								notification.setUserCode(dr.getDriverCode());
								notification.setIpAddress(ip);
								notification.setMessage(bodyContent);
								notification.setShortMessage(shortMessage);
								notification.setIsRead(Boolean.FALSE);

								notificationService.saveNotification(notification);
                                                                
                                                                //for push notification
                                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
								}
									
								}
								if(operator != null && operator.size() > 0){
									for(Operator or : operator){
										
  									Notification notification = new Notification();

  									String bodyContent = "Dear Operator"
  											+ ",Ride Type has been added by organization.";
  											
  									shortMessage = "Ride Type has been added by organization.";

  									notification.setUserCode(or.getOperatorCode());
  									notification.setIpAddress(ip);
  									notification.setMessage(bodyContent);
  									notification.setShortMessage(shortMessage);
  									notification.setIsRead(Boolean.FALSE);

  									notificationService.saveNotification(notification);
                                                                        //for push notification
                                                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
  									}
								}
								
							}

							catch (Exception e) {
								e.printStackTrace();
							}

						
					} else {
						jsonobj.put("message", "Failed");
					}
					 
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Organization Code not found.");
					}
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateRideTypeById(Long id,
			RideTypeRequest RideTypeReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && RideTypeReq != null) {

				if ((RideTypeReq.getVehicleName() != null && RideTypeReq
						.getVehicleName().trim().length() > 0)
						&& (RideTypeReq.getBaseRate() != null && RideTypeReq
								.getBaseRate() > 0)
						&& (RideTypeReq.getRatePerMile() != null && RideTypeReq
								.getRatePerMile() > 0) && (RideTypeReq.getOrganizationCode() != null && RideTypeReq
										.getOrganizationCode().trim().length() > 0)
                                        && (RideTypeReq.getGlobalRidetypeCode() != null && RideTypeReq.getGlobalRidetypeCode().trim().length() > 0)) {

					RideType vehTypelst = rideTypeDao
							.getRideTypeById(id);

					if (vehTypelst != null && vehTypelst.getId() > 0) {

						RideType rideType = rideTypeDao
						 .getRideTypeByIdVehicleNameAndOrganizationCode(
						 id, RideTypeReq.getVehicleName(),
						 RideTypeReq.getOrganizationCode());
						 if (rideType != null && rideType.getId() > 0) {
						 jsonobj.put("responsecode", 409);
						 jsonobj.put("timestamp", new Date());
						 jsonobj.put("message", "Record already exist.");
						 } else {
						Organization org = orgDao.findByOrganizationCode(RideTypeReq.getOrganizationCode());
						if (org != null && org.getId() > 0) {
							
						
						RideType vehType = vehTypelst;
						vehType.setOrganizationCode(RideTypeReq.getOrganizationCode());
						vehType.setVehicleName(RideTypeReq.getVehicleName());
						vehType.setBaseRate(RideTypeReq.getBaseRate());
						vehType.setRatePerMile(RideTypeReq.getRatePerMile());
						vehType.setIsGlobal(false);
                                                vehTypelst.setGlobalRidetypeCode(RideTypeReq.getGlobalRidetypeCode());

						vehType.setIpAddress(ip);

						RideType vehTypeRes = rideTypeDao.save(vehType);

						if (vehTypeRes != null && vehTypeRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"Ride Type updation has been done");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(vehTypeRes);
							jsonobj.put("data", new JSONObject(Detail));
							
							 try {
								 
									List<Driver> driverLst = driverDao.getDriverByOrganizationCode(RideTypeReq.getOrganizationCode());
									List<Operator> operator = operatorDao.getOperatorByOrganizationCode(RideTypeReq.getOrganizationCode());
									if(driverLst != null && driverLst.size() > 0 ){
										for(Driver dr : driverLst){
										
									Notification notification = new Notification();

									String bodyContent = "Dear Driver"
											+ ",Ride Type has been updated by organization.";
										
									shortMessage = "Ride Type has been updated by organization.";

									notification.setUserCode(dr.getDriverCode());
									notification.setIpAddress(ip);
									notification.setMessage(bodyContent);
									notification.setShortMessage(shortMessage);
									notification.setIsRead(Boolean.FALSE);

									notificationService.saveNotification(notification);
                                                                        //for push notification
                                                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
									}
										
									}
									if(operator != null && operator.size() > 0){
										for(Operator or : operator){
											
	  									Notification notification = new Notification();

	  									String bodyContent = "Dear Operator"
	  											+ ",Ride Type has been updated by organization.";
	  											
	  									shortMessage = "Ride Type has been updated by organization.";

	  									notification.setUserCode(or.getOperatorCode());
	  									notification.setIpAddress(ip);
	  									notification.setMessage(bodyContent);
	  									notification.setShortMessage(shortMessage);
	  									notification.setIsRead(Boolean.FALSE);

	  									notificationService.saveNotification(notification);
                                                                                //for push notification
                                                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
	  									}
									}
									
								}

								catch (Exception e) {
									e.printStackTrace();
								}
							
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Ride Type updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
						
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Organization Code not found.");
						}
					}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Ride Type ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByVehicleCode(String vehicleCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			RideType vehTypelst = rideTypeDao
					.getRideTypeByVehicleCode(vehicleCode);

			if (vehTypelst != null && vehTypelst.getId() > 0) {
				vehTypelst.setIsDeleted(true);
				RideType vehTypeRes = rideTypeDao.save(vehTypelst);

				if (vehTypeRes != null && vehTypeRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Ride Type deleted successfully.");
					
					 try {
						 
						 
							List<Driver> driverLst = driverDao.getDriverByOrganizationCode(vehTypeRes.getOrganizationCode());
							List<Operator> operator = operatorDao.getOperatorByOrganizationCode(vehTypeRes.getOrganizationCode());
							if(driverLst != null && driverLst.size() > 0 ){
								for(Driver dr : driverLst){
								
							Notification notification = new Notification();

							String bodyContent = "Dear Driver"
									+ ",Ride Type has been deleted.";
								
							shortMessage = "Ride Type has been deleted.";

							notification.setUserCode(dr.getDriverCode());
							
							notification.setMessage(bodyContent);
							notification.setShortMessage(shortMessage);
							notification.setIsRead(Boolean.FALSE);

							notificationService.saveNotification(notification);
                                                        //for push notification
                                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
							}
								
							}
							if(operator != null && operator.size() > 0){
								for(Operator or : operator){
									
								Notification notification = new Notification();

								String bodyContent = "Dear Operator"
										+ ",Ride Type has been deleted.";
										
								shortMessage = "Ride Type has been deleted.";

								notification.setUserCode(or.getOperatorCode());
								
								notification.setMessage(bodyContent);
								notification.setShortMessage(shortMessage);
								notification.setIsRead(Boolean.FALSE);

								notificationService.saveNotification(notification);
                                                                //for push notification
                                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
								}
							}
							
						}

						catch (Exception e) {
							e.printStackTrace();
						}
					
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByVehicleCode(List<String> vehicleCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String vehicleCode : vehicleCodeList) {
				if (vehicleCode != null && vehicleCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					vehicleCode = vehicleCode.trim();

					RideType vehTypelst = rideTypeDao
							.getRideTypeByVehicleCode(vehicleCode);

					if (vehTypelst != null && vehTypelst.getId() > 0) {
						vehTypelst.setIsDeleted(true);
						RideType vehTypeRes = rideTypeDao
								.save(vehTypelst);

						if (vehTypeRes != null && vehTypeRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message",
									"Ride Type deleted successfully.");
							
							try {
								 
								 
								List<Driver> driverLst = driverDao.getDriverByOrganizationCode(vehTypeRes.getOrganizationCode());
								List<Operator> operator = operatorDao.getOperatorByOrganizationCode(vehTypeRes.getOrganizationCode());
								if(driverLst != null && driverLst.size() > 0 ){
									for(Driver dr : driverLst){
									
								Notification notification = new Notification();

								String bodyContent = "Dear Driver"
										+ ",Ride Type has been deleted.";
									
								shortMessage = "Ride Type has been deleted.";

								notification.setUserCode(dr.getDriverCode());
								
								notification.setMessage(bodyContent);
								notification.setShortMessage(shortMessage);
								notification.setIsRead(Boolean.FALSE);

								notificationService.saveNotification(notification);
                                                                //for push notification
                                                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
								}
									
								}
								if(operator != null && operator.size() > 0){
									for(Operator or : operator){
										
									Notification notification = new Notification();

									String bodyContent = "Dear Operator"
											+ ",Ride Type has been deleted.";
											
									shortMessage = "Ride Type has been deleted.";

									notification.setUserCode(or.getOperatorCode());
									
									notification.setMessage(bodyContent);
									notification.setShortMessage(shortMessage);
									notification.setIsRead(Boolean.FALSE);

									notificationService.saveNotification(notification);
                                                                        //for push notification
                                                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);
									}
								}
								
							}

							catch (Exception e) {
								e.printStackTrace();
							}
							
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", vehicleCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllRideTypeByPgae(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			Pageable pageableRequest = PageRequest.of(page, limit);
			if (limit > 0) {

			List<Object> objlstCheck = rideTypeDao.getAllRideTypeWithName();
			Integer count = objlstCheck.size();

			List<Object> objlst = rideTypeDao.getAllRideTypeWithName(pageableRequest);
			List<RideTypeResponse> maplst = new ArrayList<RideTypeResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {
						
						RideTypeResponse rtr = new RideTypeResponse();

						RideType data = (RideType) arr[0];
						
                                                
                                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                
                                                
						rtr.setId(data.getId());
						rtr.setVehicleCode(data.getVehicleCode());
						rtr.setVehicleName(data.getVehicleName());
						rtr.setBaseRate(data.getBaseRate());
						rtr.setRatePerMile(data.getRatePerMile());
                                                rtr.setCurrencySymbol(currencySymbol);
						rtr.setOrganizationCode(data.getOrganizationCode());
	
						rtr.setOrganizationName((String) arr[1]);
						rtr.setOrganizationName((String) arr[1]);
                                                if(data.getGlobalRidetypeCode()!=null && data.getGlobalRidetypeCode().length()>0)
                                                {
                                                rtr.setGlobalRidetypeCode(data.getGlobalRidetypeCode());
                                                GlobalRideType grt=globalRideTypeRepository.getGlobalRideTypeByGlobalRideCode(data.getGlobalRidetypeCode());
                                                if(grt!=null && grt.getId()>0 && grt.getVehicleName()!=null)
                                                {
                                                   rtr.setGlobalRidetypeName(grt.getVehicleName());
                                                }
                                                }
						maplst.add(rtr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				RideTypeSpecificationsBuilder builder = new RideTypeSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<RideType> spec = builder.build();
				if (spec != null) {
					List<RideType> vehTypeLst = rideTypeDao.findAll(spec);
					if (vehTypeLst != null && vehTypeLst.size() > 0) {
						for (RideType veh : vehTypeLst) {
							if (veh.getIsDeleted() != null
									&& veh.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(veh);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("RideType", new JSONObject(
										Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;

	}

	@Override
	public String getFarePricing(String vehicleCode, Double miles) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (vehicleCode != null && vehicleCode.trim().length() > 0
					&& miles != null && miles > 0) {
				RideType vehiclType = rideTypeDao
						.getRideTypeByVehicleCode(vehicleCode);

				if (vehiclType != null && vehiclType.getId() > 0) {

					Double baseRt = vehiclType.getBaseRate();
					Double perMile = vehiclType.getRatePerMile();
					Double rate = 0.0;
					if (baseRt > 0) {
						if (perMile > 0) {

							JSONObject jobj = new JSONObject();

							rate = (miles * perMile) + baseRt;
							rate = Double.parseDouble(new DecimalFormat("##.##").format(rate));

							jobj.put("Rate", rate);

							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "success");
							jsonobj.put("Data", jobj);

						} else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Per mile Rate Not Found.");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Base Rate Not Found.");

					}

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found.");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getFarePricingForAllRideType(Double miles,String organizationCode) {
		String res = "";
		try {

			JSONObject jsonobj = new JSONObject();

			if (miles != null && miles > 0) {

				List<RideTypeRateResponse> vhlst = new ArrayList<RideTypeRateResponse>();

				List<RideType> vtlst = rideTypeDao.getAllRideTypeForFare(organizationCode);

				for (RideType vh : vtlst) {

					RideTypeRateResponse vtr = new RideTypeRateResponse();

					Double baseRt = vh.getBaseRate();
					Double perMile = vh.getRatePerMile();
					Double rate = 0.0;

					rate = (miles * perMile) + baseRt;
					rate = Double.parseDouble(new DecimalFormat("##.##").format(rate));

					vtr.setVehicleCode(vh.getVehicleCode());
					vtr.setVehicleName(vh.getVehicleName());
					vtr.setRate(rate);

					vhlst.add(vtr);

				}

				if (vhlst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(vhlst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getFarePricingForAllRideTypeByPage(Double miles, int page,
			int limit) {
		String res = "";
		try {

			JSONObject jsonobj = new JSONObject();

			Pageable pageableRequest = PageRequest.of(page, limit);
			if(limit > 0) {

			if (miles != null && miles > 0) {

				List<RideTypeRateResponse> vhlst = new ArrayList<RideTypeRateResponse>();

				List<RideType> vtlstCheck = rideTypeDao
						.getAllRideType();
				
				Integer count = vtlstCheck.size();
				
				List<RideType> vtlst = rideTypeDao
						.getAllRideType(pageableRequest);

				for (RideType vh : vtlst) {

					RideTypeRateResponse vtr = new RideTypeRateResponse();

					Double baseRt = vh.getBaseRate();
					Double perMile = vh.getRatePerMile();
					Double rate = 0.0;

					rate = (miles * perMile) + baseRt;
					rate = Double.parseDouble(new DecimalFormat("##.##").format(rate));

					vtr.setVehicleCode(vh.getVehicleCode());
					vtr.setVehicleName(vh.getVehicleName());
					vtr.setRate(rate);

					vhlst.add(vtr);

				}

				if (vhlst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(vhlst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");
			}
		} else {
			jsonobj.put("responsecode", 400);
			jsonobj.put("message", "Limit should not be Zero or Negative.");
			jsonobj.put("timestamp", new Date());
		}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllRideTypeByOrganizationCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
		
			List<Object> objlst = rideTypeDao.getAllRideTypeByOrganizationCode(organizationCode);
			List<RideTypeResponse> maplst = new ArrayList<RideTypeResponse>();
			if (objlst != null && objlst.size() > 0) {
                            String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.CURRENCYSYMBOL);
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {
						
						RideTypeResponse rtr = new RideTypeResponse();

						RideType data = (RideType) arr[0];
						
						rtr.setId(data.getId());
						rtr.setVehicleCode(data.getVehicleCode());
						rtr.setVehicleName(data.getVehicleName());
						rtr.setBaseRate(data.getBaseRate());
						rtr.setRatePerMile(data.getRatePerMile());
                                                rtr.setCurrencySymbol(currencySymbol);
						rtr.setOrganizationCode(data.getOrganizationCode());
	
						rtr.setOrganizationName((String) arr[1]);
                                                if(data.getGlobalRidetypeCode()!=null && data.getGlobalRidetypeCode().length()>0)
                                                {
                                                rtr.setGlobalRidetypeCode(data.getGlobalRidetypeCode());
                                                GlobalRideType grt=globalRideTypeRepository.getGlobalRideTypeByGlobalRideCode(data.getGlobalRidetypeCode());
                                                if(grt!=null && grt.getId()>0 && grt.getVehicleName()!=null)
                                                {
                                                   rtr.setGlobalRidetypeName(grt.getVehicleName());
                                                }
                                                }
						maplst.add(rtr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllRideTypeByOrganizationCode(String organizationCode,
			int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if(limit > 0) {
				List<Object> objlstCheck = rideTypeDao.getAllRideTypeByOrganizationCode(organizationCode);
				Integer count = objlstCheck.size();
			List<Object> objlst = rideTypeDao.getAllRideTypeByOrganizationCode(organizationCode,pageableRequest);
			List<RideTypeResponse> maplst = new ArrayList<RideTypeResponse>();
			if (objlst != null && objlst.size() > 0) {
                            String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.CURRENCYSYMBOL);
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {
						
						RideTypeResponse rtr = new RideTypeResponse();

						RideType data = (RideType) arr[0];
						
						rtr.setId(data.getId());
						rtr.setVehicleCode(data.getVehicleCode());
						rtr.setVehicleName(data.getVehicleName());
						rtr.setBaseRate(data.getBaseRate());
						rtr.setRatePerMile(data.getRatePerMile());
                                                rtr.setCurrencySymbol(currencySymbol);
						rtr.setOrganizationCode(data.getOrganizationCode());
	
						rtr.setOrganizationName((String) arr[1]);
						rtr.setOrganizationName((String) arr[1]);
                                                if(data.getGlobalRidetypeCode()!=null && data.getGlobalRidetypeCode().length()>0)
                                                {
                                                rtr.setGlobalRidetypeCode(data.getGlobalRidetypeCode());
                                                GlobalRideType grt=globalRideTypeRepository.getGlobalRideTypeByGlobalRideCode(data.getGlobalRidetypeCode());
                                                if(grt!=null && grt.getId()>0 && grt.getVehicleName()!=null)
                                                {
                                                   rtr.setGlobalRidetypeName(grt.getVehicleName());
                                                }
                                                }
						maplst.add(rtr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getRideTypeByVehicleCodeWithName(String vehicleCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
		
			Object objlst = rideTypeDao.getRideTypeByVehicleCodeWithName(vehicleCode);
//			RideTypeResponse maplst = new RideTypeResponse();
			if (objlst != null) {
//				for (int i = 0; i < objlst; i++) {
					Object[] arr = (Object[]) objlst;
					if (arr.length >= 2) {
						
						RideTypeResponse rtr = new RideTypeResponse();

						RideType data = (RideType) arr[0];
						String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
						rtr.setId(data.getId());
						rtr.setVehicleCode(data.getVehicleCode());
						rtr.setVehicleName(data.getVehicleName());
						rtr.setBaseRate(data.getBaseRate());
						rtr.setRatePerMile(data.getRatePerMile());
                                                rtr.setCurrencySymbol(currencySymbol);
						rtr.setOrganizationCode(data.getOrganizationCode());
	
						rtr.setOrganizationName((String) arr[1]);
////						maplst.
//						maplst.add(rtr);
                                                rtr.setOrganizationName((String) arr[1]);
                                                if(data.getGlobalRidetypeCode()!=null && data.getGlobalRidetypeCode().length()>0)
                                                {
                                                rtr.setGlobalRidetypeCode(data.getGlobalRidetypeCode());
                                                GlobalRideType grt=globalRideTypeRepository.getGlobalRideTypeByGlobalRideCode(data.getGlobalRidetypeCode());
                                                if(grt!=null && grt.getId()>0 && grt.getVehicleName()!=null)
                                                {
                                                   rtr.setGlobalRidetypeName(grt.getVehicleName());
                                                }
                                                }
						RideTypeResponse maplst = rtr;

//					}
//				}
				if (maplst != null) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                    } else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

}
