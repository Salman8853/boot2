package com.gigflex.prototype.microservices.documentvalidationmapping.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "document_validation_mapping")
public class DocumentValidationMapping extends CommonAttributes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "document_validation_code", unique = true)
	private String documentValidationCode;

	@Column(name = "documentcode", nullable = false)
	private String documentCode;

	@Column(name = "validation_code", nullable = false)
	private String validationCode;

	@PrePersist
	private void assignUUID() {
		if (this.getDocumentValidationCode() == null || this.getDocumentValidationCode().length() == 0) {
			this.setDocumentValidationCode((UUID.randomUUID().toString()));
		}
	}

	public DocumentValidationMapping() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DocumentValidationMapping(Long id, String documentValidationCode, String documentCode,
			String validationCode) {
		super();
		this.id = id;
		this.documentValidationCode = documentValidationCode;
		this.documentCode = documentCode;
		this.validationCode = validationCode;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocumentValidationCode() {
		return documentValidationCode;
	}

	public void setDocumentValidationCode(String documentValidationCode) {
		this.documentValidationCode = documentValidationCode;
	}

	public String getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}

	public String getValidationCode() {
		return validationCode;
	}

	public void setValidationCode(String validationCode) {
		this.validationCode = validationCode;
	}

}
