/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.repository;

import java.util.List;

import com.gigflex.prototype.microservices.driver.dtob.Driver;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Abhishek
 */
@Repository
public interface DriverRepository extends JpaRepository<Driver,Long>,JpaSpecificationExecutor<Driver> {
	
        @Query("SELECT d FROM Driver d WHERE d.isDeleted != TRUE AND d.driverCode = :driverCode")
	public Driver getDriverByDriverCode(@Param("driverCode") String driverCode);
	
	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.driverCode = :driverCode")
        public List<Object> findDriverByDriverCode(@Param("driverCode") String driverCode);
	
//	@Query("SELECT d,o.operatorName FROM Driver d,Operator o WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.driverCode = :driverCode")
//    public List<Object> findDriverByDriverCode(@Param("driverCode") String driverCode,Pageable pageableRequest);
    
	@Query("SELECT d,o.operatorName,org.organizationName , u.isActive FROM Driver d, Operator o, Organization org,Users u WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode  AND u.userCode=d.driverCode")
	public List<Object> getAllDriver();
	
//	@Query("SELECT m.vehicleCode,m.vehicleName FROM VehicleDetail m, VehicleDriverMapping vdm WHERE m.isDeleted != TRUE AND vdm.vehicleCode = m.vehicleCode AND vdm.driverCode=:driverCode")
//	public List<Object> getVehicleDetailsByDriverCode(@Param("driverCode") String driverCode);
	
//	@Query("SELECT d,dd,o.operatorName,org.organizationName,dtd.documentType FROM Driver d,Operator o,Organization org,DriverDocument dd,DocumentTypeDetail dtd WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND dd.documentCode = dtd.documentCode AND d.driverCode = dd.driverCode")
//	public List<Object> getAllDriverWithDocument();
	
	@Query("SELECT d,o.operatorName,org.organizationName, u.isActive FROM Driver d, Operator o, Organization org,Users u WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND u.userCode=d.driverCode")
	public List<Object> getAllDriver(Pageable pageableRequest);
	
	@Query("SELECT d FROM Driver d WHERE d.isDeleted != TRUE AND d.id = :id")
	public Driver getDriverById(@Param("id") Long id);
	
	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.organizationCode = :organizationCode")
    public List<Object> findDriverByOrganizationCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.organizationCode = :organizationCode")
    public List<Object> findDriverByOrganizationByPage(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
	
	
	@Query("SELECT driver FROM Driver driver WHERE driver.isDeleted != TRUE AND driver.emailId = :emailId")
	public Driver findByEmail(@Param("emailId") String emailId);
        
	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.operatorCode = :operatorCode")
    public List<Object> findDriverByOperatorCode(@Param("operatorCode") String operatorCode);
	
	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.operatorCode = :operatorCode")
    public List<Object> findDriverByOperatorCode(@Param("operatorCode") String operatorCode,Pageable pageableRequest);

	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org,VehicleDriverMapping vdm WHERE vdm.isDeleted != TRUE AND  d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.driverCode=vdm.driverCode AND vdm.vehicleCode = :vehicleCode")
    public List<Object> getDriverByVehicleTypeCode(@Param("vehicleCode") String vehicleCode);
	
	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org,VehicleDriverMapping vdm WHERE  vdm.isDeleted != TRUE AND  d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.driverCode=vdm.driverCode AND vdm.vehicleCode = :vehicleCode AND d.organizationCode = :organizationCode")
    public List<Object> getDriverByVehicleTypeCodeAndOrganizationCode(@Param("vehicleCode") String vehicleCode,@Param("organizationCode") String organizationCode);
	
	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org,VehicleDriverMapping vdm WHERE vdm.isDeleted != TRUE AND  d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.driverCode=vdm.driverCode AND vdm.vehicleCode = :vehicleCode")
    public List<Object> getDriverByVehicleTypeCode(@Param("vehicleCode") String vehicleCode,Pageable pageableRequest);
	
	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org,VehicleDriverMapping vdm WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.driverCode=vdm.driverCode AND vdm.vehicleCode = :vehicleCode AND d.organizationCode = :organizationCode")
    public List<Object> getDriverByVehicleTypeCodeAndOrganizationCode(@Param("vehicleCode") String vehicleCode,@Param("organizationCode") String organizationCode,Pageable pageableRequest);
	
	@Query("SELECT d FROM Driver d WHERE d.isDeleted != TRUE AND d.organizationCode = :organizationCode")
	public List<Driver> getDriverByOrganizationCode(@Param("organizationCode") String organizationCode);
        
        @Query("SELECT d FROM Driver d WHERE d.isDeleted != TRUE AND d.operatorCode = :operatorCode")
	public List<Driver> getDriverListByOperatorCode(@Param("operatorCode") String operatorCode);


        @Query("SELECT d,vd FROM Driver d,VehicleDetail vd  WHERE d.isDeleted != TRUE AND d.defaultVehicleCode = vd.vehicleCode AND d.driverCode = :driverCode")
        public Object findDefaultVehicleDetailByDriverCode(@Param("driverCode") String driverCode);
       
      
        @Query("SELECT d FROM Driver d WHERE d.isDeleted != TRUE ")
	public List<Driver> getAllDriverList();

        @Query("SELECT d.driverCode FROM Driver d WHERE d.isDeleted != TRUE AND d.organizationCode = :organizationCode")
        public List<String> getDriverCodeByOrganizationCode(@Param("organizationCode") String organizationCode);
       
        @Query("SELECT d.defaultVehicleCode FROM Driver d WHERE d.isDeleted != TRUE AND d.organizationCode = :organizationCode")
	public List<String> getdefoultDriverByOrganizationCode(@Param("organizationCode") String organizationCode); 
        
       @Query("SELECT d FROM Driver d WHERE d.isDeleted != TRUE AND d.driverCode!=:driverCode AND d.emailId=:email")
       public Driver  getdriverBydriverCodeAndemail(@Param("driverCode") String driverCode,@Param("email") String email); 
       
        @Query("SELECT d FROM Driver d WHERE d.isDeleted != TRUE AND d.driverCode!=:driverCode AND d.emailId=:email")
       public Driver  getdriverByrideCode(@Param("driverCode") String driverCode,@Param("email") String email); 

       
}
