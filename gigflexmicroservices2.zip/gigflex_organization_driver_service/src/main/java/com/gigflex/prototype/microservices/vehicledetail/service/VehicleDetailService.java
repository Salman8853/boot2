package com.gigflex.prototype.microservices.vehicledetail.service;

import java.util.List;

import com.gigflex.prototype.microservices.vehicledetail.dtob.SaveVehicleByDriver;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetailDriverRequest;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetailRequest;

public interface VehicleDetailService {
	
    public String getAllVehicleDetail();
    public String getVehicleDetailById(Long id);
    public String getVehicleDetailByVehicleCode(String vehicleCode);
    public String getVehicleDetailByVehicleCodeWithName(String vehicleCode);
    public String saveNewVehicleDetail(VehicleDetailRequest vehicleDetailReq, String ip);
    public String updateVehicleDetailById( Long id,VehicleDetailRequest vehicleDetailReq, String ip);
    public String softDeleteByVehicleCode(String vehicleCode);
    public String softMultipleDeleteByVehicleCode(List<String> vehicleCodeList);
    public String getAllVehicleDetailByPage(int page, int limit);
    public String search(String search);
    public String getVehicleDetailByOrganizationCode(String organizationCode);
    public String getVehicleDetailByOrganizationCodeByPage(String organizationCode,int page, int limit);
    public String getVehicleDetailByModelCode(String modelCode);
    public String getVehicleDetailByModelCodeByPage(String modelCode,int page, int limit);
    public String saveVehicleByOrganization(VehicleDetailDriverRequest vehicleDetailReq, String ip);
    public String updateVehicleByOrganizationById(Long id,VehicleDetailDriverRequest vehicleDetailReq, String ip);
    public String getVehicleDetailByDriverCode(String driverCode);
    
    public String getVehicleDetailByDriverCodeforMobile(String driverCode);
    
    public String getVehicleDetailByDriverCodeByPage(String driverCode,int page, int limit);
    public String saveVehicleByDriver(SaveVehicleByDriver vehicleDetailReq, String ip);
    public String updateVehicleByDriverById(Long id,SaveVehicleByDriver vehicleDetailReq, String ip);
    public String getVehicleTypeDetailByDriverCode(String driverCode);


}
