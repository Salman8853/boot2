package com.gigflex.prototype.microservices.operator.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.util.SearchCriteria;



public class OperatorSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public OperatorSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public OperatorSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<Operator> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<Operator>> specs = new ArrayList<Specification<Operator>>();
        for (SearchCriteria param : params) {
            specs.add(new OperatorSpecification(param));
        }
 
        Specification<Operator> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
