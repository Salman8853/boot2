package com.gigflex.prototype.microservices.makemodelmapping.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "makemodelmapping")
public class MakeModelMapping extends CommonAttributes implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "model_code", unique = true)
	private String modelCode;

	@Column(name = "modelname")
	private String modelName;

	@Column(name = "make_code")
	private String makeCode;

	public MakeModelMapping(Long id, String modelCode, String modelName, String makeCode) {
		super();
		this.id = id;
		this.modelCode = modelCode;
		this.modelName = modelName;
		this.makeCode = makeCode;
	}
	 @PrePersist
	    private void assignUUID() {
	        if(this.getModelCode()==null || this.getModelCode().length()==0)
	        {
	            this.setModelCode((UUID.randomUUID().toString()));
	        }
	    }
	
	public MakeModelMapping() {
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getModelCode() {
		return modelCode;
	}

	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getMakeCode() {
		return makeCode;
	}

	public void setMakeCode(String makeCode) {
		this.makeCode = makeCode;
	}

}
