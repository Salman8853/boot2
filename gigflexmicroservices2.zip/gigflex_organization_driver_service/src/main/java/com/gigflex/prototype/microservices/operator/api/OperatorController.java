package com.gigflex.prototype.microservices.operator.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.dtob.OperatorRequest;
import com.gigflex.prototype.microservices.operator.dtob.OperatorUpRequest;
import com.gigflex.prototype.microservices.operator.service.OperatorService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.util.TokenUtility;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class OperatorController {

	@Autowired
	public OperatorService operatorService;
         @Autowired
        TokenUtility tokenutility;
	@GetMapping("/operator/{search}")
	public String search(@PathVariable("search") String search) {
		return operatorService.search(search);
	}

	@GetMapping("/getAllOperator")
	public String getAllOperator() {
		return operatorService.findAllOperators();
	}

	@GetMapping(path = "/getAllOperatorByPage")
	public String getAllOperatorByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String opr = operatorService.getAllOperatorsByPage(page, limit);

		return opr;

	}

	@GetMapping("/getOperator/{id}")
	public String getOperatorById(@PathVariable Long id) {
		return operatorService.findOperatorById(id);
	}

	@GetMapping("/getOperatorByOperatorCode/{operatorCode}")
	public String getOperatorByOperatorCode(@PathVariable String operatorCode,@RequestHeader HttpHeaders headers) {
              String res="";
               res=tokenutility.operatorValidationwithoutactivation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                 return operatorService.getOperatorByOperatorCode(operatorCode);
               }else
               {
                  return res;
               }
		
	}
	
	@GetMapping("/getOperatorByOrganizationCode/{organizationCode}")
	public String getOperatorByOrganizationCode(@PathVariable String organizationCode,@RequestHeader HttpHeaders headers) {
              String res="";
               res=tokenutility.orgCodeValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
               return operatorService.getOperatorByOrganizationCode(organizationCode);
               }else
               {
               return res;
               }
		
	}
	
	@GetMapping(path="/getOperatorByOrganizationCodeByPage/{organizationCode}")
    public String getOperatorByOrganizationCodeByPage(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
            String res="";
               res=tokenutility.orgCodeValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
                return  operatorService.getOperatorByOrganizationCodeByPage(organizationCode, page, limit);
               }else
               {
               return res;
               }
      
    }

	@DeleteMapping("/softDeleteOperatorByOperatorCode/{operatorCode}")
	public String softDeleteOperatorByOperatorCode(
			@PathVariable String operatorCode) {
		return operatorService.softDeleteByOperatorCode(operatorCode);
	}

	@DeleteMapping("/softMultipleDeleteByOperatorCode/{operatorServiceList}")
	public String softMultipleDeleteByOperatorCode(
			@PathVariable List<String> operatorServiceList) {
		if (operatorServiceList != null && operatorServiceList.size() > 0) {
			return operatorService
					.softMultipleDeleteByOperatorCode(operatorServiceList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

	@PutMapping("/updateOperator/{id}")
	public String updateOperator(@PathVariable Long id,
			@RequestBody OperatorUpRequest OperatorReq, HttpServletRequest request) {

		if (OperatorReq !=null) {
				String ip = request.getRemoteAddr();

				return operatorService.updateOperatorById(id, OperatorReq, ip);
			
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data should not be blank");
			return derr.toString();
		}

		// if (id == null) {
		// return "Operator with Id : (" + id + ") Not found.";
		// } else if (getUserEmailAvailability(OperatorReq.getEmailId())) {
		// GigflexResponse derr = new GigflexResponse(400, new Date(),
		// "EmailId already exists.");
		// return derr.toString();
		//
		// } else {
		// String ip = request.getRemoteAddr();
		//
		// return OperatorService.updateOperatorById(id, OperatorReq, ip);
		//
		// }

	}

	@PostMapping("/createOperator")
	public String createOperator(@RequestBody OperatorRequest OperatorReq,
			HttpServletRequest request) {
		if (GigflexUtility.emailPatternValidation(OperatorReq.getEmailId()) == true) {

			if (getUserEmailAvailability(OperatorReq.getEmailId())) {
				String ip = request.getRemoteAddr();
				return operatorService.saveOperator(OperatorReq, ip);
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"EmailId already exists.");
				return derr.toString();

			}

		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Please check your email format.");
			return derr.toString();
		}

	}

	@GetMapping("/checkEmailAvailability/{emailId}")
	public Boolean getUserEmailAvailability(
			@PathVariable("emailId") String emailId) {
		Boolean EmailStatus = false;
		try {
			Operator email = operatorService.getUserEmail(emailId.trim());
			if (email == null) {
				EmailStatus = true;
			}
		} catch (Exception e) {
			EmailStatus = true;
			e.printStackTrace();
		}
		return EmailStatus;
	}

}
