/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.driver.dtob;

import com.gigflex.prototype.microservices.booking.dtob.Booking;

/**
 *
 * @author amit.kumar
 */
public class EligibleDriverResponse {
    
    private Long id; 
    private String driverCode;

    private String name;

    private String contactNumber;

    private String countryCode;

    private String emailId;
    private String callsign;

    private String operatorCode;
    private Boolean approveStatus;
    private String organizationCode;
    private String driverImage;
    private String defaultVehicleCode;
    private Double distanceFromLastDrop;
    private String vehicleTypeName ;
    
    private String priority;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getCallsign() {
        return callsign;
    }

    public void setCallsign(String callsign) {
        this.callsign = callsign;
    }

    public String getOperatorCode() {
        return operatorCode;
    }

    public void setOperatorCode(String operatorCode) {
        this.operatorCode = operatorCode;
    }

    public Boolean isApproveStatus() {
        return approveStatus;
    }

    public void setApproveStatus(Boolean approveStatus) {
        this.approveStatus = approveStatus;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getDriverImage() {
        return driverImage;
    }

    public void setDriverImage(String driverImage) {
        this.driverImage = driverImage;
    }

    public String getDefaultVehicleCode() {
        return defaultVehicleCode;
    }

    public void setDefaultVehicleCode(String defaultVehicleCode) {
        this.defaultVehicleCode = defaultVehicleCode;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public Double getDistanceFromLastDrop() {
        return distanceFromLastDrop;
    }

    public void setDistanceFromLastDrop(Double distanceFromLastDrop) {
        this.distanceFromLastDrop = distanceFromLastDrop;
    }

    public String getVehicleTypeName() {
        return vehicleTypeName;
    }

    public void setVehicleTypeName(String vehicleTypeName) {
        this.vehicleTypeName = vehicleTypeName;
    }

     
}
