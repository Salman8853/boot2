/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.passenger.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationDao;
import com.gigflex.prototype.microservices.passenger.dtob.BookingAddress;
import com.gigflex.prototype.microservices.passenger.dtob.Passenger;
import com.gigflex.prototype.microservices.passenger.dtob.PassengerResponse;
import com.gigflex.prototype.microservices.passenger.repository.PassengerDao;
import com.gigflex.prototype.microservices.passenger.service.PassengerService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */
@Service
public class PassengerServiceImpl implements PassengerService {

    @Autowired
    private PassengerDao passengerDao;
    
    @Autowired
    private OrganizationDao orgDao;

    
    @Override
    public String getPassengerAllPassengerList() {
       String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Passenger> passengerList = new ArrayList<Passenger>();

			List<PassengerResponse> passengerResponseList = new ArrayList<PassengerResponse>();
			passengerList  = passengerDao.getAllPassenger();                                                                  
			
                        if(passengerList != null && passengerList.size() > 0)
                        {
                            for (Passenger passenger : passengerList) {

				PassengerResponse pResponse = new PassengerResponse();
                                pResponse.setPassengerCode(passenger.getPassengerCode());
                                pResponse.setPassengerName(passenger.getPassengerName());
                                pResponse.setOrganizationCode(passenger.getOrganizationCode()); 
                                Organization organization = orgDao.findByOrganizationCode(passenger.getOrganizationCode());
                                if(organization != null )
                                {
                                    pResponse.setOrganizationName(organization.getOrganizationName()); 
                                }
                                else
                                {
                                   pResponse.setOrganizationName(""); 
                                }   
                                pResponse.setPrimaryContactNumber(passenger.getPrimaryContactNumber());
                                pResponse.setpCountryCode(passenger.getpCountryCode());
                                pResponse.setSecondaryContactNumber(passenger.getSecondaryContactNumber());
                                pResponse.setsCountryCode(passenger.getsCountryCode());                                
				passengerResponseList.add(pResponse);                               
			   }
                            
                            if (passengerResponseList != null && passengerResponseList.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(passengerResponseList);
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Success");
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
                            
                            
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
                        }

                        
			res = jsonobj.toString();
		} 
                catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public String getPassengerByOrganizationCode(String organizationCode) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Passenger> passengerList = new ArrayList<Passenger>();

			List<PassengerResponse> passengerResponseList = new ArrayList<PassengerResponse>();

			passengerList  = passengerDao.getPassengerByOrgCode(organizationCode);                        
                        
                        Organization organization = orgDao.findByOrganizationCode(organizationCode);
                        String orgName = "";
                        if(organization != null )
                        {
                            orgName = organization.getOrganizationName(); 
                        }                        
			
                        if(passengerList != null && passengerList.size() > 0)
                        {
                            for (Passenger passenger : passengerList) {

				PassengerResponse pResponse = new PassengerResponse();
                                pResponse.setPassengerCode(passenger.getPassengerCode());
                                pResponse.setPassengerName(passenger.getPassengerName());
                                pResponse.setOrganizationCode(passenger.getOrganizationCode()); 
                                pResponse.setOrganizationName(orgName); 
                                pResponse.setPrimaryContactNumber(passenger.getPrimaryContactNumber());
                                pResponse.setpCountryCode(passenger.getpCountryCode());
                                pResponse.setSecondaryContactNumber(passenger.getSecondaryContactNumber());
                                pResponse.setsCountryCode(passenger.getsCountryCode());  
                                
                                List<Booking> bookingList = passengerDao.getBookingListByOrganizationCodeAndPassengerCode(organizationCode,passenger.getPassengerCode());
                                
                                BookingAddress bookingAddr = new BookingAddress();
                                List<BookingAddress> bookingAddrList = new ArrayList<>();
                                if(bookingList != null && bookingList.size() > 0)
                                {
                                    for(Booking booking : bookingList)
                                    {
                                        bookingAddr.setPickUpAddress(booking.getPickUpAddress());
                                        bookingAddr.setPickLat(booking.getPickLat());
                                        bookingAddr.setPickLang(booking.getPickLang());
                                        bookingAddr.setDropOffAddress(booking.getDropOffAddress());
                                        bookingAddr.setDropLat(booking.getDropLat());
                                        bookingAddr.setDropLang(booking.getDropLang()); 
                                        bookingAddrList.add(bookingAddr); 
                                    }
                                }
                                pResponse.setBookingAddressList(bookingAddrList); 
                                
                                passengerResponseList.add(pResponse); 
                                
			   }
                            
                            if (passengerResponseList != null && passengerResponseList.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(passengerResponseList);
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Success");
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
                            
                            
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
                        }

                        
			res = jsonobj.toString();
		} 
                catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
        
    }

    @Override
    public String getPassengerByPassengerCode(String passengerCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        if(passengerCode != null && passengerCode.trim().length() > 0)
                        {
                            Passenger passenger = new Passenger();

                            passenger  = passengerDao.getPassengerByPassengerCode(passengerCode);
                            List<Booking> bookingList = passengerDao.getBookingListByPassengerCode(passengerCode);

                            if(passenger != null )
                            {
                                PassengerResponse pResponse = new PassengerResponse();
                                pResponse.setPassengerCode(passenger.getPassengerCode());
                                pResponse.setPassengerName(passenger.getPassengerName());
                                pResponse.setOrganizationCode(passenger.getOrganizationCode());
                                                            
                                
                                Organization organization = orgDao.findByOrganizationCode(passenger.getOrganizationCode());
                                if(organization != null )
                                {
                                    pResponse.setOrganizationName(organization.getOrganizationName()); 
                                }
                                else
                                {
                                   pResponse.setOrganizationName(""); 
                                }                             
                                
                                pResponse.setPrimaryContactNumber(passenger.getPrimaryContactNumber());
                                pResponse.setpCountryCode(passenger.getpCountryCode());
                                pResponse.setSecondaryContactNumber(passenger.getSecondaryContactNumber());
                                pResponse.setsCountryCode( passenger.getsCountryCode());     
                                
                                BookingAddress bookingAddr = new BookingAddress();
                                List<BookingAddress> bookingAddrList = new ArrayList<>();
                                if(bookingList != null && bookingList.size() > 0)
                                {
                                    for(Booking booking : bookingList)
                                    {
                                        bookingAddr.setPickUpAddress(booking.getPickUpAddress());
                                        bookingAddr.setPickLat(booking.getPickLat());
                                        bookingAddr.setPickLang(booking.getPickLang());
                                        bookingAddr.setDropOffAddress(booking.getDropOffAddress());
                                        bookingAddr.setDropLat(booking.getDropLat());
                                        bookingAddr.setDropLang(booking.getDropLang()); 
                                        bookingAddrList.add(bookingAddr); 
                                    }
                                }
                                pResponse.setBookingAddressList(bookingAddrList); 
				     
                                if (pResponse != null ) {
                                            ObjectMapper mapperObj = new ObjectMapper();
                                            String Detail = mapperObj.writeValueAsString(pResponse);
                                            jsonobj.put("responsecode", 200);
                                            jsonobj.put("timestamp", new Date());
                                            jsonobj.put("message", "Success");
                                            jsonobj.put("data", new JSONObject(Detail));

                                    } else {
                                            jsonobj.put("responsecode", 404);
                                            jsonobj.put("timestamp", new Date());
                                            jsonobj.put("message", "Record Not Found");
                                    }
                            }
                            else
                            {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("message", "Record Not Found");
                            }

                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Passenger Code should not be blank");
                        }
                        
                        
			res = jsonobj.toString();
		} 
                catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }
    
}
