package com.gigflex.prototype.microservices.maketype.service;

import java.util.List;

import com.gigflex.prototype.microservices.maketype.dtob.MakeTypeRequest;

public interface MakeTypeService {
	
	public String getAllMakeType();
	public String getMakeTypeById(Long id);
	public String getMakeTypeByVehicleCode(String vehicleCode);
	public String saveNewMakeType(MakeTypeRequest makeTypeReq, String ip);
	public String updateMakeTypeById( Long id,MakeTypeRequest makeTypeReq, String ip);
	public String softDeleteByVehicleCode(String vehicleCode);
    public String softMultipleDeleteByVehicleCode(List<String> vehicleCodeList);
    public String getAllMakeTypeByPgae(int page, int limit);
    public String search(String search);

}
