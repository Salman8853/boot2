/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.drivertimeoff.dtob;

import java.util.Date;

/**
 *
 * @author amit.kumar
 */
public class DriverTimeOffModel {
    
    private Long id;
     private String driverTimeoffCode;     
     private String organizationCode;
     private String organizationName;
     private String driverCode; 
     private String driverName; 
     private String createdBy;
     private String fromDate;
     private String toDate;  
     private Date fromDateTimestamp;
     private Date toDateTimestamp;
     private String fromTime;    
     private String toTime;     
     private String cancelReason;
     private String reason;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDriverTimeoffCode() {
        return driverTimeoffCode;
    }

    public void setDriverTimeoffCode(String driverTimeoffCode) {
        this.driverTimeoffCode = driverTimeoffCode;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public Date getFromDateTimestamp() {
        return fromDateTimestamp;
    }

    public void setFromDateTimestamp(Date fromDateTimestamp) {
        this.fromDateTimestamp = fromDateTimestamp;
    }

    public Date getToDateTimestamp() {
        return toDateTimestamp;
    }

    public void setToDateTimestamp(Date toDateTimestamp) {
        this.toDateTimestamp = toDateTimestamp;
    }

    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public String getCancelReason() {
        return cancelReason;
    }

    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

}
