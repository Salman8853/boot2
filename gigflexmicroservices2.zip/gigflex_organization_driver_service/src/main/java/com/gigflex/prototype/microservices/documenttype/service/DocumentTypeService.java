package com.gigflex.prototype.microservices.documenttype.service;

import java.util.List;

import com.gigflex.prototype.microservices.documenttype.dtob.DocumentTypeRequest;

public interface DocumentTypeService {
	
	public String getAllDocumentType();
	public String getDocumentTypeById(Long id);
	public String getDocumentTypeByDocumentTypeCode(String DocumentTypeCode);
	public String saveNewDocumentType(DocumentTypeRequest documentTypeReq, String ip);
	public String updateDocumentTypeById( Long id,DocumentTypeRequest documentTypeReq, String ip);
	public String softDeleteByDocumentTypeCode(String documentTypeCode);
    public String softMultipleDeleteByDocumentTypeCode(List<String> documentTypeCodeList);
    public String getAllDocumentTypeByPgae(int page, int limit);
    public String search(String search);

}
