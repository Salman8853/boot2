/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.util;

import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.dtob.Users;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.operator.repository.UserRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationDao;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

/**
 *
 * @author m.salman
 */
@Service
public class TokenUtility {
     @Autowired
	 private JwtConfig jwtConfig;
	  @Autowired
	UserRepository userRepository;
          @Autowired
          DriverRepository driverRepository;
          @Autowired
          OperatorRepository operatorRepository;  
          @Autowired
          OrganizationDao organizationdao;
      
    @Bean
    public JwtConfig jwtConfig() {
        return new JwtConfig();
    }
     
    public String getTokenFromHeader(HttpHeaders headers)
    {
        String res=null;
        try{
            List<String> lst=headers.get("Authorization");
            if(lst!=null && lst.size()>0)
            {
                res=lst.get(0);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return res;
    }
     
    public String getUserNameFromToken(String tokenold)
    {
        String userName=null;
        try{
            String token = tokenold.replace(jwtConfig.getPrefix(), "");
		 
		          Claims claims = Jwts.parser()
                 .setSigningKey(jwtConfig.getSecret().getBytes())
                 .parseClaimsJws(token)
                 .getBody();

         userName = claims.getSubject();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            userName=null;
        }
        return userName;
    }
    public String userValidation(HttpHeaders headers,String driverCode)
    {
        
     
        String res="Failed";
        JSONObject jsonobj=new JSONObject();
        try{
            List<String> lst=headers.get("Authorization");
            if(lst!=null && lst.size()>0)
            {
              String tok=lst.get(0);
              if(tok!=null && tok.length()>0)
              {
                  String newtoken = tok.replace(jwtConfig.getPrefix(), "");
                  Claims claims = Jwts.parser()
                 .setSigningKey(jwtConfig.getSecret().getBytes())
                 .parseClaimsJws(newtoken)
                 .getBody();
             String userName=claims.getSubject();
                  if(userName != null && userName.length() > 0)
                  {
                    Users u=  userRepository.findByuserName(userName);
                      if(u!=null && u.getId()>0 && u.getUserCode()!=null&& u.getIsActive().equals(true))
                      {       if(u.getIsAdmin()|| u.getIsOwner())
                              {
                             Driver driver    = driverRepository.getDriverByDriverCode(driverCode);
                                   Operator operator= operatorRepository.getOperatorByOperatorCode(u.getUserCode());
                                       Organization organization= organizationdao.findByOrganizationCode(operator.getOrganizationCode());
                                  if(organization!=null && organization.getId()>0&& organization.getIsActive().equals(true))
                                 {
                                   if(driver!=null && driver.getOperatorCode()!=null && operator!=null && operator.getOrganizationCode()!=null && driver.getOrganizationCode().equals(operator.getOrganizationCode()))
                                   {
                                     res="true";
                                   }else
                                   {
                                     jsonobj.put("responsecode", 401);
				     jsonobj.put("timestamp", new Date());
				     jsonobj.put("message", "Unauthorised Access");
                                    res=jsonobj.toString();
                                   }
                                  }else
                                       {
                                           jsonobj.put("responsecode", 401);
				            jsonobj.put("timestamp", new Date());
				          jsonobj.put("message", "Unauthorised Access");
                                           res=jsonobj.toString();
                                       }
                                           
                              }
                            else if(u.getUserCode().equals(driverCode))
                              {
                                  res="true";
                              }else
                              {
                                   jsonobj.put("responsecode", 401);
				  jsonobj.put("timestamp", new Date());
				  jsonobj.put("message", "Unauthorised Access");
                                res=jsonobj.toString();
                              }
                      
                      
                      }else
                      {
                                jsonobj.put("responsecode", 401);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Unauthorised Access");
                                 res=jsonobj.toString();
                      }
                      
                      
                  }else
                  {
                      GigflexResponse derr = new GigflexResponse(401, new Date(),
					"Access Token is not valid.");
			res = derr.toString();
                  }
              }else
              {
                GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString();
              }
               
            }
            else
            {
               GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString(); 
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return res;
    }
      public String userValidationwithoutactive(HttpHeaders headers,String driverCode)
    {
        
     
        String res="Failed";
        JSONObject jsonobj=new JSONObject();
        try{
            List<String> lst=headers.get("Authorization");
            if(lst!=null && lst.size()>0)
            {
              String tok=lst.get(0);
              if(tok!=null && tok.length()>0)
              {
                  String newtoken = tok.replace(jwtConfig.getPrefix(), "");
                  Claims claims = Jwts.parser()
                 .setSigningKey(jwtConfig.getSecret().getBytes())
                 .parseClaimsJws(newtoken)
                 .getBody();
             String userName=claims.getSubject();
                  if(userName != null && userName.length() > 0)
                  {
                    Users u=  userRepository.findByuserName(userName);
                      if(u!=null && u.getId()>0 && u.getUserCode()!=null&& u.getIsActive().equals(true))
                      {       if(u.getIsAdmin()|| u.getIsOwner())
                              {
                             Driver driver    = driverRepository.getDriverByDriverCode(driverCode);
                                   Operator operator= operatorRepository.getOperatorByOperatorCode(u.getUserCode());
                                      
                                 
                                   if(driver!=null && driver.getOperatorCode()!=null && operator!=null && operator.getOrganizationCode()!=null && driver.getOrganizationCode().equals(operator.getOrganizationCode()))
                                   {
                                     res="true";
                                   }else
                                   {
                                     jsonobj.put("responsecode", 401);
				     jsonobj.put("timestamp", new Date());
				     jsonobj.put("message", "Unauthorised Access");
                                    res=jsonobj.toString();
                                   }
                                  
                                           
                              }
                            else if(u.getUserCode().equals(driverCode))
                              {
                                  res="true";
                              }else
                              {
                                   jsonobj.put("responsecode", 401);
				  jsonobj.put("timestamp", new Date());
				  jsonobj.put("message", "Unauthorised Access");
                                res=jsonobj.toString();
                              }
                      
                      
                      }else
                      {
                                jsonobj.put("responsecode", 401);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Unauthorised Access");
                                 res=jsonobj.toString();
                      }
                      
                      
                  }else
                  {
                      GigflexResponse derr = new GigflexResponse(401, new Date(),
					"Access Token is not valid.");
			res = derr.toString();
                  }
              }else
              {
                GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString();
              }
               
            }
            else
            {
               GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString(); 
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return res;
    }
    public String operatorValidation(HttpHeaders headers,String operatorCode)
    {
    
        String res="Failed";
        JSONObject jsonobj=new JSONObject();
        try{
            List<String> lst=headers.get("Authorization");
            if(lst!=null && lst.size()>0)
            {
              String tok=lst.get(0);
              if(tok!=null && tok.length()>0)
              {
                  String newtoken = tok.replace(jwtConfig.getPrefix(), "");
                  Claims claims = Jwts.parser()
                 .setSigningKey(jwtConfig.getSecret().getBytes())
                 .parseClaimsJws(newtoken)
                 .getBody();
             String userName=claims.getSubject();
                  if(userName != null && userName.length() > 0)
                  {
                    Users u=  userRepository.findByuserName(userName);
                      if(u!=null && u.getId()>0 && u.getUserCode()!=null && u.getIsActive().equals(true))
                      {     
                          if(u.getIsAdmin()|| u.getIsOwner())
                           {
//                             Driver driver    = driverRepository.getDriverByDriverCode(driverCode);
                                     Operator operator =  operatorRepository.getOperatorByOperatorCode(operatorCode);
                                     Operator operator1= operatorRepository.getOperatorByOperatorCode(u.getUserCode());
                                     Organization organization=organizationdao.findByOrganizationCode(operator.getOrganizationCode());
                                     if(organization!=null && organization.getId()>0 && organization.getIsActive().equals(true))
                                     {
                                   if(operator!=null && operator.getOrganizationCode()!=null && operator1!=null &&operator1.getOrganizationCode()!=null && operator1.getOrganizationCode().equals(operator.getOrganizationCode()))
                                   {
                                     res="true";
                                   }else
                                   {
                                     jsonobj.put("responsecode", 401);
				     jsonobj.put("timestamp", new Date());
				     jsonobj.put("message", "Unauthorised Access");
                                    res=jsonobj.toString();
                                   }
                                   }else
                                     {
                                       
                                     jsonobj.put("responsecode", 401);
				     jsonobj.put("timestamp", new Date());
				     jsonobj.put("message", "Unauthorised Access");
                                    res=jsonobj.toString();
                                     }
                                   
                                           
                              }else
                              {
                                   jsonobj.put("responsecode", 401);
				  jsonobj.put("timestamp", new Date());
				  jsonobj.put("message", "Unauthorised Access");
                                res=jsonobj.toString();
                              }
                         
                      
                      
                      }else
                      {
                                jsonobj.put("responsecode", 401);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Unauthorised Access");
                                 res=jsonobj.toString();
                      }
                      
                      
                  }else
                  {
                      GigflexResponse derr = new GigflexResponse(401, new Date(),
					"Access Token is not valid.");
			res = derr.toString();
                  }
              }else
              {
                GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString();
              }
               
            }
            else
            {
               GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString(); 
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return res;
    }
      public String operatorValidationwithoutactivation(HttpHeaders headers,String operatorCode)
    {
    
        String res="Failed";
        JSONObject jsonobj=new JSONObject();
        try{
            List<String> lst=headers.get("Authorization");
            if(lst!=null && lst.size()>0)
            {
              String tok=lst.get(0);
              if(tok!=null && tok.length()>0)
              {
                  String newtoken = tok.replace(jwtConfig.getPrefix(), "");
                  Claims claims = Jwts.parser()
                 .setSigningKey(jwtConfig.getSecret().getBytes())
                 .parseClaimsJws(newtoken)
                 .getBody();
             String userName=claims.getSubject();
                  if(userName != null && userName.length() > 0)
                  {
                    Users u=  userRepository.findByuserName(userName);
                      if(u!=null && u.getId()>0 && u.getUserCode()!=null && u.getIsActive().equals(true))
                      {     
                          if(u.getIsAdmin()|| u.getIsOwner())
                           {
//                             Driver driver    = driverRepository.getDriverByDriverCode(driverCode);
                                     Operator operator =  operatorRepository.getOperatorByOperatorCode(operatorCode);
                                     Operator operator1= operatorRepository.getOperatorByOperatorCode(u.getUserCode());
                                    
                                     
                                   if(operator!=null && operator.getOrganizationCode()!=null && operator1!=null &&operator1.getOrganizationCode()!=null && operator1.getOrganizationCode().equals(operator.getOrganizationCode()))
                                   {
                                     res="true";
                                   }else
                                   {
                                     jsonobj.put("responsecode", 401);
				     jsonobj.put("timestamp", new Date());
				     jsonobj.put("message", "Unauthorised Access");
                                    res=jsonobj.toString();
                                   }
                                
                                   
                                           
                              }else
                              {
                                   jsonobj.put("responsecode", 401);
				  jsonobj.put("timestamp", new Date());
				  jsonobj.put("message", "Unauthorised Access");
                                res=jsonobj.toString();
                              }
                         
                      
                      
                      }else
                      {
                                jsonobj.put("responsecode", 401);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Unauthorised Access");
                                 res=jsonobj.toString();
                      }
                      
                      
                  }else
                  {
                      GigflexResponse derr = new GigflexResponse(401, new Date(),
					"Access Token is not valid.");
			res = derr.toString();
                  }
              }else
              {
                GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString();
              }
               
            }
            else
            {
               GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString(); 
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return res;
    }
    
    
     public String orgCodeValidation(HttpHeaders headers,String organizationCode)
     {
         String res="Failed";
        JSONObject jsonobj=new JSONObject();
        try{
            List<String> lst=headers.get("Authorization");
            if(lst!=null && lst.size()>0)
            {
              String tok=lst.get(0);
              if(tok!=null && tok.length()>0)
              {
                  String newtoken = tok.replace(jwtConfig.getPrefix(), "");
                  Claims claims = Jwts.parser()
                 .setSigningKey(jwtConfig.getSecret().getBytes())
                 .parseClaimsJws(newtoken)
                 .getBody();
             String userName=claims.getSubject();
                  if(userName != null && userName.length() > 0)
                  {
                    Users u=  userRepository.findByuserName(userName);
                      if(u!=null && u.getId()>0 && u.getUserCode()!=null)
                      {   Organization org= organizationdao.findByOrganizationCode(organizationCode);
                          if(org!=null && org.getId()>0 && org.getIsActive().equals(true)){
                          if(u.getIsAdmin()|| u.getIsOwner())
                              {
//                             Driver driver    = driverRepository.getDriverByDriverCode(driverCode);
                                    // Operator operator =  operatorRepository.getOperatorByOperatorCode(operatorCode);
                                     Operator operator1= operatorRepository.getOperatorByOperatorCode(u.getUserCode());
                                   if( operator1!=null && operator1.getOrganizationCode()!=null && operator1.getOrganizationCode().equals(organizationCode))
                                   {
                                     res="true";
                                   }else
                                   {
                                     jsonobj.put("responsecode", 401);
				     jsonobj.put("timestamp", new Date());
				     jsonobj.put("message", "Unauthorised Access ");
                                    res=jsonobj.toString();
                                   }
                                   
                                           
                              }else
                              {
                                   jsonobj.put("responsecode", 401);
				  jsonobj.put("timestamp", new Date());
				  jsonobj.put("message", "Unauthorised Access ");
                                res=jsonobj.toString();
                              }
                          }else
                          {
                          
                                   jsonobj.put("responsecode", 401);
				  jsonobj.put("timestamp", new Date());
				  jsonobj.put("message", "Unauthorised Access ");
                                  res=jsonobj.toString();
                          }
                      
                      }else
                      {
                                jsonobj.put("responsecode", 401);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Unauthorised Access ");
                                 res=jsonobj.toString();
                      }
                      
                      
                  }else
                  {
                      GigflexResponse derr = new GigflexResponse(401, new Date(),
					"Access Token is not valid.");
			res = derr.toString();
                  }
              }else
              {
                GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString();
              }
               
            }
            else
            {
               GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString(); 
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return res;
     }
      public String orgCodeValidationwithoutactive(HttpHeaders headers,String organizationCode)
     {
         String res="Failed";
        JSONObject jsonobj=new JSONObject();
        try{
            List<String> lst=headers.get("Authorization");
            if(lst!=null && lst.size()>0)
            {
              String tok=lst.get(0);
              if(tok!=null && tok.length()>0)
              {
                  String newtoken = tok.replace(jwtConfig.getPrefix(), "");
                  Claims claims = Jwts.parser()
                 .setSigningKey(jwtConfig.getSecret().getBytes())
                 .parseClaimsJws(newtoken)
                 .getBody();
             String userName=claims.getSubject();
                  if(userName != null && userName.length() > 0)
                  {
                    Users u=  userRepository.findByuserName(userName);
                      if(u!=null && u.getId()>0 && u.getUserCode()!=null)
                      {   
                          if(u.getIsAdmin()|| u.getIsOwner())
                              {
//                             Driver driver    = driverRepository.getDriverByDriverCode(driverCode);
                                    // Operator operator =  operatorRepository.getOperatorByOperatorCode(operatorCode);
                                     Operator operator1= operatorRepository.getOperatorByOperatorCode(u.getUserCode());
                                   if( operator1!=null && operator1.getOrganizationCode()!=null && operator1.getOrganizationCode().equals(organizationCode))
                                   {
                                     res="true";
                                   }else
                                   {
                                     jsonobj.put("responsecode", 401);
				     jsonobj.put("timestamp", new Date());
				     jsonobj.put("message", "Unauthorised Access ");
                                    res=jsonobj.toString();
                                   }
                                   
                                           
                              }else
                              {
                                   jsonobj.put("responsecode", 401);
				  jsonobj.put("timestamp", new Date());
				  jsonobj.put("message", "Unauthorised Access ");
                                res=jsonobj.toString();
                              }
                          
                         
                      
                      }else
                      {
                                jsonobj.put("responsecode", 401);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Unauthorised Access ");
                                 res=jsonobj.toString();
                      }
                      
                      
                  }else
                  {
                      GigflexResponse derr = new GigflexResponse(401, new Date(),
					"Access Token is not valid.");
			res = derr.toString();
                  }
              }else
              {
                GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString();
              }
               
            }
            else
            {
               GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString(); 
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return res;
     }
}

