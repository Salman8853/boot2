package com.gigflex.prototype.microservices.organization.dtob.api;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.organization.dtob.OrganizationRequest;
import com.gigflex.prototype.microservices.organization.service.OrganizationService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.TokenUtility;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/organizationdriverservice/")
public class OrganizationController {

	@Autowired
	OrganizationService organizationService;
	 @Autowired
        TokenUtility tokenutility;
	@GetMapping("/getOrganizationByOrgCode/{organizationCode}")
	public String getOrganizationByOrgCode(@PathVariable String organizationCode,@RequestHeader HttpHeaders headers) {
              String res="";
               res=tokenutility.orgCodeValidationwithoutactive(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
                return organizationService.getOrganizationByOrgCode(organizationCode);
               }else
               {
               return res;
               }
           
	}

	
	@PutMapping("/updateOrganization/{organizationCode}")
	public String updateOrganization(@PathVariable String organizationCode,  @RequestBody OrganizationRequest orgReq,
			HttpServletRequest httpRequest) {
		if(orgReq!=null)
        {
			String ip = httpRequest.getRemoteAddr();
            return organizationService.updateOrganization(organizationCode, orgReq, ip);
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
            return derr.toString();
        }

	}

}
