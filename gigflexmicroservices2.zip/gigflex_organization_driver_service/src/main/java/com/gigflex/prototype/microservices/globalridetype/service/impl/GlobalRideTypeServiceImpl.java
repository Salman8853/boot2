package com.gigflex.prototype.microservices.globalridetype.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.globalridetype.dtob.GlobalRideType;
import com.gigflex.prototype.microservices.globalridetype.dtob.GlobalRideTypeRequest;
import com.gigflex.prototype.microservices.globalridetype.repository.GlobalRideTypeRepository;
import com.gigflex.prototype.microservices.globalridetype.service.GlobalRideTypeService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.globalridetype.dtob.GlobalRideTypeResponse;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import java.util.ArrayList;

@Service
public class GlobalRideTypeServiceImpl implements GlobalRideTypeService {
	
	@Autowired
	private GlobalRideTypeRepository globalRideTypeDao;

             @Autowired
        GlobalSettingRepository globalSettingRepository;
    
        @Autowired
        LocalSettingRepository localSettingRepository;
        
        @Autowired
	UserTypeRepository userTypeDao;
	
	@Override
	public String getAllGlobalRideType(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (limit > 0) {

			List<GlobalRideType> check = globalRideTypeDao.getAllGlobalRideType();
			Integer count = check.size();

			List<GlobalRideType> globalRideTypelst = globalRideTypeDao.getAllGlobalRideType(pageableRequest);

			if (globalRideTypelst != null && globalRideTypelst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(globalRideTypelst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveNewGlobalRideType(GlobalRideTypeRequest globalRideTypeReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (globalRideTypeReq != null) {

				if ((globalRideTypeReq.getVehicleName() != null && globalRideTypeReq
						.getVehicleName().trim().length() > 0)
						) {

					GlobalRideType grtlst = globalRideTypeDao.getByVehicleName(globalRideTypeReq.getVehicleName());
						
					if (grtlst != null && grtlst.getId() > 0) {

						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message",
								"Vehicle name already exists");
					} else {

						GlobalRideType globalRideTypelst = new GlobalRideType();

						globalRideTypelst
								.setVehicleName(globalRideTypeReq.getVehicleName());
						globalRideTypelst.setBaseRate(globalRideTypeReq.getBaseRate());
						globalRideTypelst.setRatePerMile(globalRideTypeReq.getRatePerMile());
					
						globalRideTypelst.setIpAddress(ip);

						GlobalRideType globalRideTypeRes = globalRideTypeDao.save(globalRideTypelst);

						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());

						if (globalRideTypeRes != null && globalRideTypeRes.getId() > 0) {

							jsonobj.put("message",
									"GlobalRideType has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(globalRideTypeRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("message", "Failed");
						}
				}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Vehicle Name should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}
	
	
	@Override
	public String getGlobalRideTypeByGlobalRideCode(String globalRideCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			GlobalRideType globalRideTypeInDb = globalRideTypeDao.getGlobalRideTypeByGlobalRideCode(globalRideCode);
			if (globalRideTypeInDb != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(globalRideTypeInDb);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllGlobalRideType() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
		
		
			List<GlobalRideType> globalRideTypelst = globalRideTypeDao.getAllGlobalRideType();
			
			if (globalRideTypelst != null && globalRideTypelst.size() > 0) {
                            
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(globalRideTypelst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
	
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}
        @Override
         public String getAllGlobalRideTypeByorganizationCode( String organizationCode,int page, int limit)
         {
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        GlobalRideTypeResponse grtRes =new GlobalRideTypeResponse();
                        List<GlobalRideTypeResponse>grtList=new ArrayList<>();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (limit > 0) {

			List<GlobalRideType> check = globalRideTypeDao.getAllGlobalRideType();
			Integer count = check.size();

			List<GlobalRideType> globalRideTypelst = globalRideTypeDao.getAllGlobalRideType(pageableRequest);
                        String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.CURRENCYSYMBOL);
			if (globalRideTypelst != null && globalRideTypelst.size() > 0) {
                             for(GlobalRideType grt:globalRideTypelst)
                             {
                                grtRes.setId(grt.getId());
                                grtRes.setGlobalRideCode(grt.getGlobalRideCode());
                                grtRes.setVehicleName(grt.getVehicleName());
                                grtRes.setRatePerMile(grt.getRatePerMile());
                                grtRes.setBaseRate(grt.getBaseRate());
                                grtRes.setCurrencySymbol(currencySymbol);
                                grtList.add(grtRes);
                                
                             }
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(grtList);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}
           @Override
          public String getGlobalRideTypeByGlobalRideCodewithorgCode(String globalRideCode,String organizationCode)
          {
            String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         GlobalRideTypeResponse grtRes =new GlobalRideTypeResponse();
			GlobalRideType globalRideTypeInDb = globalRideTypeDao.getGlobalRideTypeByGlobalRideCode(globalRideCode);
                         String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.CURRENCYSYMBOL);
			if (globalRideTypeInDb != null) {
                              grtRes.setId(globalRideTypeInDb.getId());
                              grtRes.setGlobalRideCode(globalRideTypeInDb.getGlobalRideCode());
                              grtRes.setVehicleName(globalRideTypeInDb.getVehicleName());
                              grtRes.setBaseRate(globalRideTypeInDb.getBaseRate());
                              grtRes.setRatePerMile(globalRideTypeInDb.getRatePerMile());
                              grtRes.setCurrencySymbol(currencySymbol);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(grtRes);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
              
          }
          @Override
          public String getAllGlobalRideTypeByorgCode( String organizationCode)
          {
             String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
		
		          GlobalRideTypeResponse grtRes =new GlobalRideTypeResponse();
                        List<GlobalRideTypeResponse>grtList=new ArrayList<>();
			List<GlobalRideType> globalRideTypelst = globalRideTypeDao.getAllGlobalRideType();
			String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, organizationCode, GigflexConstants.CURRENCYSYMBOL);
			if (globalRideTypelst != null && globalRideTypelst.size() > 0) {
                              for(GlobalRideType grt:globalRideTypelst)
                              {
                               grtRes.setId(grt.getId());
                               grtRes.setGlobalRideCode(grt.getGlobalRideCode());
                               grtRes.setVehicleName(grt.getVehicleName());
                               grtRes.setBaseRate(grt.getBaseRate());
                               grtRes.setRatePerMile(grt.getRatePerMile());
                               grtRes.setCurrencySymbol(currencySymbol);
                                grtList.add(grtRes);
                              }
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(grtList);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
	
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
          }

}
