/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.config;

import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 *
 * @author nirbhay.p
 */
public class KafkaThreadProc implements Runnable {
     private static final Logger logger = LoggerFactory.getLogger(KafkaThreadProc.class);

    private KafkaService kafkaService;
    private Object o;

   public KafkaThreadProc(Object o, KafkaService kafkaService) {
        this.o = o;
        this.kafkaService = kafkaService;
    }

    @Override
    public void run() {
        if (o instanceof Driver) {
            Driver driver = (Driver) o;
            kafkaService.sendDriverForSave(driver);
            logger.info("Send Kafka for New driver From Driver Organization Service");
            System.out.println("Send Kafka for New driver From Registration");
        }
    }

}
