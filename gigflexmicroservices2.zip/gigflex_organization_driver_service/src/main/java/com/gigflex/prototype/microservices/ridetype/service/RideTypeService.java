package com.gigflex.prototype.microservices.ridetype.service;

import java.util.List;

import com.gigflex.prototype.microservices.ridetype.dtob.RideTypeRequest;

public interface RideTypeService {
	
	public String getAllRideType();
	public String getRideTypeById(Long id);
	public String getAllRideTypeByOrganizationCode(String organizationCode);
	public String getAllRideTypeByOrganizationCode(String organizationCode,int page, int limit);

	public String getRideTypeByVehicleCode(String vehicleCode);
	public String getRideTypeByVehicleCodeWithName(String vehicleCode);
	public String saveNewRideType(RideTypeRequest rideTypeReq, String ip);
	public String updateRideTypeById( Long id,RideTypeRequest rideTypeReq, String ip);
	public String softDeleteByVehicleCode(String vehicleCode);
    public String softMultipleDeleteByVehicleCode(List<String> vehicleCodeList);
    public String getAllRideTypeByPgae(int page, int limit);
    public String search(String search);
    public String getFarePricing(String vehicleCode,Double miles);
    public String getFarePricingForAllRideType(Double miles,String organizationCode);
    public String getFarePricingForAllRideTypeByPage(Double miles,int page, int limit);

}
