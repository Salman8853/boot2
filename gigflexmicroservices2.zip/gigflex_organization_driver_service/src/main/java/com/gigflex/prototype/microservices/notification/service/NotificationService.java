package com.gigflex.prototype.microservices.notification.service;

import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.notification.dtob.NotificationRequest;
import com.gigflex.prototype.microservices.notification.dtob.NotificationUpdate;

public interface NotificationService {
	
	public String saveNotification(NotificationRequest notificationReq, String ip);
	
	public void saveNotification(Notification notification);

	public String updateNotificationByNotificationCode(NotificationUpdate notificationReq,String notificationCode, String ip);

	public String getAllNotificationByUserCodeWithRead(String userCode);
	
	public String getAllNotificationByUserCodeWithRead(String userCode,int page, int limit);

	public String getAllNotificationByUserCodeWithUnRead(String userCode);
	
	public String getAllNotificationByUserCodeWithUnRead(String userCode,int page, int limit);

}
