package com.gigflex.prototype.microservices.fuel.service;

import java.util.List;

import com.gigflex.prototype.microservices.fuel.dtob.FuelRequest;


public interface FuelService {
	public String updateFuelById(Long id,FuelRequest fuelReq,String ip);
	public String findAllFuel();
	public String getAllFuelByPage(int page, int limit);
	public String findFuelById(Long id);
	public String saveFuel(FuelRequest fuelReq,String ip);
	public String getFuelByFuelCode(String fuelTypeCode);
	public String softDeleteByFuelCode(String fuelTypeCode);
    public String softMultipleDeleteByFuelCode(List<String> fuelTypeCodeList);
	public String search(String search);
}
