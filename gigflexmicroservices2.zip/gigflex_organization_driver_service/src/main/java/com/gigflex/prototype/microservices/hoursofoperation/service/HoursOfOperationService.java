/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.hoursofoperation.service;

import com.gigflex.prototype.microservices.hoursofoperation.dtob.HoursOfOperationRequest;
import java.util.List;

/**
 *
 * @author amit.kumar
 */
public interface HoursOfOperationService {

    public String findHoursOfOperationByDriverCode(String drivercode);

    public String findHoursOfOperationByHoursOfOperationCode(String hoursOfOperationCode);

    public String findHoursOfOperationByDriverCodeAndDayCode(String drivercode, Integer dayCode);

    public String cancelHoursOfOperationByHoursOfOperationCode(String hoursOfOperationCode);

    public String cancelMultipleHoursOfOperationByHoursOfOperationCode(List<String> hoursOfOperationCodeList);

    public String saveHoursOfOperation(HoursOfOperationRequest hoursOfOperationReq, String ip);

    public String updateHoursOfOperationByHoursOfOperationCode(String hoursOfOperationCode, HoursOfOperationRequest hoursOfOperationReq, String ip);

    public String findAllHoursOfOperation();
    
    
    
}
