/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.drivertimeoff.service;

import com.gigflex.prototype.microservices.drivertimeoff.dtob.DriverTimeOffModel;
import java.util.List;

/**
 *
 * @author amit.kumar
 */
public interface DriverTimeOffService {

    public String findAllDriverTimeOff();

    public String findTimeOffByDriverCode(String drivercode);

    public String findTimeOffByDriverCodeAndBetweenDates(String drivercode, String fromdate, String todate);

    public String findDriverTimeOffByTimeOffCode(String timeOffcode);

    public String findDriverTimeOffByOrganizationCode(String organizationcode);

    public String cancelDriverTimeOffBytimeOffCode(String timeOffCode, String reason);

    public String cancelMultipleDriverTimeOffBytimeOffCode(List<String> timeOffCodeList, String reason);

    public String updateDriverTimeOffByTimeOffcode(String timeOffCode, DriverTimeOffModel driverTimeOffReq, String ip);

    public String saveDriverTimeOff(DriverTimeOffModel driverTimeOffReq, String ip);
    
}
