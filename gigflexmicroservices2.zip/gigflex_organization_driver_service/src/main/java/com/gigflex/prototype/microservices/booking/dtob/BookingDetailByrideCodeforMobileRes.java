/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.booking.dtob;

/**
 *
 * @author m.salman
 */
public class BookingDetailByrideCodeforMobileRes {
 private String pickupaddress ;
 private String  dropaddress ;
 private String pickuplat ;
 private String pickuplong ;
 private String dropuplat;
 private String dropofflong ;
 private String price ;
 private String bookingStatus ;
 private String rideCode;

    public String getPickupaddress() {
        return pickupaddress;
    }

    public void setPickupaddress(String pickupaddress) {
        this.pickupaddress = pickupaddress;
    }

    public String getDropaddress() {
        return dropaddress;
    }

    public void setDropaddress(String dropaddress) {
        this.dropaddress = dropaddress;
    }

    public String getPickuplat() {
        return pickuplat;
    }

    public void setPickuplat(String pickuplat) {
        this.pickuplat = pickuplat;
    }

    public String getPickuplong() {
        return pickuplong;
    }

    public void setPickuplong(String pickuplong) {
        this.pickuplong = pickuplong;
    }

    public String getDropuplat() {
        return dropuplat;
    }

    public void setDropuplat(String dropuplat) {
        this.dropuplat = dropuplat;
    }

    public String getDropofflong() {
        return dropofflong;
    }

    public void setDropofflong(String dropofflong) {
        this.dropofflong = dropofflong;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

  

    public String getRideCode() {
        return rideCode;
    }

    public void setRideCode(String rideCode) {
        this.rideCode = rideCode;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }


}
