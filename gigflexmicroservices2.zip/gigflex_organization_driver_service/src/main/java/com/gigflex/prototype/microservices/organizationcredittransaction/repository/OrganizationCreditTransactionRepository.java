/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationcredittransaction.repository;

import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransaction;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface OrganizationCreditTransactionRepository extends JpaRepository<OrganizationCreditTransaction, Long>, JpaSpecificationExecutor<OrganizationCreditTransaction>{

    @Query("SELECT oct FROM OrganizationCreditTransaction oct WHERE oct.isDeleted != TRUE ")
    public List<OrganizationCreditTransaction> getAllOrganizationCreditTransactions();

    @Query("SELECT oct FROM OrganizationCreditTransaction oct WHERE oct.isDeleted != TRUE AND oct.organizationCode = :organizationCode ORDER BY oct.id DESC")
    public List<OrganizationCreditTransaction> getLastTransactionBalanceByOrganizationCode(@Param("organizationCode") String organizationCode);

    @Query("SELECT oct FROM OrganizationCreditTransaction oct WHERE oct.isDeleted != TRUE AND oct.organizationCode = :organizationCode AND  oct.createdAt>=:fromDate  AND oct.createdAt <=:toDate")
    public List<OrganizationCreditTransaction> getTransactionDetailsByOrganizationCodeAndBetweenDates(@Param("organizationCode") String organizationCode,@Param("toDate") Date toDate ,@Param("fromDate") Date fromDate );

}
