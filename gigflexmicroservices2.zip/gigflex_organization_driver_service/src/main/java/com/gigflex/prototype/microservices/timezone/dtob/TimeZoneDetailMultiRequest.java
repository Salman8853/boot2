package com.gigflex.prototype.microservices.timezone.dtob;

import java.util.List;

public class TimeZoneDetailMultiRequest {

	private List<String> timeZoneName;

	public List<String> getTimeZoneName() {
		return timeZoneName;
	}

	public void setTimeZoneName(List<String> timeZoneName) {
		this.timeZoneName = timeZoneName;
	}
	
	
	
}
