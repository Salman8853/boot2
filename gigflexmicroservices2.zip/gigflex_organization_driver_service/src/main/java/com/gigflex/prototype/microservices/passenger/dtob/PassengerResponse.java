/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.passenger.dtob;

import java.util.List;

/**
 *
 * @author amit.kumar
 */
public class PassengerResponse {
    
    private String passengerCode;
    private String passengerName;
    private String primaryContactNumber;
    private String secondaryContactNumber;
    private String pCountryCode;
    private String sCountryCode;
    private String organizationCode;
    private String organizationName;
    private List<BookingAddress> bookingAddressList;

    public String getPassengerCode() {
        return passengerCode;
    }

    public void setPassengerCode(String passengerCode) {
        this.passengerCode = passengerCode;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public String getPrimaryContactNumber() {
        return primaryContactNumber;
    }

    public void setPrimaryContactNumber(String primaryContactNumber) {
        this.primaryContactNumber = primaryContactNumber;
    }

    public String getSecondaryContactNumber() {
        return secondaryContactNumber;
    }

    public void setSecondaryContactNumber(String secondaryContactNumber) {
        this.secondaryContactNumber = secondaryContactNumber;
    }

    public String getpCountryCode() {
        return pCountryCode;
    }

    public void setpCountryCode(String pCountryCode) {
        this.pCountryCode = pCountryCode;
    }

    public String getsCountryCode() {
        return sCountryCode;
    }

    public void setsCountryCode(String sCountryCode) {
        this.sCountryCode = sCountryCode;
    }


    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }    

    public List<BookingAddress> getBookingAddressList() {
        return bookingAddressList;
    }

    public void setBookingAddressList(List<BookingAddress> bookingAddressList) {
        this.bookingAddressList = bookingAddressList;
    }    
    
}
