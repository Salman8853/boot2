/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.booking.repository;

import com.gigflex.prototype.microservices.booking.dtob.AdditionalCharges;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author m.salman
 */
public interface AdditionalChargesRepository extends JpaRepository<AdditionalCharges,Long>,JpaSpecificationExecutor<AdditionalCharges>{
   @Query("SELECT addcharges  FROM  AdditionalCharges addcharges WHERE addcharges.isDeleted != TRUE  AND addcharges.rideCode=:rideCode AND addcharges.additionalFareypeCode=:additionalFareypeCode")
   public AdditionalCharges getadditionalchargesByrideCodeAndfaretypeCode(@Param("rideCode") String rideCode,@Param("additionalFareypeCode") String additionalFareypeCode);
  
   @Query("SELECT addcharges,addFareType.name  FROM  AdditionalCharges addcharges ,AdditionalFareType addFareType WHERE addcharges.isDeleted != TRUE AND addFareType.isDeleted != TRUE AND  addFareType.additionalFareTypeCode = addcharges.additionalFareypeCode AND addcharges.rideCode =:rideCode ")
   public List<Object> getAdditionalchargesByRideCode(@Param("rideCode") String rideCode);
    
}
