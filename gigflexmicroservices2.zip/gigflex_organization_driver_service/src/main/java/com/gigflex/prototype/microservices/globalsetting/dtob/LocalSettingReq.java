/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.globalsetting.dtob;

/**
 *
 * @author nirbhay.p
 */
public class LocalSettingReq {
    private String localSettingValue;

    private String globalSettingCode;

    private String userCode;
    
    private String settingType;

    public String getLocalSettingValue() {
        return localSettingValue;
    }

    public void setLocalSettingValue(String localSettingValue) {
        this.localSettingValue = localSettingValue;
    }

    
    public String getGlobalSettingCode() {
        return globalSettingCode;
    }

    public void setGlobalSettingCode(String globalSettingCode) {
        this.globalSettingCode = globalSettingCode;
    }


    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getSettingType() {
        return settingType;
    }

    public void setSettingType(String settingType) {
        this.settingType = settingType;
    }
    
}
