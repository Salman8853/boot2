/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.additionalfaretype.repository;

import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.additionalfaretype.dtob.AdditionalFareType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public interface AdditionalFareTypeRepository extends JpaRepository<AdditionalFareType, Long>, JpaSpecificationExecutor<AdditionalFareType>{
    @Query("Select cft  from AdditionalFareType cft where cft.isDeleted != TRUE  AND cft.additionalFareTypeCode=:afCode")
    public AdditionalFareType  getAdditionalFareTypeByafCode(@Param("afCode") String afCode);
    
}
