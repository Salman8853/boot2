package com.gigflex.prototype.microservices.notification.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "notification")
public class Notification extends CommonAttributes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "notification_code", unique = true)
	private String notificationCode;

	@Column(length = 65535, columnDefinition = "text",name = "message")
	private String message;
	
	@Column(name = "shortmessage")
	private String shortMessage;
	
	@Column(name = "ride_code")
	private String rideCode;

	@Column(name = "user_code")
	private String userCode;

	@Column(name = "isread")
	private Boolean isRead;
	
	@Column(name = "user_type")
	private String userType;

	@PrePersist
	private void assignUUID() {
		if (this.getNotificationCode() == null || this.getNotificationCode().length() == 0) {
			this.setNotificationCode(UUID.randomUUID().toString());
		}
	}

	public Notification() {
		super();

	}
	
	public Notification(Long id, String notificationCode, String message,
			String shortMessage, String rideCode, String userCode,
			Boolean isRead, String userType) {
		super();
		this.id = id;
		this.notificationCode = notificationCode;
		this.message = message;
		this.shortMessage = shortMessage;
		this.rideCode = rideCode;
		this.userCode = userCode;
		this.isRead = isRead;
		this.userType = userType;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNotificationCode() {
		return notificationCode;
	}

	public void setNotificationCode(String notificationCode) {
		this.notificationCode = notificationCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getShortMessage() {
		return shortMessage;
	}

	public void setShortMessage(String shortMessage) {
		this.shortMessage = shortMessage;
	}

	public String getRideCode() {
		return rideCode;
	}

	public void setRideCode(String rideCode) {
		this.rideCode = rideCode;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public Boolean getIsRead() {
		return isRead;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

	

}
