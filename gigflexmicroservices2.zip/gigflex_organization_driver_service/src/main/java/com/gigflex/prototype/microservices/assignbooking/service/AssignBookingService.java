/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.assignbooking.service;

import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingCancelledRequest;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingRejectedCommentsResponse;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingRequest;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBookingStatus;
import com.gigflex.prototype.microservices.assignbooking.dtob.RideLocationRequest;
import com.gigflex.prototype.microservices.assignbooking.dtob.TrackingRideLocationReqest;
import java.util.List;



/**
 *
 * @author nirbhay.p
 */
public interface AssignBookingService {
    public String getAllValidUnAssignedBooking();
    public String getAllValidUnAssignedBookingByDriverCodeByPage(String driverCode,int page, int limit);
    public String getAllValidUnAssignedBookingByDriverCode(String driverCode);


    public String getAllValidUnAssignedBookingByPage(int page, int limit);
    public String getAllValidUnAssignedBookingExceptCreator(String operatorCode);
    public String getAllValidUnAssignedBookingExceptCreatorByPage(String operatorCode,int page, int limit);
    public String getAllValidUnAssignedBookingExceptCreatorOrganizationByPage(String organizationCode,int page, int limit);
    public String assignBookingAccepted(AssignBookingStatus abs,String ip);
    public String assignBookingInProgress(AssignBookingStatus abs,String ip);
    public String assignBookingRejected(AssignBookingRejectedCommentsResponse abs,String ip);
    public String assignBookingCancelled(AssignBookingCancelledRequest abs,String ip);
    public String assignBookingToDriver(AssignBookingRequest abs,String ip);
    public String changeAssignBookingStatusViaMail(String assignbookingcode,Boolean status,String driverCode);
    public String getAssignedBookingByDriverCode(String driverCode);
    public String getAssignedBookingByDriverCode(String driverCode,int page, int limit);
    public String getAcceptedBookingByDriverCode(String driverCode);
    public String getAcceptedBookingByDriverCodeByPage(String driverCode,String status,String stratDT,String endDT,int page, int limit);
    public String updateRideCurrentLocationByRideCode(String rideCode, RideLocationRequest rideLocReq, String ip);
    public String getCurrentLocationByRideCode(String rideCode);
    public String getAllLatestBookingByDriverCodeWithFilterByPage(String driverCode,List<String> status,String stratDT,String endDT,int page, int limit);
    
    public String getAllLatestBookingByDriverCodeWithFilterForMobile(String driverCode,List<String> status,String stratDT,String endDT);
   
    public String getAllLatestBookingByDriverCodeWithFilterForMobileByPage(String driverCode,List<String> status,String stratDT,String endDT,int page, int limit);

    public String saveRideCurrentLocation(TrackingRideLocationReqest trackingRideLocReq, String ip);

    public String getAllTrackingRideLocation();

    public String getTrackingLastRideLocationByRideCode(String rideCode);
    
    public String getAllTrackingRideLocationByRideCode(String rideCode);
}
