package com.gigflex.prototype.microservices.validation.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.util.SearchCriteria;
import com.gigflex.prototype.microservices.validation.dtob.Validation;


public class ValidationSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public ValidationSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public ValidationSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<Validation> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<Validation>> specs = new ArrayList<Specification<Validation>>();
        for (SearchCriteria param : params) {
            specs.add(new ValidationSpecification(param));
        }
 
        Specification<Validation> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
