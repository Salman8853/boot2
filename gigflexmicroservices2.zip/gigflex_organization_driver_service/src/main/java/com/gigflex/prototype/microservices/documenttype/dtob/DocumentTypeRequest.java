package com.gigflex.prototype.microservices.documenttype.dtob;

public class DocumentTypeRequest {
	
	 private String documentTypeName;

	public String getDocumentTypeName() {
		return documentTypeName;
	}

	public void setDocumentTypeName(String documentTypeName) {
		this.documentTypeName = documentTypeName;
	}

	
}
