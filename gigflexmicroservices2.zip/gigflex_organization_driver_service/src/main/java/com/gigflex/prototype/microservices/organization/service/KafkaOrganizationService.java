package com.gigflex.prototype.microservices.organization.service;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.globalsetting.dtob.GlobalSetting;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.dtob.OrganizationConsume;
import com.gigflex.prototype.microservices.organization.repository.OrganizationDao;
import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransaction;
import com.gigflex.prototype.microservices.organizationcredittransaction.repository.OrganizationCreditTransactionRepository;
import com.gigflex.prototype.microservices.usertype.dtob.UserType;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Autowired;




@Service
public class KafkaOrganizationService {
   
    @Autowired
    OrganizationDao organizationService;
        
    @Autowired
    GlobalSettingRepository globalSettingDao;
        
    @Autowired
    UserTypeRepository userTypeRepository;

    @Autowired
    OrganizationCreditTransactionRepository organizationCreditTransactionDao;      
        
    private static final Logger LOG = LoggerFactory.getLogger(KafkaOrganizationService.class);
    private Organization neworg;

 
    @KafkaListener(topics = "NewOrganization")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
                   
			OrganizationConsume org = objectMapper.readValue(message, OrganizationConsume.class);
                 
                        neworg=new Organization();
                        neworg.setOrganizationName(org.getOrganizationName());
                        neworg.setOrganizationCode(org.getOrganizationCode());
                        neworg.setIsActive(org.getIsActive());
                        neworg.setLang(org.getLang());
                        neworg.setLat(org.getLat());
                        neworg.setIndustryCode(org.getIndustryCode());
                        neworg.setIsVerified(org.getIsVerified());
                        neworg.setIsDeleted(Boolean.FALSE);
                        neworg.setTimezone(org.getTimezone());
			Organization organizationRes = organizationService.save(neworg);
                        
                        if(organizationRes != null && organizationRes.getId() > 0)
                        {
                            UserType userype = userTypeRepository.getUserTypeByUserTypeName(GigflexConstants.USER_TYPE_SUPER_ADMIN);
                            if(userype != null && userype.getId() > 0)
                            {
                                String userTypeCode = userype.getUserTypeCode();
                                
                                GlobalSetting globalSetting = globalSettingDao.getGlobalSettingByUserTypeSettingName(userTypeCode, GigflexConstants.SETTING_NAME_CREDIT_AMOUNT);
                              
                                if(globalSetting != null && globalSetting.getId() > 0)
                                {
                                    try
                                    {
                                        double creditAmount = Double.parseDouble(globalSetting.getSettingValue()); 
                                        
                                        OrganizationCreditTransaction oc= new OrganizationCreditTransaction();
                                        oc.setBalanceAmount(creditAmount);
                                        oc.setBookingid(null); 
                                        oc.setOrganizationCode(organizationRes.getOrganizationCode()); 
                                        oc.setTransactionBy(GigflexConstants.USER_TYPE_SUPER_ADMIN); 
                                        oc.setCreditAmount(creditAmount); 
                                        oc.setTransactionType(GigflexConstants.TRANSACTION_TYPE_CREDIT);
                                        
                                        OrganizationCreditTransaction organizationCreditTransactionRes = organizationCreditTransactionDao.save(oc);
                                    
                                    }
                                    catch(Exception e)
                                    {
                                        e.printStackTrace();
                                    }                                    
                                }
                            }
                        }
                        
                        

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
     
    
	
	
}