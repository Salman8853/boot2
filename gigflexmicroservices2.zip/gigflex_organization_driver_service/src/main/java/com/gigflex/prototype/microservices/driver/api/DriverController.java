package com.gigflex.prototype.microservices.driver.api;


import com.gigflex.prototype.microservices.driver.dtob.DefaultVehicleUpdateRequest;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.dtob.DriverDocsReq;
import com.gigflex.prototype.microservices.driver.dtob.DriverDocumentsReq;
import com.gigflex.prototype.microservices.driver.dtob.DriverRequest;
import com.gigflex.prototype.microservices.driver.dtob.DriverUpRequest;
import com.gigflex.prototype.microservices.driver.dtob.DriverVehicleRequest;
import com.gigflex.prototype.microservices.driver.dtob.GeneralDetailRes;
import com.gigflex.prototype.microservices.driver.dtob.PersonalDetailTabRes;
import com.gigflex.prototype.microservices.driver.dtob.Users;
import com.gigflex.prototype.microservices.driver.service.DriverService;
import com.gigflex.prototype.microservices.operator.repository.UserRepository;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.util.TokenUtility;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class DriverController {

	@Autowired
	public DriverService driverService;
        @Autowired
        UserRepository userRepository;
        @Autowired
        TokenUtility tokenUtility;
	@GetMapping("/driver/{search}")
	public String search(@PathVariable("search") String search) {
		return driverService.search(search);
	}

	@GetMapping("/getAllDriver")
	public String getAllDriver() {
		return driverService.findAllDriver();
	}
	
//	@GetMapping("/getAllDriverWithDocument")
//	public String getAllDriverWithDocument() {
//		return driverService.getAllDriverWithDocument();
//	}

	@GetMapping(path = "/getAllDriverByPage")
	public String getAllDriverByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String driver = driverService.getAllDriverByPage(page, limit);

		return driver;

	}

	@GetMapping("/getDriver/{id}")
	public String getDriverById(@PathVariable Long id) {
		return driverService.findDriverById(id);
	}

	@GetMapping("/getDriverByDriverCode/{driverCode}")
	public String getDriverByDriverCode(@PathVariable String driverCode,@RequestHeader HttpHeaders headers) {
            String res="";
           res= tokenUtility.userValidationwithoutactive(headers, driverCode);
              if(res.equalsIgnoreCase("true"))
              {
              return driverService.getDriverByDriverCode(driverCode);
              }else
              {
               return res;  
              }
		
	}
        
       
	
	@GetMapping("/getDriverByVehicleTypeCode/{vehicleCode}")
	public String getDriverByVehicleTypeCode(@PathVariable String vehicleCode) {
            
		return driverService.getDriverByVehicleTypeCode(vehicleCode);
	}
	
	@GetMapping("/getDriverByVehicleTypeCodeByPage/{vehicleCode}")
	public String getDriverByVehicleTypeCodeByPage(@PathVariable String vehicleCode,@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String driver = driverService.getDriverByVehicleTypeCode(vehicleCode, page, limit);

		return driver;
		
	}
	
	@GetMapping("/getDriverByVehicleTypeCodeAndOrganizationCode/{vehicleCode}/{organizationCode}")
	public String getDriverByVehicleTypeCodeAndOrganizationCode(@PathVariable String vehicleCode,@PathVariable String organizationCode,@RequestHeader HttpHeaders headers) {
              String res="";
               res= tokenUtility.userValidation(headers, organizationCode);
              if(res.equalsIgnoreCase("true"))
              {
              return driverService.getDriverByVehicleTypeCodeAndOrganizationCode(vehicleCode, organizationCode);
              }else
              {
              return res;
              }
		
	}
        
        
        
	
	@GetMapping("/getDriverByVehicleTypeCodeAndOrganizationCodeByPage/{vehicleCode}/{organizationCode}")
	public String getDriverByVehicleTypeCodeAndOrganizationCodeByPage(@PathVariable String vehicleCode,@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
            String res="";
               res= tokenUtility.userValidation(headers, organizationCode);
              if(res.equalsIgnoreCase("true"))
              {
                 return  driverService.getDriverByVehicleTypeCodeAndOrganizationCode(vehicleCode, organizationCode, page, limit);
              }else
              {
              return res;
              }	
	}

	@DeleteMapping("/softDeleteDriverByDriverCode/{driverCode}")
	public String softDeleteDriverByDriverCode(@PathVariable String driverCode) {
		return driverService.softDeleteByDriverCode(driverCode);
	}
	
	@GetMapping("/getDriverByOrgCode/{organizationCode}")
	public String getDriverByOrgCode(@PathVariable String organizationCode,@RequestHeader HttpHeaders headers) {
             String res="";
               res= tokenUtility.userValidation(headers, organizationCode);
              if(res.equalsIgnoreCase("true"))
              {
              return driverService.getDriverByOrgCode(organizationCode);
              }else
              {
              return res;
              }
		
	}
	
	@GetMapping("/getDriverByOrgCodeByPage/{organizationCode}")
	public String getDriverByOrgCodeByPage(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
            
             String res="";
               res= tokenUtility.userValidation(headers, organizationCode);
              if(res.equalsIgnoreCase("true"))
              {
              return driverService.getDriverByOrgCodeByPage(organizationCode, page, limit);
              }else
              {
              return res;
              }

		
	}
	


	@DeleteMapping("/softMultipleDeleteByDriverCode/{driverCodeList}")
	public String softMultipleDeleteByDriverCode(
			@PathVariable List<String> driverCodeList) {
		if (driverCodeList != null && driverCodeList.size() > 0) {
			return driverService.softMultipleDeleteByDriverCode(driverCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

	@PutMapping("/updateDriver/{id}")
	public String updateDriver(@PathVariable Long id,
			@RequestBody DriverUpRequest driverReq, HttpServletRequest request) {
		if(driverReq!=null && driverReq.getName()!=null && driverReq.getName().trim().length()>0 && driverReq.getContactNumber()!=null && driverReq.getOperatorCode()!=null && driverReq.getOrganizationCode()!=null &&  id!=null && id>0){
		
				String ip = request.getRemoteAddr();
				return driverService.updateDriverById(id, driverReq, ip);
		}
                else{
                   GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Invalid Input");
			return derr.toString(); 
                }

//		if (id == null) {
//			return "Driver with Id : (" + id + ") Not found.";
//		} else if (getUserEmailAvailability(driverReq.getEmailId())) {
//			GigflexResponse derr = new GigflexResponse(400, new Date(),
//					"EmailId already exists.");
//			return derr.toString();
//
//		} else {
//			String ip = request.getRemoteAddr();
//
//			return driverService.updateDriverById(id, driverReq, ip);
//
//		}

	}

	@PostMapping("/createDriver")
	public String createDriver(@RequestBody DriverRequest driverReq,
			HttpServletRequest request) {
		if (GigflexUtility.emailPatternValidation(driverReq.getEmailId()) == true) {

			if (getUserEmailAvailability(driverReq.getEmailId())) {
				String ip = request.getRemoteAddr();
				return driverService.saveDriver(driverReq, ip);
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"EmailId already exists.");
				return derr.toString();

			}

		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Please check your email format.");
			return derr.toString();
		}

	}
        
        @PostMapping("/assignVehicleToDriver")
	public String assignVehicleToDriver(@RequestBody DriverVehicleRequest driverVReq,
			HttpServletRequest request) {
		if (driverVReq!=null && driverVReq.getDriverCode()!=null && driverVReq.getDriverCode().trim().length()>0 &&
                        driverVReq.getVehicleCode()!=null &&  driverVReq.getVehicleCode().trim().length()>0) {
                                driverVReq.setDriverCode(driverVReq.getDriverCode().trim());
                                driverVReq.setVehicleCode(driverVReq.getVehicleCode().trim());
				String ip = request.getRemoteAddr();
				return driverService.assignVehicleToDriver(driverVReq, ip);
			

		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Vehicle code and Driver code should not be blank.");
			return derr.toString();
		}

	}
        
	@PutMapping("/UnassignVehicleToDriver/{driverCode}")
	public String UnassignVehicleToDriver(@PathVariable String driverCode,
			HttpServletRequest request) {
            
		if (driverCode != null && driverCode.trim().length() > 0) {

			String ip = request.getRemoteAddr();
			return driverService.UnassignVehicleToDriver(driverCode.trim(), ip);

		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Driver code should not be blank.");
			return derr.toString();
		}

	}
	
	@PutMapping("/UnassignVehicleToDriverByVehicleAndDriverCode/{driverCode}/{vehicleCode}")
	public String UnassignVehicleToDriverByVehicleAndDriverCode(@PathVariable String driverCode,@PathVariable String vehicleCode,
			HttpServletRequest request) {
		if (driverCode != null && driverCode.trim().length() > 0 && vehicleCode != null && vehicleCode.trim().length() > 0) {

			String ip = request.getRemoteAddr();
			return driverService.UnassignVehicleToDriverByVehicleAndDriverCode(driverCode.trim(), vehicleCode.trim(), ip);

		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Driver code And Vehicle Code should not be blank.");
			return derr.toString();
		}

	}

	@GetMapping("/getEmailAvailability/{emailId}")
	public Boolean getUserEmailAvailability(
			@PathVariable("emailId") String emailId) {
		Boolean EmailStatus = false;
		try {
			Driver email = driverService.getUserEmail(emailId.trim());
			if (email == null) {
                           Users usr= userRepository.findByEmailID(emailId.trim());
                           if(usr == null)
                           {
				EmailStatus = true;
                           }
			}
		} catch (Exception e) {
			EmailStatus = true;
			e.printStackTrace();
		}
		return EmailStatus;
	}
        
        
        @GetMapping("/getEmailAvailabilityFromUsers/{emailId}")
	public Boolean getEmailAvailabilityFromUsers(
			@PathVariable("emailId") String emailId) {
		Boolean EmailStatus = false;
		try {
			Users usr= userRepository.findByEmailID(emailId.trim());
                           if(usr == null)
                           {
				EmailStatus = true;
                           }
		} catch (Exception e) {
			EmailStatus = true;
			e.printStackTrace();
		}
		return EmailStatus;
	}
        
        @PostMapping("/sendRegistrationLinkToDriver/{operatorCode}/{driverEmailID}/{organizationCode}")
        public String sendRegistrationLinkToDriver(@PathVariable("operatorCode") String operatorCode,@PathVariable("driverEmailID") String driverEmailID,@PathVariable("organizationCode")String organizationCode){
            return driverService.sendRegistrationLinkTODriverByOperator(operatorCode, driverEmailID,organizationCode);
        }
        
        @GetMapping("/getDriversDetailByOperatorCode/{operatorCode}")
        public String getDriversDetailByOperatorCode(@PathVariable("operatorCode") String operatorCode,@RequestHeader HttpHeaders headers){
             String res="";
           res= tokenUtility.operatorValidation(headers, operatorCode);
              if(res.equalsIgnoreCase("true"))
              {
               return driverService.getDriverDetailByOperatorCode(operatorCode);
              }else
              {
              return res;
              }
           
        }
        
        @GetMapping(path="/getDriversDetailByOperatorCodeByPage/{operatorCode}")
        public String getDriversDetailByOperatorCodeByPage(@PathVariable String operatorCode,@RequestParam(value = "page", defaultValue = "0") int page,
                @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
            
             String res="";
             res= tokenUtility.operatorValidation(headers, operatorCode);
              if(res.equalsIgnoreCase("true"))
              {
               return  driverService.getDriverDetailByOperatorCodeByPage(operatorCode, page, limit);
              }else
              {
              return res;
              }
           
        }
        
        @PutMapping("/verifyDriverByDriverCode/{driverCode}/{approveStatus}")
        public String verifyDriverByDriverCode(@PathVariable("driverCode") String driverCode,@PathVariable("approveStatus") Boolean approveStatus){
            return driverService.verifyDriverByDriverCode(driverCode, approveStatus);
        }
        
//        @PostMapping("/driverRegistration")
//        public String driverRegistration(@RequestBody DriverRegistrationRequest driverRegistrationRequest,HttpServletRequest httpServletRequest){
//            if (GigflexUtility.emailPatternValidation(driverRegistrationRequest.getEmailId()) == true) {
//
//			if (getUserEmailAvailability(driverRegistrationRequest.getEmailId())) {
//				    String ip=httpServletRequest.getRemoteAddr();
//                              return driverService.driverRegistration(driverRegistrationRequest, ip);
//			} else {
//				GigflexResponse derr = new GigflexResponse(400, new Date(),
//						"EmailId already exists.");
//				return derr.toString();
//
//			}
//
//		} else {
//			GigflexResponse derr = new GigflexResponse(400, new Date(),
//					"Please check your email format.");
//			return derr.toString();
//		}
//        }
        
        @PostMapping ("/sendLinkToDriverForCreateCredential/{driverCode}")
        public String sendLinkToDriverForCreateCredential(@PathVariable("driverCode") String driverCode){
           return driverService.sendLinkToDriverForCreateCredential(driverCode);
        }
//        @PostMapping ("/createDriverCredential")
//        public String createDriverCredential(@RequestBody DriverCredentialRequest credentialRequest,HttpServletRequest httpServletRequest){
//             String ip=httpServletRequest.getRemoteAddr();
//            return driverService.createDriverCredential(credentialRequest, ip);
//        }
        
         @GetMapping("/getDefaultVehicleDetailByDriverCode/{driverCode}")
	public String getDefaultVehicleDetailByDriverCode(@PathVariable String driverCode,@RequestHeader HttpHeaders headers) {
            String res="";
           res= tokenUtility.userValidation(headers, driverCode);
              if(res.equalsIgnoreCase("true"))
              {
              return driverService.getDefaultVehicleDetailByDriverCode(driverCode);
              }else
              {
               return res;  
              }
		
	}
        
        @PutMapping("/updateDefaultVehicleByDriverCode/{drivercode}")
	public String updateDefaultVehicleByDriverCode(@PathVariable String drivercode,
			@RequestBody DefaultVehicleUpdateRequest defaultVehicleReq, HttpServletRequest request) {
		if(defaultVehicleReq!=null && defaultVehicleReq.getDefaultVehicleCode()!=null && defaultVehicleReq.getDefaultVehicleCode().trim().length()>0 && defaultVehicleReq.getDriverCode()!=null && defaultVehicleReq.getDriverCode().trim().length()>0  && drivercode!=null ){
		
                    String ip = request.getRemoteAddr();
                    return driverService.updateDefaultVehicleByDriverCode(drivercode, defaultVehicleReq, ip);
		}
                else{
                   GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Invalid Input");
			return derr.toString(); 
                }


	}
         @GetMapping("/getAllDetailBydriverCode/{driverCode}")
         public String getAllDetailBydriverCode(@PathVariable String driverCode)
           {
              if(driverCode!=null && driverCode.trim().length()>0)
              {
                 return driverService.getAllDetailBydriverCode(driverCode);
              }else
              {
                  GigflexResponse derr = new GigflexResponse(400, new Date(),
					"DriverCode should not be blank");
			return derr.toString(); 
              
              }
           }
          @GetMapping("/getPersonaldetailsTabsBydriverCode/{driverCode}")
         public String getPersonaldetailsTabsBydriverCode(@PathVariable String driverCode)
         {  if(driverCode!=null && driverCode.trim().length()>0)
            {
          return driverService.getPersonaldetailsTabsBydriverCode(driverCode);
            }else
         {
           
                  GigflexResponse derr = new GigflexResponse(400, new Date(),
					"DriverCode should not be blank");
			return derr.toString(); 
         }
     }
         
           @PutMapping("/updatePersonaldetailsTabsBydriverCode/{driverCode}")
         public String updatePersonaldetailsTabsBydriverCode(@RequestBody PersonalDetailTabRes req,@PathVariable String driverCode)
         {  if(driverCode!=null && driverCode.trim().length()>0 && req.getName()!=null && req.getName().trim().length()>0 && req.getMobileNo()!=null &&req.getMobileNo().trim().length()>0 && req.getAddress()!=null && req.getAddress().trim().length()>0 && req.getCity()!=null && req.getCity().trim().length()>0 && req.getCountry()!=null &&req.getCountry().trim().length()>0 && req.getDob()!=null && req.getDob().trim().length()>0)
            {
                  return driverService.updatePersonaldetailsTabsBydriverCode(driverCode,req);
            }else
           {
           
                  GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Please fill Mandatory fields");
			return derr.toString(); 
         }
     }
         
         
         
          @GetMapping("/getGeneraldetailsTabsBydriverCode/{driverCode}")
         public String getGeneraldetailsTabsBydriverCode(@PathVariable String driverCode)
         {  if(driverCode!=null && driverCode.trim().length()>0)
            {
                 return driverService.getGeneraldetailsTabsBydriverCode(driverCode);
                 
                 
            }else
              {
           
                  GigflexResponse derr = new GigflexResponse(400, new Date(),
					"DriverCode should not be blank");
			return derr.toString(); 
              }
           
      }
          @PutMapping("/updateGeneratDetailsBydriverCode/{driverCode}")
         public String updateGeneratDetailsBydriverCode(@RequestBody GeneralDetailRes req , @PathVariable String driverCode)
         {  if(driverCode!=null && driverCode.trim().length()>0  && req.getEmail()!=null && req.getEmail().trim().length()>0 && req.getName()!=null &&req.getName().trim().length()>0 )
            {    
                if(req.getPassword()!=null && req.getCpassword()!=null && req.getPassword().trim().length()>0&&  req.getCpassword().trim().length()>0)
                {
                if(!( req.getPassword().equals(req.getCpassword())))
                  {
                   
                     GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Password is  Mismatch");
			return derr.toString(); 
                  }
                }
                 return driverService.updatedriverPassword(req,driverCode);
                 
            }else
              {
           
                  GigflexResponse derr = new GigflexResponse(400, new Date(),
					"DriverCode And Email should not be blank");
			return derr.toString(); 
              }
           
      }
      
         
          @GetMapping("/getOthersdetailsTabsBydriverCode/{driverCode}")
         public String getOthersdetailsTabsBydriverCode(@PathVariable String driverCode)
         {  if(driverCode!=null && driverCode.trim().length()>0)
            {
                 return driverService.getOthersdetailsTabsBydriverCode(driverCode);
                 
                 
            }else
              {
           
                  GigflexResponse derr = new GigflexResponse(400, new Date(),
					"DriverCode should not be blank");
			return derr.toString(); 
              }
           
      }
         @PutMapping("/updateOthersdetailsTabsBydriverCode/{driverCode}")
         public String updateOthersdetailsTabsBydriverCode(@RequestBody DriverDocsReq req ,@PathVariable String driverCode)
         {  if(driverCode!=null && driverCode.trim().length()>0&&req.getEmail()!=null && req.getEmail().trim().length()>0)
            {
                if(req.getDdList()!=null && req.getDdList().size()>0) 
                {
                   List<DriverDocumentsReq> ddreq= req.getDdList();
                   for(DriverDocumentsReq dd:ddreq)
                    {
                        if(dd.getDocValue()==null || dd.getDocValue().trim().length()==0)
                        {
                             GigflexResponse derr = new GigflexResponse(404, new Date(),
					"Document value should not be blank.");
			return derr.toString(); 
                        }
                    }
                }
                return driverService.updateOthersdetailsTabsBydriverCode(req,driverCode);
                 
                 
            }else
              {
           
                  GigflexResponse derr = new GigflexResponse(400, new Date(),
					"please fill mandatory fields");
			return derr.toString(); 
              }
           
      }
         @GetMapping("getDriverContactDetailByRideCodeforMobile/{rideCode}")
     public String getDriverContactDetailByRideCodeforMobile(@PathVariable String rideCode)
     {
       if(rideCode!=null && rideCode.trim().length()>0)
       {
          return driverService.getDriverContactDetailByRideCodeforMobile(rideCode);
       }else
       {
         GigflexResponse derr = new GigflexResponse(400, new Date(),"ride Code not found");
			return derr.toString();
       }
     }
     
}
