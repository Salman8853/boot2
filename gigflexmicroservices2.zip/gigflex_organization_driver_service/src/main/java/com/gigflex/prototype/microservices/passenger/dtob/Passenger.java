/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.passenger.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "passenger")
public class Passenger extends CommonAttributes implements Serializable{
    
        @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
        
	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "passenger_code", unique = true)
	private String passengerCode;

	@Column(name = "passengername", nullable = false)
	private String passengerName;
	
	
	@Column(name = "organization_code")
	private String organizationCode;
        
        
        @Column(name = "primarycontactnumber", nullable = false)
	private String primaryContactNumber;

	@Column(name = "secondarycontactnumber", nullable = false)
	private String secondaryContactNumber;
	

	@Column(name = "pcountry_code")
        private String pCountryCode;
	
	@Column(name = "scountry_code")
        private String sCountryCode;

	
    @PrePersist
    private void assignUUID() {
            if (this.getPassengerCode() == null || this.getPassengerCode().length() == 0) {
                    this.setPassengerCode(UUID.randomUUID().toString());
            }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPassengerCode() {
        return passengerCode;
    }

    public void setPassengerCode(String passengerCode) {
        this.passengerCode = passengerCode;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    
    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getPrimaryContactNumber() {
        return primaryContactNumber;
    }

    public void setPrimaryContactNumber(String primaryContactNumber) {
        this.primaryContactNumber = primaryContactNumber;
    }

    public String getSecondaryContactNumber() {
        return secondaryContactNumber;
    }

    public void setSecondaryContactNumber(String secondaryContactNumber) {
        this.secondaryContactNumber = secondaryContactNumber;
    }

    public String getpCountryCode() {
        return pCountryCode;
    }

    public void setpCountryCode(String pCountryCode) {
        this.pCountryCode = pCountryCode;
    }

    public String getsCountryCode() {
        return sCountryCode;
    }

    public void setsCountryCode(String sCountryCode) {
        this.sCountryCode = sCountryCode;
    }
        
    
}
