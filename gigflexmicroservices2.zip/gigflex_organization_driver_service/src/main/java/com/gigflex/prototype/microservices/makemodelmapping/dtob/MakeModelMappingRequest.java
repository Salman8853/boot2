package com.gigflex.prototype.microservices.makemodelmapping.dtob;


public class MakeModelMappingRequest {

	private String modelName;

	private String makeCode;

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getMakeCode() {
		return makeCode;
	}

	public void setMakeCode(String makeCode) {
		this.makeCode = makeCode;
	}
	
	
	

}
