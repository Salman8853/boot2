package com.gigflex.prototype.microservices.maketype.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "maketype")
public class MakeType extends CommonAttributes implements Serializable{
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "vech_code", unique = true)
    private String vehicleCode;

    @Column(name = "vech_name", nullable = false)
    private String vehicleName;
    
    @Column(name = "abbrev_name", nullable = false)
    private String abbrevationName;
    
    @PrePersist
    private void assignUUID() {
        if(this.getVehicleCode()==null || this.getVehicleCode().length()==0)
        {
            this.setVehicleCode((UUID.randomUUID().toString()));
        }
    }
    

	public MakeType(Long id, String vehicleCode, String vehicleName,
			String abbrevationName) {
		super();
		this.id = id;
		this.vehicleCode = vehicleCode;
		this.vehicleName = vehicleName;
		this.abbrevationName = abbrevationName;
	}



	public MakeType() {
		// TODO Auto-generated constructor stub
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVehicleCode() {
		return vehicleCode;
	}

	public void setVehicleCode(String vehicleCode) {
		this.vehicleCode = vehicleCode;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public String getAbbrevationName() {
		return abbrevationName;
	}

	public void setAbbrevationName(String abbrevationName) {
		this.abbrevationName = abbrevationName;
	}
    
    

}
