package com.gigflex.prototype.microservices.booking.service.impl;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBooking;
import com.gigflex.prototype.microservices.assignbooking.repository.AssignBookingRepository;
import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.booking.dtob.BookingAllResponse;
import com.gigflex.prototype.microservices.booking.dtob.BookingCompletedUpdateResponse;
import com.gigflex.prototype.microservices.booking.dtob.BookingRequest;
import com.gigflex.prototype.microservices.booking.dtob.BookingResponse;
import com.gigflex.prototype.microservices.booking.dtob.BookingUpdateRequest;
import com.gigflex.prototype.microservices.booking.repository.BookingDao;
import com.gigflex.prototype.microservices.booking.search.BookingSpecificationsBuilder;
import com.gigflex.prototype.microservices.booking.service.BookingService;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.ridetype.dtob.RideType;
import com.gigflex.prototype.microservices.ridetype.repository.RideTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.utility.GigflexDateUtil;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.booking.dtob.AdditionalCharges;
import com.gigflex.prototype.microservices.booking.dtob.AdditionalChargesReq;
import com.gigflex.prototype.microservices.booking.dtob.AdditionalChargesResponse;
import com.gigflex.prototype.microservices.booking.dtob.BookingDetailByrideCodeforMobileRes;
import com.gigflex.prototype.microservices.booking.repository.AdditionalChargesRepository;
import com.gigflex.prototype.microservices.device.dtob.DeviceDetail;
import com.gigflex.prototype.microservices.device.repository.DeviceDetailRepository;

import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.dtob.EligibleDriverResponse;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.drivertimeoff.dtob.DriverTimeOff;
import com.gigflex.prototype.microservices.drivertimeoff.repository.DriverTimeOffDao;
import com.gigflex.prototype.microservices.globalridetype.dtob.GlobalRideType;
import com.gigflex.prototype.microservices.globalsetting.dtob.GlobalSetting;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.hoursofoperation.dtob.HoursOfOperation;
import com.gigflex.prototype.microservices.hoursofoperation.repository.HoursOfOperationDao;
import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.notification.service.NotificationService;
import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransaction;
import com.gigflex.prototype.microservices.organizationcredittransaction.repository.OrganizationCreditTransactionRepository;
import com.gigflex.prototype.microservices.passenger.dtob.Passenger;
import com.gigflex.prototype.microservices.passenger.repository.PassengerDao;
import com.gigflex.prototype.microservices.rideexchange.dtob.RideExchange;
import com.gigflex.prototype.microservices.rideexchange.repository.RideExchangeRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.usertype.dtob.UserType;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.utility.PushNotification;
import com.gigflex.prototype.microservices.utility.SendMessageAPI;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetail;
import com.gigflex.prototype.microservices.vehicledetail.repository.VehicleDetailRepository;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class BookinServiceImpl implements BookingService {
	
    private static final Logger LOG = LoggerFactory.getLogger(BookinServiceImpl.class);
    
    @Autowired
	KafkaService kafkaService;
	
    @Autowired
    private TimeZoneRepository timeZoneRepository;    


	@Autowired
	private BookingDao bookingDao;
	
	@Autowired
	OperatorRepository operatorRepository;
        
	@Autowired
	private OrganizationRepository orgDao;

	@Autowired
	private RideTypeRepository vehTypeDao;

	@Autowired
	private AssignBookingRepository assgnBookingDao;

	@Autowired
	private OperatorRepository operatorDao;
        
        @Autowired
	private DriverRepository driverDao;
        
        @Autowired
        GlobalSettingRepository globalSettingRepository;
    
        @Autowired
        LocalSettingRepository localSettingRepository;
        
        @Autowired
	UserTypeRepository userTypeDao;
        
        @Autowired
        RideTypeRepository rideTypeDao; 
        
        @Autowired
        VehicleDetailRepository vehicleDetailDao;
        
        @Autowired
        VehicleDetailRepository vehicledetailrepository;

        
        @Autowired
        private NotificationService notificationService;
        @Autowired
        RideTypeRepository rideTypeRepository;
    	private String subjectComplt = "Booking Request Completion Notification";
        
        
        @Autowired
        private PassengerDao passengerDao;
        
        
        @Autowired
        DriverTimeOffDao driverTimeOffDao;
        
        @Autowired
        HoursOfOperationDao hoursOfOperationDao;
    	
        @Autowired
        AdditionalChargesRepository additionalchargesdao;
  
        
        @Autowired
        OrganizationCreditTransactionRepository organizationCreditTransactionRepository;
        
        @Autowired
        RideExchangeRepository rideExchangeDao;
        
        @Autowired
        DeviceDetailRepository deviceDetailDao;
        
    	@Value("${email.service.url}")
    	private String mailServiceURL;
        
        @Value("${message.appKey}")
        private String appKey;//="5f660e09-e0b7-474e-889c-fd3c077f195c";
        
        @Value("${message.appSecret}")
        private String appSecret;//="qegMoUCBT0OGXuASFMPB+Q==";

        @Value("${message.url}")
        private String url;//="https://messagingapi.sinch.com/v1/sms/";
        
        private String shortMessage;

        @Value("${setting.name.sms.notifications}")
        private String smsNotiName;
        
        @Value("${setting.name.mail.notifications}")
        private String mailNotiName;
        
//        @Value("${notification.deviceid}")
//        private String deviceId;
        
        @Value("${notification.fcm.url}")
        private String FMCurl;
        
        @Value("${notification.fcm.authkey}")
        private String authKey;
        
        
        private Character unitMiles ='M';
        
	@Override
	public String updateBookingById(Long id, BookingUpdateRequest bookingReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (id > 0 && bookingReq != null) {
				if (bookingReq.getPassengerName() != null && bookingReq.getPassengerName().trim().length() > 0
						&& bookingReq.getOrganizationCode() != null
						&& bookingReq.getOrganizationCode().trim().length() > 0 && bookingReq.getVehicleCode() != null
						&& bookingReq.getVehicleCode().trim().length() > 0 && bookingReq.getOperatorCode() != null
						&& bookingReq.getOperatorCode().trim().length() > 0 && bookingReq.getPickUpTime() != null
						&& bookingReq.getPickUpTime().trim().length() > 0 &&bookingReq.getDropOffTime()!=null && bookingReq.getDropOffTime().trim().length()>0
                                        && bookingReq.getNoOfPassengers()!=null && bookingReq.getNoOfPassengers()>0) {

					Booking bookingInDb = bookingDao.getBookingById(id);

					

					if (bookingInDb != null && bookingInDb.getId() > 0) {
                                            
                                            if(!(bookingInDb.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingInProgressStatus)) )
                                            {
                                                if(!(bookingInDb.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingCompletedStatus)) )
                                            {


//						Organization org = orgDao.findByOrganizationCode(bookingReq.getOrganizationCode());
//						if (org != null && org.getId() > 0) {

                                                Operator operator = operatorDao.getOperatorByOperatorCode(bookingReq.getOperatorCode());
                                                if (operator != null && operator.getId() > 0) {

                                                        RideType veh = vehTypeDao.getRideTypeByVehicleCode(bookingReq.getVehicleCode());
                                                        if (veh != null && veh.getId() > 0) {

//					
					try {
						
                                         if( !(GigflexDateUtil.isDate(bookingReq.getPickUpTime().trim(), GigflexConstants.YYYY_MM_DD_HH_MM_SS)))
                                            {
                                           GigflexResponse derr = new GigflexResponse(400, new Date(),
					    "Plz send PickUpDate in correct format("+GigflexConstants.YYYY_MM_DD_HH_MM_SS+") ");
					    return derr.toString();
                                               }
                                             if( !(GigflexDateUtil.isDate(bookingReq.getDropOffTime().trim(), GigflexConstants.YYYY_MM_DD_HH_MM_SS)))
                                             {
                                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send DropUpTime in correct format("+GigflexConstants.YYYY_MM_DD_HH_MM_SS+") ");
	                                            return derr.toString();
                                          }
					} catch (Exception ex) {
						ex.printStackTrace();
						GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send date in correct format("+GigflexConstants.dateFormatterForSave+") ");
						return derr.toString();
					}
                                                
                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, bookingReq.getOrganizationCode(), GigflexConstants.TimeZone);
                                                
                                                TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                                Date pickuptime= null;
                                                Date dropuptime=null;
                                                if (tz != null && tz.getId() > 0) {

                                                   pickuptime=GigflexDateUtil.convertStringDateToGMT(bookingReq.getPickUpTime().trim(), tz.getTimeZoneName(),GigflexConstants.dateFormatterForSave);

                                               }   
                                                
                                               if (tz != null && tz.getId() > 0) {

                                                   dropuptime=GigflexDateUtil.convertStringDateToGMT(bookingReq.getDropOffTime().trim(), tz.getTimeZoneName(),GigflexConstants.dateFormatterForSave);

                                               }   
                                                if (pickuptime == null ||dropuptime==null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Date conversion has been failed.");
							return derr.toString();
						}
                                                Date currentTime = new Date();
					         if (pickuptime.after(currentTime) && dropuptime.after(currentTime) ) {

                                                double currentBalance = bookingInDb.getCustomerFare();
						Booking booking = bookingInDb;

//						if (!(skillMasterReq.getSkillname().equals(skills.getSkillName()))) {

//						Booking bookinglst = skillMasterDao.getBySkillName(skillMasterReq.getSkillname());
//									
//							if (skilllst != null && skilllst.getId() > 0) {
//								jsonobj.put("responsecode", 409);
//								jsonobj.put("timestamp", new Date());
//								jsonobj.put("message",
//										"Skill name already exists");
//							} else {
//										booking.setPassengerName(bookingReq.getPassengerName());
//										booking.setPrimaryContactNumber(bookingReq.getPrimaryContactNumber());
//										booking.setpCountryCode(bookingReq.getpCountryCode());
//										booking.setSecondaryContactNumber(bookingReq.getSecondaryContactNumber());
//										booking.setsCountryCode(bookingReq.getsCountryCode());
										booking.setPickUpTime(pickuptime);
                                                                                booking.setDropOffTime(dropuptime);
										booking.setPickLat(bookingReq.getPickLat());
										booking.setPickLang(bookingReq.getPickLang());
										booking.setPickUpAddress(bookingReq.getPickUpAddress());
										booking.setDropLat(bookingReq.getDropLat());
										booking.setDropLang(bookingReq.getDropLang());
										booking.setDropOffAddress(bookingReq.getDropOffAddress());
										booking.setAdditionalStopPage(bookingReq.getAdditionalStopPage());
										booking.setVehicleCode(bookingReq.getVehicleCode());
										booking.setNoOfPassengers(bookingReq.getNoOfPassengers());
										booking.setNoOfBaggage(bookingReq.getNoOfBaggage());
										booking.setAdditionalComment(bookingReq.getAdditionalComment());
										booking.setCustomerFare(bookingReq.getCustomerFare());
//						booking.setBookingStatus(bookingReq.getBookingStatus());
										booking.setPaymentOption(bookingReq.getPaymentOption());
										booking.setOrganizationCode(bookingReq.getOrganizationCode());
										booking.setOperatorCode(bookingReq.getOperatorCode());
										booking.setIpAddress(ip);
                                                                                
                                                                                //code for check balance amount before new booking
                                                                                List<OrganizationCreditTransaction> objlst = organizationCreditTransactionRepository.getLastTransactionBalanceByOrganizationCode(booking.getOrganizationCode());

                                                                                double creditAmount = 0.0;
                                                                                double debitAmount =0.0;
                                                                                double balaceAmount = 0.0;
                                                                                double lastBalance = 0.0;
                                                                                String transactionType= "";
                                                                                if (objlst != null && objlst.size() > 0) {

                                                                                    OrganizationCreditTransaction oprRes = objlst.get(0);

                                                                                    if(oprRes != null && oprRes.getId() >0 )
                                                                                    {
                                                                                         lastBalance = oprRes.getBalanceAmount();
                                                                                    
                                                                                        if(currentBalance > bookingReq.getCustomerFare() )
                                                                                        {
                                                                                            creditAmount = currentBalance-bookingReq.getCustomerFare();
                                                                                            balaceAmount = lastBalance+ creditAmount ;
                                                                                            transactionType = GigflexConstants.TRANSACTION_TYPE_CREDIT;
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                             debitAmount = bookingReq.getCustomerFare()-currentBalance;
                                                                                             balaceAmount =lastBalance - debitAmount ;
                                                                                             transactionType = GigflexConstants.TRANSACTION_TYPE_CREDIT;
                                                                                        }
                                                                                        
                                                                                        if(creditAmount > 0 || debitAmount > 0)
                                                                                        {
                                                                                            OrganizationCreditTransaction oct = new OrganizationCreditTransaction();

                                                                                            oct.setBalanceAmount(balaceAmount); 
                                                                                            oct.setCreditAmount(creditAmount); 
                                                                                            oct.setDebitAmount(debitAmount);
                                                                                            oct.setOrganizationCode(booking.getOrganizationCode()); 
                                                                                            oct.setBookingid(booking.getBookingid());
                                                                                            oct.setTransactionBy(GigflexConstants.BOOKING); 
                                                                                            oct.setTransactionType(transactionType); 
                                                                                            oct.setIpAddress(ip); 

                                                                                            OrganizationCreditTransaction operatorCreditTransactionRes = organizationCreditTransactionRepository.save(oct);

                                                                                            if(operatorCreditTransactionRes == null && operatorCreditTransactionRes.getId()==0 )
                                                                                            {
                                                                                                jsonobj.put("message", "Failed due to credit transaction");
                                                                                                jsonobj.put("responsecode", 400);
                                                                                                jsonobj.put("timestamp", new Date());

                                                                                                return jsonobj.toString();
                                                                                            }
                                                                                        }

                                                                                        
                                                                                    }
                                                                                   
                                                                                }
                                                                               
                                                                                
                                                                                Passenger passenger = passengerDao.getPassengerByPassengerCode(booking.getPassengerCode()) ;
                                                                                Passenger passengerRes = null;
                                                                                if(passenger != null )
                                                                                {
                                                                                    
                                                                                    passenger.setPassengerName(bookingReq.getPassengerName());
                                                                                    passenger.setPrimaryContactNumber(bookingReq.getPrimaryContactNumber());
                                                                                    passenger.setpCountryCode(bookingReq.getpCountryCode());
                                                                                    passenger.setSecondaryContactNumber(bookingReq.getSecondaryContactNumber());
                                                                                    passenger.setsCountryCode(bookingReq.getsCountryCode());
                                                                                    passenger.setOrganizationCode(bookingReq.getOrganizationCode());
                                                                                    
                                                                                    passengerRes =  passengerDao.save(passenger);
                                                                                    
                                                                                }
                                                                                
                                                                                
                                                                                
										Booking bookingRes = bookingDao.save(booking);
										if (bookingRes != null && bookingRes.getId() > 0 && passengerRes != null && passengerRes.getId() > 0) {
											jsonobj.put("responsecode", 200);
											jsonobj.put("message", "Booking updation has been done");
											jsonobj.put("timestamp", new Date());
											ObjectMapper mapperObj = new ObjectMapper();
											String Detail = mapperObj.writeValueAsString(bookingRes);
											jsonobj.put("data", new JSONObject(Detail));

										} else {
                                                                                        
                                                                                        String msg ="";
                                                                                        
                                                                                        if(bookingRes == null && passengerRes == null  )
                                                                                        {
                                                                                            msg = "Booking updation has been failed.";
                                                                                        }
                                                                                        else if(bookingRes == null && passengerRes != null)
                                                                                        {
                                                                                            msg ="Passenger updation has been done but Booking updation has been failed. ";
                                                                                        }
                                                                                        else if(bookingRes != null && passengerRes == null)
                                                                                        {
                                                                                            msg ="Booking updation has been done but Passenger updation has been failed. ";
                                                                                        }                                                                                        
                                                                                    
											jsonobj.put("responsecode", 400);
											jsonobj.put("message", msg);
											jsonobj.put("timestamp", new Date());
										}
//							}
//						} else {
//							jsonobj.put("responsecode", 400);
//							jsonobj.put("message",
//									"Old Skill name and New Skill name should be different.");
//							jsonobj.put("timestamp", new Date());
//						}
									} else {
										jsonobj.put("responsecode", 404);
										jsonobj.put("timestamp", new Date());
										jsonobj.put("message", "PickUp time,Dropup Time  must be after current time");
									}
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message", "Vehicle Code not found.");
								}
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Operator Code not found.");
							}

//						} 
//                                                else {
//							jsonobj.put("responsecode", 400);
//							jsonobj.put("timestamp", new Date());
//							jsonobj.put("message", "Organization Code not found.");
//						}
                                                } else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Booking can not update. Booking has been completed.");
						jsonobj.put("timestamp", new Date());
					}

                                                } else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Booking can not update. Booking is inprogress");
						jsonobj.put("timestamp", new Date());
					}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Booking Id is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("JSON parsing exception is occurred.",ex); 
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex); 
		}
		return res;
	}

	@Override
	public String findAllBooking() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = bookingDao.getAllBooking();
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {
						
						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
						Passenger passengerData = (Passenger) arr[4];
					        String conDt="";
                                                String dropOffTime="";
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                               
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                
                                            
                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                               TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                               if (tzd != null && tzd.getId() > 0) {

                                                   String timezone = tzd.getTimeZoneName();
                                                   if(timezone!=null && timezone.length()>0 )
                                                   {  if(data.getPickUpTime()!=null){
                                                        Date pDate = data.getPickUpTime();
                                                        pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                        conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                       }
                                                        if(data.getDropOffTime()!=null){
                                                        Date pDate = data.getDropOffTime();
                                                        pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                       dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                            }
                                                   }
                                                 

                                               }         
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
						brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
						brwo.setpCountryCode(passengerData.getpCountryCode());
						brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
						brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode()); 
                                                
						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());
                                                

						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String getAllBookingByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlstCheck = bookingDao.getAllBooking();
			int count = objlstCheck.size();
				List<Object> objlst = bookingDao.getAllBooking(pageableRequest);
				
				List<BookingResponse> maplst = new ArrayList<BookingResponse>();
				if (objlst != null && objlst.size() > 0) {

					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 5) {
							BookingResponse brwo = new BookingResponse();

							Booking data = (Booking) arr[0];
                                                        Passenger passengerData = (Passenger) arr[4];
							String conDt = "";
							String dropOffTime="";
                                                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                         String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                        {
                                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                        }                

                                                        String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                                        TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                        if (tzd != null && tzd.getId() > 0) {

                                                            String timezone = tzd.getTimeZoneName();
                                                            if(timezone!=null && timezone.length()>0 )
                                                            {     if(data.getPickUpTime()!=null)
                                                                  {
                                                                    Date pDate = data.getPickUpTime();
                                                                 pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                 conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                   }  
                                                                if(data.getDropOffTime()!=null){
                                                                 Date pDate = data.getDropOffTime();
                                                                 pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                  dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                         }
                                                            }
                                                          

                                                        }       
                                                        brwo.setDateFormat(dateformat);
                                                        brwo.setTimeFormat(timeformat);
                                                        brwo.setBookingid(data.getBookingid());
							brwo.setId(data.getId());
							brwo.setRideCode(data.getRideCode());
                                                        brwo.setPassengerName(passengerData.getPassengerName());
                                                        brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                        brwo.setpCountryCode(passengerData.getpCountryCode());
                                                        brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                        brwo.setsCountryCode(passengerData.getsCountryCode());
                                                        brwo.setPassengerCode(passengerData.getPassengerCode()); 

							brwo.setPickUpTime(conDt);
                                                        brwo.setDropOffTime(dropOffTime);
							brwo.setPickLat(data.getPickLat());
							brwo.setPickLang(data.getPickLang());
							brwo.setPickUpAddress(data.getPickUpAddress());
							brwo.setDropLat(data.getDropLat());
							brwo.setDropLang(data.getDropLang());
							brwo.setDropOffAddress(data.getDropOffAddress());
							brwo.setAdditionalStopPage(data.getAdditionalStopPage());
							brwo.setVehicleCode(data.getVehicleCode());
							brwo.setNoOfPassengers(data.getNoOfPassengers());
							brwo.setNoOfBaggage(data.getNoOfBaggage());
							brwo.setAdditionalComment(data.getAdditionalComment());
							brwo.setCustomerFare(data.getCustomerFare());
                                                        brwo.setCurrencySymbol(currencySymbol);
							brwo.setBookingStatus(data.getBookingStatus());
							brwo.setPaymentOption(data.getPaymentOption());
							brwo.setOrganizationCode(data.getOrganizationCode());
							brwo.setOperatorCode(data.getOperatorCode());
							brwo.setIsPublished(data.getIsPublished());

							brwo.setOrganizationName((String) arr[1]);
							brwo.setVehicleName((String) arr[2]);
							brwo.setOperatorName((String) arr[3]);
                                                        GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
							maplst.add(brwo);

						}

					}

					if (maplst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(maplst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("count", count);
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String findBookingById(Long id) {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//			Booking bookinglst = bookingDao.getBookingById(id);
//			if (bookinglst != null && bookinglst.getId() > 0) {
//				jsonobj.put("responsecode", 200);
//				jsonobj.put("message", "Success");
//				jsonobj.put("timestamp", new Date());
//				ObjectMapper mapperObj = new ObjectMapper();
//				String Detail = mapperObj.writeValueAsString(bookinglst);
//				jsonobj.put("data", new JSONObject(Detail));
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("message", "Record Not Found");
//				jsonobj.put("timestamp", new Date());
//
//			}
//			res = jsonobj.toString();
//		} catch (Exception e) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
//			res = derr.toString();
//		}
//		return res;
		String res = "";
		BookingResponse brwo = null;
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = bookingDao.getBookingByIdWithName(id);
//			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						brwo = new BookingResponse();
						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt = "";
						String dropOffTime="";
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                

                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {      if(data.getPickUpTime()!=null){
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                          }
                                                        if(data.getDropOffTime()!=null){
                                                       Date pDate = data.getDropOffTime();
                                                       pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                      dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                      }
                                                    }
                                                    

                                                }     
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat); 
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode()); 

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());

						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
//						maplst.add(brwo);

					}
				}
				if (brwo != null) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(brwo);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String saveBooking(BookingRequest bookingReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        OrganizationCreditTransaction organizationCreditTransactionRes = null; 
			if (bookingReq != null) {

				if (bookingReq.getPassengerName() != null && bookingReq.getPassengerName().trim().length() > 0
						&& bookingReq.getOrganizationCode() != null
						&& bookingReq.getOrganizationCode().trim().length() > 0 && bookingReq.getVehicleCode() != null
						&& bookingReq.getVehicleCode().trim().length() > 0 && bookingReq.getOperatorCode() != null
						&& bookingReq.getOperatorCode().trim().length() > 0 && bookingReq.getPickUpTime() != null
						&& bookingReq.getPickUpTime().trim().length() > 0&&bookingReq.getDropOffTime()!=null &&bookingReq.getDropOffTime().trim().length()>0
                                        && bookingReq.getNoOfPassengers()!=null && bookingReq.getNoOfPassengers()>0) {
					
					Organization org = orgDao.findByOrganizationCode(bookingReq.getOrganizationCode());
					if (org != null && org.getId() > 0) {

						Operator operator = operatorDao.getOperatorByOperatorCode(bookingReq.getOperatorCode());
						if (operator != null && operator.getId() > 0) {

							RideType veh = vehTypeDao.getRideTypeByVehicleCode(bookingReq.getVehicleCode());
							if (veh != null && veh.getId() > 0) {

//						DepartmentMaster deptMast = departmentMasterRepository
//								.getDepartmentMasterByOrgCodeDeptNameParentId(
//										deptReq.getOrganizationCode(),
//										deptReq.getDepartmentName(),
//										deptReq.getParentid());
//						if (deptMast != null && deptMast.getId() > 0) {
//							jsonobj.put("responsecode", 409);
//							jsonobj.put("timestamp", new Date());
//							jsonobj.put("message", "Record already exist.");
//						} else {
								
								try {
                                                                 if( !(GigflexDateUtil.isDate(bookingReq.getPickUpTime().trim(), GigflexConstants.YYYY_MM_DD_HH_MM_SS)))
                                                                 {
                                                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
											"Plz send PickUpDate in correct format("+GigflexConstants.YYYY_MM_DD_HH_MM_SS+") ");
									return derr.toString();
                                                                 }
                                                                if( !(GigflexDateUtil.isDate(bookingReq.getDropOffTime().trim(), GigflexConstants.YYYY_MM_DD_HH_MM_SS)))
                                                                 {
                                                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
											"Plz send DropUpTime in correct format("+GigflexConstants.YYYY_MM_DD_HH_MM_SS+") ");
									return derr.toString();
                                                                 }

//						currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
								} catch (Exception ex) {
									ex.printStackTrace();
									GigflexResponse derr = new GigflexResponse(400, new Date(),
											"Plz send PickUpDate in correct format(yyyy-MM-dd HH:mm:ss) ");
									return derr.toString();
								}
                                                                
                                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, bookingReq.getOrganizationCode(), GigflexConstants.TimeZone);

                                                               	TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                                                
                                                                 Date pickuptime= null;
                                                                if (tz != null && tz.getId() > 0) {

                                                                   pickuptime=GigflexDateUtil.convertStringDateToGMT(bookingReq.getPickUpTime().trim(), tz.getTimeZoneName(),GigflexConstants.dateFormatterForSave);

                                                               }  
                                                                  Date dropuptime= null;
                                                                if (tz != null && tz.getId() > 0) {

                                                                   dropuptime=GigflexDateUtil.convertStringDateToGMT(bookingReq.getDropOffTime().trim(), tz.getTimeZoneName(),GigflexConstants.dateFormatterForSave);

                                                               } 
								
								if (pickuptime == null || dropuptime==null) {
									GigflexResponse derr = new GigflexResponse(400, new Date(),
											"Date conversion has been failed.");
									return derr.toString();
								}
								Date currentTime = new Date();
								if (pickuptime.after(currentTime) && dropuptime.after(currentTime)) {
                                                                   long randomNo= genRandomNo();
                                                                   if(randomNo>0)
                                                                   {
									Booking booking = new Booking();
                                                                        booking.setBookingid(randomNo);
//									booking.setPassengerName(bookingReq.getPassengerName());
//									booking.setPrimaryContactNumber(bookingReq.getPrimaryContactNumber());
//									booking.setpCountryCode(bookingReq.getpCountryCode());
//									booking.setSecondaryContactNumber(bookingReq.getSecondaryContactNumber());
//									booking.setsCountryCode(bookingReq.getsCountryCode());
									booking.setPickUpTime(pickuptime);
                                                                        booking.setDropOffTime(dropuptime);
									booking.setPickLat(bookingReq.getPickLat());
									booking.setPickLang(bookingReq.getPickLang());
									booking.setPickUpAddress(bookingReq.getPickUpAddress());
									booking.setDropLat(bookingReq.getDropLat());
									booking.setDropLang(bookingReq.getDropLang());
									booking.setDropOffAddress(bookingReq.getDropOffAddress());
									booking.setAdditionalStopPage(bookingReq.getAdditionalStopPage());
									booking.setVehicleCode(bookingReq.getVehicleCode());
									booking.setNoOfPassengers(bookingReq.getNoOfPassengers());
									booking.setNoOfBaggage(bookingReq.getNoOfBaggage());
									booking.setAdditionalComment(bookingReq.getAdditionalComment());
									booking.setCustomerFare(bookingReq.getCustomerFare());
									booking.setBookingStatus(GigflexConstants.assignedBookingStatus);

									booking.setPaymentOption(bookingReq.getPaymentOption());
									booking.setOrganizationCode(bookingReq.getOrganizationCode());
									booking.setIsPublished(Boolean.FALSE);
									booking.setOperatorCode(bookingReq.getOperatorCode());

									booking.setIpAddress(ip);                                                                        
                                                                      
                                                                        //code for check balance amount before new booking
                                                                        List<OrganizationCreditTransaction> objlst = organizationCreditTransactionRepository.getLastTransactionBalanceByOrganizationCode(booking.getOrganizationCode());

                                                                        if (objlst != null && objlst.size() > 0) {

                                                                            OrganizationCreditTransaction oprRes = objlst.get(0);

                                                                            double lastBalance = oprRes.getBalanceAmount();

                                                                            if(lastBalance > bookingReq.getCustomerFare() )
                                                                            {
                                                                                double balanceAmount = lastBalance-bookingReq.getCustomerFare();
                                                                                
                                                                                double debitAmount = bookingReq.getCustomerFare();
                                                                                
                                                                                OrganizationCreditTransaction oct = new OrganizationCreditTransaction();
                                                                                
                                                                                oct.setBalanceAmount(balanceAmount); 
                                                                                oct.setDebitAmount(debitAmount); 
                                                                                oct.setOrganizationCode(booking.getOrganizationCode()); 
                                                                                oct.setTransactionBy(GigflexConstants.BOOKING); 
                                                                                oct.setTransactionType(GigflexConstants.TRANSACTION_TYPE_DEBIT); 
                                                                                oct.setIpAddress(ip); 
                                                                                        
                                                                                
                                                                                organizationCreditTransactionRes = organizationCreditTransactionRepository.save(oct);
                                                                                
                                                                                if(organizationCreditTransactionRes == null && organizationCreditTransactionRes.getId()==0 )
                                                                                {
                                                                                    jsonobj.put("message", "Failed due to credit transaction");
                                                                                    jsonobj.put("responsecode", 400);
                                                                                    jsonobj.put("timestamp", new Date());
                                                                                    
                                                                                    return jsonobj.toString();
                                                                                }
                                                                            }
                                                                            else
                                                                            {
                                                                                GigflexResponse derr = new GigflexResponse(400, new Date(),
											"Insuffitient balance amount for the booking");
                                                                                return derr.toString();
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                           GigflexResponse derr = new GigflexResponse(400, new Date(),
											"Insuffitient balance amount for the booking");
                                                                           return derr.toString();
                                                                        }
                                                                        
                                                                        Passenger passengerRes = null;
                                                                        Booking bookingRes = null;
                                                                        if(bookingReq.getPassengerCode() != null && bookingReq.getPassengerCode().trim().length() > 0)
                                                                        {
                                                                            Passenger passenger = passengerDao.getPassengerByPassengerCode(bookingReq.getPassengerCode());
                                                                            if(passenger == null)
                                                                            {
                                                                                passenger = new Passenger(); 
                                                                                passenger.setIpAddress(ip); 
                                                                                passenger.setOrganizationCode(bookingReq.getOrganizationCode());                                                                    
                                                                                passenger.setPassengerName(bookingReq.getPassengerName()); 
                                                                                passenger.setPrimaryContactNumber(bookingReq.getPrimaryContactNumber());
                                                                                passenger.setpCountryCode(bookingReq.getpCountryCode());
                                                                                passenger.setSecondaryContactNumber(bookingReq.getSecondaryContactNumber());
                                                                                passenger.setsCountryCode(bookingReq.getsCountryCode());

                                                                                passengerRes = passengerDao.save(passenger);
                                                                            }
                                                                            else
                                                                            {
                                                                                passengerRes =passenger;
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            Passenger passenger = new Passenger();
                                                                            passenger.setIpAddress(ip); 
                                                                            passenger.setOrganizationCode(bookingReq.getOrganizationCode()); 
    //                                                                        passenger.setPassengerCode(bookingReq.getPassengerCode()); 
                                                                            passenger.setPassengerName(bookingReq.getPassengerName()); 
                                                                            passenger.setPrimaryContactNumber(bookingReq.getPrimaryContactNumber());
                                                                            passenger.setpCountryCode(bookingReq.getpCountryCode());
                                                                            passenger.setSecondaryContactNumber(bookingReq.getSecondaryContactNumber());
                                                                            passenger.setsCountryCode(bookingReq.getsCountryCode());
                                                                            
                                                                            passengerRes = passengerDao.save(passenger);
                                                                        }
                                                                       
                                                                        
                                                                        
                                                                        if(passengerRes != null && passengerRes.getId() > 0)
                                                                        {
                                                                            booking.setPassengerCode(passengerRes.getPassengerCode()); 
                                                                            bookingRes = bookingDao.save(booking);
                                                                        }
									

									if (bookingRes != null && bookingRes.getId() > 0  ) {
                                                                                
                                                                                Booking bookingPassengerRes = new Booking();
                                                                                
                                                                                bookingPassengerRes.setPassengerName(passengerRes.getPassengerName());
        									bookingPassengerRes.setPrimaryContactNumber(passengerRes.getPrimaryContactNumber());
        									bookingPassengerRes.setpCountryCode(passengerRes.getpCountryCode());
        									bookingPassengerRes.setSecondaryContactNumber(passengerRes.getSecondaryContactNumber());
        									bookingPassengerRes.setsCountryCode(passengerRes.getsCountryCode());
                                                                                
                                                                                bookingPassengerRes.setBookingid(bookingRes.getBookingid());
                                                                                bookingPassengerRes.setPickUpTime(bookingRes.getPickUpTime());
                                                                                bookingPassengerRes.setPickLat(bookingRes.getPickLat());
                                                                                bookingPassengerRes.setPickLang(bookingRes.getPickLang());
                                                                                bookingPassengerRes.setPickUpAddress(bookingRes.getPickUpAddress());
                                                                                bookingPassengerRes.setDropLat(bookingRes.getDropLat());
                                                                                bookingPassengerRes.setDropLang(bookingRes.getDropLang());
                                                                                bookingPassengerRes.setDropOffAddress(bookingRes.getDropOffAddress());
                                                                                bookingPassengerRes.setAdditionalStopPage(bookingRes.getAdditionalStopPage());
                                                                                bookingPassengerRes.setVehicleCode(bookingRes.getVehicleCode());
                                                                                bookingPassengerRes.setNoOfPassengers(bookingRes.getNoOfPassengers());
                                                                                bookingPassengerRes.setNoOfBaggage(bookingRes.getNoOfBaggage());
                                                                                bookingPassengerRes.setAdditionalComment(bookingRes.getAdditionalComment());
                                                                                bookingPassengerRes.setCustomerFare(bookingRes.getCustomerFare());
                                                                                bookingPassengerRes.setBookingStatus(bookingRes.getBookingStatus());
                                                                                bookingPassengerRes.setPaymentOption(bookingRes.getPaymentOption());
                                                                                bookingPassengerRes.setOrganizationCode(bookingRes.getOrganizationCode());
                                                                                bookingPassengerRes.setIsPublished(bookingRes.getIsPublished());
                                                                                bookingPassengerRes.setOperatorCode(bookingRes.getOperatorCode());
                                                                                bookingPassengerRes.setIpAddress(bookingRes.getIpAddress());                                                                                
                                                                                bookingPassengerRes.setCreatedAt(bookingRes.getCreatedAt()); 
                                                                                bookingPassengerRes.setUpdatedAt(bookingRes.getUpdatedAt()); 
                                                                                bookingPassengerRes.setIsDeleted(bookingRes.getIsDeleted()); 
                                                                                bookingPassengerRes.setId(bookingRes.getId()); 
                                                                                bookingPassengerRes.setRideCode(bookingRes.getRideCode()); 
                                                                                bookingPassengerRes.setDropOffTime(bookingRes.getDropOffTime()); 
                                                                                bookingPassengerRes.setCancelationComment(bookingRes.getCancelationComment()); 
                                                                                bookingPassengerRes.setOldStatus(bookingRes.getOldStatus()); 
                                                                          
                                                                               
										AssignBooking ab = new AssignBooking();
										ab.setRideCode(bookingRes.getRideCode());
										ab.setIpAddress(ip);
										ab.setStatus(GigflexConstants.assignedBookingStatus);
										AssignBooking abres = assgnBookingDao.save(ab);
                                                                                
                                                                                
                                                                               
                                                                                
                                                                                
                                                                                
										if (abres != null && abres.getId() > 0) {
                                                                                    
                                                                                    
                                                                                        organizationCreditTransactionRes.setBookingid(bookingRes.getBookingid());
                                                                                        organizationCreditTransactionRepository.save(organizationCreditTransactionRes); 
											jsonobj.put("responsecode", 200);
											jsonobj.put("timestamp", new Date());
											jsonobj.put("message", "Booking has been added successfully.");
											ObjectMapper mapperObj = new ObjectMapper();
//											String Detail = mapperObj.writeValueAsString(bookingRes);
                                                                                        String Detail = mapperObj.writeValueAsString(bookingPassengerRes);
											jsonobj.put("data", new JSONObject(Detail));
										
										} else {
											jsonobj.put("message", "Failed");
											jsonobj.put("responsecode", 400);
											jsonobj.put("timestamp", new Date());
											bookingDao.deleteById(bookingRes.getId());
                                                                                        passengerDao.deleteById(passengerRes.getId()); 
                                                                                        organizationCreditTransactionRepository.deleteById(organizationCreditTransactionRes.getId()); 
										}
									}
                                                                        else {
                                                                            
                                                                                if(passengerRes != null )
                                                                                {
                                                                                     passengerDao.deleteById(passengerRes.getId()); 
                                                                                }
                                                                                
                                                                                if(organizationCreditTransactionRes != null)
                                                                                {
                                                                                    organizationCreditTransactionRepository.deleteById(organizationCreditTransactionRes.getId()); 
                                                                                }
										jsonobj.put("message", "Failed");
										jsonobj.put("responsecode", 400);
										jsonobj.put("timestamp", new Date());
									}
//						}
                                                        } else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message", "Booking ID generation has been failed.");
								}
								} else {
									jsonobj.put("responsecode", 404);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message", "PickUpTime,DropUpTime must be after current time");
								}
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Vehicle Code not found.");
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Operator Code not found.");
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Organization Code not found.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String getBookingByBookingCode(String rideCode) {
		String res = "";
                BookingResponse brwo = null;
		try {
			JSONObject jsonobj = new JSONObject();
			Object obj = bookingDao.getBookingWithPassengerByRideCode(rideCode);
                        
		       if (obj != null ) {
					Object[] arr = (Object[]) obj;
					if (arr.length >= 1) {

						brwo = new BookingResponse();
						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[1];
						String conDt = "";
                                                String dropOffTime ="";       
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                

                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {   if( data.getPickUpTime()!=null){
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                         }
                                                         if(data.getDropOffTime()!=null){
                                                          Date pDate = data.getDropOffTime();
                                                        pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                           dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                       }
                                                    }
                                                   

                                                }    
                                                
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode()); 

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());

//						brwo.setOrganizationName((String) arr[1]);
//						brwo.setVehicleName((String) arr[2]);
//						brwo.setOperatorName((String) arr[3]);
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
//						maplst.add(brwo);

					}
				if (brwo != null) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(brwo);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String softDeleteByBookingCode(String rideCode) {
		
            String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Booking bookinglst = bookingDao.getBookingByRideCode(rideCode);
                        
			if (bookinglst != null && bookinglst.getId() > 0) {
                                
				bookinglst.setIsDeleted(true);
				Booking bookingRes = bookingDao.save(bookinglst);
				if (bookingRes != null && bookingRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Booking deleted successfully.");
                                        try
                                        {
                                            AssignBooking abres = assgnBookingDao.getAssignBookingByRideCode(rideCode);
					    if (abres != null && abres.getId() > 0) {
                                                abres.setIsDeleted(Boolean.TRUE);
                                                assgnBookingDao.save(abres);
                                            }
                                        }
                                        catch(Exception e)
                                        {
                                            e.printStackTrace();
                                        }

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}
                                

                            

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByBookingCode(List<String> rideCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String rideCode : rideCodeList) {
				if (rideCode != null && rideCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					rideCode = rideCode.trim();

					Booking bookinglst = bookingDao.getBookingByRideCode(rideCode);

					if (bookinglst != null && bookinglst.getId() > 0) {
						bookinglst.setIsDeleted(true);
						Booking bookingRes = bookingDao.save(bookinglst);
						if (bookingRes != null && bookingRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", rideCode);
							jsonobj.put("message", "Booking deleted successfully.");
                                                        try
                                        {
                                            AssignBooking abres = assgnBookingDao.getAssignBookingByRideCode(rideCode);
					    if (abres != null && abres.getId() > 0) {
                                                abres.setIsDeleted(Boolean.TRUE);
                                                assgnBookingDao.save(abres);
                                            }
                                        }
                                        catch(Exception e)
                                        {
                                            e.printStackTrace();
                                        }

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", rideCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", rideCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				BookingSpecificationsBuilder builder = new BookingSpecificationsBuilder();
				Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
				}

				Specification<Booking> spec = builder.build();
				if (spec != null) {
					List<Booking> bookinglst = bookingDao.findAll(spec);
					if (bookinglst != null && bookinglst.size() > 0) {
						for (Booking act : bookinglst) {
							if (act.getIsDeleted() != null && act.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(act);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("booking", new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String getBookingByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = bookingDao.getBookingByOrgCode(organizationCode);
			
				List<BookingResponse> maplst = new ArrayList<BookingResponse>();
				if (objlst != null && objlst.size() > 0) {
					Organization org = orgDao.findByOrganizationCode(organizationCode);
					if (org != null && org.getId() > 0) {
					
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 5) {

							BookingResponse brwo = new BookingResponse();
                                                        String conDt ="";
                                                        
                                                        String dropOffTime="";
							Booking data = (Booking) arr[0];
                                                        Passenger passengerData = (Passenger) arr[4];
							
                                                        
                                                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.DATEFORMAT);
                                                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TIMEFORMAT);
                                                        String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                        {
                                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                        }                

                                                        String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);

                                                        TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                        if (tzd != null && tzd.getId() > 0) {

                                                            String timezone = tzd.getTimeZoneName();
                                                            if(timezone!=null && timezone.length()>0 )
                                                            {
                                                                if(data.getPickUpTime()!=null){
                                                                 Date pDate = data.getPickUpTime();
                                                                 pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                 conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                }
                                                                if(data.getDropOffTime()!=null){
                                                                 Date pDate = data.getDropOffTime();
                                                                 pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                 dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                }
                                                            }

                                                        }     
                                                        brwo.setDateFormat(dateformat);
                                                        brwo.setTimeFormat(timeformat);
                                                        brwo.setBookingid(data.getBookingid());
							brwo.setId(data.getId());
							brwo.setRideCode(data.getRideCode());
                                                        brwo.setPassengerName(passengerData.getPassengerName());
                                                        brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                        brwo.setpCountryCode(passengerData.getpCountryCode());
                                                        brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                        brwo.setsCountryCode(passengerData.getsCountryCode());
                                                        brwo.setPassengerCode(passengerData.getPassengerCode()); 

							brwo.setPickUpTime(conDt);
                                                        brwo.setDropOffTime(dropOffTime);
							brwo.setPickLat(data.getPickLat());
							brwo.setPickLang(data.getPickLang());
							brwo.setPickUpAddress(data.getPickUpAddress());
							brwo.setDropLat(data.getDropLat());
							brwo.setDropLang(data.getDropLang());
							brwo.setDropOffAddress(data.getDropOffAddress());
							brwo.setAdditionalStopPage(data.getAdditionalStopPage());
							brwo.setVehicleCode(data.getVehicleCode());
							brwo.setNoOfPassengers(data.getNoOfPassengers());
							brwo.setNoOfBaggage(data.getNoOfBaggage());
							brwo.setAdditionalComment(data.getAdditionalComment());
							brwo.setCustomerFare(data.getCustomerFare());
                                                        brwo.setCurrencySymbol(currencySymbol);
							brwo.setBookingStatus(data.getBookingStatus());
							brwo.setPaymentOption(data.getPaymentOption());
							brwo.setOrganizationCode(data.getOrganizationCode());
							brwo.setOperatorCode(data.getOperatorCode());
							brwo.setIsPublished(data.getIsPublished());

							brwo.setOrganizationName((String) arr[1]);
							brwo.setVehicleName((String) arr[2]);
							brwo.setOperatorName((String) arr[3]);
                                                        GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
							maplst.add(brwo);

						}
					}
					}
					if (maplst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(maplst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}

				res = jsonobj.toString();
			
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String getBookingByOrgCodeByPage(String organizationCode, int page, int limit) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);
			
			List<Object> objlstCheck = bookingDao.getBookingByOrgCode(organizationCode);
			int count = objlstCheck.size();

			List<Object> objlst = bookingDao.getBookingByOrgCode(organizationCode, pageableRequest);
			

			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				Organization org = orgDao.findByOrganizationCode(organizationCode);
				if (org != null && org.getId() > 0) {
				
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt ="";
                                                String dropOffTime="";
                                                
                                                
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TIMEFORMAT);
                                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                

                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);

                                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        if(data.getPickUpTime()!=null){
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                        }
                                                        if(data.getDropOffTime()!=null){
                                                            Date pDate = data.getDropOffTime();
                                                              pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                               dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                            }
                                                    }

                                                }            

                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());

						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
			
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),  "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String bookingPublishRequest(Boolean isPublished, String rideCode, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Booking bookinglst = bookingDao.getBookingByRideCode(rideCode);
			
			if (bookinglst != null && bookinglst.getId() > 0) {
				
				
				if(isPublished == true) {
					if(bookinglst.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || bookinglst.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus)){

					bookinglst.setOldStatus(bookinglst.getBookingStatus());
					bookinglst.setBookingStatus(GigflexConstants.assignedBookingPublishedStatus);
					
				
					
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Booking cannot be published!");
						 return jsonobj.toString();
					}
					
				}else {
                                    if(bookinglst.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus) || bookinglst.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || bookinglst.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus)){
					bookinglst.setBookingStatus(bookinglst.getOldStatus());
					bookinglst.setOldStatus("");
                                    }
                                    else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Booking cannot be unpublished!");
						 return jsonobj.toString();
					}
				}
				bookinglst.setIsPublished(isPublished);				
				Booking bookingRes = bookingDao.save(bookinglst);
				if (bookingRes != null && bookingRes.getId() > 0) {
					
					AssignBooking assignBooking = assgnBookingDao.getAssignBookingByRideCode(bookingRes.getRideCode());
					if(assignBooking != null && assignBooking.getId() > 0) {
						assignBooking.setStatus(bookingRes.getBookingStatus());
						assgnBookingDao.save(assignBooking);
					}
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Booking publish status has been changed successfully.");
					
					if (isPublished == true) {
						try {

							Notification notification = new Notification();

							String bodyContent = "Dear Operator"
									+ ",Booking has been published successfully. Details are given below-"
									+ "Passenger Name : " + bookingRes.getPassengerName() + "," + "Pick-up Time : "
									+ bookingRes.getPickUpTime() + "," + "Pick-up Address : "
									+ bookingRes.getPickUpAddress() + "," + "Drop-off Address : "
									+ bookingRes.getDropOffAddress();
							shortMessage = "Booking has been published successfully.";

							notification.setUserCode(bookingRes.getOperatorCode());
							notification.setMessage(bodyContent);
							notification.setUserType("All");
							notification.setShortMessage(shortMessage);
							notification.setRideCode(bookingRes.getRideCode());
							notification.setIsRead(Boolean.FALSE);
							notification.setIpAddress(ip);

							notificationService.saveNotification(notification);
                                                                                                         
//                                                      PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, bodyContent);

						}

						catch (Exception e) {
							e.printStackTrace();
						}
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}
				
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
                        ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}
        
        
//        @Override
//	public String bookingPublishRequest(Boolean isPublished, String rideCode, String ip) {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//			Booking bookinglst = bookingDao.getBookingByRideCode(rideCode);
//
//			if (bookinglst != null && bookinglst.getId() > 0) {
//				bookinglst.setIsPublished(isPublished);
//				Booking bookingRes = bookingDao.save(bookinglst);
//				if (bookingRes != null && bookingRes.getId() > 0) {
//					jsonobj.put("responsecode", 200);
//					jsonobj.put("timestamp", new Date());
//					jsonobj.put("message", "Booking publish status has been changed successfully.");
//
//				} else {
//					jsonobj.put("responsecode", 400);
//					jsonobj.put("timestamp", new Date());
//					jsonobj.put("message", "Failed");
//				}
//
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("timestamp", new Date());
//				jsonobj.put("message", "Record Not Found");
//			}
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		} catch (Exception ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
//			res = derr.toString();
//		}
//		return res;
//	}

	@Override
	public String assignBookingCompleted(String rideCode, BookingCompletedUpdateResponse bcres, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (rideCode != null && rideCode.trim().length() > 0) {
                            
				Date currentTime = null;
				currentTime = GigflexDateUtil.getCurrentDate(new Date());
                        Driver d = driverDao.getDriverByDriverCode(bcres.getDriverCode());
			if (d != null && d.getId() > 0) {
				Booking b = bookingDao.getBookingByRideCode(rideCode);
				if (b != null && b.getId() > 0) {
                                    
                                    
                                        double additionalCharges = 0.0;
                                        double currentBalance = 0.0;
                                        double updatedBalance = 0.0;
					b.setBookingStatus(GigflexConstants.assignedBookingCompletedStatus);
					b.setDropOffTime(currentTime);
                                        currentBalance = b.getCustomerFare();
                                        if(bcres.getCustomerFare()>0)
                                        {
                                            b.setCustomerFare(bcres.getCustomerFare());
                                            updatedBalance = bcres.getCustomerFare();
                                        
                                        }
					b.setIpAddress(ip);

					Booking abres = bookingDao.save(b);
					if (abres != null && abres.getId() > 0) {

						AssignBooking ab = assgnBookingDao.getAssignBookingByRideCode(rideCode);
						if (ab != null && ab.getId() > 0) {
                                                    UserType utOtr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOperator);
                                                    boolean SMSSt=true;
                                                    boolean MailST=true;
                                                        ab.setDriverCode(bcres.getDriverCode());
							ab.setStatus(GigflexConstants.assignedBookingCompletedStatus);
							AssignBooking bookingRes = assgnBookingDao.save(ab);
							if (bookingRes != null && bookingRes.getId() > 0) {
                                                            
                                                            try{
                                                          List<AdditionalChargesReq> req= bcres.getAdditionalChargesList();
                                                            if(req!=null && req.size()>0)
                                                            {
                                                              for(AdditionalChargesReq acr:req)
                                                              {  
                                                                   if(acr.getAdditionalFareypeCode()!=null && acr.getAdditionalFareypeCode().trim().length()>0 && acr.getAmmount()>0)
                                                                   {
                                                                AdditionalCharges addcharge= additionalchargesdao.getadditionalchargesByrideCodeAndfaretypeCode(rideCode, acr.getAdditionalFareypeCode());
                                                                 
                                                                 if(addcharge==null)
                                                                 {
                                                                     AdditionalCharges addcharges= new AdditionalCharges();
                                                                       addcharges.setAmmount(acr.getAmmount());
                                                                       additionalCharges = additionalCharges+acr.getAmmount();
                                                                       addcharges.setAdditionalFareypeCode(acr.getAdditionalFareypeCode());
                                                                        addcharges.setQuantity(acr.getQuantity());
                                                                       addcharges.setRideCode(rideCode);
                                                                       additionalchargesdao.save(addcharges);
                                                                       
                                                                     
                                                                 }else
                                                                 {
                                                                   addcharge.setAmmount(acr.getAmmount());
                                                                   addcharge.setQuantity(acr.getQuantity());
                                                                    additionalchargesdao.save(addcharge);
                                                                 }
                                                               }
                                                              }
                                                            }
                                                            }catch(Exception ex)
                                                            {
                                                               GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
                                                                        ex.printStackTrace();
			                                               res = derr.toString();
                                                            }
                                                            
                                                            
                                                            // For Debit/Credit Transaction
                                                            if( !b.getIsPublished())
                                                            {
                                                                List<OrganizationCreditTransaction> objlst = organizationCreditTransactionRepository.getLastTransactionBalanceByOrganizationCode(b.getOrganizationCode());

                                                                double creditAmount = 0.0;
                                                                double debitAmount =0.0;
                                                                double balaceAmount = 0.0;
                                                                double lastBalance = 0.0;
                                                                String transactionType = "";
                                                                if (objlst != null && objlst.size() > 0) {

                                                                    OrganizationCreditTransaction oprRes = objlst.get(0);

                                                                    if(oprRes != null && oprRes.getId() >0 )
                                                                    {
                                                                         lastBalance = oprRes.getBalanceAmount();

    //                                                                     if(currentBalance > (updatedBalance+additionalCharges) )
                                                                        if(currentBalance > updatedBalance )
                                                                        {
                                                                            creditAmount = currentBalance-updatedBalance;   
                                                                            balaceAmount = lastBalance+ creditAmount ;
                                                                            transactionType = GigflexConstants.TRANSACTION_TYPE_CREDIT;
                                                                        }
                                                                        else
                                                                        {
                                                                             debitAmount = updatedBalance-currentBalance;
                                                                             balaceAmount = lastBalance - debitAmount ;
                                                                             transactionType = GigflexConstants.TRANSACTION_TYPE_DEBIT;
                                                                        }

                                                                        if(creditAmount > 0 || debitAmount > 0)
                                                                        {
                                                                            OrganizationCreditTransaction oct = new OrganizationCreditTransaction();

                                                                            oct.setBalanceAmount(balaceAmount); 
                                                                            oct.setCreditAmount(creditAmount); 
                                                                            oct.setDebitAmount(debitAmount);
                                                                            oct.setOrganizationCode(abres.getOrganizationCode()); 
                                                                            oct.setBookingid(abres.getBookingid()); 
                                                                            oct.setTransactionBy(GigflexConstants.BOOKING); 
                                                                            oct.setTransactionType(transactionType); 
                                                                            oct.setIpAddress(ip); 

                                                                            OrganizationCreditTransaction organizationCreditTransactionRes = organizationCreditTransactionRepository.save(oct);

                                                                            if(organizationCreditTransactionRes == null && organizationCreditTransactionRes.getId()==0 )
                                                                            {
                                                                                jsonobj.put("message", "Failed due to credit transaction");
                                                                                jsonobj.put("responsecode", 400);
                                                                                jsonobj.put("timestamp", new Date());

                                                                                return jsonobj.toString();
                                                                            }
                                                                        }                
                                                                     }
                                                                    }
                                                            
                                                            }
                                                            else
                                                            {
                                                               
                                                                if(b.getOrganizationCode().equals(ab.getOrganizationCode()) ) 
                                                                {
                                                                    List<OrganizationCreditTransaction> objlst = organizationCreditTransactionRepository.getLastTransactionBalanceByOrganizationCode(b.getOrganizationCode());

                                                                    double creditAmount = 0.0;
                                                                    double debitAmount = 0.0;
                                                                    double balaceAmount = 0.0;
                                                                    double lastBalance = 0.0;
                                                                    String transactionType = "";
                                                                    if (objlst != null && objlst.size() > 0) {

                                                                    OrganizationCreditTransaction oprRes = objlst.get(0);

                                                                    if(oprRes != null && oprRes.getId() >0 )
                                                                    {
                                                                         lastBalance = oprRes.getBalanceAmount();

    //                                                                     if(currentBalance > (updatedBalance+additionalCharges) )
                                                                        if(currentBalance > updatedBalance )
                                                                        {
                                                                            creditAmount = currentBalance-updatedBalance;   
                                                                            balaceAmount = lastBalance+ creditAmount ;
                                                                            transactionType = GigflexConstants.TRANSACTION_TYPE_CREDIT;
                                                                        }
                                                                        else
                                                                        {
                                                                             debitAmount = updatedBalance-currentBalance;
                                                                             balaceAmount = lastBalance - debitAmount ;
                                                                             transactionType = GigflexConstants.TRANSACTION_TYPE_DEBIT;
                                                                        }

                                                                        if(creditAmount > 0 || debitAmount > 0)
                                                                        {
                                                                            OrganizationCreditTransaction oct = new OrganizationCreditTransaction();

                                                                            oct.setBalanceAmount(balaceAmount); 
                                                                            oct.setCreditAmount(creditAmount); 
                                                                            oct.setDebitAmount(debitAmount);
                                                                            oct.setOrganizationCode(abres.getOrganizationCode()); 
                                                                            oct.setBookingid(abres.getBookingid()); 
                                                                            oct.setTransactionBy(GigflexConstants.BOOKING); 
                                                                            oct.setTransactionType(transactionType); 
                                                                            oct.setIpAddress(ip); 

                                                                            OrganizationCreditTransaction organizationCreditTransactionRes = organizationCreditTransactionRepository.save(oct);

                                                                            if(organizationCreditTransactionRes == null && organizationCreditTransactionRes.getId()==0 )
                                                                            {
                                                                                jsonobj.put("message", "Failed due to credit transaction");
                                                                                jsonobj.put("responsecode", 400);
                                                                                jsonobj.put("timestamp", new Date());

                                                                                return jsonobj.toString();
                                                                            }
                                                                        }                
                                                                     }
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    //for Assign Booking Ride Exchange
                                                                    
                                                                    //for booking 
                                                                    List<OrganizationCreditTransaction> bookingOrganizationTransactionList = organizationCreditTransactionRepository.getLastTransactionBalanceByOrganizationCode(b.getOrganizationCode());
                                                                                                                                       
                                                                    if (bookingOrganizationTransactionList != null && bookingOrganizationTransactionList.size() > 0) {
                                                                        
                                                                        double creditAmount = 0.0;
                                                                        double debitAmount =0.0;
                                                                        double balaceAmount = 0.0;
                                                                        double lastBalance = 0.0;
                                                                        String transactionType = "";

                                                                        OrganizationCreditTransaction bookingOrgRes = bookingOrganizationTransactionList.get(0);

                                                                        if(bookingOrgRes != null && bookingOrgRes.getId() >0 )
                                                                        {
                                                                             lastBalance = bookingOrgRes.getBalanceAmount();

                                                                            if(currentBalance > updatedBalance )
                                                                            {
                                                                                creditAmount = currentBalance-updatedBalance;   
                                                                                balaceAmount = lastBalance+ creditAmount ;
                                                                                transactionType = GigflexConstants.TRANSACTION_TYPE_CREDIT;
                                                                            }
                                                                            else
                                                                            {
                                                                                 debitAmount = updatedBalance-currentBalance;
                                                                                 balaceAmount = lastBalance - debitAmount ;
                                                                                 transactionType = GigflexConstants.TRANSACTION_TYPE_DEBIT;
                                                                            }

                                                                            if(creditAmount > 0 || debitAmount > 0)
                                                                            {
                                                                                OrganizationCreditTransaction oct = new OrganizationCreditTransaction();

                                                                                oct.setBalanceAmount(balaceAmount); 
                                                                                oct.setCreditAmount(creditAmount); 
                                                                                oct.setDebitAmount(debitAmount);
                                                                                oct.setOrganizationCode(abres.getOrganizationCode()); 
                                                                                oct.setBookingid(abres.getBookingid()); 
                                                                                oct.setTransactionBy(GigflexConstants.BOOKING); 
                                                                                oct.setTransactionType(transactionType); 
                                                                                oct.setIpAddress(ip); 

                                                                                OrganizationCreditTransaction organizationCreditTransactionRes = organizationCreditTransactionRepository.save(oct);

                                                                                if(organizationCreditTransactionRes == null && organizationCreditTransactionRes.getId()==0 )
                                                                                {
                                                                                    jsonobj.put("message", "Failed due to credit transaction");
                                                                                    jsonobj.put("responsecode", 400);
                                                                                    jsonobj.put("timestamp", new Date());

                                                                                    return jsonobj.toString();
                                                                                }
                                                                            }                
                                                                         }
                                                                    }
                                                                    
                                                                    // For Assign Booking -Credit Entry  
                                                                    List<OrganizationCreditTransaction> assignBookingOrganizationTransactionList = organizationCreditTransactionRepository.getLastTransactionBalanceByOrganizationCode(ab.getOrganizationCode());
                                                                    if (assignBookingOrganizationTransactionList != null && assignBookingOrganizationTransactionList.size() > 0) {

                                                                        double creditAmount = 0.0;
                                                                        double debitAmount =0.0;
                                                                        double balanceAmount = 0.0;
                                                                        double lastBalance = 0.0;                                                                       
                                                                        String transactionType = "";
                                                                        
                                                                        double rideExchangeAmount = 0.0;
                                                                        double commisionPersentage = 0.0;
                                                                        double amountForAssignedBooking =0.0;
                                                                        
                                                                        UserType userype = userTypeDao.getUserTypeByUserTypeName(GigflexConstants.USER_TYPE_SUPER_ADMIN);
                                                                        
                                                                        if(userype != null && userype.getId() > 0)
                                                                        {
                                                                            String userTypeCode = userype.getUserTypeCode();

                                                                            GlobalSetting globalSetting = globalSettingRepository.getGlobalSettingByUserTypeSettingName(userTypeCode, GigflexConstants.SETTING_NAME_COMMISION_PERSENTAGE);

                                                                            if(globalSetting != null && globalSetting.getId() > 0)
                                                                            {
                                                                                try
                                                                                {
                                                                                    commisionPersentage = Double.parseDouble(globalSetting.getSettingValue()); 
                                                                                }
                                                                                catch(Exception ex)
                                                                                {
                                                                                    ex.printStackTrace();
                                                                                }
                                                                        
                                                                            }   
                                                                        }
                                                                        
                                                                        
                                                                        OrganizationCreditTransaction assignedbookingOrgRes = assignBookingOrganizationTransactionList.get(0);

                                                                        rideExchangeAmount = updatedBalance*commisionPersentage/100;
                                                                        amountForAssignedBooking = updatedBalance-rideExchangeAmount;
                                                                        if(assignedbookingOrgRes != null && assignedbookingOrgRes.getId() >0 )
                                                                        {
                                                                            lastBalance = assignedbookingOrgRes.getBalanceAmount();
                                                                            creditAmount  = amountForAssignedBooking;
                                                                            transactionType = GigflexConstants.TRANSACTION_TYPE_CREDIT;                                                                             
                                                                            balanceAmount = lastBalance + creditAmount ;

                                                                            OrganizationCreditTransaction oct = new OrganizationCreditTransaction();

                                                                            oct.setBalanceAmount(balanceAmount); 
                                                                            oct.setCreditAmount(creditAmount); 
                                                                            oct.setDebitAmount(debitAmount);
                                                                            oct.setOrganizationCode(ab.getOrganizationCode()); 
                                                                            oct.setBookingid(abres.getBookingid()); 
                                                                            oct.setTransactionBy(GigflexConstants.BOOKING); 
                                                                            oct.setTransactionType(transactionType); 
                                                                            oct.setIpAddress(ip); 

                                                                            OrganizationCreditTransaction organizationCreditTransactionRes = organizationCreditTransactionRepository.save(oct);

                                                                            if(organizationCreditTransactionRes == null && organizationCreditTransactionRes.getId()==0 )
                                                                            {
                                                                                jsonobj.put("message", "Failed due to credit transaction");
                                                                                jsonobj.put("responsecode", 400);
                                                                                jsonobj.put("timestamp", new Date());

                                                                                return jsonobj.toString();
                                                                            }
                                                                             
                                                                             // For Assign Booking -Ride Exchange
                                                                            
                                                                            String organizationCodeForAssignedBooking =ab.getOrganizationCode();
                                                                            String organizationCodeForBooking = b.getOrganizationCode();
                                                                             
                                                                             // save for ride exchange table
                                                                             
                                                                            double rideExchangeBalanceAmount = 0.0;
                                                                            List<RideExchange> rideExchangeList =rideExchangeDao.getLastBalanceOfRideExcahange();
                                                                            
                                                                            if(rideExchangeList != null && rideExchangeList.size()>0 )
                                                                            {
                                                                                RideExchange rideExchangeRes = rideExchangeList.get(0);
                                                                                rideExchangeBalanceAmount = rideExchangeRes.getBalanceAmount();
                                                                            }
                                                                            rideExchangeBalanceAmount =rideExchangeBalanceAmount+rideExchangeAmount;
                                                                            RideExchange rideExchange = new RideExchange();
                                                                            rideExchange.setBalanceAmount(rideExchangeBalanceAmount);
                                                                            rideExchange.setIpAddress(ip); 
                                                                            rideExchange.setOrganizationCodePublish(organizationCodeForBooking);
                                                                            rideExchange.setOrganizationCodeAssigned(organizationCodeForAssignedBooking); 
                                                                            rideExchange.setRideExchangeAmount(rideExchangeAmount); 
                                                                            rideExchange.setRideCode(rideCode); 
                                                                            RideExchange rideExchangeRes = rideExchangeDao.save(rideExchange);
                                                                            
                                                                            
                                                                            if(rideExchangeRes == null && rideExchangeRes.getId()==0)
                                                                            {
                                                                                jsonobj.put("message", "Failed due to credit transaction");
                                                                                jsonobj.put("responsecode", 400);
                                                                                jsonobj.put("timestamp", new Date());

                                                                                return jsonobj.toString();
                                                                            }
                                                                             
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            
                                                            
                                                            
                                                            String abOperatorCode = ab.getOperatorCode();
							    String bOperatorCode = b.getOperatorCode();
							    String toMail = "";
								String conDt="";
							    String operatorCodes = null;
                                                            String contactNumber="";
							    
                                                             if(abOperatorCode != null && bOperatorCode != null ) {
							    	if(abOperatorCode.equals(bOperatorCode)) {
								    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {
                                                                        
								    	toMail = operator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                            contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								    	}
								    	operatorCodes = abOperatorCode;
								    }else {
								    	Operator aboperator = operatorRepository.getOperatorByOperatorCode(abOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, mailNotiName);
								    	if(MailST && aboperator!=null && aboperator.getEmailId() != null && aboperator.getEmailId().length() > 0) {

								    	toMail = aboperator.getEmailId();
								    	}
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, smsNotiName);
                                                                        if(SMSSt && aboperator!=null && aboperator.getContactNumber() != null && aboperator.getContactNumber().length() > 0 && aboperator.getCountryCode() != null && aboperator.getCountryCode().length() > 0) {

                                                                        contactNumber="+"+aboperator.getCountryCode()+aboperator.getContactNumber();
								    	}
								    	Operator boperator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								    	if(MailST && boperator!=null && boperator.getEmailId() != null && boperator.getEmailId().length() > 0) {
								    		if(toMail != null && toMail.length() > 0) {
								    	toMail += ","+boperator.getEmailId();
								    	}else {
									    	toMail = boperator.getEmailId();

								    	}
                                                                        }
                                                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && boperator!=null && boperator.getContactNumber() != null && boperator.getContactNumber().length() > 0 && boperator.getCountryCode() != null && boperator.getCountryCode().length() > 0) {
								    		if(contactNumber != null && contactNumber.length() > 0) {
								    	
                                                                        contactNumber +=",+"+boperator.getCountryCode()+ boperator.getContactNumber();
								    	}else {
                                                                                contactNumber="+"+boperator.getCountryCode()+ boperator.getContactNumber();

								    	}
								    	}
								    	operatorCodes = abOperatorCode+","+bOperatorCode;
								    }
							    	
							    }else if(bOperatorCode != null){
							    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
							    	if(MailST && operator.getEmailId() != null && operator.getEmailId().length() > 0) {
							    	toMail = operator.getEmailId();
							    	}
                                                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                   contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								}
							    	operatorCodes = bOperatorCode;
							    }
                                                            
//						             Organization org = orgDao.findByOrganizationCode(b.getOrganizationCode());
//						             if (org != null && org.getId() > 0) {
//						                 String timezoneCode = org.getTimezone();
//						                 TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
//						                 if(b.getPickUpTime()!=null){
//                                                                 Date pDate = b.getPickUpTime();
//						                 pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, tz.getTimeZoneName(), GigflexConstants.dateFormatterForView);
//						                 conDt=GigflexDateUtil.converDateToString(pDate);
//                                                                 }
//						             }
                                                             
                                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                                {
                                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                                }                

                                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TimeZone);

                                                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                                if (tzd != null && tzd.getId() > 0) {

                                                                    String timezone = tzd.getTimeZoneName();
                                                                    if(timezone!=null && timezone.length()>0 )
                                                                    {
                                                                        if(b.getPickUpTime()!=null){
                                                                         Date pDate = b.getPickUpTime();
                                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                        }
                                                                    }

                                                                }            

                                                             
                                                             
								   String bodyContent = "Dear Operator " 
									+ ", <br><br>Assigned Booking has been completed successfully. Details are given below-<br><br>";
                                                                  if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                    {
                                                                     bodyContent+="Driver Name : "+d.getName()+"<br>";
                                                                    }
									bodyContent+="Passenger Name : "+b.getPassengerName()+"<br>"+ "Pick-up Time : "
									+ conDt + "<br>" + "Pick-up Address : " + b.getPickUpAddress()
									+ "<br>" + "Drop-off Address : " + b.getDropOffAddress();
                                                                   
                                                                   String messageBody="Dear Operator, "+"\n" 
									+ "Assigned Booking has been completed successfully. Details are given below-"+"\n";
                                                                           if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                    {
                                                                     messageBody+="Driver Name : "+d.getName()+"\n";
                                                                    }
									messageBody+="Passenger Name : "+b.getPassengerName()+"\n"+ "Pick-up Time : "
									+ conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
									+ "\n" + "Drop-off Address : " + b.getDropOffAddress();
									
							if(toMail != null && toMail.length() > 0) {
//                                                            byte[] encodedbody = Base64.getEncoder().encode(bodyContent.getBytes());
//                                                            String body = new String(encodedbody);
							String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
							Map<String, String> map = new HashMap<>();
							map.put("to", toMail);
							map.put("subject", subjectComplt);
							map.put("body", encodeURL);
							try {
                                                                
								RestTemplate restTemplate = new RestTemplate();
								ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL,
										String.class, map);
								String mailRes = response.getBody();
                                                                

							} catch (Exception ex) {
								ex.printStackTrace();
							}
							   }
                                                        
                                                        
                                                                  try {
                                                                if (contactNumber != null && contactNumber.length()>0) {
                                                                    String contactArray[] = contactNumber.split(",");
                                                                    SendMessageAPI sendmessageapi = new SendMessageAPI();
                                                                    for (int i = 0; i <contactArray.length; i++) {
                                                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, contactArray[i], messageBody);
                                                                        System.out.println("====messageToken For operators=====" + messageToken);
                                                                    }
                                                                }
                                                            } catch (Exception e) {
                                                                e.printStackTrace();
                                                            }
							   
							   try {
								   if(operatorCodes != null && operatorCodes.length() > 0) {
									   String userCodes[] = operatorCodes.split(",");
									   for(String userCode : userCodes) {
										  if(userCode != null && userCode.length() > 0) {
											  Notification notification = new Notification();
											  
											  String bodyContentNoti = "Dear Operator" 
														+ ",Assigned Booking has been completed successfully. Details are given below-";
												if(d!=null && d.getName()!=null && d.getName().length()>0)
                                                                                                {
                                                                                                bodyContentNoti+="Driver Name : "+d.getName()+",";
                                                                                                }		
                                                                                                  bodyContentNoti+="Passenger Name : "+b.getPassengerName()+","+ "Pick-up Time : "
														+ conDt + "," + "Pick-up Address : " + b.getPickUpAddress()
														+ "," + "Drop-off Address : " + b.getDropOffAddress();
											  shortMessage = "Assigned Booking has been completed successfully.";
											  
											  notification.setUserCode(userCode);
											  notification.setMessage(bodyContentNoti);
											  notification.setShortMessage(shortMessage);
											  notification.setRideCode(b.getRideCode());

											  notification.setIpAddress(ip);
											  notification.setIsRead(Boolean.FALSE);
											  
											  notificationService.saveNotification(notification);
                                                                                                                                                                                 
                                                                                         
                                                                                           List<DeviceDetail> deviceDetailResList  = deviceDetailDao.getDeviceDetailByUserCode(d.getDriverCode().trim());
                                                                                           if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                                                                                           {
                                                                                               for(DeviceDetail deviceDetail:deviceDetailResList)
                                                                                               {                                                                                                  
                                                                                                   PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Ride Alert", "Assigned Booking has been completed successfully.");
                                                                                               }
                                                                                               
                                                                                           }
                                                                                         
										  }
									   }
								   }
								   
							   }catch(Exception e){
								   e.printStackTrace();
							   }
							
						

						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Assigned Booking has been completed successfully");
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(abres);
						jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Failed");
							}
						
							} else {
								jsonobj.put("responsecode", 404);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record Not Found");
							}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Failed");
					}

					// } else {
					// jsonobj.put("responsecode", 404);
					// jsonobj.put("timestamp", new Date());
					// jsonobj.put("message", "Record Not Found");
					// }
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Booking record not found");
				}
                                } else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Driver does not exist.");
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
                        e.printStackTrace();
                        LOG.error("Exception is occurred.",e);

		}
		return res;
	}

	@Override
	public String getBookingByRideCodeWithName(String rideCode) {
		String res = "";
		BookingAllResponse brwo = null;
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = bookingDao.getBookingByRideCodeWithName(rideCode);
//			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 6) {

						brwo = new BookingAllResponse();
						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[5];
                                                
						String conDt="";
                                                String dropOffTime ="";     
                                                
                                                
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                

                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TimeZone);
                                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        if(data.getPickUpTime()!=null){
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                        }
                                                        if(data.getDropOffTime()!=null){
                                                          Date pDate = data.getDropOffTime();
                                                          pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                          dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                           }
                                                    }
                                                }                  
                                                 
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat); 
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());

						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                AssignBooking ab = (AssignBooking) arr[4];
                                                if (ab != null && ab.getId() > 0) {
                                    if (ab.getOperatorCode() != null && ab.getOperatorCode().length() > 0) {
                                        brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                        Operator op = operatorDao.getOperatorByOperatorCode(ab.getOperatorCode());
                                        if (op != null && op.getId() > 0 && op.getOperatorName() != null) {
                                            brwo.setAssignorOperatorName(op.getOperatorName());
                                        }
                                    }

                                    if (ab.getDriverCode() != null && ab.getDriverCode().length() > 0) {
                                        brwo.setDriverCode(ab.getDriverCode());
                                        Driver dr = driverDao.getDriverByDriverCode(ab.getDriverCode());
                                        if (dr != null && dr.getId() > 0 && dr.getName() != null) {
                                            brwo.setDriverName(dr.getName());
                                             brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                        }
                                    }
                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
//						maplst.add(brwo);

					}
				}
				if (brwo != null) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(brwo);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String getBookingByBookingStatus(String bookingStatus) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = bookingDao.getBookingByBookingStatus(bookingStatus);
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt="";
                                                String dropOffTime="";
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                 String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                

                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        if(data.getPickUpTime()!=null){
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                        }
                                                        if(data.getDropOffTime()!=null){
                                                             Date pDate = data.getDropOffTime();
                                                              pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                   }
                                                    }
                                                }              
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat); 
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());

                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());

						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String getBookingByBookingStatusByPage(String bookingStatus, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
				List<Object> objlstCheck = bookingDao.getBookingByBookingStatus(bookingStatus);
				int count = objlstCheck.size();
			Pageable pageableRequest = PageRequest.of(page, limit);
			

			List<Object> objlst = bookingDao.getBookingByBookingStatus(bookingStatus, pageableRequest);
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt="";
                                                String dropOffTime="";
                                    String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                     String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                    {
                                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                                    }                

                                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                    TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                    if (tzd != null && tzd.getId() > 0) {

                                        String timezone = tzd.getTimeZoneName();
                                        if(timezone!=null && timezone.length()>0 )
                                        {
                                            if(data.getPickUpTime()!=null){
                                             Date pDate = data.getPickUpTime();
                                             pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                             conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                            }
                                            if(data.getDropOffTime()!=null){
                                                 Date pDate = data.getDropOffTime();
                                                 pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                 dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                     }
                                        }
                                    }                         
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat); 
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());

						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String getBookingByOperatorCode(String operatorCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = bookingDao.getBookingByOperatorCode(operatorCode);
			List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                            Operator operator = operatorRepository.getOperatorByOperatorCode(operatorCode);
                            String organizationCode = operator.getOrganizationCode();
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TIMEFORMAT);
                             String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);

                            TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 6) {

						BookingAllResponse brwo = new BookingAllResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[5];
						String conDt="";
                                                String dropOffTime="";
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        if(data.getPickUpTime()!=null){
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                        }
                                                        if(data.getDropOffTime()!=null){
                                                          Date pDate = data.getDropOffTime();
                                                            pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                           dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                             }
                                                    }
                                                }             
                                                
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());
                                                brwo.setCancelationComment(data.getCancelationComment());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                AssignBooking ab=(AssignBooking) arr[4];
                                                if(ab!=null && ab.getId()>0)
                                                {
                                                    if(ab.getOperatorCode()!=null && ab.getOperatorCode().length()>0)
                                                    {
                                                        brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                                       Operator op=operatorDao.getOperatorByOperatorCode(ab.getOperatorCode());
                                                       if(op!=null && op.getId()>0 && op.getOperatorName()!=null)
                                                       {
                                                          brwo.setAssignorOperatorName(op.getOperatorName());
                                                       }
                                                    }
                                                    
                                                    if(ab.getDriverCode()!=null && ab.getDriverCode().length()>0)
                                                    {
                                                        brwo.setDriverCode(ab.getDriverCode());
                                                       Driver dr=driverDao.getDriverByDriverCode(ab.getDriverCode());
                                                       if(dr!=null && dr.getId()>0 && dr.getName()!=null)
                                                       {
                                                          brwo.setDriverName(dr.getName());
                                                           brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                                       }
                                                    }
                                                }
                                                if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date curdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (curdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                             GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String getBookingByOperatorCodeByPage(String operatorCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
				List<Object> objlstCheck = bookingDao.getBookingByOperatorCode(operatorCode);
				int count = objlstCheck.size();

			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = bookingDao.getBookingByOperatorCode(operatorCode, pageableRequest);
			List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                            Operator operator = operatorRepository.getOperatorByOperatorCode(operatorCode);
                            String organizationCode = operator.getOrganizationCode();
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TIMEFORMAT);
                            String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);

                            TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 6) {

						BookingAllResponse brwo = new BookingAllResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[5];
						String conDt="";
                                                String dropOffTime="";
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        if(data.getPickUpTime()!=null){
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                        }
                                                        if(data.getDropOffTime()!=null){
                                                             Date pDate = data.getDropOffTime();
                                                             pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                             dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                             }
                                                    }
                                                }         
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());
                                                brwo.setCancelationComment(data.getCancelationComment());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                AssignBooking ab=(AssignBooking) arr[4];
                                                if(ab!=null && ab.getId()>0)
                                                {
                                                    if(ab.getOperatorCode()!=null && ab.getOperatorCode().length()>0)
                                                    {
                                                        brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                                       Operator op=operatorDao.getOperatorByOperatorCode(ab.getOperatorCode());
                                                       if(op!=null && op.getId()>0 && op.getOperatorName()!=null)
                                                       {
                                                          brwo.setAssignorOperatorName(op.getOperatorName());
                                                       }
                                                    }
                                                    
                                                    if(ab.getDriverCode()!=null && ab.getDriverCode().length()>0)
                                                    {
                                                        brwo.setDriverCode(ab.getDriverCode());
                                                       Driver dr=driverDao.getDriverByDriverCode(ab.getDriverCode());
                                                       if(dr!=null && dr.getId()>0 && dr.getName()!=null)
                                                       {
                                                          brwo.setDriverName(dr.getName());
                                                           brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                                       }
                                                    }
                                                }
                                                if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date curdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (curdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
		} else {
			jsonobj.put("responsecode", 400);
			jsonobj.put("message", "Limit should not be Zero or Negative.");
			jsonobj.put("timestamp", new Date());
		}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	}

	@Override
	public String getAllBookingByDateByPage(Date fromDT, Date toDT, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
				List<Object> objlstCheck = bookingDao.getAllBookingByDate(fromDT, toDT);
				int count = objlstCheck.size();

			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = bookingDao.getAllBookingByDate(fromDT, toDT,pageableRequest);
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt="";
                                                String dropOffTime ="";
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                

                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        if(data.getPickUpTime()!=null){
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                        }
                                                         if(data.getDropOffTime()!=null){
                                                            Date pDate = data.getDropOffTime();
                                                       pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                        dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                       }                
                                                    }
                                                }             
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setIsPublished(data.getIsPublished());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
			}
			if (maplst != null && maplst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
                        LOG.error("Exception is occurred.",e);

		}
		return res;
	}

	@Override
	public String getAllBookingByDate(Date fromDT, Date toDT) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = bookingDao.getAllBookingByDate(fromDT, toDT);
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt="";
                                                String dropOffTime="";
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                

                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        if(data.getPickUpTime()!=null){
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                        }
                                                        if(data.getDropOffTime()!=null){
                                                        Date pDate = data.getDropOffTime();
                                                        pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                        dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                       }
                                                    }
                                                }          
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setIsPublished(data.getIsPublished());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
			}
			if (maplst != null && maplst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
                        LOG.error("Exception is occurred.",e);

		}
		return res;
	}

	@Override
	public String getAllAcceptedBookingByDateByPage(Date fromDT, Date toDT, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
				List<Object> objlstCheck = bookingDao.getAllAcceptedBookingByDate(GigflexConstants.assignedBookingAcceptedStatus, fromDT, toDT);
				int count = objlstCheck.size();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = bookingDao.getAllAcceptedBookingByDate(GigflexConstants.assignedBookingAcceptedStatus, fromDT, toDT, pageableRequest);
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt="";
                                                String dropOffTime="";
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                

                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        if(data.getPickUpTime()!=null){
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                        }
                                                        if(data.getDropOffTime()!=null){
                                                           Date pDate = data.getDropOffTime();
                                                           pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                           dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                            }
                                                    }
                                                }          
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setIsPublished(data.getIsPublished());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
			}
			if (maplst != null && maplst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
                        LOG.error("Exception is occurred.",e);

		}
		return res;
	}

	@Override
	public String getAllAcceptedBookingByDate(Date fromDT, Date toDT) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = bookingDao.getAllAcceptedBookingByDate(GigflexConstants.assignedBookingAcceptedStatus, fromDT, toDT);
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						BookingResponse brwo = new BookingResponse();

						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						String conDt="";
                                                String dropOffTime="";
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                

                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        if(data.getPickUpTime()!=null){
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                        }
                                                        if(data.getDropOffTime()!=null){
                                                            Date pDate = data.getDropOffTime();
                                                              pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                               dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                   }
                                                    }
                                                }          
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setIsPublished(data.getIsPublished());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
						maplst.add(brwo);

					}
				}
			}
			if (maplst != null && maplst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
                        LOG.error("Exception is occurred.",e); 

		}
		return res;
	}

    @Override
    public String getAllBookingByOperatorCodeWithFilterByPage(String operatorCode, String status, String stratDT,String endDT, int page, int limit) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {

                        Pageable pageableRequest = PageRequest.of(page, limit);
                        
                        

                        Operator opr=operatorDao.getOperatorByOperatorCode(operatorCode);
                       
                        if(opr!=null && opr.getId()>0 && opr.getOrganizationCode()!=null)
                        {
                                String organizationCode = opr.getOrganizationCode();
                                Organization org = orgDao.findByOrganizationCode(opr.getOrganizationCode());
                                String timezone=null;
                                Date sDT=null;
                                Date eDT=null;
                         
			        
                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);
                               
                                TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                if (tz != null && tz.getTimeZoneName() != null) 
                                {
                                    timezone = tz.getTimeZoneName();
                                    if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
                                  {
                                    stratDT=stratDT+" 00:00:00";
                                    endDT=endDT+" 00:00:00";        
                        
                                    //Date sd = GigflexDateUtil.getGMTtoLocationDate(sDT,timezone, GigflexConstants.dateFormatterForView);
                                    sDT = GigflexDateUtil.convertStringDateToGMT(stratDT, timezone, GigflexConstants.dateFormatterForSave);
                                    eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.dateFormatterForSave);
                                    if (sDT == null || eDT == null) {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                "Date conversion has been failed.");
                                        return derr.toString();
                                    }
                                    Calendar cal = Calendar.getInstance();
                                    cal.setTime(eDT);
                                    cal.add(Calendar.DATE, 1);
                                    eDT = cal.getTime();
                                 }
                                }
                            
			             		List<Object> objlstCheck =null;
			                        if(status.equalsIgnoreCase("all"))
			                        {
			                          if(sDT!=null && eDT!=null)
			                          {
			                        	  objlstCheck=bookingDao.getAllBookingByOperatorCodeWithFilter(operatorCode, sDT, eDT);  
			                          }
			                          else
			                          {
			                        	  objlstCheck=bookingDao.getAllBookingByOperatorCodeWithFilter(operatorCode);  
			                          }
			                        }
			                        else
			                        {
			                            if(sDT!=null && eDT!=null)
			                          {
			                            	objlstCheck=bookingDao.getAllBookingByOperatorCodeWithFilter(operatorCode,status, sDT, eDT);
			                          }
			                            else
			                            {
			                            	objlstCheck=bookingDao.getAllBookingByOperatorCodeWithFilter(operatorCode,status);
			                            }
			                        }
			                        
			        				int count = objlstCheck.size();
                                     
                                     
			List<Object> objlst =null;
                        if(status.equalsIgnoreCase("all"))
                        {
                          if(sDT!=null && eDT!=null)
                          {
                            objlst=bookingDao.getAllBookingByOperatorCodeWithFilter(operatorCode, sDT, eDT,pageableRequest);  
                          }
                          else
                          {
                              objlst=bookingDao.getAllBookingByOperatorCodeWithFilter(operatorCode,pageableRequest);  
                          }
                        }
                        else
                        {
                            if(sDT!=null && eDT!=null)
                          {
                        objlst=bookingDao.getAllBookingByOperatorCodeWithFilter(operatorCode,status, sDT, eDT,pageableRequest);
                          }
                            else
                            {
                                objlst=bookingDao.getAllBookingByOperatorCodeWithFilter(operatorCode,status,pageableRequest);
                            }
                        }
			List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TIMEFORMAT);
                              String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);

                            TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	

                            for (int i = 0; i < objlst.size(); i++) {
                                
                                Object[] arr = (Object[]) objlst.get(i);
                                if (arr.length >= 6) {

                                BookingAllResponse brwo = new BookingAllResponse();
                                String conDt="";
                                String dropOffTime="";
                                Booking data = (Booking) arr[0];
                                Passenger passengerData = (Passenger) arr[5];

//                               Date pDate = data.getPickUpTime();
//                               if(timezone!=null)
//                               {
//                                pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, GigflexConstants.dateFormatterForView); 
//                               conDt=GigflexDateUtil.converDateToString(pDate);
//                                        }
                                                        
                                                       if (tzd != null && tzd.getId() > 0) {

                                                            timezone = tzd.getTimeZoneName();
                                                            if(timezone!=null && timezone.length()>0 )
                                                            {
                                                                if(data.getPickUpTime()!=null){
                                                                 Date pDate = data.getPickUpTime();
                                                                 pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                 conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                }
                                                                if(data.getDropOffTime()!=null){
                                                                     Date pDate = data.getDropOffTime();
                                                                      pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                      dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                                     }
                                                                 
                                                            }
                                                        }    
                            
                                                        brwo.setDateFormat(dateformat);
                                                        brwo.setTimeFormat(timeformat); 
                                                        brwo.setBookingid(data.getBookingid());
							brwo.setId(data.getId());
							brwo.setRideCode(data.getRideCode());
                                                        brwo.setPassengerName(passengerData.getPassengerName());
                                                        brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                        brwo.setpCountryCode(passengerData.getpCountryCode());
                                                        brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                        brwo.setsCountryCode(passengerData.getsCountryCode());
                                                        brwo.setPassengerCode(passengerData.getPassengerCode());

							brwo.setPickUpTime(conDt);
                                                        brwo.setDropOffTime(dropOffTime);
							brwo.setPickLat(data.getPickLat());
							brwo.setPickLang(data.getPickLang());
							brwo.setPickUpAddress(data.getPickUpAddress());
							brwo.setDropLat(data.getDropLat());
							brwo.setDropLang(data.getDropLang());
							brwo.setDropOffAddress(data.getDropOffAddress());
							brwo.setAdditionalStopPage(data.getAdditionalStopPage());
							brwo.setVehicleCode(data.getVehicleCode());
							brwo.setNoOfPassengers(data.getNoOfPassengers());
							brwo.setNoOfBaggage(data.getNoOfBaggage());
							brwo.setAdditionalComment(data.getAdditionalComment());
							brwo.setCustomerFare(data.getCustomerFare());
                                                        brwo.setCurrencySymbol(currencySymbol);
							brwo.setBookingStatus(data.getBookingStatus());
							brwo.setPaymentOption(data.getPaymentOption());
							brwo.setOrganizationCode(data.getOrganizationCode());
							brwo.setOperatorCode(data.getOperatorCode());
							brwo.setIsPublished(data.getIsPublished());
                                                        brwo.setCancelationComment(data.getCancelationComment());
							brwo.setOrganizationName((String) arr[1]);
							brwo.setVehicleName((String) arr[2]);
							brwo.setOperatorName((String) arr[3]);
                                                        AssignBooking ab=(AssignBooking) arr[4];
                                                if(ab!=null && ab.getId()>0)
                                                {
                                                    if(ab.getOperatorCode()!=null && ab.getOperatorCode().length()>0)
                                                    {
                                                        brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                                       Operator op=operatorDao.getOperatorByOperatorCode(ab.getOperatorCode());
                                                       if(op!=null && op.getId()>0 && op.getOperatorName()!=null)
                                                       {
                                                          brwo.setAssignorOperatorName(op.getOperatorName());
                                                       }
                                                    }
                                                    
                                                    if(ab.getDriverCode()!=null && ab.getDriverCode().length()>0)
                                                    {
                                                        brwo.setDriverCode(ab.getDriverCode());
                                                       Driver dr=driverDao.getDriverByDriverCode(ab.getDriverCode());
                                                       if(dr!=null && dr.getId()>0 && dr.getName()!=null)
                                                       {
                                                          brwo.setDriverName(dr.getName());
                                                           brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                                       }
                                                    }
                                                }
                                                if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date curdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (curdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
							maplst.add(brwo);
						

					}
				}
			}
			if (maplst != null && maplst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Operator does not exist.");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}        

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
                        LOG.error("Exception is occurred.",e);

		}
		return res;
    }

    @Override
    public String getAllLatestBookingByOperatorCodeWithFilterByPage(String operatorCode, List<String> status, String stratDT, String endDT, int page, int limit) {
        
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            if (limit > 0) {
                
         
                        List<String> orderLst = new ArrayList<String>();
                        orderLst.add(GigflexConstants.assignedBookingStatus);
                        orderLst.add(GigflexConstants.assignedBookingPublishedStatus);
                        orderLst.add(GigflexConstants.assignedBookingRejectedStatus);
                        orderLst.add(GigflexConstants.assignedBookingInProgressStatus);
                        orderLst.add(GigflexConstants.bookingStatus);
                        orderLst.add(GigflexConstants.assignedBookingAcceptedStatus);
                        orderLst.add(GigflexConstants.assignedBookingCompletedStatus);
                        orderLst.add(GigflexConstants.assignedBookingCancelledStatus);
                        orderLst.add(GigflexConstants.assignedBookingExpiredStatus);
                        
                        
                        
                        
                Pageable pageableRequest = PageRequest.of(page, limit);

                Operator opr = operatorDao.getOperatorByOperatorCode(operatorCode);
                if (opr != null && opr.getId() > 0 && opr.getOrganizationCode() != null) {
                    
                    String organizationCode = opr.getOrganizationCode();
                    Organization org = orgDao.findByOrganizationCode(opr.getOrganizationCode());
                    String timezone = null;
                    Date sDT = null;
                    Date eDT = null;

                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);
                    TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    if (tz != null && tz.getTimeZoneName() != null) {
                        timezone = tz.getTimeZoneName();
                        if (stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                            stratDT = stratDT + " 00:00:00";
                            endDT = endDT + " 00:00:00";

                            //Date sd = GigflexDateUtil.getGMTtoLocationDate(sDT,timezone, GigflexConstants.dateFormatterForView);
                            sDT = GigflexDateUtil.convertStringDateToGMT(stratDT, timezone, GigflexConstants.dateFormatterForSave);
                            eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.dateFormatterForSave);
                            if (sDT == null || eDT == null) {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Date conversion has been failed.");
                                return derr.toString();
                            }
                            Calendar cal = Calendar.getInstance();
                            cal.setTime(eDT);
                            cal.add(Calendar.DATE, 1);
                            eDT = cal.getTime();
                        }
                    }

                    List<Object> objlstCheck = null;

                    int count = 0;
                    
                    if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.assignedBookingStatus);
                        stlst.add(GigflexConstants.assignedBookingInProgressStatus);
                        stlst.add(GigflexConstants.assignedBookingAcceptedStatus);
                        stlst.add(GigflexConstants.assignedBookingRejectedStatus);
                        stlst.add(GigflexConstants.assignedBookingChangedStatus);
                        stlst.add(GigflexConstants.bookingStatus);
                        stlst.add(GigflexConstants.assignedBookingPublishedStatus);
                        status = stlst;
                    }

                    List<Object> objlst = null;

                    if (sDT != null && eDT != null) {
                        objlst = bookingDao.getAllLatestBookingByOperatorCodeWithFilterByPage(operatorCode, status, sDT, eDT,orderLst, pageableRequest);
                        objlstCheck = bookingDao.getAllLatestBookingByOperatorCodeWithFilterByPage(operatorCode, status, sDT, eDT,orderLst);
                        if (objlstCheck != null && objlstCheck.size() > 0) {
                            count = objlstCheck.size();
                        }
                    } else {
                        objlst = bookingDao.getAllLatestBookingByOperatorCodeWithFilterByPage(operatorCode, status,orderLst, pageableRequest);
                        objlstCheck = bookingDao.getAllLatestBookingByOperatorCodeWithFilterByPage(operatorCode, status,orderLst);
                        if (objlstCheck != null && objlstCheck.size() > 0) {
                            count = objlstCheck.size();
                        }
                    }

                    List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
                    if (objlst != null && objlst.size() > 0) {
                        
                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.DATEFORMAT);
                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TIMEFORMAT);
                        String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                        {
                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                        }                

                        timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);

                        TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                        
                        for (int i = 0; i < objlst.size(); i++) {
                            Object[] arr = (Object[]) objlst.get(i);
                            if (arr.length >= 6) {

                                BookingAllResponse brwo = new BookingAllResponse();
                                String conDt = "";
                                String dropOffTime="";
                                Booking data = (Booking) arr[0];
                                Passenger passengerData = (Passenger) arr[5];
                                
                                
                                if (tzd != null && tzd.getId() > 0) {

                                    timezone = tzd.getTimeZoneName();
                                    if(timezone!=null && timezone.length()>0 )
                                    {
                                        if(data.getPickUpTime()!=null){
                                         Date pDate = data.getPickUpTime();
                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                        }
                                        if(data.getDropOffTime()!=null){
                                             Date pDate = data.getDropOffTime();
                                            pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                           dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                   }
                                    }
                                }    
                                brwo.setDateFormat(dateformat);
                                brwo.setTimeFormat(timeformat);
                                brwo.setBookingid(data.getBookingid());
                                brwo.setId(data.getId());
                                brwo.setRideCode(data.getRideCode());
                                brwo.setPassengerName(passengerData.getPassengerName());
                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                brwo.setPassengerCode(passengerData.getPassengerCode());

                                brwo.setPickUpTime(conDt);
                                brwo.setDropOffTime(dropOffTime);
                                brwo.setPickLat(data.getPickLat());
                                brwo.setPickLang(data.getPickLang());
                                brwo.setPickUpAddress(data.getPickUpAddress());
                                brwo.setDropLat(data.getDropLat());
                                brwo.setDropLang(data.getDropLang());
                                brwo.setDropOffAddress(data.getDropOffAddress());
                                brwo.setAdditionalStopPage(data.getAdditionalStopPage());
                                brwo.setVehicleCode(data.getVehicleCode());
                                brwo.setNoOfPassengers(data.getNoOfPassengers());
                                brwo.setNoOfBaggage(data.getNoOfBaggage());
                                brwo.setAdditionalComment(data.getAdditionalComment());
                                brwo.setCustomerFare(data.getCustomerFare());
                                brwo.setCurrencySymbol(currencySymbol);
                                brwo.setBookingStatus(data.getBookingStatus());
                                brwo.setPaymentOption(data.getPaymentOption());
                                brwo.setOrganizationCode(data.getOrganizationCode());
                                brwo.setOperatorCode(data.getOperatorCode());
                                brwo.setIsPublished(data.getIsPublished());
                                brwo.setCancelationComment(data.getCancelationComment());
                                
                                List<Object> additionalChargesList = additionalchargesdao.getAdditionalchargesByRideCode(data.getRideCode());
                                
                                if(additionalChargesList != null && additionalChargesList.size() > 0)
                                {
                                    List<AdditionalChargesResponse>  additionalChargesResList = new  ArrayList<AdditionalChargesResponse>();
                                    for(int k= 0; k <additionalChargesList.size();k++)
                                    {
                                         Object[] arrAddtionalCharges = (Object[]) additionalChargesList.get(k);
                                         
                                        if (arrAddtionalCharges.length >= 2) {

                                            AdditionalChargesResponse additionalChargesres = new AdditionalChargesResponse(); 
                                            AdditionalCharges additionalChargesdata = (AdditionalCharges) arrAddtionalCharges[0];
                                            String additionalFareypeCodeName = (String) arrAddtionalCharges[1];
                                            additionalChargesres.setAdditionalFareypeCode(additionalChargesdata.getAdditionalFareypeCode()); 
                                            additionalChargesres.setAdditionalFareypeCodeName(additionalFareypeCodeName);
                                            additionalChargesres.setAmmount(additionalChargesdata.getAmmount());
                                            additionalChargesres.setQuantity(additionalChargesdata.getQuantity());
                                            additionalChargesres.setCurrencySymbol(currencySymbol); 
                                            additionalChargesResList.add(additionalChargesres);
                                        }
                                    }
                                    brwo.setAdditionalChargesDetails(additionalChargesResList);
                                }
                                
                                brwo.setOrganizationName((String) arr[1]);
                                brwo.setVehicleName((String) arr[2]);
                                brwo.setOperatorName((String) arr[3]);
                                AssignBooking ab = (AssignBooking) arr[4];
                                if (ab != null && ab.getId() > 0) {
                                    if (ab.getOperatorCode() != null && ab.getOperatorCode().length() > 0) {
                                        brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                        Operator op = operatorDao.getOperatorByOperatorCode(ab.getOperatorCode());
                                        if (op != null && op.getId() > 0 && op.getOperatorName() != null) {
                                            brwo.setAssignorOperatorName(op.getOperatorName());
                                        }
                                    }

                                    if (ab.getDriverCode() != null && ab.getDriverCode().length() > 0) {
                                        brwo.setDriverCode(ab.getDriverCode());
                                        Driver dr = driverDao.getDriverByDriverCode(ab.getDriverCode());
                                        if (dr != null && dr.getId() > 0 && dr.getName() != null) {
                                            brwo.setDriverName(dr.getName());
                                             brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                        }
                                    }
                                }
                                if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date curdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (curdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
                                maplst.add(brwo);

                            }
                        }
                    }
                    if (maplst != null && maplst.size() > 0) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("count", count);
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(maplst);
                        jsonobj.put("data", new JSONArray(Detail));
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Operator does not exist.");
                    jsonobj.put("timestamp", new Date());
                }
            } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }

            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;

    }
    
    public long genRandomNo()
    {
        long rand=0l;
        Booking b=null;
        do
        {
            rand=System.currentTimeMillis();
            b=bookingDao.getBookingByBookingid(rand);
        }while(b!=null && b.getId()>0);
        return rand;
    }

    
    @Override
    public String getBookingByBookingID(Long bookingid) {
        
		String res = "";
		BookingResponse brwo = null;
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = bookingDao.getBookingByBookingidWithName(bookingid);
//			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {

						brwo = new BookingResponse();
						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						 String conDt="";
                                                String dropOffTime="";
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization,  data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                

                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                                TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                if (tzd != null && tzd.getId() > 0) {

                                                    String timezone = tzd.getTimeZoneName();
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        
                                                        if(data.getPickUpTime()!=null){
                                                         Date pDate = data.getPickUpTime();
                                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                        }
                                                        if(data.getDropOffTime()!=null){
                                                        Date pDate = data.getDropOffTime();
                                                        pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                        dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                         }
                                                    }
                                                }    
                                                brwo.setDateFormat(dateformat);
                                                brwo.setTimeFormat(timeformat);
                                                brwo.setBookingid(data.getBookingid());
						brwo.setId(data.getId());
						brwo.setRideCode(data.getRideCode());
                                                brwo.setPassengerName(passengerData.getPassengerName());
                                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                                brwo.setPassengerCode(passengerData.getPassengerCode());

						brwo.setPickUpTime(conDt);
                                                brwo.setDropOffTime(dropOffTime);
						brwo.setPickLat(data.getPickLat());
						brwo.setPickLang(data.getPickLang());
						brwo.setPickUpAddress(data.getPickUpAddress());
						brwo.setDropLat(data.getDropLat());
						brwo.setDropLang(data.getDropLang());
						brwo.setDropOffAddress(data.getDropOffAddress());
						brwo.setAdditionalStopPage(data.getAdditionalStopPage());
						brwo.setVehicleCode(data.getVehicleCode());
						brwo.setNoOfPassengers(data.getNoOfPassengers());
						brwo.setNoOfBaggage(data.getNoOfBaggage());
						brwo.setAdditionalComment(data.getAdditionalComment());
						brwo.setCustomerFare(data.getCustomerFare());
                                                brwo.setCurrencySymbol(currencySymbol);
						brwo.setBookingStatus(data.getBookingStatus());
						brwo.setPaymentOption(data.getPaymentOption());
						brwo.setOrganizationCode(data.getOrganizationCode());
						brwo.setOperatorCode(data.getOperatorCode());
						brwo.setIsPublished(data.getIsPublished());

						brwo.setOrganizationName((String) arr[1]);
						brwo.setVehicleName((String) arr[2]);
						brwo.setOperatorName((String) arr[3]);
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
//						maplst.add(brwo);

					}
				}
				if (brwo != null) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(brwo);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
	
    }

    @Override
    public String getAllLatestBookingByOrganizationCodeWithFilterByPage(String organizationCode, List<String> status, String stratDT, String endDT, int page, int limit) {
      
        
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            if (limit > 0) {
                
         
                        List<String> orderLst = new ArrayList<String>();
                        orderLst.add(GigflexConstants.assignedBookingStatus);
                        orderLst.add(GigflexConstants.assignedBookingPublishedStatus);
                        orderLst.add(GigflexConstants.assignedBookingRejectedStatus);
                        orderLst.add(GigflexConstants.assignedBookingInProgressStatus);
                        orderLst.add(GigflexConstants.bookingStatus);
                        orderLst.add(GigflexConstants.assignedBookingAcceptedStatus);
                        orderLst.add(GigflexConstants.assignedBookingCompletedStatus);
                        orderLst.add(GigflexConstants.assignedBookingCancelledStatus);
                        orderLst.add(GigflexConstants.assignedBookingExpiredStatus);
                        
                Pageable pageableRequest = PageRequest.of(page, limit);

                 Organization org = orgDao.findByOrganizationCode(organizationCode);
                if (org != null && org.getId() > 0 ) {
                   
                    String timezone = null;
                    Date sDT = null;
                    Date eDT = null;

                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);
                    TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    if (tz != null && tz.getTimeZoneName() != null) {
                        timezone = tz.getTimeZoneName();
                        if (stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                            stratDT = stratDT + " 00:00:00";
                            endDT = endDT + " 00:00:00";

                            //Date sd = GigflexDateUtil.getGMTtoLocationDate(sDT,timezone, GigflexConstants.dateFormatterForView);
                            sDT = GigflexDateUtil.convertStringDateToGMT(stratDT, timezone, GigflexConstants.dateFormatterForSave);
                            eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.dateFormatterForSave);
                            if (sDT == null || eDT == null) {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Date conversion has been failed.");
                                return derr.toString();
                            }
                            Calendar cal = Calendar.getInstance();
                            cal.setTime(eDT);
                            cal.add(Calendar.DATE, 1);
                            eDT = cal.getTime();
                        }
                    }
                    List<Object> objlstCheck = null;

                    int count = 0;
                    if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.assignedBookingStatus);
                        stlst.add(GigflexConstants.assignedBookingInProgressStatus);
                        stlst.add(GigflexConstants.assignedBookingAcceptedStatus);
                        stlst.add(GigflexConstants.assignedBookingRejectedStatus);
                        stlst.add(GigflexConstants.assignedBookingChangedStatus);
                        stlst.add(GigflexConstants.bookingStatus);
                        stlst.add(GigflexConstants.assignedBookingPublishedStatus);
                        status = stlst;
                    }

                    List<Object> objlst = null;

                    if (sDT != null && eDT != null) {
                        objlst = bookingDao.getAllLatestBookingByOrganizationCodeWithFilterByPage(organizationCode, status, sDT, eDT,orderLst, pageableRequest);
                        objlstCheck = bookingDao.getAllLatestBookingByOrganizationCodeWithFilterByPage(organizationCode, status, sDT, eDT,orderLst);
                        if (objlstCheck != null && objlstCheck.size() > 0) {
                            count = objlstCheck.size();
                        }
                    } else {
                        objlst = bookingDao.getAllLatestBookingByOrganizationCodeWithFilterByPage(organizationCode, status,orderLst, pageableRequest);
                        objlstCheck = bookingDao.getAllLatestBookingByOrganizationCodeWithFilterByPage(organizationCode, status,orderLst);
                        if (objlstCheck != null && objlstCheck.size() > 0) {
                            count = objlstCheck.size();
                        }
                    }

                    List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
                    if (objlst != null && objlst.size() > 0) {
                        
                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.DATEFORMAT);
                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TIMEFORMAT);
                        String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization,  organizationCode, GigflexConstants.CURRENCYSYMBOL);
                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                        {
                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                        }                

                        String timeznCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);

                        TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timeznCode);
                        
                        for (int i = 0; i < objlst.size(); i++) {
                            Object[] arr = (Object[]) objlst.get(i);
                            if (arr.length >= 6) {

                                BookingAllResponse brwo = new BookingAllResponse();
                                String conDt = "";
                                String dropOffTime="";
                                Booking data = (Booking) arr[0];
                                Passenger passengerData = (Passenger) arr[5];
                                	
                                if (tzd != null && tzd.getId() > 0) {

                                    timezone = tzd.getTimeZoneName();
                                    if(timezone!=null && timezone.length()>0 )
                                    {
                                        if(data.getPickUpTime()!=null){
                                         Date pDate = data.getPickUpTime();
                                         pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                         conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                        }
                                        if(data.getDropOffTime()!=null){
                                            Date pDate = data.getDropOffTime();
                                        pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                           dropOffTime=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                             }
                                    }
                                }    
                                brwo.setDateFormat(dateformat);
                                brwo.setTimeFormat(timeformat); 
                                brwo.setBookingid(data.getBookingid());
                                brwo.setId(data.getId());
                                brwo.setRideCode(data.getRideCode());
                                brwo.setPassengerName(passengerData.getPassengerName());
                                brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                brwo.setpCountryCode(passengerData.getpCountryCode());
                                brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                brwo.setsCountryCode(passengerData.getsCountryCode());
                                brwo.setPassengerCode(passengerData.getPassengerCode());

                                brwo.setPickUpTime(conDt);
                                brwo.setDropOffTime(dropOffTime);
                                brwo.setPickLat(data.getPickLat());
                                brwo.setPickLang(data.getPickLang());
                                brwo.setPickUpAddress(data.getPickUpAddress());
                                brwo.setDropLat(data.getDropLat());
                                brwo.setDropLang(data.getDropLang());
                                brwo.setDropOffAddress(data.getDropOffAddress());
                                brwo.setAdditionalStopPage(data.getAdditionalStopPage());
                                brwo.setVehicleCode(data.getVehicleCode());
                                brwo.setNoOfPassengers(data.getNoOfPassengers());
                                brwo.setNoOfBaggage(data.getNoOfBaggage());
                                brwo.setAdditionalComment(data.getAdditionalComment());
                                brwo.setCustomerFare(data.getCustomerFare());
                                brwo.setCurrencySymbol(currencySymbol);
                                brwo.setBookingStatus(data.getBookingStatus());
                                brwo.setPaymentOption(data.getPaymentOption());
                                brwo.setOrganizationCode(data.getOrganizationCode());
                                brwo.setOperatorCode(data.getOperatorCode());
                                brwo.setIsPublished(data.getIsPublished());
                                brwo.setCancelationComment(data.getCancelationComment());
                                
                                
                                List<Object> additionalChargesList = additionalchargesdao.getAdditionalchargesByRideCode(data.getRideCode());
                                
                                if(additionalChargesList != null && additionalChargesList.size() > 0)
                                {
                                    List<AdditionalChargesResponse>  additionalChargesResList = new  ArrayList<AdditionalChargesResponse>();
                                    for(int k= 0; k <additionalChargesList.size();k++)
                                    {
                                         Object[] arrAddtionalCharges = (Object[]) additionalChargesList.get(k);
                                         
                                        if (arrAddtionalCharges.length >= 2) {

                                            AdditionalChargesResponse additionalChargesres = new AdditionalChargesResponse(); 
                                            AdditionalCharges additionalChargesdata = (AdditionalCharges) arrAddtionalCharges[0];
                                            String additionalFareypeCodeName = (String) arrAddtionalCharges[1];
                                            additionalChargesres.setAdditionalFareypeCode(additionalChargesdata.getAdditionalFareypeCode()); 
                                            additionalChargesres.setAdditionalFareypeCodeName(additionalFareypeCodeName);
                                            additionalChargesres.setAmmount(additionalChargesdata.getAmmount());
                                            additionalChargesres.setQuantity(additionalChargesdata.getQuantity());
                                            additionalChargesres.setCurrencySymbol(currencySymbol); 
                                            additionalChargesResList.add(additionalChargesres);
                                        }
                                    }
                                    brwo.setAdditionalChargesDetails(additionalChargesResList);
                                }
                                  
                                brwo.setOrganizationName((String) arr[1]);
                                brwo.setVehicleName((String) arr[2]);
                                brwo.setOperatorName((String) arr[3]);
                                AssignBooking ab = (AssignBooking) arr[4];
                                if (ab != null && ab.getId() > 0) {
                                    if (ab.getOperatorCode() != null && ab.getOperatorCode().length() > 0) {
                                        brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                        Operator op = operatorDao.getOperatorByOperatorCode(ab.getOperatorCode());
                                        if (op != null && op.getId() > 0 && op.getOperatorName() != null) {
                                            brwo.setAssignorOperatorName(op.getOperatorName());
                                        }
                                    }

                                    if (ab.getDriverCode() != null && ab.getDriverCode().length() > 0) {
                                        brwo.setDriverCode(ab.getDriverCode());
                                        Driver dr = driverDao.getDriverByDriverCode(ab.getDriverCode());
                                        if (dr != null && dr.getId() > 0 && dr.getName() != null) {
                                            brwo.setDriverName(dr.getName());
                                            brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                        }
                                    }
                                }
                                if(data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus) || data.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))
                                                {
                                                    Date curdt=new Date();
                                                    Date picdt=data.getPickUpTime();
                                                    long diff_curdt= (curdt.getTime()/(60 * 1000));
                                                    long diff_picdt= (picdt.getTime()/(60 * 1000));
                                                    long diff = diff_picdt - diff_curdt;
                                                    if(diff>0 && diff<=60)
                                                    {
                                                        brwo.setIsFocused(Boolean.TRUE);
                                                    }
                                                    else
                                                    {
                                                        brwo.setIsFocused(Boolean.FALSE);
                                                    }
                                                }
                                                else
                                                {
                                                   brwo.setIsFocused(Boolean.FALSE);
                                                }
                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
                                maplst.add(brwo);

                            }
                        }
                    }
                    if (maplst != null && maplst.size() > 0) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("count", count);
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(maplst);
                        jsonobj.put("data", new JSONArray(Detail));
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Organization does not exist.");
                    jsonobj.put("timestamp", new Date());
                }
            } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }

            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;

    
    }
    
    @Override
        public String validatePassangerQuantity(String vehicleType, Long noofPassangers)
        {
           String res="";
            try
            {
           JSONObject jsonobj = new JSONObject();
           
           RideType rt=rideTypeRepository.getRideTypeByVehicleCode(vehicleType);
             if(rt!=null && rt.getId()>0)
             {
              String grtc=    rt.getGlobalRidetypeCode();
              String orgCode=rt.getOrganizationCode();
              if(orgCode!=null &&orgCode.trim().length()>0 &&grtc!=null && grtc.trim().length()>0)
              {
               List<String> defoultDriverCodeList=driverDao.getdefoultDriverByOrganizationCode(orgCode);  
               if(defoultDriverCodeList!=null && defoultDriverCodeList.size()>0){
               List<VehicleDetail> vdList= vehicledetailrepository.getVehicledetailListByglobalrideTypeCodeAndVehicleCode(grtc,defoultDriverCodeList);
                  if(vdList!=null && vdList.size()>0)
                  {    boolean nofpassenger=false;
                     JSONObject jsonobj1 = new JSONObject();  
                      for(VehicleDetail vd:vdList)
                      {
                             if(noofPassangers<= vd.getPassengerQuantity())
                             {
                                  nofpassenger= true;
                                    break;
                             }
                             
                      }
                      jsonobj1.put("Status",nofpassenger);
                      
                      if(nofpassenger)
                      {
                        
                              jsonobj.put("responsecode", 200);
                              jsonobj.put("message", "Success");
                              jsonobj.put("timestamp", new Date());
                              jsonobj.put("Data",jsonobj1 );
                      }else
                      {
                           jsonobj.put("responsecode", 400);
                           jsonobj.put("message", "Failled");
                           jsonobj.put("timestamp", new Date());
                           jsonobj.put("Data",jsonobj1 );
                      }
                  
                  }else
                  {
                  
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "VehicleDetail is  not Found");
                    jsonobj.put("timestamp", new Date());
                  }
               
               }else
               {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "DefaultDriverCode is  not Found");
                    jsonobj.put("timestamp", new Date());
               }
             
              }else
              {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Either GlobalRideTypeCode or OrganizationCode are not Found");
                    jsonobj.put("timestamp", new Date());
              }
         
             }else
             {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "RideType Not Found");
                    jsonobj.put("timestamp", new Date());
             }
           res=jsonobj.toString();
            }catch(Exception ex)
            {
               GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
                 ex.printStackTrace();
                res = derr.toString();
                LOG.error("Exception is occurred.",ex);
            }
          return res;
        }
       @Override
         public String validateBaggagesQuantity(String vehicleType,Long noOfBaggages)
         {
                String res="";
            try
            {
           JSONObject jsonobj = new JSONObject();
           
           RideType rt=rideTypeRepository.getRideTypeByVehicleCode(vehicleType);
             if(rt!=null && rt.getId()>0)
             {
              String grtc=    rt.getGlobalRidetypeCode();
              String orgCode=rt.getOrganizationCode();
              if(orgCode!=null &&orgCode.trim().length()>0 &&grtc!=null && grtc.trim().length()>0)
              {
               List<String> defoultDriverCodeList=driverDao.getdefoultDriverByOrganizationCode(orgCode);  
               if(defoultDriverCodeList!=null && defoultDriverCodeList.size()>0){
               List<VehicleDetail> vdList= vehicledetailrepository.getVehicledetailListByglobalrideTypeCodeAndVehicleCode(grtc,defoultDriverCodeList);
                  if(vdList!=null && vdList.size()>0)
                  {    boolean nofbaggages=false;
                     JSONObject jsonobj1 = new JSONObject();  
                      for(VehicleDetail vd:vdList)
                      {
                             if(noOfBaggages<= vd.getBaggageQuantity())
                             {
                                  nofbaggages= true;
                                    break;
                             }
                             
                      }
                      jsonobj1.put("Status",nofbaggages);
                      
                      if(nofbaggages)
                      {
                        
                              jsonobj.put("responsecode", 200);
                              jsonobj.put("message", "Success");
                              jsonobj.put("timestamp", new Date());
                              jsonobj.put("Data",jsonobj1 );
                      }else
                      {
                           jsonobj.put("responsecode", 400);
                           jsonobj.put("message", "Failled");
                           jsonobj.put("timestamp", new Date());
                           jsonobj.put("Data",jsonobj1 );
                      }
                  
                  }else
                  {
                  
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "VehicleDetail is  not Found");
                    jsonobj.put("timestamp", new Date());
                  }
               
               }else
               {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "DefaultDriverCode is  not Found");
                    jsonobj.put("timestamp", new Date());
               }
             
              }else
              {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Either GlobalRideTypeCode or OrganizationCode are not Found");
                    jsonobj.put("timestamp", new Date());
              }
         
             }else
             {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "RideType Not Found");
                    jsonobj.put("timestamp", new Date());
             }
           res=jsonobj.toString();
            }catch(Exception ex)
            {
               GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
                 ex.printStackTrace();
                res = derr.toString();
                LOG.error("Exception is occurred.",ex);
            }
          return res;
           
         }

    @Override
    public String getEligibleDriverListByRideCode(String rideCode,String operatorCode) {
        
        String res = "";
	List<EligibleDriverResponse> eligibleDriverList =  new ArrayList<EligibleDriverResponse>();
		try {
			JSONObject jsonobj = new JSONObject();
			Booking booking = bookingDao.getBookingByRideCode(rideCode);
                        Pageable pageableRequest = PageRequest.of(0, 1); 
			if (booking != null && booking.getId() > 0) {
                        Operator operator=operatorRepository.getOperatorByOperatorCode(operatorCode);
                        if(operator!=null && operator.getId()>0)
                        {
                                   
                            Date bookingPickupTime  = booking.getPickUpTime();
                            Date bookingDropoffTime = booking.getDropOffTime();
                            Calendar cal = Calendar.getInstance();

                            cal.setTime(bookingPickupTime);
                            cal.add(Calendar.HOUR_OF_DAY, -1);                           
                            Date decrementedPickupTime = cal.getTime();

                            cal.setTime(bookingDropoffTime);
                            cal.add(Calendar.HOUR_OF_DAY, 1);
                            Date incrementedDropOffTime = cal.getTime();
                            
                            List<Driver> driverList = driverDao.getDriverByOrganizationCode(operator.getOrganizationCode()); 
                            List<String> drivercodeList = driverDao.getDriverCodeByOrganizationCode(operator.getOrganizationCode());
                            if(drivercodeList != null && drivercodeList.size() > 0 )
                            {
                                List<Driver> busyDriverList = bookingDao.getAssignedBusyDriver(decrementedPickupTime,incrementedDropOffTime,drivercodeList,GigflexConstants.assignedBookingCancelledStatus,GigflexConstants.assignedBookingRejectedStatus,GigflexConstants.assignedBookingCompletedStatus,GigflexConstants.assignedBookingExpiredStatus);
                                driverList.removeAll(busyDriverList) ;
                            }
                            
                           
                           if(driverList != null && driverList.size() > 0)
                           {
                                                          
				for (int i = 0; i < driverList.size(); i++) {
                                    
                                    Driver driver = driverList.get(i);
                                    
                                    
                                    List<DriverTimeOff>  driverTimeOffList = driverTimeOffDao.getTimeOffByDriverCodeAndBetweenDate(driver.getDriverCode(),bookingPickupTime,bookingDropoffTime) ;
                                    if(driverTimeOffList != null && driverTimeOffList.size() > 0 )
                                    {
                                        continue;
                                    }
                                    
                                    String timezone = null;
                                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, operator.getOrganizationCode(), GigflexConstants.TimeZone);
                                    TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                    if (tz != null && tz.getTimeZoneName() != null) {
                                        timezone = tz.getTimeZoneName();               
                                    }
                                    Date pdt=null;
                                    Date ddt=null;
                                    try
                                    {
                                    pdt=GigflexDateUtil.getGMTtoLocationDate( booking.getPickUpTime(), timezone, GigflexConstants.YYYY_MM_DD_HH_MM_SS);
                                    ddt=GigflexDateUtil.getGMTtoLocationDate(booking.getDropOffTime(), timezone, GigflexConstants.YYYY_MM_DD_HH_MM_SS);
                                    }
                                    catch(Exception ee)
                                    {
                                        ee.printStackTrace();
                                    }
                                    if(pdt==null || ddt==null)
                                    {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "Date conversion has been failed.");
                                            return derr.toString();
                                    }
                                    Calendar calPickupDate = Calendar.getInstance();

                                    calPickupDate.setTime(pdt);
                                    int pickupDay = calPickupDate.get(Calendar.DAY_OF_WEEK);
                                   
                                    
                                    
                                    String pickupDT = GigflexDateUtil.convertDateToString(pdt, GigflexConstants.YYYY_MM_DD);
                                    String dropDT = GigflexDateUtil.convertDateToString(ddt, GigflexConstants.YYYY_MM_DD);        
                                            
                                    
                                    HoursOfOperation  hoursOfOperation = hoursOfOperationDao.getHoursByDriverCodeAndDayCode(driver.getDriverCode(), pickupDay); 
                                    
                                    if(hoursOfOperation == null || hoursOfOperation.getId() == 0 )
                                    {
                                        continue;
                                    }
                                    
                                    String fromTime = pickupDT+" "+hoursOfOperation.getFromTime();
                                    String toTime = dropDT+" "+hoursOfOperation.getToTime();
                                    
//                                    Date fromDT = GigflexDateUtil.convertStringToDate(fromTime, GigflexConstants.YYYY_MM_DD_HH_MM_SS);
//                                    Date toDT = GigflexDateUtil.convertStringToDate(toTime, GigflexConstants.YYYY_MM_DD_HH_MM_SS);
                                    
                                    
                                    Date fromDT= null;
                                    Date toDT  = null;
                                    if (timezone != null) {                                      
                                        fromDT = GigflexDateUtil.convertStringDateToGMT(fromTime, timezone, GigflexConstants.dateFormatterForSave);
                                        toDT = GigflexDateUtil.convertStringDateToGMT(toTime, timezone, GigflexConstants.dateFormatterForSave);
                                        if (fromDT == null || toDT == null) {
                                            GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "Date conversion has been failed due to timezone.");
                                            return derr.toString();
                                        }
                                    }
                                    else
                                    {
                                         GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "Date conversion has been failed due to timezone.");
                                            return derr.toString();
                                    }
                                  
                                    
                                    if( !((bookingPickupTime.after(fromDT) || bookingPickupTime.equals(fromDT) ) && (bookingDropoffTime.before(toDT) || bookingDropoffTime.equals(toDT) )))  
                                    {
                                        continue;
                                    }
                                   
                                    
                                    VehicleDetail  vd = vehicleDetailDao.getVehicleDetailByVehicleCode(hoursOfOperation.getVehicleCode());
                                    RideType rt = rideTypeDao.getRideTypeByVehicleCode(booking.getVehicleCode());
                                    EligibleDriverResponse driverRes = new EligibleDriverResponse();
                                    String globalRideCodeFromDriver = "";
                                    String globalRideCodeFromBooking = "";

                                    if(vd != null)
                                    {
                                       globalRideCodeFromDriver = vd.getVehicleType().trim();
                                    }
                                    
                                    if(rt != null)
                                    {
                                        globalRideCodeFromBooking = rt.getGlobalRidetypeCode().trim();
                                    }
                                    
                                    if( !(globalRideCodeFromDriver != null && globalRideCodeFromBooking != null &&  globalRideCodeFromDriver.trim().length() > 0 && globalRideCodeFromBooking.trim().length() > 0
                                            && globalRideCodeFromDriver.equals(globalRideCodeFromBooking)))  
                                    {
                                       
                                        continue; 

                                    }
                                    
                                    
                                    Long numberOfBaggageFromDriver = vd.getBaggageQuantity() ;
                                    int numberOfBaggageFromBooking = booking.getNoOfBaggage();
                                    if(numberOfBaggageFromBooking > numberOfBaggageFromDriver)
                                    {
                                       continue; 
                                    }
                                   
                                    Long numberOfPassengerFromDriver = vd.getPassengerQuantity();
                                    int numberOfPassengerFromBooking = booking.getNoOfPassengers();
                                    if(numberOfPassengerFromBooking > numberOfPassengerFromDriver)
                                    {
                                        continue; 
                                    }
                                    
                                    List<Booking> acceptedBookingList = bookingDao.getNearestBookingByDriverCodeFromPickupTime(driver.getDriverCode(),decrementedPickupTime,GigflexConstants.assignedBookingCancelledStatus,GigflexConstants.assignedBookingExpiredStatus,GigflexConstants.assignedBookingRejectedStatus,pageableRequest);
                                    
                                    
                                    
                                    if(acceptedBookingList != null && acceptedBookingList.size() > 0)
                                    { 
                                        Booking acceptedBooking = acceptedBookingList.get(0);
                                        double bookingLat = Double.parseDouble(booking.getPickLat());
                                        double bookingLan = Double.parseDouble(booking.getPickLang());
                                        double driverLat = Double.parseDouble(acceptedBooking.getDropLat());
                                        double driverLan = Double.parseDouble(acceptedBooking.getDropLang());
                                        char unit = unitMiles;                                        
                                        double distance = distance(bookingLat,bookingLan,driverLat,driverLan,unit);                                        
                                        driverRes.setDistanceFromLastDrop(distance); 
                                        
                                    }
                                    else
                                    {                                          
                                        driverRes.setDistanceFromLastDrop(null);                                          
                                    }
                                     
                                        driverRes.setId(driver.getId());
                                        driverRes.setApproveStatus(driver.getApproveStatus());
                                        driverRes.setCallsign(driver.getCallsign());
                                        driverRes.setContactNumber(driver.getContactNumber());
                                        driverRes.setCountryCode(driver.getCountryCode());
                                        driverRes.setDefaultVehicleCode(vd.getVehicleCode());
                                        driverRes.setVehicleTypeName(rt.getVehicleName());
                                        driverRes.setDriverCode(driver.getDriverCode());
                                        driverRes.setDriverImage(driver.getDriverImage());
                                        driverRes.setEmailId(driver.getEmailId());
                                        driverRes.setName(driver.getName());
                                        driverRes.setOperatorCode(driver.getOperatorCode());
                                        driverRes.setOrganizationCode(driver.getOrganizationCode());
                                        driverRes.setPriority("P2");                                         
                                        eligibleDriverList.add(driverRes) ;
				}
                                
                                
                                        Comparator<EligibleDriverResponse> cm2=Comparator.comparing(EligibleDriverResponse::getDistanceFromLastDrop,Comparator.nullsLast(Comparator.naturalOrder())); 

                                        Collections.sort(eligibleDriverList,cm2);
                                        
                                       if(eligibleDriverList.size() > 0)
                                       {
                                           EligibleDriverResponse resp = eligibleDriverList.get(0);
                                           resp.setPriority("P1");
                                           eligibleDriverList.set(0, resp);
                                       }
                                        
                                
				if (eligibleDriverList != null && eligibleDriverList.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(eligibleDriverList);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail)); 
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
                                
                        }
                           else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Driver Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        }else
                        {
                                jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date()); 
                        }   
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
    }
    
    
    private double distance(double lat1, double lon1, double lat2, double lon2, char unit) {
      double theta = lon1 - lon2;
      double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
      dist = Math.acos(dist);
      dist = rad2deg(dist);
      dist = dist * 60 * 1.1515;
      
      if (unit == 'K') {
        dist = dist * 1.609344;
      }      
      
      return (dist);
    }
    
     private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }
     
    private double rad2deg(double rad) {
         return (rad * 180.0 / Math.PI);
    }
    @Override
    public String getFareByRideCode( String rideCode)
    {
       String res="";
       try{
          JSONObject jsonobj = new JSONObject(); 
       Double fareAmount= bookingDao.getFareByRideCode(rideCode);
            if(fareAmount!=null)
            {
            JSONObject obj=  new JSONObject();
            obj.put("Fare", fareAmount);
            jsonobj.put("responsecode", 200);
	    jsonobj.put("message", "Success");
	    jsonobj.put("timestamp", new Date());
	    jsonobj.put("data",obj);
            }else
            {
              jsonobj.put("responsecode", 404);
	      jsonobj.put("message", "Fare not found");
	      jsonobj.put("timestamp", new Date());
            }
            res=jsonobj.toString();
         }catch(Exception ex)
         {GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
         }
       return res;
    }
     public String getBookingDetailByrideCodeforMobile(String rideCode)
     {
          String res="";
       try{
           
            JSONObject jsonobj = new JSONObject();
            Booking booking=bookingDao.getBookingByRideCode(rideCode);
            if(booking!=null && booking.getId()>0)  
            {    
                BookingDetailByrideCodeforMobileRes bookingres=new BookingDetailByrideCodeforMobileRes();
                bookingres.setPickupaddress(booking.getPickUpAddress());
                bookingres.setDropaddress(booking.getDropOffAddress());
                bookingres.setPickuplat(booking.getPickLat());
                bookingres.setPickuplong(booking.getPickLang());
                bookingres.setDropuplat(booking.getDropLat());
                bookingres.setDropofflong(booking.getDropLang());
                bookingres.setRideCode(booking.getRideCode());
                bookingres.setBookingStatus(booking.getBookingStatus());
                String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, booking.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                if(currencySymbol!=null){
                bookingres.setPrice(currencySymbol+booking.getCustomerFare());
                }else
                {
                 bookingres.setPrice(""+booking.getCustomerFare());
                }
                 jsonobj.put("responsecode", 200);
	         jsonobj.put("message", "Success");
	         jsonobj.put("timestamp", new Date());
                 ObjectMapper obj=new ObjectMapper();
                 String detail=obj.writeValueAsString(bookingres);
	         jsonobj.put("data",new JSONObject(detail));
            }else
            {
              jsonobj.put("responsecode", 404);
	      jsonobj.put("message", "rideCode not found");
	      jsonobj.put("timestamp", new Date());
            }
           res= jsonobj.toString();
           }catch(JSONException ex)
           {
             GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Parsing Exception is occurred.",ex);
           }catch(Exception ex)
           {
                       GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                      LOG.error("Exception is occurred.",ex);
           }
       return res;
     }
     
}
