package com.gigflex.prototype.microservices.ridetype.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;


@Entity
@Table(name = "ridetype")
public class RideType extends CommonAttributes implements Serializable {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "vechicle_code", unique = true)
    private String vehicleCode;

    @Column(name = "vechiclename", nullable = false)
    private String vehicleName;
    
    @Column(name = "baserate", nullable = false)
    private Double baseRate;
    
    @Column(name = "ratepermile", nullable = false)
    private Double ratePerMile;
    
    @Column(name = "organization_code", nullable = false)
    private String organizationCode;
    
	@Column(name = "isglobal", columnDefinition = "boolean default false", nullable = false)
	private Boolean isGlobal = false;

    @Column(name = "global_ridetype_code")
    private String globalRidetypeCode;
    
    @PrePersist
    private void assignUUID() {
        if(this.getVehicleCode()==null || this.getVehicleCode().length()==0)
        {
            this.setVehicleCode((UUID.randomUUID().toString()));
        }
    }


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVehicleCode() {
		return vehicleCode;
	}

	public void setVehicleCode(String vehicleCode) {
		this.vehicleCode = vehicleCode;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public Double getBaseRate() {
		return baseRate;
	}

	public void setBaseRate(Double baseRate) {
		this.baseRate = baseRate;
	}

	public Double getRatePerMile() {
		return ratePerMile;
	}

	public void setRatePerMile(Double ratePerMile) {
		this.ratePerMile = ratePerMile;
	}


	public String getOrganizationCode() {
		return organizationCode;
	}


	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}


	public Boolean getIsGlobal() {
		return isGlobal;
	}


	public void setIsGlobal(Boolean isGlobal) {
		this.isGlobal = isGlobal;
	}

    public String getGlobalRidetypeCode() {
        return globalRidetypeCode;
    }

    public void setGlobalRidetypeCode(String globalRidetypeCode) {
        this.globalRidetypeCode = globalRidetypeCode;
    }
    
    

}
