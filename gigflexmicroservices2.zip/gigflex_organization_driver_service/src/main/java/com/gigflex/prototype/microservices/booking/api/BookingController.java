package com.gigflex.prototype.microservices.booking.api;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.booking.dtob.BookingCompletedUpdateResponse;
import com.gigflex.prototype.microservices.booking.dtob.BookingRequest;
import com.gigflex.prototype.microservices.booking.dtob.BookingUpdateRequest;
import com.gigflex.prototype.microservices.booking.service.BookingNotification;
import com.gigflex.prototype.microservices.booking.service.BookingService;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.TokenUtility;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class BookingController {
	
	@Autowired
	public BookingService bookingService;
	
	@Autowired
	public BookingNotification bookingNotification;
        @Autowired
        TokenUtility tokenutility;
	
	@GetMapping("/getBookingByOrganizationCode/{organizationCode}")
	public String getBookingByOrganizationCode(@PathVariable String organizationCode,@RequestHeader HttpHeaders headers) {
              String res="";
               res=tokenutility.orgCodeValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
               return bookingService.getBookingByOrgCode(organizationCode);
               }else
               {
                 return res;
               }
		
	}
	
	@GetMapping("/getAllAcceptedUpcomingBooking")
	public String getAllAcceptedUpcomingBooking() {
		return bookingNotification.getAllAcceptedUpcomingBooking();
	}
	
	@GetMapping("/getAllAcceptedUpcomingBookingByOperatorCode/{operatorCode}")
	public String getAllAcceptedUpcomingBookingByOperatorCode(@PathVariable String operatorCode,@RequestHeader HttpHeaders headers) {
            
            String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
               return bookingNotification.getAllAcceptedUpcomingBookingByOperatorCode(operatorCode);
               }else
               {
                return res;
               }
		
	}
	
	@GetMapping(path="/getAllAcceptedUpcomingBookingByOperatorCodeByPage/{operatorCode}")
    public String getAllAcceptedUpcomingBookingByOperatorCodeByPage(@PathVariable String operatorCode,@RequestHeader HttpHeaders headers,
    		@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {
           String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                 return  bookingNotification.getAllAcceptedUpcomingBookingByOperatorCodeByPage(operatorCode, page, limit);
               }else
               {
               return res;
               }
    }
    
    
    
    @GetMapping(path="/getAllAcceptedUpcomingBookingByOrganizationCodeByPage/{organizationCode}")
    public String getAllAcceptedUpcomingBookingByOrganizationCodeByPage(@PathVariable String organizationCode,
    		@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
        String res="";
               res=tokenutility.orgCodeValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
                   if(organizationCode!=null && organizationCode.trim().length()>0 ) {

                  String booking = bookingNotification.getAllAcceptedUpcomingBookingByOrganizationCodeByPage(organizationCode.trim(), page, limit);
      
                return booking;
              }
             else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code should not be blank.");
			return derr.toString();
		}
           }else
               {
               return res;
               }

    }
    
    
    
    
    @GetMapping(path="/getAllLatestBookingByOrganizationCodeWithFilterByPage/{organizationCode}/{status}/{stratDT}/{endDT}")
    public String getAllLatestBookingByOrganizationCodeWithFilterByPage(@PathVariable String organizationCode,@PathVariable List<String> status,
            @PathVariable String stratDT,@PathVariable String endDT,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
            String res="";
               res=tokenutility.orgCodeValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
                     if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  ) {

            if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(stratDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
            }
            else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}
		
		
			return bookingService.getAllLatestBookingByOrganizationCodeWithFilterByPage(organizationCode.trim(),status,stratDT.trim(), endDT.trim(),page, limit);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code and Status should not be blank.");
			return derr.toString();
		}
	
               }else
               {
               return res;
               }
   
    }
    
    
    
     @GetMapping(path="/getAllLatestBookingByOrganizationCodeWithFilterByPage/{organizationCode}/{status}")
    public String getAllLatestBookingByOrganizationCodeWithFilterByPage(@PathVariable String organizationCode,@PathVariable List<String> status,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
        
               String res="";
               res=tokenutility.orgCodeValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
                  if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  ) {

            
		
			return bookingService.getAllLatestBookingByOrganizationCodeWithFilterByPage(organizationCode.trim(),status,null, null,page, limit);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code and Status should not be blank.");
			return derr.toString();
		}
	
              }else
               {
              return res;
              }
       
    }
    
    
    
    @GetMapping(path="/getAllLatestBookingByOperatorCodeWithFilterByPage/{operatorCode}/{status}/{stratDT}/{endDT}")
    public String getAllLatestBookingByOperatorCodeWithFilterByPage(@PathVariable String operatorCode,@PathVariable List<String> status,
            @PathVariable String stratDT,@PathVariable String endDT,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
           String res="true";
//               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                   if(operatorCode!=null && operatorCode.trim().length()>0 && status!=null && status.size()>0  ) {

                       if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
                       {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(stratDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
            }
            else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}
		
		
			return bookingService.getAllLatestBookingByOperatorCodeWithFilterByPage(operatorCode.trim(),status,stratDT.trim(), endDT.trim(),page, limit);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Operator Code and Status should not be blank.");
			return derr.toString();
		}
                   
                     
               }else
               {
               return res;
               }
    }
    
    
    
    
     @GetMapping(path="/getAllLatestBookingByOperatorCodeWithFilterByPage/{operatorCode}/{status}")
    public String getAllLatestBookingByOperatorCodeWithFilterByPage(@PathVariable String operatorCode,@PathVariable List<String> status,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
               String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                  if(operatorCode!=null && operatorCode.trim().length()>0 && status!=null && status.size()>0  ) {

			return bookingService.getAllLatestBookingByOperatorCodeWithFilterByPage(operatorCode.trim(),status,null, null,page, limit);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Operator Code and Status should not be blank.");
			return derr.toString();
		}
	
               }else
               {
               return res;
               }

    }
    
    
    
    
    @GetMapping(path="/getAllBookingByOperatorCodeWithFilterByPage/{operatorCode}/{status}/{stratDT}/{endDT}")
    public String getAllBookingByOperatorCodeWithFilterByPage(@PathVariable String operatorCode,@PathVariable String status,
            @PathVariable String stratDT,@PathVariable String endDT,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
               String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                     if(operatorCode!=null && operatorCode.trim().length()>0 && status!=null && status.trim().length()>0  ) {

            if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(stratDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
            }
            else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}
		
		
			return bookingService.getAllBookingByOperatorCodeWithFilterByPage(operatorCode.trim(),status.trim(),stratDT.trim(), endDT.trim(),page, limit);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Operator Code and Status should not be blank.");
			return derr.toString();
		}
	
                   
               }
               else
               {
               return res;
               }
    }
    
    
    @GetMapping(path="/getAllBookingByOperatorCodeWithFilterByPage/{operatorCode}/{status}")
    public String getAllBookingByOperatorCodeWithFilterByPage(@PathVariable String operatorCode,@PathVariable String status,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers)  {
         String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                   if(operatorCode!=null && operatorCode.trim().length()>0 && status!=null && status.trim().length()>0  ) {

            
		
			return bookingService.getAllBookingByOperatorCodeWithFilterByPage(operatorCode.trim(),status.trim(),null, null,page, limit);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Operator Code and Status should not be blank.");
			return derr.toString();
		}
	
       
               }else
               {
                 return res;
               }

      
    }
	
//	@GetMapping("/getAllAcceptedUpcomingBookingByDriverCode/{driverCode}")
//	public String getAllAcceptedUpcomingBookingByDriverCode(@PathVariable String driverCode) {
//		return bookingNotification.getAllAcceptedUpcomingBookingByDriverCode(driverCode);
//	}
//	
//	@GetMapping(path="/getAllAcceptedUpcomingBookingByDriverCodeByPage/{driverCode}")
//    public String getAllAcceptedUpcomingBookingByDriverCodeByPage(@PathVariable String driverCode,@RequestParam(value = "page", defaultValue = "0") int page,
//            @RequestParam(value = "limit", defaultValue = "30") int limit) {
//
//        String booking = bookingNotification.getAllAcceptedUpcomingBookingByDriverCodeByPage(driverCode, page, limit);
//      
//        return booking;
//       
//    }
	
	@GetMapping("/getAllBookingByDate/{fromDT}/{toDT}")
	public String getAllBookingByDate(@PathVariable String fromDT, @PathVariable String toDT) {
		if(fromDT != null && fromDT.trim().length() > 0 && toDT != null && toDT.trim().length() > 0 ) {

		Date fromDt = null;
		Date toDt = null;
		try {
			fromDt = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(fromDT.trim());
			toDt = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(toDT.trim());
			if(fromDt == null || toDt == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send fromDate and toDate in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send fromDate and toDate in correct format(yyyy-MM-dd)");
			return derr.toString();
		}
		if (fromDt.equals(toDt) || (toDt.after(fromDt))) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(toDt);
		cal.add(Calendar.DATE, 1);
		toDt = cal.getTime();
		
			return bookingService.getAllBookingByDate(fromDt, toDt);
		}
		else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"To Date must be after From Date.");
			return derr.toString();
		}
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"fromDate and toDate should not be blank.");
			return derr.toString();
		}
	}
	
	@GetMapping("/getAllBookingByDateByPage/{fromDT}/{toDT}")
	public String getAllBookingByDateByPage(@PathVariable String fromDT, @PathVariable String toDT,@RequestParam(value = "page", defaultValue = "0") int page,
          @RequestParam(value = "limit", defaultValue = "30") int limit) {
		if(fromDT != null && fromDT.trim().length() > 0 && toDT != null && toDT.trim().length() > 0 ) {

		Date fromDt = null;
		Date toDt = null;
		try {
			fromDt = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(fromDT.trim());
			toDt = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(toDT.trim());
			if(fromDt == null || toDt == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send fromDate and toDate in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send fromDate and toDate in correct format(yyyy-MM-dd)");
			return derr.toString();
		}
		if (fromDt.equals(toDt) || (toDt.after(fromDt))) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(toDt);
		cal.add(Calendar.DATE, 1);
		toDt = cal.getTime();
		String booking = bookingService.getAllBookingByDateByPage(fromDt, toDt, page, limit);
			return booking;
		}
		else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"To Date must be after From Date.");
			return derr.toString();
		}
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"fromDate and toDate should not be blank.");
			return derr.toString();
		}
	}
	
	
	@GetMapping("/getAllAcceptedUpcomingBookingByOperatorCodeByDate/{operatorCode}/{fromDT}/{toDT}")
	public String getAllAcceptedUpcomingBookingByOperatorCodeByDate(@PathVariable String operatorCode,@PathVariable String fromDT, @PathVariable String toDT,@RequestHeader HttpHeaders headers) {
                      String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
               
		if(fromDT != null && fromDT.trim().length() > 0 && toDT != null && toDT.trim().length() > 0 ) {
                    
		Date fromDt = null;
		Date toDt = null;
             		try {
			fromDt = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(fromDT.trim());
			toDt = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(toDT.trim());
			if(fromDt == null || toDt == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send fromDate and toDate in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send fromDate and toDate in correct format(yyyy-MM-dd)");
			return derr.toString();
		}
		if (fromDt.equals(toDt) || (toDt.after(fromDt))) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(toDt);
		cal.add(Calendar.DATE, 1);
		toDt = cal.getTime();
		
		return bookingNotification.getAllAcceptedUpcomingBookingByOperatorCodeByDate(operatorCode, fromDt, toDt);
		}
		else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"To Date must be after From Date.");
			return derr.toString();
		}
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"fromDate and toDate should not be blank.");
			return derr.toString();
		}
               }else
               {
                 return res;
               }
	}
	
	@GetMapping(path="/getAllAcceptedUpcomingBookingByOperatorCodeByDateByPage/{operatorCode}/{fromDT}/{toDT}")
    public String getAllAcceptedUpcomingBookingByOperatorCodeByDateByPage(@PathVariable String operatorCode,@PathVariable String fromDT, @PathVariable String toDT,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
              String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
               if(fromDT != null && fromDT.trim().length() > 0 && toDT != null && toDT.trim().length() > 0 ) {

		Date fromDt = null;
		Date toDt = null;
		try {
			fromDt = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(fromDT.trim());
			toDt = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(toDT.trim());
			if(fromDt == null || toDt == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send fromDate and toDate in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send fromDate and toDate in correct format(yyyy-MM-dd)");
			return derr.toString();
		}
		if (fromDt.equals(toDt) || (toDt.after(fromDt))) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(toDt);
		cal.add(Calendar.DATE, 1);
		toDt = cal.getTime();

        String booking = bookingNotification.getAllAcceptedUpcomingBookingByOperatorCodeByDateByPage(operatorCode, fromDt, toDt, page, limit);
      
        return booking;
		}
		else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"To Date must be after From Date.");
			return derr.toString();
		}
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"fromDate and toDate should not be blank.");
			return derr.toString();
		}
       
               }else
               {
               return res;
               }
		
    }
	
	
	@GetMapping("/getAllAcceptedBookingByDate/{fromDT}/{toDT}")
	public String getAllAcceptedBookingByDate(@PathVariable String fromDT, @PathVariable String toDT) {
		if(fromDT != null && fromDT.trim().length() > 0 && toDT != null && toDT.trim().length() > 0 ) {

		Date fromDt = null;
		Date toDt = null;
		try {
			fromDt = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(fromDT.trim());
			toDt = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(toDT.trim());
			if(fromDt == null || toDt == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send fromDate and toDate in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send fromDate and toDate in correct format(yyyy-MM-dd)");
			return derr.toString();
		}
		if (fromDt.equals(toDt) || (toDt.after(fromDt))) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(toDt);
		cal.add(Calendar.DATE, 1);
		toDt = cal.getTime();
		
			return bookingService.getAllAcceptedBookingByDate(fromDt, toDt);
		}
		else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"To Date must be after From Date.");
			return derr.toString();
		}
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"fromDate and toDate should not be blank.");
			return derr.toString();
		}
	}
	
	@GetMapping("/getAllAcceptedBookingByDateByPage/{fromDT}/{toDT}")
	public String getAllAcceptedBookingByDateByPage(@PathVariable String fromDT, @PathVariable String toDT,@RequestParam(value = "page", defaultValue = "0") int page,
          @RequestParam(value = "limit", defaultValue = "30") int limit) {
		if(fromDT != null && fromDT.trim().length() > 0 && toDT != null && toDT.trim().length() > 0 ) {

		Date fromDt = null;
		Date toDt = null;
		try {
			fromDt = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(fromDT.trim());
			toDt = new SimpleDateFormat(GigflexConstants.saveDateWithoutTime).parse(toDT.trim());
			if(fromDt == null || toDt == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send fromDate and toDate in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send fromDate and toDate in correct format(yyyy-MM-dd)");
			return derr.toString();
		}
		if (fromDt.equals(toDt) || (toDt.after(fromDt))) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(toDt);
		cal.add(Calendar.DATE, 1);
		toDt = cal.getTime();
		String booking = bookingService.getAllAcceptedBookingByDateByPage(fromDt, toDt, page, limit);
			return booking;
		}
		else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"To Date must be after From Date.");
			return derr.toString();
		}
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"fromDate and toDate should not be blank.");
			return derr.toString();
		}
	}
	
	@GetMapping(path="/getAllAcceptedUpcomingBookingByPage")
    public String getAllAcceptedUpcomingBookingByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String booking = bookingNotification.getAllAcceptedUpcomingBookingByPage(page, limit);
      
        return booking;
       
    }
	
	@GetMapping("/getBookingByOperatorCode/{operatorCode}")
	public String getBookingByOperatorCode(@PathVariable String operatorCode,@RequestHeader HttpHeaders headers) {
              String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
               return bookingService.getBookingByOperatorCode(operatorCode);
               }else
               {
                return res;
               }
		
	}
	
	@GetMapping("/sendUpcomingBookingNotificationMail/{rideCode}")
	public String sendUpcomingBookingNotificationMail(@PathVariable String rideCode) {
		if (rideCode != null && rideCode.trim().length() > 0) {
		return bookingNotification.sendUpcomingBookingNotificationMail(rideCode.trim());
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Ride Code should not be blank.");
			return derr.toString();
		}
	}
        
        @GetMapping("/sendUpcomingBookingNotificationSMS/{rideCode}")
	public String sendUpcomingBookingNotificationSMS(@PathVariable String rideCode) {
		if (rideCode != null && rideCode.trim().length() > 0) {
		return bookingNotification.sendUpcomingBookingNotificationSMS(rideCode.trim());
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Ride Code should not be blank.");
			return derr.toString();
		}
	}
	
	@GetMapping("/getBookingByBookingStatus/{bookingStatus}")
	public String getBookingByBookingStatus(@PathVariable String bookingStatus) {
		return bookingService.getBookingByBookingStatus(bookingStatus);
	}
        
        @PutMapping("/bookingPublishRequest/{rideCode}/{isPublished}")
	public String bookingPublishRequest(@PathVariable String rideCode,
			@PathVariable Boolean isPublished, HttpServletRequest req) {
		if (isPublished != null && rideCode != null && rideCode.trim().length() > 0) {
			return bookingService.bookingPublishRequest(isPublished, rideCode.trim(),
					req.getRemoteHost());
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
			return derr.toString();
		}

	}
	
	@GetMapping(path="/getBookingByOrganizationCodeByPage/{organizationCode}")
    public String getBookingByOrganizationCodeByPage(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
             String res="";
               res=tokenutility.orgCodeValidation(headers, organizationCode);
               if(res.equalsIgnoreCase("true"))
               {
                return bookingService.getBookingByOrgCodeByPage(organizationCode, page, limit);
               }else
               {
               return res;
               }

        
       
    }
	
	@GetMapping(path="/getBookingByOperatorCodeByPage/{operatorCode}")
    public String getBookingByOperatorCodeByPage(@PathVariable String operatorCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
                 String res="";
               res=tokenutility.operatorValidation(headers, operatorCode);
               if(res.equalsIgnoreCase("true"))
               {
                 return bookingService.getBookingByOperatorCodeByPage(operatorCode, page, limit);
               }else
               {
               return res;
               }
        
       
    }
	
	@GetMapping(path="/getBookingByBookingStatusByPage/{bookingStatus}")
    public String getBookingByBookingStatusByPage(@PathVariable String bookingStatus,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String booking = bookingService.getBookingByBookingStatusByPage(bookingStatus, page, limit);
      
        return booking;
       
    }
	
	
	@GetMapping("/booking/{search}")
	public String search(@PathVariable("search") String search) {
		return bookingService.search(search);
	}

	@GetMapping("/getAllBooking")
	public String getAllBooking() {
		return bookingService.findAllBooking();
	}
	
	@GetMapping(path="/getAllBookingByPage")
    public String getAllBookingByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String act = bookingService.getAllBookingByPage(page, limit);
      
        return act;
       
    }

	@GetMapping("/getBooking/{id}")
	public String getBookingById(@PathVariable Long id) {
		return bookingService.findBookingById(id);
	}

	@GetMapping("/getBookingByRideCode/{rideCode}")
	public String getBookingByRideCode(@PathVariable String rideCode) {
		return bookingService.getBookingByRideCodeWithName(rideCode);
	}
        
        @GetMapping("/getEligibleDriverListByRideCode/{rideCode}/{operatorCode}")
	public String getEligibleDriverListByRideCode(@PathVariable String rideCode,@PathVariable String operatorCode) {
		return bookingService.getEligibleDriverListByRideCode(rideCode,operatorCode);
	}
        
        @GetMapping("/getBookingByBookingID/{bookingid}")
	public String getBookingByBookingID(@PathVariable Long bookingid) {
            if(bookingid!=null && bookingid>0)
            {
		return bookingService.getBookingByBookingID(bookingid);
                } else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Booking id is not valid");
			return derr.toString();
		}
	}

	@PostMapping("/createBooking")
	public String createBooking(
			 @RequestBody BookingRequest BookingReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return bookingService.saveBooking(BookingReq, ip);

	}

	
	@DeleteMapping("/softDeleteBookingByRideCode/{rideCode}")
	public String softDeleteBookingByRideCode(@PathVariable String rideCode) {
		return bookingService.softDeleteByBookingCode(rideCode);
	}
	
	@DeleteMapping("/softMultipleDeleteByRideCode/{rideCodeList}")
	public String softMultipleDeleteByRideCode(@PathVariable List<String> rideCodeList) {
		if(rideCodeList != null && rideCodeList.size()>0){
			return bookingService.softMultipleDeleteByBookingCode(rideCodeList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
		
	}

	@PutMapping("/updateBooking/{id}")
	public String updateBooking(@PathVariable Long id,
			 @RequestBody BookingUpdateRequest bookingReq,
			HttpServletRequest request) {

		if (id == null) {
			return "Booking with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return bookingService.updateBookingById(id, bookingReq, ip);

		}

	}
	
	 @PutMapping("/assignBookingCompleted/{rideCode}")
		public String assignBookingCompleted(@PathVariable String rideCode,
				@RequestBody BookingCompletedUpdateResponse bcres, HttpServletRequest req) {
			if (bcres != null && rideCode != null && rideCode.trim().length() > 0 &&
                                bcres.getDriverCode() != null && bcres.getDriverCode().trim().length() > 0 &&
                                 bcres.getCustomerFare()!=null &&  bcres.getCustomerFare()>0) {
                                bcres.setDriverCode(bcres.getDriverCode().trim());
				return bookingService.assignBookingCompleted(rideCode.trim(), bcres, req.getRemoteHost());
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Ride code, Driver code, Fare should not be blank.");
				return derr.toString();
			}

		}
                @GetMapping("validatePassangerQuantity/{vehicleType}/{noofPassangers}")
                public String validatePassangerQuantity(@PathVariable String vehicleType,@PathVariable Long noofPassangers)
                {    if(vehicleType!=null && vehicleType.trim().length()>0 && noofPassangers!=0){
                         return   bookingService.validatePassangerQuantity(vehicleType,noofPassangers);
                      }else
                       {
                           GigflexResponse derr = new GigflexResponse(400, new Date(),"vehicleType AND noofPassangers must be fill");
				return derr.toString();
                         
                       }
                }
                @GetMapping("validateBaggagesQuantity/{vehicleType}/{noOfBaggages}")
                public String validateBaggagesQuantity(@PathVariable String vehicleType,@PathVariable Long noOfBaggages)
                {    if(vehicleType!=null && vehicleType.trim().length()>0 && noOfBaggages>=0){
                         return   bookingService.validateBaggagesQuantity(vehicleType,noOfBaggages);
                      }else
                       {
                            GigflexResponse derr = new GigflexResponse(400, new Date(), "vehicleType AND noofPassangers must be fill");
				return derr.toString();
                          
                       }
                }
                @GetMapping("getFareByRideCode/{rideCode}")
                public String getFareByRideCode(@PathVariable String rideCode)
                {  if(rideCode!=null && rideCode.trim().length()>0)
                   {
                     return bookingService.getFareByRideCode(rideCode);
                   }else
                   {
                    GigflexResponse derr = new GigflexResponse(400, new Date(), "rideCode Should not be null or blank");
				return derr.toString();
                   }  
                }
                @GetMapping("getBookingDetailByrideCodeforMobile/{rideCode}")
                public String getBookingDetailByrideCodeforMobile(@PathVariable String rideCode)
                {
                    if(rideCode!=null && rideCode.trim().length()>0)
                    {
                       return bookingService.getBookingDetailByrideCodeforMobile(rideCode);
                    }else
                    {
                    GigflexResponse derr = new GigflexResponse(400, new Date(), "rideCode Should not be null or blank");
				return derr.toString();
                    }
                }

}
