/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.driver.dtob;

/**
 *
 * @author amit.kumar
 */
public class DefaultVehicleUpdateRequest {
    
    private String driverCode;
    private String defaultVehicleCode;

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }

    public String getDefaultVehicleCode() {
        return defaultVehicleCode;
    }

    public void setDefaultVehicleCode(String defaultVehicleCode) {
        this.defaultVehicleCode = defaultVehicleCode;
    }    
    
}
