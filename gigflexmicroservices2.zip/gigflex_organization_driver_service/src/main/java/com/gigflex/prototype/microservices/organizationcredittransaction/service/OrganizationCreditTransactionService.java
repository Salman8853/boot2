/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationcredittransaction.service;

import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransactionRequest;

/**
 *
 * @author amit.kumar
 */
public interface OrganizationCreditTransactionService {

    public String findAllOrganizationCreditTransactions();

    public String getLastTransactionBalanceByOrganizationCode(String organizationCode);

    public String saveOrganizationCreditTransaction(OrganizationCreditTransactionRequest organizationReq, String ip);

    public String getTransactionDetailsByOrganizationCodeAndBetweenDates(String organizationCode, String startDT, String endDT);

    public String getSummaryOfTransactionDetailsByOrgCodeAndBetweenDates(String organizationCode, String startDT, String endDT);

}
