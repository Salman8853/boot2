package com.gigflex.prototype.microservices.booking.dtob;

import java.util.Date;
import java.util.List;

public class BookingCompletedUpdateResponse {
	 
	 private Double customerFare;
         
         private String driverCode;
  private List<AdditionalChargesReq> additionalChargesList;
    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }
         
         

	public Double getCustomerFare() {
		return customerFare;
	}

	public void setCustomerFare(Double customerFare) {
		this.customerFare = customerFare;
	}

    public List<AdditionalChargesReq> getAdditionalChargesList() {
        return additionalChargesList;
    }

    public void setAdditionalChargesList(List<AdditionalChargesReq> additionalChargesList) {
        this.additionalChargesList = additionalChargesList;
    }
	 
	 

}
