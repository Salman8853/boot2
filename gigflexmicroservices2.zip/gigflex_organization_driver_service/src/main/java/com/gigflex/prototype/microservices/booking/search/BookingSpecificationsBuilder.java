package com.gigflex.prototype.microservices.booking.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.util.SearchCriteria;



public class BookingSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public BookingSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public BookingSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<Booking> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<Booking>> specs = new ArrayList<Specification<Booking>>();
        for (SearchCriteria param : params) {
            specs.add(new BookingSpecification(param));
        }
 
        Specification<Booking> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
