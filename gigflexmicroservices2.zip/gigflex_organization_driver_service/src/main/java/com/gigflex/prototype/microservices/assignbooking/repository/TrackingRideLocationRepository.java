/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.assignbooking.repository;

import com.gigflex.prototype.microservices.assignbooking.dtob.TrackingRideStatus;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface TrackingRideLocationRepository extends JpaRepository<TrackingRideStatus, Long>, JpaSpecificationExecutor<TrackingRideStatus>{

    @Query("SELECT trs FROM TrackingRideStatus trs WHERE trs.isDeleted != TRUE")
    public List<TrackingRideStatus> getAllTrackingRideLocation();

    @Query("SELECT trs FROM TrackingRideStatus trs WHERE trs.isDeleted != TRUE AND trs.rideCode = :rideCode ORDER BY trs.id DESC")
    public List<TrackingRideStatus> getTrackingRideLocationByRideCode(@Param("rideCode") String rideCode);
    
   @Query("SELECT trs FROM TrackingRideStatus trs WHERE trs.isDeleted != TRUE AND trs.rideCode = :rideCode")
    public List<TrackingRideStatus> getallTrackingRideLocationByRideCode(@Param("rideCode") String rideCode);
    
    
        
}
