package com.gigflex.prototype.microservices.uploadqueue.service;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.driver.service.DriverService;
import com.gigflex.prototype.microservices.uploadqueue.dtob.UploadQueue;
import com.gigflex.prototype.microservices.uploadqueue.repository.UploadQueueDao;

public class DriverUploadThread implements Runnable {
	KafkaService kafkaService;
	private String fileName;
	private String uploadCode;
	private String operatorCode;
	private String organizationCode;
	private UploadQueueDao uploadQueueDao;
	private DriverRepository driverDao;
        private DriverService driverService;


	public DriverUploadThread(KafkaService kafkaService, String fileName,
			String uploadCode, String operatorCode, String organizationCode,
			UploadQueueDao uploadQueueDao, DriverRepository driverDao,DriverService driverService) {
		super();
		this.kafkaService = kafkaService;
		this.fileName = fileName;
		this.uploadCode = uploadCode;
		this.operatorCode = operatorCode;
		this.organizationCode = organizationCode;
		this.uploadQueueDao = uploadQueueDao;
		this.driverDao = driverDao;
                this.driverService=driverService;
                
	}



	@Override
	public void run() {
		try {
			File myFile = new File(fileName);
			FileInputStream fis = new FileInputStream(myFile);

			Workbook myWorkBook;
			Sheet mySheet = null;

			int inx = fileName.lastIndexOf(".");
			String filenameEnd = fileName.substring(inx);

			if (filenameEnd.equalsIgnoreCase(".xls")) {
				myWorkBook = new HSSFWorkbook(fis);
				mySheet = myWorkBook.getSheetAt(0);
			} else if (filenameEnd.equalsIgnoreCase(".xlsx")) {
				myWorkBook = new XSSFWorkbook(fis);
				mySheet = myWorkBook.getSheetAt(0);
			}
			Iterator<Row> rowIterator = mySheet.iterator();
			int rowCount = -1;
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				Boolean status = false;
				try {

					if (row != null) {
						rowCount++;

						if (rowCount != 0) {
							Iterator<Cell> cellIterator = row.cellIterator();
							int cellCount = 0;
							Driver driver = new Driver();

							while (cellIterator.hasNext()) {
								cellCount++;

								Cell cell = cellIterator.next();

								if (cell != null) {
									String res = "";
									switch (cell.getCellType()) {
									case Cell.CELL_TYPE_STRING:
										if(cell.getStringCellValue()!=null)
                                                                                {
                                                                                res = cell.getStringCellValue().trim();
                                                                                }
										break;
									case Cell.CELL_TYPE_NUMERIC:
										double var = cell.getNumericCellValue();
										Long l = (long) var;
										res = l.toString();
										break;
									case Cell.CELL_TYPE_BOOLEAN:
										if (cell.getBooleanCellValue()) {
											res = "true";
										} else {
											res = "false";
										}

										break;
									default:

									}

//									if (cellCount == 4) {
//										if (res.trim().length() > 0) {
//											driver.setFleetSize(0);
//
//										}
//										break;
//
//									} else 
                                                                            if (cellCount == 3) {
										driver.setEmailId(res);
                                                                                break;

									} else if (cellCount == 2) {

										driver.setContactNumber(res);

									} else if (cellCount == 1) {
										driver.setName(res);

									}

								}

							}
							if (driver != null && driver.getEmailId() != null) {
							//driver.setFleetSize(0);	
                                                            driver.setIsDeleted(false);
								driver.setApproveStatus(true);
								driver.setOperatorCode(operatorCode);
								driver.setOrganizationCode(organizationCode);
								Driver driverRes = driverDao.save(driver);

								if (driverRes != null && driverRes.getId() > 0) {
									status = true;
								kafkaService.sendDriverForSave(driverRes);
                                                                    try {
                                                                        String responseStatus = driverService.sendLinkToDriverForCreateCredential(driverRes.getDriverCode());
                                                                        System.out.println("==========responseStatus for driver mail=======" + responseStatus);
                                                                    } catch (Exception e) {
                                                                        e.printStackTrace();
                                                                    }
								}

							}

						}
					}
				}

				catch (Exception ex) {
					ex.printStackTrace();
				}
				if (rowCount >= 1) {
					UploadQueue uploadRes = uploadQueueDao
							.getUploadQueueByUploadCode(uploadCode);

					if (uploadRes != null && uploadRes.getId() > 0) {
						if (status) {
							uploadRes.setProcessedRecords(uploadRes
									.getProcessedRecords() + 1);
						} else {
							uploadRes.setFaliedRecords(uploadRes
									.getFaliedRecords() + 1);
						}

						uploadQueueDao.save(uploadRes);
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

}
