package com.gigflex.prototype.microservices.booking.dtob;



public class BookingRequest {

	    private String passengerName;
	    
	    private String primaryContactNumber;
	    
	    private String secondaryContactNumber;
	    
		   private String pCountryCode;
			
		    private String sCountryCode;

	    
	    private String pickUpTime;
            
           private String dropOffTime;
           
	    private String pickLat;
	    
	    private String pickLang;
	    
	    private String pickUpAddress;
	    
	    private String dropLat;
	    
	    private String dropLang;
	    
	    private String dropOffAddress;
	    
	    private String additionalStopPage;
	    
	    private String vehicleCode;
	    
	    private Integer noOfPassengers;
	    
	    private Integer noOfBaggage;
	    
	    private String additionalComment;
	    
	    private Double customerFare;
	    
//	    private String bookingStatus;
	    
	    private String paymentOption;
	    
	    private String organizationCode;
	    
	    private String operatorCode;
                
            private String passengerCode;    

	    
//	    private Boolean isPublished;
//	    
//	    
//
//		public Boolean getIsPublished() {
//			return isPublished;
//		}
//
//		public void setIsPublished(Boolean isPublished) {
//			this.isPublished = isPublished;
//		}

		public String getPassengerName() {
			return passengerName;
		}

		public void setPassengerName(String passengerName) {
			this.passengerName = passengerName;
		}

		public String getPrimaryContactNumber() {
			return primaryContactNumber;
		}

		public void setPrimaryContactNumber(String primaryContactNumber) {
			this.primaryContactNumber = primaryContactNumber;
		}

		public String getSecondaryContactNumber() {
			return secondaryContactNumber;
		}

		public void setSecondaryContactNumber(String secondaryContactNumber) {
			this.secondaryContactNumber = secondaryContactNumber;
		}

		public String getPickUpTime() {
			return pickUpTime;
		}

		public void setPickUpTime(String pickUpTime) {
			this.pickUpTime = pickUpTime;
		}

		public String getPickLat() {
			return pickLat;
		}

		public void setPickLat(String pickLat) {
			this.pickLat = pickLat;
		}

		public String getPickLang() {
			return pickLang;
		}

		public void setPickLang(String pickLang) {
			this.pickLang = pickLang;
		}

		public String getPickUpAddress() {
			return pickUpAddress;
		}

		public void setPickUpAddress(String pickUpAddress) {
			this.pickUpAddress = pickUpAddress;
		}

		public String getDropLat() {
			return dropLat;
		}

		public void setDropLat(String dropLat) {
			this.dropLat = dropLat;
		}

		public String getDropLang() {
			return dropLang;
		}

		public void setDropLang(String dropLang) {
			this.dropLang = dropLang;
		}

		public String getDropOffAddress() {
			return dropOffAddress;
		}

		public void setDropOffAddress(String dropOffAddress) {
			this.dropOffAddress = dropOffAddress;
		}

		public String getAdditionalStopPage() {
			return additionalStopPage;
		}

		public void setAdditionalStopPage(String additionalStopPage) {
			this.additionalStopPage = additionalStopPage;
		}

		

		public String getVehicleCode() {
			return vehicleCode;
		}

		public void setVehicleCode(String vehicleCode) {
			this.vehicleCode = vehicleCode;
		}

		public Integer getNoOfPassengers() {
			return noOfPassengers;
		}

		public void setNoOfPassengers(Integer noOfPassengers) {
			this.noOfPassengers = noOfPassengers;
		}

		public Integer getNoOfBaggage() {
			return noOfBaggage;
		}

		public void setNoOfBaggage(Integer noOfBaggage) {
			this.noOfBaggage = noOfBaggage;
		}

		public String getAdditionalComment() {
			return additionalComment;
		}

		public void setAdditionalComment(String additionalComment) {
			this.additionalComment = additionalComment;
		}

		
		public Double getCustomerFare() {
			return customerFare;
		}

		public void setCustomerFare(Double customerFare) {
			this.customerFare = customerFare;
		}


//		public String getBookingStatus() {
//			return bookingStatus;
//		}
//
//		public void setBookingStatus(String bookingStatus) {
//			this.bookingStatus = bookingStatus;
//		}

		public String getPaymentOption() {
			return paymentOption;
		}

		public void setPaymentOption(String paymentOption) {
			this.paymentOption = paymentOption;
		}

		public String getOrganizationCode() {
			return organizationCode;
		}

		public void setOrganizationCode(String organizationCode) {
			this.organizationCode = organizationCode;
		}

		public String getOperatorCode() {
			return operatorCode;
		}

		public void setOperatorCode(String operatorCode) {
			this.operatorCode = operatorCode;
		}

		public String getpCountryCode() {
			return pCountryCode;
		}

		public void setpCountryCode(String pCountryCode) {
			this.pCountryCode = pCountryCode;
		}

		public String getsCountryCode() {
			return sCountryCode;
		}

		public void setsCountryCode(String sCountryCode) {
			this.sCountryCode = sCountryCode;
		}

                public String getPassengerCode() {
                    return passengerCode;
                }

                public void setPassengerCode(String passengerCode) {
                    this.passengerCode = passengerCode;
                }

    public String getDropOffTime() {
        return dropOffTime;
    }

    public void setDropOffTime(String dropOffTime) {
        this.dropOffTime = dropOffTime;
    }

                
}
