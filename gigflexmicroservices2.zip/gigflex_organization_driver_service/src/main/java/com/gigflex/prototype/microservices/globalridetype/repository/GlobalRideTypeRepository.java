package com.gigflex.prototype.microservices.globalridetype.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.globalridetype.dtob.GlobalRideType;


public interface GlobalRideTypeRepository  extends JpaRepository<GlobalRideType, Long>{
	
	@Query("SELECT m FROM GlobalRideType m WHERE m.isDeleted != TRUE")
	public List<GlobalRideType> getAllGlobalRideType(Pageable pageableRequest);

	@Query("SELECT m FROM GlobalRideType m WHERE m.isDeleted != TRUE")
	public List<GlobalRideType> getAllGlobalRideType();

	@Query("SELECT p FROM GlobalRideType p WHERE p.isDeleted != TRUE AND p.vehicleName = :vehicleName")
	public GlobalRideType getByVehicleName(@Param("vehicleName") String vehicleName);

	
	@Query("SELECT r FROM GlobalRideType r WHERE r.isDeleted != TRUE AND r.globalRideCode = :globalRideCode")
    public GlobalRideType getGlobalRideTypeByGlobalRideCode(@Param("globalRideCode") String globalRideCode);
}
