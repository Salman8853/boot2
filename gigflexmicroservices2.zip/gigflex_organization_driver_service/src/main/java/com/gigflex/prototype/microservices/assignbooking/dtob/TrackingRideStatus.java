/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.assignbooking.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "tracking_ride_status")
public class TrackingRideStatus extends CommonAttributes implements Serializable{
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "tracking_ride_status_code", unique = true)
    private String trackingRideStatusCode;
    
    @Column(name = "lat", nullable = false)
    private String lat;

    @Column(name = "lang",nullable = false)
    private String lang;
    
    @Column(name = "ride_code", nullable = false)
    private String rideCode;
    
    
     @PrePersist
    private void assignUUID() {
    	if (this.getTrackingRideStatusCode() == null || this.getTrackingRideStatusCode().length() == 0) {
           this.setTrackingRideStatusCode(UUID.randomUUID().toString());
    	}
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTrackingRideStatusCode() {
        return trackingRideStatusCode;
    }

    public void setTrackingRideStatusCode(String trackingRideStatusCode) {
        this.trackingRideStatusCode = trackingRideStatusCode;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getRideCode() {
        return rideCode;
    }

    public void setRideCode(String rideCode) {
        this.rideCode = rideCode;
    }
    
    
}
