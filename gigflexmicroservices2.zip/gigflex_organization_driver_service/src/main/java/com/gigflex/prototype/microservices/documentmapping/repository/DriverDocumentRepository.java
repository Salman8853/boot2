    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocument;
import com.gigflex.prototype.microservices.documentmapping.dtob.OperatorDocument;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import java.util.Date;

/**
 *
 * @author nirbhay.p
 */
public interface DriverDocumentRepository extends JpaRepository<DriverDocument, Long>,JpaSpecificationExecutor<DriverDocument>{
    
	@Query("SELECT a,b.documentName,c.name FROM DriverDocument a, DocumentTypeDetail b,Driver c WHERE a.isDeleted != TRUE AND b.documentCode = a.documentCode AND a.driverCode = c.driverCode")
	public List<Object> getAllDriverDocument(Pageable pageableRequest);

	@Query("SELECT a,b.documentName,c.name,d FROM DriverDocument a, DocumentTypeDetail b,Driver c,DocumentType d WHERE a.isDeleted != TRUE AND b.documentCode = a.documentCode AND a.driverCode = c.driverCode AND a.driverCode = :driverCode AND d.documentTypeCode=b.documentTypeCode")
	public List<Object> getAllDriverDocumentByDriverCode(@Param("driverCode") String driverCode);
	
	@Query("SELECT a,b.documentName,c.name FROM DriverDocument a, DocumentTypeDetail b,Driver c WHERE a.isDeleted != TRUE AND b.documentCode = a.documentCode AND a.driverCode = c.driverCode AND a.driverCode = :driverCode")
	public List<Object> getAllDriverDocumentByDriverCode(@Param("driverCode") String driverCode,Pageable pageableRequest);
	
	@Query("SELECT a,b.documentName,c.name FROM DriverDocument a, DocumentTypeDetail b,Driver c WHERE a.isDeleted != TRUE AND b.documentCode = a.documentCode AND a.driverCode = c.driverCode")
	public List<Object> getAllDriverDocument();
	
	
//    @Query("SELECT d FROM DriverDocument d WHERE d.isDeleted != TRUE")
//    public List<DriverDocument> getAllDriverDocument();
//    
//    @Query("SELECT d FROM DriverDocument d WHERE d.isDeleted != TRUE AND d.driverCode=:driverCode")
//    public List<DriverDocument> getAllDriverDocumentByDriverCode(@Param("driverCode") String driverCode);
    
    @Query("SELECT d FROM DriverDocument d WHERE d.isDeleted != TRUE AND d.driverDocumentCode=:driverDocumentCode")
    public DriverDocument getDriverDocumentByDriverDocumentCode(@Param("driverDocumentCode") String driverDocumentCode);
    
    
    @Query("SELECT d FROM DriverDocument d WHERE d.isDeleted != TRUE AND d.documentCode=:documentCode AND d.driverCode=:driverCode")
    public DriverDocument getDriverDocumentByDriverCodeDocumentCode(@Param("documentCode") String documentCode,@Param("driverCode") String driverCode);
    
    @Query("SELECT d FROM DriverDocument d WHERE d.isDeleted != TRUE AND d.documentCode=:documentCode AND d.driverCode=:driverCode AND d.driverDocumentCode!=:driverDocumentCode")
    public DriverDocument getDriverDocumentByDriverCodeDocumentCodeNotInCode(@Param("driverDocumentCode") String driverDocumentCode,@Param("documentCode") String documentCode,@Param("driverCode") String driverCode);
    
	@Query("SELECT a FROM TimeZoneDetail a,Organization b,Driver c WHERE a.isDeleted != TRUE AND c.isDeleted != TRUE AND b.isDeleted != TRUE AND c.organizationCode = b.organizationCode AND b.timezone = a.timeZoneCode AND c.driverCode = :driverCode")
    public TimeZoneDetail getTimeZoneByDriverCode(@Param("driverCode") String driverCode);
    
    @Query("SELECT o FROM OperatorDocument o WHERE o.isDeleted != TRUE AND o.operatorCode=:operatorCode AND o.docExpiration<:curDT")
    public List<OperatorDocument> getExpiredOperatorDocumentByOperatorCode(@Param("operatorCode") String operatorCode,@Param("curDT") Date curDT );

    @Query("SELECT d FROM DriverDocument d WHERE d.isDeleted != TRUE AND d.driverCode=:driverCode AND d.docExpiration<:curDT")
    public List<DriverDocument> getExpiredDriverDocumentByDriverCode(@Param("driverCode") String driverCode,@Param("curDT") Date curDT );
    
     @Query("SELECT d FROM DriverDocument d WHERE d.isDeleted!=TRUE AND d.driverCode=:driverCode")
     public List< DriverDocument> getdriverDocumentBydriverCode(@Param("driverCode")String driverCode);

    
}
