/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.utility;

import atg.taglib.json.util.JSONObject;
import com.notnoop.apns.APNS;
import com.notnoop.apns.ApnsNotification;
import com.notnoop.apns.ApnsService;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import org.springframework.core.io.ClassPathResource;

/**
 *
 * @author nirbhay.p
 */
public class PushNotification {
    public final static String AUTH_KEY_FCM = "AIzaSyAXrlKGc8fCk6j4jDkXadZPoULs4TpUkTs";
    public final static String API_URL_FCM = "https://fcm.googleapis.com/fcm/send";
     public static void main(String a[]) {

        pushFCMNotification(API_URL_FCM,AUTH_KEY_FCM,"crDRfdMDqvo:APA91bEGsskwSvQ2XKuAhd96YqOdGoKteNuKJaRdxubOw9HVc4ZgFWL_wra7tVdUeKisE7VJgCnEO5XeG_aucsbxNsEqtPCtinSvJmYLnJzJ1PSXhklXuSsJgCyc58wp_TD5mr8YKDbq", "Test", "NPS");
    }
    
     
     public static void pushFCMNotification(String FMCurl, String authKey, String DeviceId, String title, String body) {
       //  String p12filePass = "Esoft1234" ;
       try {
            URL url = new URL(FMCurl);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

            conn.setUseCaches(false);
            conn.setDoInput(true);
            conn.setDoOutput(true);

            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", "key=" + authKey);
            conn.setRequestProperty("Content-Type", "application/json");

            JSONObject data = new JSONObject();
            data.put("to", DeviceId.trim());   
            //data.put("to", "356823073570676"); 
            JSONObject info = new JSONObject();
            info.put("title", title); // Notification title
            info.put("body", body); // Notification body
            data.put("notification", info);

            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data.toString());
            wr.flush();
            wr.close();

            int responseCode = conn.getResponseCode();
            System.out.println("Response Code : " + responseCode);
            System.out.println("Response  : " + conn.getResponseMessage());
//            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//            String inputLine;
//            StringBuffer response = new StringBuffer();
//
//            while ((inputLine = in.readLine()) != null) {
//                response.append(inputLine);
//            }
//            in.close();
        } catch (Exception ex) {
            System.out.println("Error in Andriod pushFCMNotification ::" + ex);
            ex.printStackTrace();
        }
       
//       try{
//           InputStream inputStream = new ClassPathResource("PushNotification-Certificates-reena.p12").getInputStream();
//                ApnsService service;
//             
//                    service = APNS.newService().withCert(inputStream, p12filePass).withProductionDestination().withGatewayDestination("gateway.push.apple.com", 2195).build();
//                
//               // String payload = APNS.newPayload().customField("customData", "customData").alertBody(title+System.lineSeparator()+body).build();
//              String payload = APNS.newPayload()
//            // .customFields(map)
//            .alertBody(title + " " + body).sound("default").build();
//               ApnsNotification apns = service.push(DeviceId, payload);
//               System.out.println("pushIOSNotification >> Response Code : " + apns.toString());
//              
//       }
//       catch (Exception ex) {
//           ex.printStackTrace();
//            System.out.println("Error in IOS pushFCMNotification ::" + ex);
//        }
    }
}
