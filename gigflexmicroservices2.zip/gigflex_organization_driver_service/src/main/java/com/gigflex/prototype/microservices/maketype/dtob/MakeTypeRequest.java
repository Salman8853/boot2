package com.gigflex.prototype.microservices.maketype.dtob;

import javax.persistence.Column;

public class MakeTypeRequest {
	
	 private String vehicleName;

	 private String abbrevationName;

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public String getAbbrevationName() {
		return abbrevationName;
	}

	public void setAbbrevationName(String abbrevationName) {
		this.abbrevationName = abbrevationName;
	}
	 
	 

}
