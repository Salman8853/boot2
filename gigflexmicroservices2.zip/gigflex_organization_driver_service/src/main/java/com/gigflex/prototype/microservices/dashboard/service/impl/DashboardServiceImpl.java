package com.gigflex.prototype.microservices.dashboard.service.impl;

import atg.taglib.json.util.JSONArray;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.booking.repository.BookingDao;
import com.gigflex.prototype.microservices.dashboard.service.DashboardService;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

@Service
public class DashboardServiceImpl implements DashboardService {

	@Autowired
	private BookingDao bookingDao;

	@Autowired
	OperatorRepository operatorRepository;

	@Override
	public String getBookingForDashboardByOperatorCode(String operatorCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Booking> objlst = bookingDao.getAllDashboardBookingByOperatorCode(operatorCode);
			int count = objlst.size();

			List<Booking> assigned = bookingDao.getAllDashboardBookingByOperatorCodeByStatus(operatorCode,
					GigflexConstants.bookingStatus);
			int assignedCount = assigned.size();

			List<Booking> pending = bookingDao.getAllDashboardBookingByOperatorCodeByStatus(operatorCode,
					GigflexConstants.assignedBookingStatus);
			int pendingCount = pending.size();

			List<Booking> inProgress = bookingDao.getAllDashboardBookingByOperatorCodeByStatus(operatorCode,
					GigflexConstants.assignedBookingInProgressStatus);
			int inProgressCount = inProgress.size();

			List<Booking> accepted = bookingDao.getAllDashboardBookingByOperatorCodeByStatus(operatorCode,
					GigflexConstants.assignedBookingAcceptedStatus);
			int acceptedCount = accepted.size();

			List<Booking> cancelled = bookingDao.getAllDashboardBookingByOperatorCodeByStatus(operatorCode,
					GigflexConstants.assignedBookingCancelledStatus);
			int cancelledCount = cancelled.size();

			List<Booking> expired = bookingDao.getAllDashboardBookingByOperatorCodeByStatus(operatorCode,
					GigflexConstants.assignedBookingExpiredStatus);
			int expiredCount = expired.size();

			List<Booking> rejected = bookingDao.getAllDashboardBookingByOperatorCodeByStatus(operatorCode,
					GigflexConstants.assignedBookingRejectedStatus);
			int rejectedCount = rejected.size();

//			List<Booking> changed = bookingDao.getAllDashboardBookingByOperatorCodeByStatus(operatorCode,
//					GigflexConstants.assignedBookingChangedStatus);
//			int changedCount = changed.size();

			List<Booking> completed = bookingDao.getAllDashboardBookingByOperatorCodeByStatus(operatorCode,
					GigflexConstants.assignedBookingCompletedStatus);
			int completedCount = completed.size();
			
			List<Booking> published = bookingDao.getAllDashboardBookingByOperatorCodeByStatus(operatorCode,
					GigflexConstants.assignedBookingPublishedStatus);
			int publishedCount = published.size();

			if (objlst != null && objlst.size() > 0) {
				JSONArray jarr = new JSONArray();

				JSONObject j1 = new JSONObject();
				j1.put("status", GigflexConstants.bookingStatus);
				j1.put("count", assignedCount);
				JSONArray jarr1 = new JSONArray();
				if (assignedCount > 0) {
					for (Booking b : assigned) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr1.add(j11);
					}
				}
				j1.put("responsedata", jarr1);
				jarr.add(j1);
				
				
				JSONObject j2 = new JSONObject();
				j2.put("status", GigflexConstants.assignedBookingStatus);
				j2.put("count", pendingCount);
				JSONArray jarr2 = new JSONArray();
				if (pendingCount > 0) {
					for (Booking b : pending) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr2.add(j11);
					}
				}
				j2.put("responsedata", jarr2);
				jarr.add(j2);
				
				
				JSONObject j3 = new JSONObject();
				j3.put("status", GigflexConstants.assignedBookingInProgressStatus);
				j3.put("count", inProgressCount);
				JSONArray jarr3 = new JSONArray();
				if (inProgressCount > 0) {
					for (Booking b : inProgress) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr3.add(j11);
					}
				}
				j3.put("responsedata", jarr3);
				jarr.add(j3);
				
				
				JSONObject j4 = new JSONObject();
				j4.put("status", GigflexConstants.assignedBookingAcceptedStatus);
				j4.put("count", acceptedCount);
				JSONArray jarr4 = new JSONArray();
				if (acceptedCount > 0) {
					for (Booking b : accepted) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr4.add(j11);
					}
				}
				j4.put("responsedata", jarr4);
				jarr.add(j4);
				
				JSONObject j5 = new JSONObject();
				j5.put("status", GigflexConstants.assignedBookingCancelledStatus);
				j5.put("count", cancelledCount);
				JSONArray jarr5 = new JSONArray();
				if (cancelledCount > 0) {
					for (Booking b : cancelled) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr5.add(j11);
					}
				}
				j5.put("responsedata", jarr5);
				jarr.add(j5);
				
				JSONObject j6 = new JSONObject();
				j6.put("status", GigflexConstants.assignedBookingExpiredStatus);
				j6.put("count", expiredCount);
				JSONArray jarr6 = new JSONArray();
				if (expiredCount > 0) {
					for (Booking b : expired) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr6.add(j11);
					}
				}
				j6.put("responsedata", jarr6);
				jarr.add(j6);
				
				JSONObject j7 = new JSONObject();
				j7.put("status", GigflexConstants.assignedBookingRejectedStatus);
				j7.put("count", rejectedCount);
				JSONArray jarr7 = new JSONArray();
				if (rejectedCount > 0) {
					for (Booking b : rejected) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr7.add(j11);
					}
				}
				j7.put("responsedata", jarr7);
				jarr.add(j7);
				
				JSONObject j8 = new JSONObject();
				j8.put("status", GigflexConstants.assignedBookingCompletedStatus);
				j8.put("count", completedCount);
				JSONArray jarr8 = new JSONArray();
				if (completedCount > 0) {
					for (Booking b : completed) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr8.add(j11);
					}
				}
				j8.put("responsedata", jarr8);
				jarr.add(j8);
				
				JSONObject j9 = new JSONObject();
				j9.put("status", GigflexConstants.assignedBookingPublishedStatus);
				j9.put("count", publishedCount);
				JSONArray jarr9 = new JSONArray();
				if (publishedCount > 0) {
					for (Booking b : published) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr9.add(j11);
					}
				}
				j9.put("responsedata", jarr9);
				jarr.add(j9);

				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("allcount", count);
				jsonobj.put("data", jarr);

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getBookingForDashboardByDriverCode(String driverCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Booking> objlst = bookingDao.getAllDashboardBookingByDriverCode(driverCode);
			int count = objlst.size();

			List<Booking> assigned = bookingDao.getAllDashboardBookingByDriverCodeByStatus(driverCode,
					GigflexConstants.bookingStatus);
			int assignedCount = assigned.size();

			List<Booking> pending = bookingDao.getAllDashboardBookingByDriverCodeByStatus(driverCode,
					GigflexConstants.assignedBookingStatus);
			int pendingCount = pending.size();

			List<Booking> inProgress = bookingDao.getAllDashboardBookingByDriverCodeByStatus(driverCode,
					GigflexConstants.assignedBookingInProgressStatus);
			int inProgressCount = inProgress.size();

			List<Booking> accepted = bookingDao.getAllDashboardBookingByDriverCodeByStatus(driverCode,
					GigflexConstants.assignedBookingAcceptedStatus);
			int acceptedCount = accepted.size();

			List<Booking> cancelled = bookingDao.getAllDashboardBookingByDriverCodeByStatus(driverCode,
					GigflexConstants.assignedBookingCancelledStatus);
			int cancelledCount = cancelled.size();

			List<Booking> expired = bookingDao.getAllDashboardBookingByDriverCodeByStatus(driverCode,
					GigflexConstants.assignedBookingExpiredStatus);
			int expiredCount = expired.size();

			List<Booking> rejected = bookingDao.getAllDashboardBookingByDriverCodeByStatus(driverCode,
					GigflexConstants.assignedBookingRejectedStatus);
			int rejectedCount = rejected.size();

//			List<Booking> changed = bookingDao.getAllDashboardBookingByOperatorCodeByStatus(operatorCode,
//					GigflexConstants.assignedBookingChangedStatus);
//			int changedCount = changed.size();

			List<Booking> completed = bookingDao.getAllDashboardBookingByDriverCodeByStatus(driverCode,
					GigflexConstants.assignedBookingCompletedStatus);
			int completedCount = completed.size();
			
			List<Booking> published = bookingDao.getAllDashboardBookingByDriverCodeByStatus(driverCode,
					GigflexConstants.assignedBookingPublishedStatus);
			int publishedCount = published.size();

			if (objlst != null && objlst.size() > 0) {
				JSONArray jarr = new JSONArray();

				JSONObject j1 = new JSONObject();
				j1.put("status", GigflexConstants.bookingStatus);
				j1.put("count", assignedCount);
				JSONArray jarr1 = new JSONArray();
				if (assignedCount > 0) {
					for (Booking b : assigned) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr1.add(j11);
					}
				}
				j1.put("responsedata", jarr1);
				jarr.add(j1);
				
				
				JSONObject j2 = new JSONObject();
				j2.put("status", GigflexConstants.assignedBookingStatus);
				j2.put("count", pendingCount);
				JSONArray jarr2 = new JSONArray();
				if (pendingCount > 0) {
					for (Booking b : pending) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr2.add(j11);
					}
				}
				j2.put("responsedata", jarr2);
				jarr.add(j2);
				
				
				JSONObject j3 = new JSONObject();
				j3.put("status", GigflexConstants.assignedBookingInProgressStatus);
				j3.put("count", inProgressCount);
				JSONArray jarr3 = new JSONArray();
				if (inProgressCount > 0) {
					for (Booking b : inProgress) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr3.add(j11);
					}
				}
				j3.put("responsedata", jarr3);
				jarr.add(j3);
				
				
				JSONObject j4 = new JSONObject();
				j4.put("status", GigflexConstants.assignedBookingAcceptedStatus);
				j4.put("count", acceptedCount);
				JSONArray jarr4 = new JSONArray();
				if (acceptedCount > 0) {
					for (Booking b : accepted) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr4.add(j11);
					}
				}
				j4.put("responsedata", jarr4);
				jarr.add(j4);
				
				JSONObject j5 = new JSONObject();
				j5.put("status", GigflexConstants.assignedBookingCancelledStatus);
				j5.put("count", cancelledCount);
				JSONArray jarr5 = new JSONArray();
				if (cancelledCount > 0) {
					for (Booking b : cancelled) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr5.add(j11);
					}
				}
				j5.put("responsedata", jarr5);
				jarr.add(j5);
				
				JSONObject j6 = new JSONObject();
				j6.put("status", GigflexConstants.assignedBookingExpiredStatus);
				j6.put("count", expiredCount);
				JSONArray jarr6 = new JSONArray();
				if (expiredCount > 0) {
					for (Booking b : expired) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr6.add(j11);
					}
				}
				j6.put("responsedata", jarr6);
				jarr.add(j6);
				
				JSONObject j7 = new JSONObject();
				j7.put("status", GigflexConstants.assignedBookingRejectedStatus);
				j7.put("count", rejectedCount);
				JSONArray jarr7 = new JSONArray();
				if (rejectedCount > 0) {
					for (Booking b : rejected) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr7.add(j11);
					}
				}
				j7.put("responsedata", jarr7);
				jarr.add(j7);
				
				JSONObject j8 = new JSONObject();
				j8.put("status", GigflexConstants.assignedBookingCompletedStatus);
				j8.put("count", completedCount);
				JSONArray jarr8 = new JSONArray();
				if (completedCount > 0) {
					for (Booking b : completed) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr8.add(j11);
					}
				}
				j8.put("responsedata", jarr8);
				jarr.add(j8);
				
				
				JSONObject j9 = new JSONObject();
				j9.put("status", GigflexConstants.assignedBookingPublishedStatus);
				j9.put("count", publishedCount);
				JSONArray jarr9 = new JSONArray();
				if (publishedCount > 0) {
					for (Booking b : published) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr9.add(j11);
					}
				}
				j9.put("responsedata", jarr9);
				jarr.add(j9);


				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("allcount", count);
				jsonobj.put("data", jarr);

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

    @Override
    public String getBookingForDashboardByOrganizationCode(String organizationCode) {
       
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Booking> objlst = bookingDao.getAllDashboardBookingByOrganizationCode(organizationCode);
			int count = objlst.size();

			List<Booking> assigned = bookingDao.getAllDashboardBookingByOrganizationCodeByStatus(organizationCode,
					GigflexConstants.bookingStatus);
			int assignedCount = assigned.size();

			List<Booking> pending = bookingDao.getAllDashboardBookingByOrganizationCodeByStatus(organizationCode,
					GigflexConstants.assignedBookingStatus);
			int pendingCount = pending.size();

			List<Booking> inProgress = bookingDao.getAllDashboardBookingByOrganizationCodeByStatus(organizationCode,
					GigflexConstants.assignedBookingInProgressStatus);
			int inProgressCount = inProgress.size();

			List<Booking> accepted = bookingDao.getAllDashboardBookingByOrganizationCodeByStatus(organizationCode,
					GigflexConstants.assignedBookingAcceptedStatus);
			int acceptedCount = accepted.size();

			List<Booking> cancelled = bookingDao.getAllDashboardBookingByOrganizationCodeByStatus(organizationCode,
					GigflexConstants.assignedBookingCancelledStatus);
			int cancelledCount = cancelled.size();

			List<Booking> expired = bookingDao.getAllDashboardBookingByOrganizationCodeByStatus(organizationCode,
					GigflexConstants.assignedBookingExpiredStatus);
			int expiredCount = expired.size();

			List<Booking> rejected = bookingDao.getAllDashboardBookingByOrganizationCodeByStatus(organizationCode,
					GigflexConstants.assignedBookingRejectedStatus);
			int rejectedCount = rejected.size();

//			List<Booking> changed = bookingDao.getAllDashboardBookingByOperatorCodeByStatus(operatorCode,
//					GigflexConstants.assignedBookingChangedStatus);
//			int changedCount = changed.size();

			List<Booking> completed = bookingDao.getAllDashboardBookingByOrganizationCodeByStatus(organizationCode,
					GigflexConstants.assignedBookingCompletedStatus);
			int completedCount = completed.size();
			
			List<Booking> published = bookingDao.getAllDashboardBookingByOrganizationCodeByStatus(organizationCode,
					GigflexConstants.assignedBookingPublishedStatus);
			int publishedCount = published.size();

			if (objlst != null && objlst.size() > 0) {
				JSONArray jarr = new JSONArray();

				JSONObject j1 = new JSONObject();
				j1.put("status", GigflexConstants.bookingStatus);
				j1.put("count", assignedCount);
				JSONArray jarr1 = new JSONArray();
				if (assignedCount > 0) {
					for (Booking b : assigned) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr1.add(j11);
					}
				}
				j1.put("responsedata", jarr1);
				jarr.add(j1);
				
				
				JSONObject j2 = new JSONObject();
				j2.put("status", GigflexConstants.assignedBookingStatus);
				j2.put("count", pendingCount);
				JSONArray jarr2 = new JSONArray();
				if (pendingCount > 0) {
					for (Booking b : pending) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr2.add(j11);
					}
				}
				j2.put("responsedata", jarr2);
				jarr.add(j2);
				
				
				JSONObject j3 = new JSONObject();
				j3.put("status", GigflexConstants.assignedBookingInProgressStatus);
				j3.put("count", inProgressCount);
				JSONArray jarr3 = new JSONArray();
				if (inProgressCount > 0) {
					for (Booking b : inProgress) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr3.add(j11);
					}
				}
				j3.put("responsedata", jarr3);
				jarr.add(j3);
				
				
				JSONObject j4 = new JSONObject();
				j4.put("status", GigflexConstants.assignedBookingAcceptedStatus);
				j4.put("count", acceptedCount);
				JSONArray jarr4 = new JSONArray();
				if (acceptedCount > 0) {
					for (Booking b : accepted) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr4.add(j11);
					}
				}
				j4.put("responsedata", jarr4);
				jarr.add(j4);
				
				JSONObject j5 = new JSONObject();
				j5.put("status", GigflexConstants.assignedBookingCancelledStatus);
				j5.put("count", cancelledCount);
				JSONArray jarr5 = new JSONArray();
				if (cancelledCount > 0) {
					for (Booking b : cancelled) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr5.add(j11);
					}
				}
				j5.put("responsedata", jarr5);
				jarr.add(j5);
				
				JSONObject j6 = new JSONObject();
				j6.put("status", GigflexConstants.assignedBookingExpiredStatus);
				j6.put("count", expiredCount);
				JSONArray jarr6 = new JSONArray();
				if (expiredCount > 0) {
					for (Booking b : expired) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr6.add(j11);
					}
				}
				j6.put("responsedata", jarr6);
				jarr.add(j6);
				
				JSONObject j7 = new JSONObject();
				j7.put("status", GigflexConstants.assignedBookingRejectedStatus);
				j7.put("count", rejectedCount);
				JSONArray jarr7 = new JSONArray();
				if (rejectedCount > 0) {
					for (Booking b : rejected) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr7.add(j11);
					}
				}
				j7.put("responsedata", jarr7);
				jarr.add(j7);
				
				JSONObject j8 = new JSONObject();
				j8.put("status", GigflexConstants.assignedBookingCompletedStatus);
				j8.put("count", completedCount);
				JSONArray jarr8 = new JSONArray();
				if (completedCount > 0) {
					for (Booking b : completed) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr8.add(j11);
					}
				}
				j8.put("responsedata", jarr8);
				jarr.add(j8);
				
				JSONObject j9 = new JSONObject();
				j9.put("status", GigflexConstants.assignedBookingPublishedStatus);
				j9.put("count", publishedCount);
				JSONArray jarr9 = new JSONArray();
				if (publishedCount > 0) {
					for (Booking b : published) {
						JSONObject j11 = new JSONObject();
						j11.put("rideCode", b.getRideCode());
						j11.put("pickLat", b.getPickLat());
						j11.put("pickLang", b.getPickLang());
						jarr9.add(j11);
					}
				}
				j9.put("responsedata", jarr9);
				jarr.add(j9);

				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("allcount", count);
				jsonobj.put("data", jarr);

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	
    }

}
