package com.gigflex.prototype.microservices.maketype.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.gigflex.prototype.microservices.maketype.dtob.MakeType;

public interface MakeTypeRepository extends JpaRepository<MakeType, Long>,JpaSpecificationExecutor<MakeType>{
	
	@Query("SELECT m FROM MakeType m WHERE m.isDeleted != TRUE")
	public List<MakeType> getAllMakeType();
	
	@Query("SELECT m FROM MakeType m WHERE m.isDeleted != TRUE")
	public List<MakeType> getAllMakeType(Pageable pageableRequest);
	
	@Query("SELECT m FROM MakeType m WHERE m.isDeleted != TRUE AND m.vehicleCode = :vehicleCode")
	public MakeType getMakeTypeByVehicleCode(@Param("vehicleCode") String vehicleCode);
	
	@Query("SELECT m FROM MakeType m WHERE m.isDeleted != TRUE AND m.id = :id")
	public MakeType getMakeTypeById(@Param("id") Long id);
	
	@Query("SELECT m FROM MakeType m WHERE m.isDeleted != TRUE AND m.vehicleName = :vehicleName AND m.abbrevationName = :abbrevationName")
	public MakeType getMakeTypeByVehicleNameAndAbbrevationName(@Param("vehicleName") String vehicleName,@Param("abbrevationName") String abbrevationName);
	
	@Query("SELECT m FROM MakeType m WHERE m.isDeleted != TRUE AND m.id != :id AND m.vehicleName = :vehicleName AND m.abbrevationName = :abbrevationName")
	public MakeType getMakeTypeByIdVehicleNameAndAbbrevationName(@Param("id") Long id,@Param("vehicleName") String vehicleName,@Param("abbrevationName") String abbrevationName);

}
