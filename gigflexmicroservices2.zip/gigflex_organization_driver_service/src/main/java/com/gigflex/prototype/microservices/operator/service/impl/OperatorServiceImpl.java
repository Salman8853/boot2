/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.operator.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.driver.dtob.Users;
import com.gigflex.prototype.microservices.notification.service.NotificationService;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.dtob.OperatorRequest;
import com.gigflex.prototype.microservices.operator.dtob.OperatorResponse;
import com.gigflex.prototype.microservices.operator.dtob.OperatorUpRequest;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.operator.repository.UserRepository;
import com.gigflex.prototype.microservices.operator.search.OperatorSpecificationsBuilder;
import com.gigflex.prototype.microservices.operator.service.OperatorService;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationDao;
import com.gigflex.prototype.microservices.util.GigflexResponse;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

/**
 *
 * @author Abhishek
 */
@Service
public class OperatorServiceImpl implements OperatorService {
	@Autowired
	OperatorRepository operatorRepository;

	@Autowired
	OrganizationDao orgDao;
	@Autowired
	KafkaService kafkaService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	NotificationService notificationService;

	@Override
	public Operator saveOperatorsDetatil(Operator operator) {
		return operatorRepository.save(operator);
	}

	@Override
	public String findAllOperators() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = operatorRepository.getAllOperator();
			List<OperatorResponse> maplst = new ArrayList<OperatorResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {

						OperatorResponse opr = new OperatorResponse();

						Operator data = (Operator) arr[0];
						opr.setId(data.getId());
						opr.setOperatorCode(data.getOperatorCode());
						opr.setOperatorName(data.getOperatorName());
						opr.setContactNumber(data.getContactNumber());
						opr.setCountryCode(data.getCountryCode());
						opr.setEmailId(data.getEmailId());
						opr.setTradingAddress(data.getTradingAddress());
						opr.setOrganizationCode(data.getOrganizationCode());
						opr.setOperatorImage(data.getOperatorImage());
						opr.setOrganizationName((String) arr[1]);

						maplst.add(opr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllOperatorsByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<Object> objlst = operatorRepository.getAllOperator(pageableRequest);
			List<OperatorResponse> maplst = new ArrayList<OperatorResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {

						OperatorResponse opr = new OperatorResponse();

						Operator data = (Operator) arr[0];
						opr.setId(data.getId());
						opr.setOperatorCode(data.getOperatorCode());
						opr.setOperatorName(data.getOperatorName());
						opr.setContactNumber(data.getContactNumber());
						opr.setCountryCode(data.getCountryCode());
						opr.setEmailId(data.getEmailId());
						opr.setTradingAddress(data.getTradingAddress());
						opr.setOrganizationCode(data.getOrganizationCode());
						opr.setOperatorImage(data.getOperatorImage());
						opr.setOrganizationName((String) arr[1]);

						maplst.add(opr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getOperatorByOperatorCode(String operatorCode) {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//			Operator operatorlst = operatorRepository
//					.getOperatorByOperatorCode(operatorCode);
//			if (operatorlst != null && operatorlst.getId() > 0) {
//				ObjectMapper mapperObj = new ObjectMapper();
//				String Detail = mapperObj.writeValueAsString(operatorlst);
//				jsonobj.put("responsecode", 200);
//				jsonobj.put("timestamp", new Date());
//				jsonobj.put("message", "Success");
//				jsonobj.put("data", new JSONObject(Detail));
//
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("timestamp", new Date());
//				jsonobj.put("message", "Record Not Found");
//			}
//			res = jsonobj.toString();
//		} catch (JSONException | JsonProcessingException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		} catch (Exception ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"Exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		}
//		return res;
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			Object objlst = operatorRepository.getOperatorByOperatorCodeWithName(operatorCode);
			OperatorResponse maplst = null;
			if (objlst != null) {
//				for (int i = 0; i < objlst.size(); i++) {
				Object[] arr = (Object[]) objlst;
				if (arr.length >= 2) {

					OperatorResponse opr = new OperatorResponse();

					Operator data = (Operator) arr[0];
					opr.setId(data.getId());
					opr.setOperatorCode(data.getOperatorCode());
					opr.setOperatorName(data.getOperatorName());
					opr.setContactNumber(data.getContactNumber());
					opr.setCountryCode(data.getCountryCode());
					opr.setEmailId(data.getEmailId());
					opr.setTradingAddress(data.getTradingAddress());
					opr.setOrganizationCode(data.getOrganizationCode());
					opr.setOperatorImage(data.getOperatorImage());
					opr.setOrganizationName((String) arr[1]);
					maplst = opr;
//						maplst.add(opr);
//
//					}
				}
				if (maplst != null) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String findOperatorById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Operator operatorlst = operatorRepository.getOperatorById(id);
			if (operatorlst != null && operatorlst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(operatorlst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveOperator(OperatorRequest operatorReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (operatorReq != null) {
				// GigflexResponse OperatorResponse = new GigflexResponse();

				if (operatorReq.getOperatorName() != null && operatorReq.getOperatorName().trim().length() > 0
						&& operatorReq.getOrganizationCode() != null
						&& operatorReq.getOrganizationCode().trim().length() > 0) {

					Organization org = orgDao.findByOrganizationCode(operatorReq.getOrganizationCode());
					if (org != null && org.getId() > 0) {

						// if (GigflexUtility.emailPatternValidation(OperatorReq
						// .getEmailId()) == true) {

						Operator opr = new Operator();

						opr.setOperatorName(operatorReq.getOperatorName());
						opr.setContactNumber(operatorReq.getContactNumber());
						opr.setCountryCode(operatorReq.getCountryCode());
						opr.setEmailId(operatorReq.getEmailId());
						opr.setTradingAddress(operatorReq.getTradingAddress());
						opr.setOrganizationCode(operatorReq.getOrganizationCode());
						opr.setIpAddress(ip);

						Operator OperatorRes = operatorRepository.save(opr);

						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());

						if (OperatorRes != null && OperatorRes.getId() > 0) {
							jsonobj.put("message", "Operator has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(OperatorRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("message", "Failed");
						}
						// } else {
						// jsonobj.put("responsecode", 400);
						// jsonobj.put("timestamp", new Date());
						// jsonobj.put("message",
						// "Please check your email format.");
						// }

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Organization Code not found.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateOperatorById(Long id, OperatorUpRequest operatorReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (operatorReq != null) {
				// GigflexResponse OperatorResponse = new GigflexResponse();

				if (operatorReq.getOperatorName() != null && operatorReq.getOperatorName().trim().length() > 0
						&& operatorReq.getOrganizationCode() != null
						&& operatorReq.getOrganizationCode().trim().length() > 0) {

					Organization org = orgDao.findByOrganizationCode(operatorReq.getOrganizationCode());
					if (org != null && org.getId() > 0) {

						Operator operatorlst = operatorRepository.getOperatorById(id);
						if (operatorlst != null && operatorlst.getId() > 0) {

							// if
							// (GigflexUtility.emailPatternValidation(OperatorReq
							// .getEmailId()) == true) {

							Operator opr = operatorlst;

							opr.setOperatorName(operatorReq.getOperatorName());
							opr.setContactNumber(operatorReq.getContactNumber());
							opr.setCountryCode(operatorReq.getCountryCode());
							opr.setTradingAddress(operatorReq.getTradingAddress());
							opr.setOrganizationCode(operatorReq.getOrganizationCode());
							opr.setIpAddress(ip);
							opr.setOperatorImage(operatorReq.getOperatorImage());

							Operator OperatorRes = operatorRepository.save(opr);
							if (OperatorRes != null && OperatorRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("message", "Operator updation has been done");
								jsonobj.put("timestamp", new Date());
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(OperatorRes);
								jsonobj.put("data", new JSONObject(Detail));
								kafkaService.sendOperatorForUpdate(OperatorRes);
								Users user = userRepository.findByUserCode(OperatorRes.getOperatorCode());
								if (user != null && user.getId() > 0) {
									user.setName(OperatorRes.getOperatorName());
									user.setEmail(OperatorRes.getEmailId());
									Users userres = userRepository.save(user);
									if (userres != null && userres.getId() > 0) {
										kafkaService.sendUpdateUser(userres);
									}
								}
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("message", "Operator updation has been failed.");
								jsonobj.put("timestamp", new Date());

							}
							// } else {
							// jsonobj.put("responsecode", 400);
							// jsonobj.put("timestamp", new Date());
							// jsonobj.put("message",
							// "Please check your email format.");
							// }
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Operator ID is not valid.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Organization Code not found.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByOperatorCode(String operatorCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Operator operatorlst = operatorRepository.getOperatorByOperatorCode(operatorCode);
			if (operatorlst != null && operatorlst.getId() > 0) {
				operatorlst.setIsDeleted(true);
				Operator operatorRes = operatorRepository.save(operatorlst);
				if (operatorRes != null && operatorRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Operator deleted successfully.");
					kafkaService.sendOperatorForUpdate(operatorRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByOperatorCode(List<String> operatorCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String operatorCode : operatorCodeList) {
				if (operatorCode != null && operatorCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					operatorCode = operatorCode.trim();

					Operator operatorlst = operatorRepository.getOperatorByOperatorCode(operatorCode);
					if (operatorlst != null && operatorlst.getId() > 0) {
						operatorlst.setIsDeleted(true);
						Operator OperatorRes = operatorRepository.save(operatorlst);
						if (OperatorRes != null && OperatorRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", operatorCode);
							jsonobj.put("message", "Operator deleted successfully.");
							kafkaService.sendOperatorForUpdate(OperatorRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", operatorCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", operatorCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				OperatorSpecificationsBuilder builder = new OperatorSpecificationsBuilder();
				Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
				}

				Specification<Operator> spec = builder.build();
				if (spec != null) {
					List<Operator> Operatorlst = operatorRepository.findAll(spec);
					if (Operatorlst != null && Operatorlst.size() > 0) {
						for (Operator act : Operatorlst) {
							if (act.getIsDeleted() != null && act.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(act);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("Operator", new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;

	}

	@Override
	public Operator getUserEmail(String userEmail) {
		return operatorRepository.findByEmail(userEmail);
	}

	@Override
	public String getOperatorByOrganizationCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = operatorRepository.getOperatorByOrgCode(organizationCode);
			List<OperatorResponse> maplst = new ArrayList<OperatorResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {

						OperatorResponse opr = new OperatorResponse();

						Operator data = (Operator) arr[0];
						opr.setId(data.getId());
						opr.setOperatorCode(data.getOperatorCode());
						opr.setOperatorName(data.getOperatorName());
						opr.setContactNumber(data.getContactNumber());
						opr.setCountryCode(data.getCountryCode());
						opr.setEmailId(data.getEmailId());
						opr.setTradingAddress(data.getTradingAddress());
						opr.setOrganizationCode(data.getOrganizationCode());
						opr.setOperatorImage(data.getOperatorImage());
						opr.setOrganizationName((String) arr[1]);

						maplst.add(opr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getOperatorByOrganizationCodeByPage(String organizationCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = operatorRepository.getOperatorByOrgCode(organizationCode, pageableRequest);
			List<OperatorResponse> maplst = new ArrayList<OperatorResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {

						OperatorResponse opr = new OperatorResponse();

						Operator data = (Operator) arr[0];
						opr.setId(data.getId());
						opr.setOperatorCode(data.getOperatorCode());
						opr.setOperatorName(data.getOperatorName());
						opr.setContactNumber(data.getContactNumber());
						opr.setCountryCode(data.getCountryCode());
						opr.setEmailId(data.getEmailId());
						opr.setTradingAddress(data.getTradingAddress());
						opr.setOrganizationCode(data.getOrganizationCode());
						opr.setOperatorImage(data.getOperatorImage());
						opr.setOrganizationName((String) arr[1]);

						maplst.add(opr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}
}
