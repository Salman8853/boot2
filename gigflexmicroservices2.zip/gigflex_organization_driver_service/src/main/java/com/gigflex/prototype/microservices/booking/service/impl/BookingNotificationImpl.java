/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.booking.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBooking;
import com.gigflex.prototype.microservices.assignbooking.repository.AssignBookingRepository;
import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.booking.dtob.BookingResponse;
import com.gigflex.prototype.microservices.booking.notification.SendNotification;
import com.gigflex.prototype.microservices.booking.repository.BookingDao;
import com.gigflex.prototype.microservices.booking.service.BookingNotification;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.organization.repository.OrganizationDao;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.utility.GigflexDateUtil;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.booking.dtob.BookingAllResponse;
import com.gigflex.prototype.microservices.device.dtob.DeviceDetail;
import com.gigflex.prototype.microservices.device.repository.DeviceDetailRepository;
import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocument;
import com.gigflex.prototype.microservices.documentmapping.dtob.OperatorDocument;
import com.gigflex.prototype.microservices.documentmapping.repository.DriverDocumentRepository;
import com.gigflex.prototype.microservices.documentmapping.repository.OperatorDocumentRepository;
import com.gigflex.prototype.microservices.globalridetype.dtob.GlobalRideType;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.notification.service.NotificationService;
import com.gigflex.prototype.microservices.organizationcredittransaction.dtob.OrganizationCreditTransaction;
import com.gigflex.prototype.microservices.organizationcredittransaction.repository.OrganizationCreditTransactionRepository;
import com.gigflex.prototype.microservices.passenger.dtob.Passenger;
import com.gigflex.prototype.microservices.passenger.repository.PassengerDao;
import com.gigflex.prototype.microservices.ridetype.repository.RideTypeRepository;
import com.gigflex.prototype.microservices.setting.service.SettingService;
import com.gigflex.prototype.microservices.usertype.dtob.UserType;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.utility.PushNotification;
import com.gigflex.prototype.microservices.utility.SendMessageAPI;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author nirbhay.p
 */
@Service

public class BookingNotificationImpl implements BookingNotification {
	private static final Logger logger = LoggerFactory.getLogger(BookingNotificationImpl.class);
	@Autowired
	public BookingDao bookingDao;
        @Autowired
        OrganizationCreditTransactionRepository organizationCreditTransactionRepository;
        @Autowired
        private NotificationService notificationService;
	@Autowired
	OrganizationDao organizationDao;
	@Autowired
	DriverRepository driverRepository;

        @Autowired
        TimeZoneRepository timeZoneRepository;
	@Autowired
	AssignBookingRepository assignBookingRepository;
        @Autowired
        RideTypeRepository rideTypeRepository;
	@Autowired
	OperatorRepository operatorRepository;
        
        @Autowired
        SettingService settingService;
        
        @Autowired
        OperatorDocumentRepository operatorDocumentRepository;
        @Autowired
        DriverDocumentRepository driverDocumentRepository;
        
        @Autowired
        GlobalSettingRepository globalSettingRepository;
    
        @Autowired
        LocalSettingRepository localSettingRepository;
        
        @Autowired
	UserTypeRepository userTypeDao;
        
        @Autowired
        private PassengerDao passengerDao;
        
        
        @Autowired
        DeviceDetailRepository deviceDetailDao;

	@Value("${email.upcomingacceptedbooking.subject}")
	private String subject; //= "Upcoming accepted booking notification";
        
        private String subjectExpired= "Booking expiry notification";

	@Value("${email.service.url}")
	private String mailServiceURL;//="http://18.223.158.6:8091/superadminservice/sendEmail/to/{to}/subject/{subject}/body/{body}";

	@Value("${email.service.url.withcc}")
	private String mailServiceURLCC;// = "http://18.223.158.6:8091/superadminservice/sendEmailWithCC/to/{to}/cc/{cc}/subject/{subject}/body/{body}";
        
        @Value("${message.appKey}")
        private String appKey; //="5f660e09-e0b7-474e-889c-fd3c077f195c";
        
        @Value("${message.appSecret}")
        private String appSecret;//="qegMoUCBT0OGXuASFMPB+Q==";

        @Value("${message.url}")
        private String url;//="https://messagingapi.sinch.com/v1/sms/";
        
        @Value("${setting.name.configure.minutes}")
        private String configureminutesName;
        
        @Value("${setting.name.alert.minutes}")
        private String alertminutesName;
        
        @Value("${setting.name.expired.minutes}")
        private String expiredminutesName;
        
        @Value("${setting.name.is.recursive}")
        private String isrecursiveName;
        
        @Value("${setting.name.sms.notifications}")
        private String smsNotiName;
        
        @Value("${setting.name.mail.notifications}")
        private String mailNotiName;
        
        @Value("${notification.deviceid}")
        private String deviceId;
        
        @Value("${notification.fcm.url}")
        private String FMCurl; 
        
        @Value("${notification.fcm.authkey}")
        private String authKey;
        
	 @Override
    public void sendNotification() {
        Date dt = new Date();
        List<Booking> blst = bookingDao.getAllUpcomingAcceptedBooking(dt, GigflexConstants.assignedBookingAcceptedStatus);
        if(blst!=null && blst.size()>0)
        {
            logger.info("In Scheduler all upcoming booking size="+blst.size());
       // String smsNotiStatus= settingService.getSettinValue("Scheduler.Booking.Upcoming.SmsNotification");
        UserType ut=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOrganization);
        UserType utOtr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOperator);
        UserType utDvr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeDriver);
        for (Booking b : blst) {
        	try {
                if (b != null && b.getId() > 0) {
                Date curdt = new Date();
                int configMinut =1440;
                int alertMinute=30;
                Boolean isRecursive=false;
                
                String passengerName="";
                Passenger pgr=  passengerDao.getPassengerByPassengerCode(b.getPassengerCode());
                if(pgr!=null && pgr.getId()>0)
                 {
                   passengerName=pgr.getPassengerName();
                 }
                
                if (ut!=null && ut.getUserTypeCode()!=null && ut.getUserTypeCode().length()>0 && b.getOrganizationCode() != null && b.getOrganizationCode().length() > 0) {
                    
                   String configureminutesValue= GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), b.getOrganizationCode(), configureminutesName);
                   if(configureminutesValue!=null && configureminutesValue.length()>0)
                   {
                       try
                       {
                           configMinut=Integer.parseInt(configureminutesValue);
                       }
                       catch(Exception ex)
                       {
                           ex.printStackTrace();;
                       }
                   }
                   
                   String alertminutesValue= GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), b.getOrganizationCode(), alertminutesName);
                   if(alertminutesValue!=null && alertminutesValue.length()>0)
                   {
                       try
                       {
                           alertMinute=Integer.parseInt(alertminutesValue);
                       }
                       catch(Exception ex)
                       {
                           ex.printStackTrace();;
                       }
                   }
                   
                   String isrecursiveValue= GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), b.getOrganizationCode(), isrecursiveName);
                   if(isrecursiveValue!=null && isrecursiveValue.length()>0)
                   {
                       try
                       {
                           if(isrecursiveValue.equalsIgnoreCase("true"))
                           {
                           isRecursive=true;
                           }
                           
                       }
                       catch(Exception ex)
                       {
                           ex.printStackTrace();
                       }
                   }
                }
                if(!isRecursive){
                Calendar cal = Calendar.getInstance();
                cal.setTime(curdt);
                cal.add(Calendar.MINUTE, alertMinute);
                Date sdt = cal.getTime();
                cal.add(Calendar.MINUTE, 1);
                Date edt = cal.getTime();
                Date pdt = b.getPickUpTime();
                if (pdt != null && (pdt.after(sdt) || pdt.equals(sdt)) && pdt.before(edt)) {
                    logger.info("In Scheduler picup time is matched. booking id="+b.getId());
                    AssignBooking ab = assignBookingRepository.getAssignBookingByRideCode(b.getRideCode());
                    if (ab != null && ab.getId() > 0 && ab.getDriverCode() != null && ab.getDriverCode().length() > 0) {
                        Driver d = driverRepository.getDriverByDriverCode(ab.getDriverCode());
                        if (d != null && d.getId() > 0 && d.getEmailId() != null && d.getEmailId().length() > 0) {
                            String toid = "";
                            boolean SMSSt=true;
                            boolean MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), ab.getDriverCode(), mailNotiName);
                            if(MailST)
                            {
                               toid = d.getEmailId(); 
                            }
                            String operatorCodes=d.getDriverCode();
                            String abOperatorCode = ab.getOperatorCode();
                            String bOperatorCode = b.getOperatorCode();
                            String ccMail = "";
                            String contactOtr="";
                            if (abOperatorCode != null && bOperatorCode != null) {
                                if (abOperatorCode.equals(bOperatorCode)) {
                                    Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                    MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
                                    if (MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

                                        ccMail = operator.getEmailId();
                                    }
                                    SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                    if (SMSSt && operator!=null && operator.getContactNumber() != null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!=null && operator.getCountryCode().length()>0) {

                                        contactOtr = "+"+operator.getCountryCode().trim()+operator.getContactNumber().trim();
                                    }
                                    operatorCodes+=","+bOperatorCode;
                                } else {
                                    Operator aboperator = operatorRepository.getOperatorByOperatorCode(abOperatorCode);
                                    MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, mailNotiName);
                                    if (MailST && aboperator!=null && aboperator.getEmailId() != null && aboperator.getEmailId().length() > 0) {

                                        ccMail = aboperator.getEmailId();
                                    }
                                    Operator boperator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                    MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
                                    if (MailST && boperator!=null && boperator.getEmailId() != null && boperator.getEmailId().length() > 0) {
                                        if (ccMail != null && ccMail.length() > 0) {
                                            ccMail += "," + boperator.getEmailId();
                                        } else {
                                            ccMail = boperator.getEmailId();
                                        }
                                    }
                                    SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, smsNotiName);
                                    if (SMSSt && aboperator!=null && aboperator.getContactNumber() != null && aboperator.getContactNumber().length() > 0 && aboperator.getCountryCode()!=null && aboperator.getCountryCode().length()>0) {

                                        contactOtr = "+"+aboperator.getCountryCode().trim()+aboperator.getContactNumber().trim();
                                    }
                                    SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                    if (SMSSt && boperator!=null && boperator.getContactNumber() != null && boperator.getContactNumber().length() > 0 && boperator.getCountryCode()!=null && boperator.getCountryCode().length()>0) {

                                        if (contactOtr != null && contactOtr.length() > 0) {
                                            contactOtr +=  ",+"+boperator.getCountryCode().trim()+boperator.getContactNumber().trim();
                                        } else {
                                            contactOtr = "+"+boperator.getCountryCode().trim()+boperator.getContactNumber().trim();
                                        }
                                    }
                                    
                                    operatorCodes+=","+bOperatorCode;
                                    operatorCodes+=","+abOperatorCode;
                                }
                            } else if (bOperatorCode != null) {
                                Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                 MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
                                 if (MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

                                    ccMail = operator.getEmailId();
                                }
                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                if (SMSSt && operator!=null && operator.getContactNumber() != null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!=null && operator.getCountryCode().length()>0) {

                                        contactOtr = "+"+operator.getCountryCode().trim()+operator.getContactNumber().trim();
                                    }
                                operatorCodes+=","+bOperatorCode;
                            }
                            String conDt="";
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TimeZone);

                           TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                           if (tzd != null && tzd.getId() > 0) {

                               String timezone = tzd.getTimeZoneName();
                               if(timezone!=null && timezone.length()>0 )
                               {
                                    Date pDate = b.getPickUpTime();
                                    pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                    conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                               }

                            }         

                            String bodyContent = "Your upcoming accepted booking details are given below-<br><br>"
                                    + "Driver Name : " + d.getName() + "<br>"
                                    +"Passenger Name : "+passengerName+"<br>"+ "Pick-up Time : "
                                    + conDt + "<br>" + "Pick-up Address : " + b.getPickUpAddress()
                                    + "<br>" + "Drop-off Address : " + b.getDropOffAddress();
                            
                             String messageBody = "\n"+"Your upcoming accepted booking details are given below-"+"\n"
                                            + "Driver Name : " + d.getName() + "\n"
                                            +"Passenger Name : "+passengerName+"\n"+ "Pick-up Time : "
                                            + conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
                                            + "\n" + "Drop-off Address : " + b.getDropOffAddress();
                             String notificationBody = "Your upcoming accepted booking details are given below-"
                                            + "Driver Name : " + d.getName() + ","
                                            +" Passenger Name : "+passengerName+","+ " Pick-up Time : "
                                            + conDt + "," + " Pick-up Address : " + b.getPickUpAddress()
                                            + "," + " Drop-off Address : " + b.getDropOffAddress();
                            SendNotification sn = new SendNotification();
                            SendMessageAPI sendmessageapi = new SendMessageAPI();
                              logger.info("====messageBody=====" + messageBody);
                         //   String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, "+917007873442", bodyContent);
                            if (ccMail != null && ccMail.length() > 0) {
                               String res= sn.sendMail(ccMail, subject, bodyContent, mailServiceURL);
                                
                               logger.info("Cron scheduler mail respose in BookingNotificationImpl >>>>>>", res);
                            } 
                            if (toid != null && toid.length() > 0) {
                                String res= sn.sendMail(toid, subject, bodyContent, mailServiceURL);
                                logger.info("Cron scheduler mail respose in BookingNotificationImpl >>>>>>", res);
                                
                            }
                          
                         
//                           if(smsNotiStatus!=null && smsNotiStatus.length()>0 && smsNotiStatus.trim().equalsIgnoreCase("true"))
//                           {
                            try {
                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), d.getDriverCode(), smsNotiName);
                                    if(SMSSt && d.getContactNumber()!=null && d.getContactNumber().trim().length()>0 && d.getCountryCode()!=null && d.getCountryCode().trim().length()>0){
                                   String conno="+"+d.getCountryCode().trim()+d.getContactNumber().trim();
                                   String msg="Dear Driver,"+messageBody;
                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, conno, msg);
                                    System.out.println("====messageToken=====" + messageToken);
                                    logger.info("====messageToken=====" + messageToken);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            
                            
                            try {
                                
                                if (contactOtr != null && contactOtr.length() > 0) {
                                    String oprmobarr[] = contactOtr.split(",");
                                    for (String oprmob : oprmobarr) {
                                        if (oprmob != null && oprmob.length() > 0) {
                                        String msg="Dear Operator,"+messageBody;
                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, oprmob, msg);
                                    System.out.println("====messageToken=====" + messageToken);
                                    logger.info("====messageToken=====" + messageToken);
                                    }
                                    }
                                }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                           //}
                            try {
                                if (operatorCodes != null && operatorCodes.length() > 0) {
                                    String userCodes[] = operatorCodes.split(",");
                                    for (String userCode : userCodes) {
                                        if (userCode != null && userCode.length() > 0) {
                                            Notification notification = new Notification();
                                            String shortMessage = "Upcoming accepted booking notification.";
                                            notification.setUserCode(userCode);
                                            notification.setMessage(notificationBody);
                                            notification.setShortMessage(shortMessage);
                                            notification.setRideCode(b.getRideCode());
                                            notification.setIpAddress("via scheduler");
                                            notification.setIsRead(Boolean.FALSE);
                                            notificationService.saveNotification(notification);
                                            
                                            
                                        }
                                    }
                                }

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            
                            
                            List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(d.getDriverCode().trim());
                            if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                            {
                              //for push notification 
                                for(DeviceDetail deviceDetail:deviceDetailResList)
                                {
                                    PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Ride is about to start", "The ride is about to start shortly");
                                }
                              
                            }
                           
                        }
                    }
                }
                else
                {
                     logger.info("In Scheduler picup time is not matched. booking id="+b.getId());
                }}
                else{
                        
                    Date curDt = new Date();
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(curDt);
                    cal.add(Calendar.MINUTE, configMinut);
                    Date sdt = cal.getTime();
                    Date pdt = b.getPickUpTime();
                    if (pdt != null && pdt.after(curDt) && (pdt.before(sdt) || pdt.equals(sdt))) {

                        long pdtInMinute = ((pdt.getTime()) / (60000));
                        long curInMinute = ((curDt.getTime()) / (60000));
                        long difInMinute = pdtInMinute - curInMinute;
                        long modAlert = difInMinute % alertMinute;
                        logger.info("In Scheduler picup time is matched for isRecursive. booking id=" + b.getId());
                        if (modAlert >= 0 && modAlert < 5) {
                            AssignBooking ab = assignBookingRepository.getAssignBookingByRideCode(b.getRideCode());
                            if (ab != null && ab.getId() > 0 && ab.getDriverCode() != null && ab.getDriverCode().length() > 0) {
                                Driver d = driverRepository.getDriverByDriverCode(ab.getDriverCode());
                                if (d != null && d.getId() > 0 && d.getEmailId() != null && d.getEmailId().length() > 0) {
                                    
                            String toid = "";
                            boolean SMSSt=true;
                            boolean MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), ab.getDriverCode(), mailNotiName);
                            if(MailST)
                            {
                               toid = d.getEmailId(); 
                            }
                            String operatorCodes=d.getDriverCode();
                            String abOperatorCode = ab.getOperatorCode();
                            String bOperatorCode = b.getOperatorCode();
                            String ccMail = "";
                            String contactOtr="";
                            if (abOperatorCode != null && bOperatorCode != null) {
                                if (abOperatorCode.equals(bOperatorCode)) {
                                    Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                    MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
                                    if (MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

                                        ccMail = operator.getEmailId();
                                    }
                                    SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                    if (SMSSt && operator!=null && operator.getContactNumber() != null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!=null && operator.getCountryCode().length()>0) {

                                        contactOtr = "+"+operator.getCountryCode().trim()+operator.getContactNumber().trim();
                                    }
                                    operatorCodes+=","+bOperatorCode;
                                } else {
                                    Operator aboperator = operatorRepository.getOperatorByOperatorCode(abOperatorCode);
                                    MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, mailNotiName);
                                    if (MailST && aboperator!=null && aboperator.getEmailId() != null && aboperator.getEmailId().length() > 0) {

                                        ccMail = aboperator.getEmailId();
                                    }
                                    Operator boperator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                    MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
                                    if (MailST && boperator!=null && boperator.getEmailId() != null && boperator.getEmailId().length() > 0) {
                                        if (ccMail != null && ccMail.length() > 0) {
                                            ccMail += "," + boperator.getEmailId();
                                        } else {
                                            ccMail = boperator.getEmailId();
                                        }
                                    }
                                    SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, smsNotiName);
                                    if (SMSSt && aboperator!=null && aboperator.getContactNumber() != null && aboperator.getContactNumber().length() > 0 && aboperator.getCountryCode()!=null && aboperator.getCountryCode().length()>0) {

                                        contactOtr = "+"+aboperator.getCountryCode().trim()+aboperator.getContactNumber().trim();
                                    }
                                    SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                    if (SMSSt && boperator!=null && boperator.getContactNumber() != null && boperator.getContactNumber().length() > 0 && boperator.getCountryCode()!=null && boperator.getCountryCode().length()>0) {

                                        if (contactOtr != null && contactOtr.length() > 0) {
                                            contactOtr +=  ",+"+boperator.getCountryCode().trim()+boperator.getContactNumber().trim();
                                        } else {
                                            contactOtr = "+"+boperator.getCountryCode().trim()+boperator.getContactNumber().trim();
                                        }
                                    }
                                    
                                    operatorCodes+=","+bOperatorCode;
                                    operatorCodes+=","+abOperatorCode;
                                }
                            } else if (bOperatorCode != null) {
                                Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                 MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
                                 if (MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

                                    ccMail = operator.getEmailId();
                                }
                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                if (SMSSt && operator!=null && operator.getContactNumber() != null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!=null && operator.getCountryCode().length()>0) {

                                        contactOtr = "+"+operator.getCountryCode().trim()+operator.getContactNumber().trim();
                                    }
                                operatorCodes+=","+bOperatorCode;
                            }
                                    String conDt = "";
                                    String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                    {
                                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                                    }                

                                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TimeZone);

                                   TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                   if (tzd != null && tzd.getId() > 0) {

                                       String timezone = tzd.getTimeZoneName();
                                       if(timezone!=null && timezone.length()>0 )
                                       {
                                            Date pDate = b.getPickUpTime();
                                            pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                            conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                       }

                                    }     
                                    String bodyContent = "Your upcoming accepted booking details are given below-<br><br>"
                                            + "Driver Name : " + d.getName() + "<br>"
                                            +"Passenger Name : "+passengerName+"<br>"+ "Pick-up Time : "
                                            + conDt + "<br>" + "Pick-up Address : " + b.getPickUpAddress()
                                            + "<br>" + "Drop-off Address : " + b.getDropOffAddress();
                                     String messageBody = "\n"+"Your upcoming accepted booking details are given below-"+"\n"
                                            + "Driver Name : " + d.getName() + "\n"
                                            +"Passenger Name : "+passengerName+"\n"+ "Pick-up Time : "
                                            + conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
                                            + "\n" + "Drop-off Address : " + b.getDropOffAddress();
                                     String notificationBody = "Your upcoming accepted booking details are given below-"
                                            + "Driver Name : " + d.getName() + ","
                                            +" Passenger Name : "+passengerName+","+ " Pick-up Time : "
                                            + conDt + "," + " Pick-up Address : " + b.getPickUpAddress()
                                            + "," + " Drop-off Address : " + b.getDropOffAddress();
                                    SendNotification sn = new SendNotification();
                                    SendMessageAPI sendmessageapi = new SendMessageAPI();
                                    logger.info("====messageToken=====" + messageBody);
                                   //String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, "+917007873442", messageBody);
                                    if (ccMail != null && ccMail.length() > 0) {
                               String res= sn.sendMail(ccMail, subject, bodyContent, mailServiceURL);
                                
                               logger.info("Cron scheduler mail respose in BookingNotificationImpl >>>>>>", res);
                            } 
                            if (toid != null && toid.length() > 0) {
                                String res= sn.sendMail(toid, subject, bodyContent, mailServiceURL);
                                logger.info("Cron scheduler mail respose in BookingNotificationImpl >>>>>>", res);
                                
                            }
                                    
                                     
//                           if(smsNotiStatus!=null && smsNotiStatus.length()>0 && smsNotiStatus.trim().equalsIgnoreCase("true"))
//                           {
                            try {
                                    SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), d.getDriverCode(), smsNotiName);
                                    if(SMSSt && d.getContactNumber()!=null && d.getContactNumber().trim().length()>0 && d.getCountryCode()!=null && d.getCountryCode().trim().length()>0){
                                   String conno="+"+d.getCountryCode().trim()+d.getContactNumber().trim();
                                   String msg="Dear Driver,"+messageBody;
                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, conno, msg);
                                    System.out.println("====messageToken=====" + messageToken);
                                    logger.info("====messageToken=====" + messageToken);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            
                            
                            try {
                                
                                if (contactOtr != null && contactOtr.length() > 0) {
                                    String oprmobarr[] = contactOtr.split(",");
                                    for (String oprmob : oprmobarr) {
                                        if (oprmob != null && oprmob.length() > 0) {
                                        String msg="Dear Operator,"+messageBody;
                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, oprmob, msg);
                                    System.out.println("====messageToken=====" + messageToken);
                                    logger.info("====messageToken=====" + messageToken);
                                    }
                                    }
                                }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                           //}
                                    
                                    try {
                                if (operatorCodes != null && operatorCodes.length() > 0) {
                                    String userCodes[] = operatorCodes.split(",");
                                    for (String userCode : userCodes) {
                                        if (userCode != null && userCode.length() > 0) {
                                            Notification notification = new Notification();
                                            String shortMessage = "Upcoming accepted booking notification.";
                                            notification.setUserCode(userCode);
                                            notification.setMessage(notificationBody);
                                            notification.setShortMessage(shortMessage);
                                            notification.setRideCode(b.getRideCode());
                                            notification.setIpAddress("via scheduler");
                                            notification.setIsRead(Boolean.FALSE);
                                            notificationService.saveNotification(notification);
                                            
                                            
                                        }
                                    }
                                }

                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                               List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(d.getDriverCode().trim());
                               if(deviceDetailResList != null && deviceDetailResList.size() >0)
                               {
                                 //for push notification 
                                   for(DeviceDetail deviceDetail:deviceDetailResList)
                                   {
                                       PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Ride is about to start", "The ride is about to start shortly");    
                                   }
                                 
                               }
                                
                                  
                                }
                            }
                        }
                    }

                }
            }

        }catch (Exception ex) {
			ex.printStackTrace();
		}
	 }
    }
        else
        {
            logger.info("In Scheduler all upcoming booking size=0");
        }
    }

    public void setExpired()
    {
        Date dt = new Date();
        List<String> stlst = new ArrayList<String>();
        //stlst.add(GigflexConstants.assignedBookingInProgressStatus);
        stlst.add(GigflexConstants.assignedBookingCancelledStatus);
        stlst.add(GigflexConstants.assignedBookingExpiredStatus);
        stlst.add(GigflexConstants.assignedBookingCompletedStatus);
        List<Booking> blst = bookingDao.getAllBookingNearToExpire(dt, stlst);
        if (blst != null && blst.size() > 0) {
            UserType ut=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOrganization);
            UserType utOtr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOperator);
            UserType utDvr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeDriver);
            //String smsNotiStatus= settingService.getSettinValue("Scheduler.Booking.Expiry.SmsNotification");
            int min = 15;
            String orgcode = "";
            for (Booking b : blst) {
                try
                {
                    if (b.getOrganizationCode() == null) {
                        min = 15;
                        orgcode = "";
                    } else {
                        if (orgcode.length() == 0 || !(orgcode.equalsIgnoreCase(b.getOrganizationCode()))) {
                            orgcode = b.getOrganizationCode();
                            if (ut != null && ut.getUserTypeCode() != null && ut.getUserTypeCode().length() > 0 && b.getOrganizationCode() != null && b.getOrganizationCode().length() > 0) {

                                String expiredminutesValue = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), b.getOrganizationCode(), expiredminutesName);
                                if (expiredminutesValue != null && expiredminutesValue.length() > 0) {
                                    try {
                                        min = Integer.parseInt(expiredminutesValue);
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                        min = 15;
                                    }
                                } else {
                                    min = 15;
                                }
                            } else {
                                min = 15;
                            }
                    }
                }

//                if(b.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingInProgressStatus))
//                {
//                
//                    try {
//                        Date curdt = dt;
//                        Date picdt=b.getPickUpTime();
//                        curdt=new SimpleDateFormat("yyyy-MM-dd").parse( new SimpleDateFormat("yyyy-MM-dd").format(curdt));
//                        picdt=new SimpleDateFormat("yyyy-MM-dd").parse( new SimpleDateFormat("yyyy-MM-dd").format(picdt));
//                        if(picdt.before(curdt))
//                        
//                    } catch (ParseException ex) {
//                        logger.error("ParseException in set Expire from inprogrss>>>", ex);
//                    }
//                    catch (Exception ex) {
//                        logger.error("Exception in set Expire from inprogrss>>>", ex);
//                    }
//                }
//                else
//                {
try{       
    min=min*-1;
                Calendar cal = Calendar.getInstance();
                cal.setTime(dt);
                cal.add(Calendar.MINUTE, min);
                Date curdt = cal.getTime();
                 Date picdt=b.getPickUpTime();
                if(b.getBookingStatus().equalsIgnoreCase(GigflexConstants.assignedBookingInProgressStatus))
                {
                    curdt = dt;
                    curdt=new SimpleDateFormat("yyyy-MM-dd").parse( new SimpleDateFormat("yyyy-MM-dd").format(curdt));
                    picdt=new SimpleDateFormat("yyyy-MM-dd").parse( new SimpleDateFormat("yyyy-MM-dd").format(picdt));
                        
                }
                
                if (curdt.after(picdt)) {
                    String oldst = b.getBookingStatus();
                    b.setBookingStatus(GigflexConstants.assignedBookingExpiredStatus);
                    b.setDropOffTime(new Date());
                    Booking dres = bookingDao.save(b);
                    if (dres != null && dres.getId() > 0) {
                        //code for check balance amount before new booking
                                    List<OrganizationCreditTransaction> objlst = organizationCreditTransactionRepository.getLastTransactionBalanceByOrganizationCode(b.getOrganizationCode());


                                    double creditAmount = 0.0;
                                    double debitAmount =0.0;
                                    double balaceAmount = 0.0;
                                    double lastBalance = 0.0;
                                    if (objlst != null && objlst.size() > 0) {

                                        OrganizationCreditTransaction oprRes = objlst.get(0);

                                        if(oprRes != null && oprRes.getId() >0 )
                                        {
                                            lastBalance = oprRes.getBalanceAmount();
                                            creditAmount = b.getCustomerFare();
                                            balaceAmount = lastBalance+ creditAmount ;

                                            OrganizationCreditTransaction oct = new OrganizationCreditTransaction();

                                            oct.setBalanceAmount(balaceAmount); 
                                            oct.setCreditAmount(creditAmount); 
                                            oct.setDebitAmount(debitAmount);
                                            oct.setOrganizationCode(b.getOrganizationCode()); 
                                            oct.setBookingid(b.getBookingid());
                                            oct.setTransactionBy(GigflexConstants.BOOKING); 
                                            oct.setTransactionType(GigflexConstants.TRANSACTION_TYPE_CREDIT); 
                                            oct.setIpAddress("via scheduler"); 

                                           OrganizationCreditTransaction operatorCreditTransactionRes = organizationCreditTransactionRepository.save(oct);

                                            if(operatorCreditTransactionRes == null || operatorCreditTransactionRes.getId()==0 )
                                            {
                                               logger.info("Credit Transaction Failed in booking expiry via scheduler");
                                            }                                               
                                        }

                                    }
                        try {
                            AssignBooking ab = assignBookingRepository.getAssignBookingByRideCode(dres.getRideCode());
                            if (ab != null && ab.getId() > 0) {
                                ab.setStatus(GigflexConstants.assignedBookingExpiredStatus);
                                AssignBooking abres = assignBookingRepository.save(ab);
                                if (abres != null && abres.getId() > 0) {
                                    
                                 Driver d = null;
                                 if(oldst!=null && !(oldst.equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus)) && !(oldst.equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))  && !(oldst.equalsIgnoreCase(GigflexConstants.assignedBookingStatus)))
                                        {
                                            d=driverRepository.getDriverByDriverCode(abres.getDriverCode());   
                                        }
                                    
                                 boolean SMSSt=true;
                                 boolean MailST=true;
                                 String operatorCodes="";
                                    String abOperatorCode = abres.getOperatorCode();
                                    String bOperatorCode = dres.getOperatorCode();
                                    String oprMail = "";
                                    String oprMob="";
                                    if (abOperatorCode != null && bOperatorCode != null) {
                                        if (abOperatorCode.equals(bOperatorCode)) {
                                            Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                            MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
                                            if (MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

                                                oprMail = operator.getEmailId();
                                            }
                                            SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                            if (SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {

                                                oprMob ="+"+operator.getCountryCode()+ operator.getContactNumber();
                                            }
                                            operatorCodes=bOperatorCode;
                                        } else {
                                            Operator aboperator = operatorRepository.getOperatorByOperatorCode(abOperatorCode);
                                            MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, mailNotiName);
                                            if (MailST && aboperator!=null && aboperator.getEmailId() != null && aboperator.getEmailId().length() > 0) {

                                                oprMail = aboperator.getEmailId();
                                            }
                                            SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, smsNotiName);
                                            if (SMSSt && aboperator!=null && aboperator.getContactNumber()!= null && aboperator.getContactNumber().length() > 0 && aboperator.getCountryCode()!= null && aboperator.getCountryCode().length() > 0) {

                                                oprMob ="+"+aboperator.getCountryCode()+ aboperator.getContactNumber();
                                            }
                                            Operator boperator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                            MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
                                            if (MailST && boperator!=null && boperator.getEmailId() != null && boperator.getEmailId().length() > 0 ) {
                                                if (oprMail != null && oprMail.length() > 0) {
                                                    oprMail += "," + boperator.getEmailId();
                                                } else {
                                                    oprMail = boperator.getEmailId();
                                                }
                                            }
                                            SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                            if (SMSSt && boperator!=null && boperator.getContactNumber() != null && boperator.getContactNumber().length() > 0 && boperator.getCountryCode()!=null && boperator.getCountryCode().length()>0) {
                                                if (oprMob != null && oprMob.length() > 0) {
                                                    oprMob += ",+"+boperator.getCountryCode() + boperator.getContactNumber();
                                                } else {
                                                    oprMob = "+"+boperator.getCountryCode() + boperator.getContactNumber();
                                                }
                                            }
                                            operatorCodes+=","+bOperatorCode;
                                            operatorCodes+=","+abOperatorCode;
                                        }
                                    } else if (bOperatorCode != null) {
                                        Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
                                        if (MailST && operator!=null && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

                                            oprMail = operator.getEmailId();
                                        }
                                        SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                         if (SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!=null && operator.getCountryCode().length()>0) {

                                                oprMob ="+"+operator.getCountryCode()+ operator.getContactNumber();
                                        }
                                        operatorCodes+=","+bOperatorCode;
                                    }
                                    String conDt = "";
                                    String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                    {
                                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                                    }                

                                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, b.getOrganizationCode(), GigflexConstants.TimeZone);

                                   TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                   if (tzd != null && tzd.getId() > 0) {

                                       String timezone = tzd.getTimeZoneName();
                                       if(timezone!=null && timezone.length()>0 )
                                       {
                                            Date pDate = b.getPickUpTime();
                                            pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                            conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                       }

                                    }     
                                  String passengerName="";
                                  Passenger pgr=  passengerDao.getPassengerByPassengerCode(b.getPassengerCode());
                                    if(pgr!=null && pgr.getId()>0)
                                    {
                                        passengerName=pgr.getPassengerName();
                                    }
                                   //String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, "+917007873442", messageBody);
                                    if (oprMail != null && oprMail.length() > 0) {
                                        String bodyContent = "Your booking has been expired. Booking details are given below-<br><br>";
                                        if(d!=null && d.getName()!=null && d.getName().length()>0)
                                        {
                                             bodyContent+="Driver Name : "+d.getName()+"<br>";
                                        }
                                        bodyContent+="Passenger Name : "+passengerName+"<br>"+ "Pick-up Time : "
                                            + conDt + "<br>" + "Pick-up Address : " + b.getPickUpAddress()
                                            + "<br>" + "Drop-off Address : " + b.getDropOffAddress();
                                         SendNotification sn = new SendNotification();
                                        String res = sn.sendMail(oprMail, subjectExpired, bodyContent, mailServiceURL);
                                        logger.info("Cron scheduler mail respose in BookingNotificationImpl >>>>>>", res);
                                    }
                                   
//                                     if(smsNotiStatus!=null && smsNotiStatus.length()>0 && smsNotiStatus.trim().equalsIgnoreCase("true"))
//                           {
                                    if(oprMob!=null && oprMob.length()>0)
                                    {
                                        
                                        try {
                                             String messageBody = "Your booking has been expired. Booking details are given below-"+"\n";
                                             if(d!=null && d.getName()!=null && d.getName().length()>0)
                                            {
                                             messageBody+="Driver Name : "+d.getName()+"\n";
                                            }
                                            messageBody+="Passenger Name : "+passengerName+"\n"+ "Pick-up Time : "
                                            + conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
                                            + "\n" + "Drop-off Address : " + b.getDropOffAddress();
                                            SendMessageAPI sendmessageapi = new SendMessageAPI();
                                            String mobarr[]=oprMob.split(",");
                                            for(String mob:mobarr)
                                            {
                                            String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, mob, messageBody);
                                            System.out.println("====messageToken=====" + messageToken);
                                            logger.info("====messageToken=====" + messageToken);
                                            }
                                            
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
 //                          }
                                    try {
                                if (operatorCodes != null && operatorCodes.length() > 0) {
                                     String notificationBody = "Your booking has been expired. Booking details are given below-";
                                     if(d!=null && d.getName()!=null && d.getName().length()>0)
                                            {
                                             notificationBody+=" Driver Name : "+d.getName()+",";
                                            }
                                            notificationBody+=" Passenger Name : "+passengerName+","+ " Pick-up Time : "
                                            + conDt + "," + " Pick-up Address : " + b.getPickUpAddress()
                                            + "," + " Drop-off Address : " + b.getDropOffAddress();
                                   
                                    String userCodes[] = operatorCodes.split(",");
                                    for (String userCode : userCodes) {
                                        if (userCode != null && userCode.length() > 0) {
                                            Notification notification = new Notification();
                                            String shortMessage = "Booking expiry notification.";
                                            notification.setUserCode(userCode);
                                            notification.setMessage(notificationBody);
                                            notification.setShortMessage(shortMessage);
                                            notification.setRideCode(b.getRideCode());
                                            notification.setIpAddress("via scheduler");
                                            notification.setIsRead(Boolean.FALSE);
                                            notificationService.saveNotification(notification);
                                            
                                            //for push notification 
//                                            PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, notificationBody);
                                        }
                                    }
                                }

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                                 
                                    if(abres.getDriverCode()!=null && abres.getDriverCode().length()>0 )
                                    {
                                        if(oldst!=null && !(oldst.equalsIgnoreCase(GigflexConstants.assignedBookingRejectedStatus)) && !(oldst.equalsIgnoreCase(GigflexConstants.assignedBookingPublishedStatus))  && !(oldst.equalsIgnoreCase(GigflexConstants.assignedBookingStatus)))
                                        {
                                            
                                            if(d!=null && d.getId()>0)
                                            {
                                               MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), abres.getDriverCode(), mailNotiName); 
                                                
                                                 if (MailST && d.getEmailId() != null && d.getEmailId().length() > 0) {
                                        String bodyContent = "Your booking has been expired. Booking details are given below-<br><br>";
                                            if(!(oldst.equalsIgnoreCase(GigflexConstants.bookingStatus)))
                                            {
                                            bodyContent +="Passenger Name : "+passengerName+"<br>";
                                            }
                                             bodyContent +="Pick-up Time : "+ conDt + "<br>" + "Pick-up Address : " + b.getPickUpAddress()
                                            + "<br>" + "Drop-off Address : " + b.getDropOffAddress();
                                         SendNotification sn = new SendNotification();
                                        String res = sn.sendMail(d.getEmailId(), subjectExpired, bodyContent, mailServiceURL);
                                        logger.info("Cron scheduler mail respose in BookingNotificationImpl >>>>>>", res);
                                    }
//                                                  if(smsNotiStatus!=null && smsNotiStatus.length()>0 && smsNotiStatus.trim().equalsIgnoreCase("true"))
//                           {
                                  
                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                if(SMSSt && d.getContactNumber()!=null && d.getContactNumber().length()>0)
                                    {
                                        
                                        try {
                                            if(d.getContactNumber()!=null && d.getContactNumber().length()>0 && d.getCountryCode()!=null && d.getCountryCode().length()>0)
                                            {
                                             String  mob="+"+d.getCountryCode()+d.getContactNumber();
                                             String messageBody = "Your booking has been expired. Booking details are given below-"+"\n";
                                             if(!(oldst.equalsIgnoreCase(GigflexConstants.bookingStatus)))
                                            {
                                            messageBody +="Passenger Name : "+passengerName+"\n";
                                                    }
                                            messageBody += "Pick-up Time : "+ conDt + "\n" + "Pick-up Address : " + b.getPickUpAddress()
                                            + "\n" + "Drop-off Address : " + b.getDropOffAddress();
                                            SendMessageAPI sendmessageapi = new SendMessageAPI();
                                            
                                            String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, mob, messageBody);
                                            System.out.println("====messageToken=====" + messageToken);
                                            logger.info("====messageToken=====" + messageToken);
                                           
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }   
                         //  }
                                    try {
                                if (d.getDriverCode() != null && d.getDriverCode().length() > 0) {
                                     String notificationBody = "Your booking has been expired. Booking details are given below-";
                                      if(!(oldst.equalsIgnoreCase(GigflexConstants.bookingStatus)))
                                            {      
                                           notificationBody +=" Passenger Name : "+passengerName+",";
                                            }
                                           notificationBody += " Pick-up Time : "+ conDt + "," + " Pick-up Address : " + b.getPickUpAddress()
                                            + "," + " Drop-off Address : " + b.getDropOffAddress();
                                   
                                    
                                            Notification notification = new Notification();
                                            String shortMessage = "Booking expiry notification.";
                                            notification.setUserCode(d.getDriverCode());
                                            notification.setMessage(notificationBody);
                                            notification.setShortMessage(shortMessage);
                                            notification.setRideCode(b.getRideCode());
                                            notification.setIpAddress("via scheduler");
                                            notification.setIsRead(Boolean.FALSE);
                                            notificationService.saveNotification(notification);
                                            
                                            //for push notification  
                                            
                                            List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(d.getDriverCode().trim());
                                            if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                                            {
                                                for(DeviceDetail deviceDetail:deviceDetailResList)
                                                {
                                                    PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Ride Alert", "Booking expiry notification.");
                                                }
                                                
                                            }
                                            
                                     
                                }

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                                                
                                                
                                            }
                                        }
                                    }
                                    
                                    
                                }
                                else
                                {
                                   b.setBookingStatus(oldst);
                                    bookingDao.save(b); 
                                }
                            }

                        } catch (Exception ee) {
                            logger.error("Error in set Expire>>>", ee);
                            b.setBookingStatus(oldst);
                            bookingDao.save(b);
                        }
                    }

                }
                } catch (ParseException exx) {
                        logger.error("ParseException in set Expire from inprogrss>>>", exx);
                    }
     //       }
                } catch (Exception e) {
                            logger.error("Error in loop set Expire>>>", e);
                            
                        }
            }
        } else {
            logger.info("In Scheduler near to expire booking size=0");
        }
    }
    
       public void sendDocumentExpiryNotification() {
        List<Operator> oprlst = operatorRepository.getAllOperatorsList();
        if (oprlst != null && oprlst.size() > 0) {
            //String smsNotiStatus= settingService.getSettinValue("Scheduler.Document.Expiry.SmsNotification");
             UserType utOtr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOperator);
            UserType utDvr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeDriver);                        
            for (Operator opr : oprlst) {
                if (opr != null && opr.getId() > 0) {
                    boolean SMSSt=true;
                    boolean MailST=true;

                    List<OperatorDocument> operatorDocument = operatorDocumentRepository.getOperatorDocumentExpirationByOperatorCode(opr.getOperatorCode(), new Date());
                    if (operatorDocument != null && operatorDocument.size() > 0) {
                        String notificationBody = "Dear Operator, your document has been expired.";

                        Notification notification = new Notification();
                        String shortMessage = "Document expiry notification.";
                        notification.setUserCode(opr.getOperatorCode());
                        notification.setMessage(notificationBody);
                        notification.setShortMessage(shortMessage);
                        notification.setIpAddress("via scheduler");
                        notification.setIsRead(Boolean.FALSE);
                        notificationService.saveNotification(notification);
                        
                        //for push notification  
//                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, notificationBody);
                        
                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), opr.getOperatorCode(), mailNotiName);
                        if(MailST && opr.getEmailId()!=null && opr.getEmailId().length()>0)
                        {
                            try
                            {
                                String mailBody="Dear Operator,<br><br>Your document has been expired.";
                                SendNotification sn = new SendNotification();
                                        String res = sn.sendMail(opr.getEmailId(), shortMessage, mailBody, mailServiceURL);
                                        logger.info("Cron scheduler mail respose in doc exp >>>>>>", res);
                            }
                            catch (Exception e) {
                            e.printStackTrace();
                        }
                        }
//                        if(smsNotiStatus!=null && smsNotiStatus.length()>0 && smsNotiStatus.trim().equalsIgnoreCase("true"))
//                           {
                    SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), opr.getOperatorCode(), smsNotiName);
                    if(SMSSt && opr.getContactNumber()!=null && opr.getContactNumber().length()>0 && opr.getCountryCode()!=null && opr.getCountryCode().length()>0)
                        {
                            try
                            {
                                 String messageBody="Dear Operator,\n Your document has been expired.";
                                 SendMessageAPI sendmessageapi = new SendMessageAPI();
                                 String mob="+"+opr.getCountryCode( )+ opr.getContactNumber();         
                                            String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, mob, messageBody);
                                            System.out.println("====messageToken=====" + messageToken);
                                            logger.info("====messageToken=====" + messageToken);
                                 
                            }
                            catch (Exception e) {
                            e.printStackTrace();
                        }
                        }
                      //     }
                    }

                    List<Driver> drlst = driverRepository.getDriverListByOperatorCode(opr.getOperatorCode());
                    if (drlst != null && drlst.size() > 0) {
                        for (Driver d : drlst) {
                            List<DriverDocument> ddoclst = driverDocumentRepository.getExpiredDriverDocumentByDriverCode(d.getDriverCode(), new Date());
                            if (ddoclst != null && ddoclst.size() > 0) {
                                String notificationBody = "Dear Driver, your document has been expired.";

                                Notification notification = new Notification();
                                String shortMessage = "Document expiry notification.";
                                notification.setUserCode(d.getDriverCode());
                                notification.setMessage(notificationBody);
                                notification.setShortMessage(shortMessage);
                                notification.setIpAddress("via scheduler");
                                notification.setIsRead(Boolean.FALSE);
                                notificationService.saveNotification(notification);
                                                               
                                //for push notification  
                                List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(d.getDriverCode().trim());
                                if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                                {
                                    for(DeviceDetail deviceDetail:deviceDetailResList)
                                    {
                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Document Alert", "Document expiry notification.");
                                    }
                                     
                                }

                               
                                
                        boolean   MailSTDr=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), d.getDriverCode(), mailNotiName);     
                                if(MailSTDr && d.getEmailId()!=null && d.getEmailId().length()>0)
                        {
                            try
                            {
                                String mailBody="Dear Driver,<br><br>Your document has been expired.";
                                SendNotification sn = new SendNotification();
                                        String res = sn.sendMail(d.getEmailId(), shortMessage, mailBody, mailServiceURL);
                                        logger.info("Cron scheduler mail respose in doc exp >>>>>>", res);
                            }
                            catch (Exception e) {
                            e.printStackTrace();
                        }
                        }
//                                if(smsNotiStatus!=null && smsNotiStatus.length()>0 && smsNotiStatus.trim().equalsIgnoreCase("true"))
//                           {
 boolean   SMSStDr=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), d.getDriverCode(), smsNotiName);                             
if(SMSStDr && d.getContactNumber()!=null && d.getContactNumber().length()>0 && d.getCountryCode()!=null && d.getCountryCode().length()>0)
                        {
                            try
                            {
                                 String messageBody="Dear Driver,\n Your document has been expired.";
                                 SendMessageAPI sendmessageapi = new SendMessageAPI();
                                 String mob="+"+d.getCountryCode( )+ d.getContactNumber();         
                                            String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, mob, messageBody);
                                            System.out.println("====messageToken=====" + messageToken);
                                            logger.info("====messageToken=====" + messageToken);
                                 
                            }
                            catch (Exception e) {
                            e.printStackTrace();
                        }
                        }
                           //}

                                notificationBody = "Dear Operator, your driver's document has been expired. ";
                                notificationBody += "Driver Name: " + d.getName();
                                notification = new Notification();
                                shortMessage = "Driver's document expiry notification.";
                                notification.setUserCode(opr.getOperatorCode());
                                notification.setMessage(notificationBody);
                                notification.setShortMessage(shortMessage);
                                notification.setIpAddress("via scheduler");
                                notification.setIsRead(Boolean.FALSE);
                                notificationService.saveNotification(notification);
                                
                                //for push notification  
//                                PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, notificationBody);
                                
                                if(MailST && opr.getEmailId()!=null && opr.getEmailId().length()>0)
                        {
                            try
                            {
                                String mailBody="Dear Operator,<br><br>your driver's document has been expired.<br>Driver Name: "+ d.getName();
                                SendNotification sn = new SendNotification();
                                        String res = sn.sendMail(opr.getEmailId(), shortMessage, mailBody, mailServiceURL);
                                        logger.info("Cron scheduler mail respose in doc exp >>>>>>", res);
                            }
                            catch (Exception e) {
                            e.printStackTrace();
                        }
                        }
//                                if(smsNotiStatus!=null && smsNotiStatus.length()>0 && smsNotiStatus.trim().equalsIgnoreCase("true"))
//                           {
                        if(SMSSt &&  opr.getContactNumber()!=null && opr.getContactNumber().length()>0 && opr.getCountryCode()!=null && opr.getCountryCode().length()>0)
                        {
                            try
                            {
                                 String messageBody="Dear Operator,\n your driver's document has been expired.\n Driver Name: "+ d.getName();
                                 SendMessageAPI sendmessageapi = new SendMessageAPI();
                                 String mob="+"+opr.getCountryCode( )+ opr.getContactNumber();         
                                            String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, mob, messageBody);
                                            System.out.println("====messageToken=====" + messageToken);
                                            logger.info("====messageToken=====" + messageToken);
                                 
                            }
                            catch (Exception e) {
                            e.printStackTrace();
                        }
                        }
                           //}
                           }
                        }
                    }
                }
            }
        }
    }

	@Override
	public String getAllAcceptedUpcomingBooking() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Date curDT = new Date();
			List<Object> objlst = bookingDao.getAllAcceptedUpcomingBooking(curDT,
					GigflexConstants.assignedBookingAcceptedStatus);

			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
                            UserType ut=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOrganization);
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {
						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						int configMinut = 30;
                                                if (ut != null && ut.getUserTypeCode() != null && ut.getUserTypeCode().length() > 0 && data.getOrganizationCode() != null && data.getOrganizationCode().length() > 0) {

                                                String configureminutesValue = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), data.getOrganizationCode(), configureminutesName);
                                                if (configureminutesValue != null && configureminutesValue.length() > 0) {
                                                    try {
                                                        configMinut = Integer.parseInt(configureminutesValue);
                                                    } catch (Exception ex) {
                                                        ex.printStackTrace();;
                                                    }
                                                }
                                                }
						Date curDt = new Date();
						Calendar cal = Calendar.getInstance();
						cal.setTime(curDt);
						cal.add(Calendar.MINUTE, configMinut);
						Date sdt = cal.getTime();
						Date pdt = data.getPickUpTime();
						if (pdt != null && pdt.after(curDt) && (pdt.before(sdt) || pdt.equals(sdt))) {

							BookingResponse brwo = new BookingResponse();
                                                        String conDt="";
                                                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                        String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                        {
                                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                        }                

                                                        String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.Organizations, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                                       TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                       if (tzd != null && tzd.getId() > 0) {

                                                           String timezone = tzd.getTimeZoneName();
                                                           if(timezone!=null && timezone.length()>0 )
                                                           {
                                                                Date pDate = data.getPickUpTime();
                                                                pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                           }

                                                       }         

                                                        brwo.setDateFormat(dateformat);
                                                        brwo.setTimeFormat(timeformat);
                                                        brwo.setBookingid(data.getBookingid());
							brwo.setId(data.getId());
							brwo.setRideCode(data.getRideCode());
                                                        
							brwo.setPassengerName(passengerData.getPassengerName());
                                                        brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                        brwo.setpCountryCode(passengerData.getpCountryCode());
                                                        brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                        brwo.setsCountryCode(passengerData.getsCountryCode());
                                                        brwo.setPassengerCode(passengerData.getPassengerCode());

							brwo.setPickUpTime(conDt);
							brwo.setPickLat(data.getPickLat());
							brwo.setPickLang(data.getPickLang());
							brwo.setPickUpAddress(data.getPickUpAddress());
							brwo.setDropLat(data.getDropLat());
							brwo.setDropLang(data.getDropLang());
							brwo.setDropOffAddress(data.getDropOffAddress());
							brwo.setAdditionalStopPage(data.getAdditionalStopPage());
							brwo.setVehicleCode(data.getVehicleCode());
							brwo.setNoOfPassengers(data.getNoOfPassengers());
							brwo.setNoOfBaggage(data.getNoOfBaggage());
							brwo.setAdditionalComment(data.getAdditionalComment());
							brwo.setCustomerFare(data.getCustomerFare());
                                                        brwo.setCurrencySymbol(currencySymbol);
							brwo.setBookingStatus(data.getBookingStatus());
							brwo.setPaymentOption(data.getPaymentOption());
							brwo.setOrganizationCode(data.getOrganizationCode());
							brwo.setOperatorCode(data.getOperatorCode());
							brwo.setIsPublished(data.getIsPublished());

							brwo.setOrganizationName((String) arr[1]);
							brwo.setVehicleName((String) arr[2]);
							brwo.setOperatorName((String) arr[3]);
                                                        GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
							maplst.add(brwo);
						}

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllAcceptedUpcomingBookingByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
			Date curDT = new Date();
			List<Object> objlstCheck = bookingDao.getAllAcceptedUpcomingBooking(curDT,
					GigflexConstants.assignedBookingAcceptedStatus);
			int count = objlstCheck.size();

			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = bookingDao.getAllAcceptedUpcomingBooking(curDT,
					GigflexConstants.assignedBookingAcceptedStatus, pageableRequest);
			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
			if (objlst != null && objlst.size() > 0) {
                            UserType ut=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOrganization);
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 5) {
						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[4];
						int configMinut = 30;
						if (ut != null && ut.getUserTypeCode() != null && ut.getUserTypeCode().length() > 0 && data.getOrganizationCode() != null && data.getOrganizationCode().length() > 0) {

                                                String configureminutesValue = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), data.getOrganizationCode(), configureminutesName);
                                                if (configureminutesValue != null && configureminutesValue.length() > 0) {
                                                    try {
                                                        configMinut = Integer.parseInt(configureminutesValue);
                                                    } catch (Exception ex) {
                                                        ex.printStackTrace();;
                                                    }
                                                }
                                                }
						Date curDt = new Date();
						Calendar cal = Calendar.getInstance();
						cal.setTime(curDt);
						cal.add(Calendar.MINUTE, configMinut);
						Date sdt = cal.getTime();
						Date pdt = data.getPickUpTime();
						if (pdt != null && pdt.after(curDt) && (pdt.before(sdt) || pdt.equals(sdt))) {
							
                                                        String conDt="";
                                                        String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                         String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.CURRENCYSYMBOL);
                                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                        {
                                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                        }                

                                                        String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, data.getOrganizationCode(), GigflexConstants.TimeZone);

                                                       TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                       if (tzd != null && tzd.getId() > 0) {

                                                           String timezone = tzd.getTimeZoneName();
                                                           if(timezone!=null && timezone.length()>0 )
                                                           {
                                                                Date pDate = data.getPickUpTime();
                                                                pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                           }

                                                       }         


                                                        
							BookingResponse brwo = new BookingResponse();
                                                        brwo.setDateFormat(dateformat);
                                                        brwo.setTimeFormat(timeformat);
                                                        brwo.setBookingid(data.getBookingid());
							brwo.setId(data.getId());
							brwo.setRideCode(data.getRideCode());
                                                        
							brwo.setPassengerName(passengerData.getPassengerName());
                                                        brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                        brwo.setpCountryCode(passengerData.getpCountryCode());
                                                        brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                        brwo.setsCountryCode(passengerData.getsCountryCode());
                                                        brwo.setPassengerCode(passengerData.getPassengerCode());

							brwo.setPickUpTime(conDt);
							brwo.setPickLat(data.getPickLat());
							brwo.setPickLang(data.getPickLang());
							brwo.setPickUpAddress(data.getPickUpAddress());
							brwo.setDropLat(data.getDropLat());
							brwo.setDropLang(data.getDropLang());
							brwo.setDropOffAddress(data.getDropOffAddress());
							brwo.setAdditionalStopPage(data.getAdditionalStopPage());
							brwo.setVehicleCode(data.getVehicleCode());
							brwo.setNoOfPassengers(data.getNoOfPassengers());
							brwo.setNoOfBaggage(data.getNoOfBaggage());
							brwo.setAdditionalComment(data.getAdditionalComment());
							brwo.setCustomerFare(data.getCustomerFare());
                                                        brwo.setCurrencySymbol(currencySymbol);
							brwo.setBookingStatus(data.getBookingStatus());
							brwo.setPaymentOption(data.getPaymentOption());
							brwo.setOrganizationCode(data.getOrganizationCode());
							brwo.setOperatorCode(data.getOperatorCode());
							brwo.setIsPublished(data.getIsPublished());

							brwo.setOrganizationName((String) arr[1]);
							brwo.setVehicleName((String) arr[2]);
							brwo.setOperatorName((String) arr[3]);
                                                        GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
							maplst.add(brwo);
						}

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("count", count);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String sendUpcomingBookingNotificationMail(String rideCode) {
		String res = "";
		String status = "not";
		try {
			JSONObject jsonobj = new JSONObject();
		Booking b = bookingDao.getBookingByRideCode(rideCode);
		if (b != null && b.getId() > 0) {
			
                    String passengerName="";
                    Passenger pgr=  passengerDao.getPassengerByPassengerCode(b.getPassengerCode());
                    if(pgr!=null && pgr.getId()>0)
                    {
                       passengerName=pgr.getPassengerName();
                    }
                    
//			if (pdt != null && (pdt.after(sdt) || pdt.equals(sdt)) && pdt.before(edt)) {
				AssignBooking ab = assignBookingRepository.getAssignBookingByRideCode(b.getRideCode());
				if (ab != null && ab.getId() > 0 && ab.getDriverCode() != null && ab.getDriverCode().length() > 0) {
					Driver d = driverRepository.getDriverByDriverCode(ab.getDriverCode());
					if (d != null && d.getId() > 0 && d.getEmailId() != null && d.getEmailId().length() > 0) {
                                            UserType utOtr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOperator);
                                            UserType utDvr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeDriver);
                                            boolean MailST=true;
						String toid = "";
                                                MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), d.getDriverCode(), mailNotiName);
                                                if(MailST)
                                                {
                                                toid=d.getEmailId();
                                                }

						String abOperatorCode = ab.getOperatorCode();
						String bOperatorCode = b.getOperatorCode();
						String ccMail = "";
						if (abOperatorCode != null && bOperatorCode != null) {
							if (abOperatorCode.equals(bOperatorCode)) {
								Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								if (MailST && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

									ccMail = operator.getEmailId();
								}
							} else {
								Operator aboperator = operatorRepository.getOperatorByOperatorCode(abOperatorCode);
                                                                MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, mailNotiName);
								if (MailST && aboperator.getEmailId() != null && aboperator.getEmailId().length() > 0) {

									ccMail = aboperator.getEmailId();
								}
								Operator boperator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                                MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
								if (MailST && boperator.getEmailId() != null && boperator.getEmailId().length() > 0) {
									if (ccMail != null && ccMail.length() > 0) {
										ccMail += "," + boperator.getEmailId();
									} else {
										ccMail = boperator.getEmailId();

									}
								}
							}
						} else if (bOperatorCode != null) {
							Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
                                                        MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, mailNotiName);
							if (MailST && operator.getEmailId() != null && operator.getEmailId().length() > 0) {

								ccMail = operator.getEmailId();
							}
						}
                                                String conDt="";
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, b.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, b.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                
                                            
                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, b.getOrganizationCode(), GigflexConstants.TimeZone);

                                               TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                               if (tzd != null && tzd.getId() > 0) {

                                                   String timezone = tzd.getTimeZoneName();
                                                   if(timezone!=null && timezone.length()>0 )
                                                   {
                                                        Date pDate = b.getPickUpTime();
                                                        pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                        conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                   }

                                               }         

						String bodyContent = "Dear Driver, <br><br>Your upcoming accepted booking details are given below-<br><br>"
								+ "Driver Name : " + d.getName() + "<br>" +"Passenger Name : "+passengerName+"<br>"+ "Pick-up Time : " + conDt + "<br>"
								+ "Pick-up Address : " + b.getPickUpAddress() + "<br>" + "Drop-off Address : "
								+ b.getDropOffAddress();
						SendNotification sn = new SendNotification();
						if (ccMail != null && ccMail.length() > 0) {
							status = sn.sendMail( ccMail, subject, bodyContent, mailServiceURL);
							logger.info("Cron scheduler mail respose in sendUpcomingBookingNotificationMail >>>>>>", res);
						} 
                                                if (toid != null && toid.length() > 0){
							status = sn.sendMail(toid, subject, bodyContent, mailServiceURL);
							logger.info("Cron scheduler mail respose in sendUpcomingBookingNotificationMail >>>>>>", res);
						}

					}
				}
//			}
				if(status.equalsIgnoreCase("true")) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Ride Notification sent successfully.");
					jsonobj.put("timestamp", new Date());
					
				}else if(status.equalsIgnoreCase("not"))  {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Mail notification is not allowed from setting.");
					jsonobj.put("timestamp", new Date());
				}                                
                                else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Failed");
					jsonobj.put("timestamp", new Date());
				}
		}else {
			jsonobj.put("responsecode", 404);
			jsonobj.put("message", "Record Not Found");
			jsonobj.put("timestamp", new Date());
		}
		res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

        
        
        @Override
	public String sendUpcomingBookingNotificationSMS(String rideCode) {
		String res = "";
		String status = "not";
		try {
			JSONObject jsonobj = new JSONObject();
		Booking b = bookingDao.getBookingByRideCode(rideCode);
		if (b != null && b.getId() > 0) {
		
                    String passengerName="";
                    Passenger pgr=  passengerDao.getPassengerByPassengerCode(b.getPassengerCode());
                    if(pgr!=null && pgr.getId()>0)
                     {
                       passengerName=pgr.getPassengerName();
                     }
//			if (pdt != null && (pdt.after(sdt) || pdt.equals(sdt)) && pdt.before(edt)) {
				AssignBooking ab = assignBookingRepository.getAssignBookingByRideCode(b.getRideCode());
				if (ab != null && ab.getId() > 0 && ab.getDriverCode() != null && ab.getDriverCode().length() > 0) {
					Driver d = driverRepository.getDriverByDriverCode(ab.getDriverCode());
					if (d != null && d.getId() > 0 && d.getEmailId() != null && d.getEmailId().length() > 0) {
						
                                            UserType utOtr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOperator);
                                            UserType utDvr=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeDriver);
						String abOperatorCode = ab.getOperatorCode();
						String bOperatorCode = b.getOperatorCode();
						boolean SMSSt=true;
                                                String contactNumber="";
							   
							    if(abOperatorCode != null && bOperatorCode != null ) {
							    	if(abOperatorCode.equals(bOperatorCode)) {
								    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
								    	SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                            contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								    	}
								    	
								    }else {
								    	Operator aboperator = operatorRepository.getOperatorByOperatorCode(abOperatorCode);
								    	SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), abOperatorCode, smsNotiName);
                                                                        if(SMSSt && aboperator!=null && aboperator.getContactNumber() != null && aboperator.getContactNumber().length() > 0 && aboperator.getCountryCode() != null && aboperator.getCountryCode().length() > 0) {

                                                                        contactNumber="+"+aboperator.getCountryCode()+aboperator.getContactNumber();
								    	}
								    	Operator boperator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
								    	SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                        if(SMSSt && boperator!=null && boperator.getContactNumber() != null && boperator.getContactNumber().length() > 0 && boperator.getCountryCode() != null && boperator.getCountryCode().length() > 0) {
								    		if(contactNumber != null && contactNumber.length() > 0) {
								    	
                                                                        contactNumber +=",+"+boperator.getCountryCode()+ boperator.getContactNumber();
								    	}else {
                                                                                contactNumber="+"+boperator.getCountryCode()+ boperator.getContactNumber();

								    	}
								    	}
								    	
								    }
							    	
							    }else if(bOperatorCode != null){
							    	Operator operator = operatorRepository.getOperatorByOperatorCode(bOperatorCode);
							    	SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utOtr.getUserTypeCode(), bOperatorCode, smsNotiName);
                                                                if(SMSSt && operator!=null && operator.getContactNumber()!= null && operator.getContactNumber().length() > 0 && operator.getCountryCode()!= null && operator.getCountryCode().length() > 0) {
                                                                   contactNumber="+"+operator.getCountryCode()+ operator.getContactNumber();
								}
							    	
							    }
                                                    
                                                String conDt="";
                                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, b.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, b.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                {
                                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                }                
                                            
                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, b.getOrganizationCode(), GigflexConstants.TimeZone);

                                               TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                               if (tzd != null && tzd.getId() > 0) {

                                                   String timezone = tzd.getTimeZoneName();
                                                   if(timezone!=null && timezone.length()>0 )
                                                   {
                                                        Date pDate = b.getPickUpTime();
                                                        pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                        conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                   }

                                               }         

						
                                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, utDvr.getUserTypeCode(), d.getDriverCode(), smsNotiName);
                                                if (SMSSt && d.getContactNumber() != null && d.getContactNumber().trim().length() > 0 && d.getCountryCode()!= null && d.getCountryCode().trim().length() > 0) {
                                                                try {
                                                                    String mob="+" +d.getCountryCode()+d.getContactNumber();
                                                                    SendMessageAPI sendmessageapi = new SendMessageAPI();
                                                                    String bodyContentDriver = "Dear Driver, Your upcoming accepted booking details are given below-\n"
								+ "Driver Name : " + d.getName() + "\n" +"Passenger Name : "+passengerName+"\n"+ "Pick-up Time : " + conDt + "\n"
								+ "Pick-up Address : " + b.getPickUpAddress() + "\n" + "Drop-off Address : "
								+ b.getDropOffAddress();
						
                                                                    String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, mob, bodyContentDriver);
                                                                    System.out.println("====messageToken for driver=====" + messageToken);
                                                                    if(messageToken!=null && messageToken.length()>0)
                                                                    {
                                                                        status="true";
                                                                    }
                                                                    else
                                                                    {
                                                                        status="false";
                                                                    }
                                                                } catch (Exception e) {
                                                                    e.printStackTrace();
                                                                }
                                                            }
                                                
						if (contactNumber != null && contactNumber.length() > 0) {
                                                                String mobarr[]=contactNumber.split(",");
                                                                for(String mob:mobarr)
                                                                {
                                                                try {
                                                                    SendMessageAPI sendmessageapi = new SendMessageAPI();
                                                                    String bodyContentOperator = "Dear Operator, Your upcoming accepted booking details are given below-\n"
								+ "Driver Name : " + d.getName() + "\n" +"Passenger Name : "+passengerName+"\n"+ "Pick-up Time : " + conDt + "\n"
								+ "Pick-up Address : " + b.getPickUpAddress() + "\n" + "Drop-off Address : "
								+ b.getDropOffAddress();
                                                                    String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, mob, bodyContentOperator);
                                                                    System.out.println("====messageToken for driver=====" + messageToken);
                                                                    if(messageToken!=null && messageToken.length()>0)
                                                                    {
                                                                        status="true";
                                                                    }
                                                                    else
                                                                    {
                                                                        status="false";
                                                                    }
                                                                } catch (Exception e) {
                                                                    e.printStackTrace();
                                                                }
                                                                }
                                                            }
                                                

					}
				}
//			}
				if(status.equalsIgnoreCase("true")) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Ride SMS Notification sent successfully.");
					jsonobj.put("timestamp", new Date());
					
				}
                                else if(status.equalsIgnoreCase("not"))  {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "SMS notification is not allowed from setting.");
					jsonobj.put("timestamp", new Date());
				} 
                                else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Failed");
					jsonobj.put("timestamp", new Date());
				}
		}else {
			jsonobj.put("responsecode", 404);
			jsonobj.put("message", "Record Not Found");
			jsonobj.put("timestamp", new Date());
		}
		res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}
        
        
        
	@Override
	public String getAllAcceptedUpcomingBookingByOperatorCode(String operatorCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Date curDT = new Date();
			List<Object> objlst = bookingDao.getAllAcceptedUpcomingBookingByOperatorCode(curDT, GigflexConstants.assignedBookingAcceptedStatus, operatorCode);

			List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                            Operator operator = operatorRepository.getOperatorByOperatorCode(operatorCode);
                            String organizationCode = operator.getOrganizationCode(); 
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TIMEFORMAT);
                             String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);

                           TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                            UserType ut=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOrganization);
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 6) {
						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[5];
						int configMinut = 30;
						if (ut != null && ut.getUserTypeCode() != null && ut.getUserTypeCode().length() > 0 && data.getOrganizationCode() != null && data.getOrganizationCode().length() > 0) {

                                                String configureminutesValue = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), data.getOrganizationCode(), configureminutesName);
                                                if (configureminutesValue != null && configureminutesValue.length() > 0) {
                                                    try {
                                                        configMinut = Integer.parseInt(configureminutesValue);
                                                    } catch (Exception ex) {
                                                        ex.printStackTrace();;
                                                    }
                                                }
                                                }
						Date curDt = new Date();
						Calendar cal = Calendar.getInstance();
						cal.setTime(curDt);
						cal.add(Calendar.MINUTE, configMinut);
						Date sdt = cal.getTime();
						Date pdt = data.getPickUpTime();
						if (pdt != null && pdt.after(curDt) && (pdt.before(sdt) || pdt.equals(sdt))) {

							BookingAllResponse brwo = new BookingAllResponse();
						    String conDt="";
                                                   
                                                   if (tzd != null && tzd.getId() > 0) {

                                                       String timezone = tzd.getTimeZoneName();
                                                       if(timezone!=null && timezone.length()>0 )
                                                       {
                                                            Date pDate = data.getPickUpTime();
                                                            pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                            conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                       }

                                                   }         

                                            
                                                        brwo.setDateFormat(dateformat);
                                                        brwo.setTimeFormat(timeformat); 
                                                        brwo.setBookingid(data.getBookingid());
							brwo.setId(data.getId());
							brwo.setRideCode(data.getRideCode());
                                                        
							brwo.setPassengerName(passengerData.getPassengerName());
                                                        brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                        brwo.setpCountryCode(passengerData.getpCountryCode());
                                                        brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                        brwo.setsCountryCode(passengerData.getsCountryCode());
                                                        brwo.setPassengerCode(passengerData.getPassengerCode());

							brwo.setPickUpTime(conDt);
							brwo.setPickLat(data.getPickLat());
							brwo.setPickLang(data.getPickLang());
							brwo.setPickUpAddress(data.getPickUpAddress());
							brwo.setDropLat(data.getDropLat());
							brwo.setDropLang(data.getDropLang());
							brwo.setDropOffAddress(data.getDropOffAddress());
							brwo.setAdditionalStopPage(data.getAdditionalStopPage());
							brwo.setVehicleCode(data.getVehicleCode());
							brwo.setNoOfPassengers(data.getNoOfPassengers());
							brwo.setNoOfBaggage(data.getNoOfBaggage());
							brwo.setAdditionalComment(data.getAdditionalComment());
							brwo.setCustomerFare(data.getCustomerFare());
                                                        brwo.setCurrencySymbol(currencySymbol);
							brwo.setBookingStatus(data.getBookingStatus());
							brwo.setPaymentOption(data.getPaymentOption());
							brwo.setOrganizationCode(data.getOrganizationCode());
							brwo.setOperatorCode(data.getOperatorCode());
							brwo.setIsPublished(data.getIsPublished());
                                                        brwo.setCancelationComment(data.getCancelationComment());
							brwo.setOrganizationName((String) arr[1]);
							brwo.setVehicleName((String) arr[2]);
							brwo.setOperatorName((String) arr[3]);
                                                        AssignBooking ab=(AssignBooking) arr[4];
                                                if(ab!=null && ab.getId()>0)
                                                {
                                                    if(ab.getOperatorCode()!=null && ab.getOperatorCode().length()>0)
                                                    {
                                                        brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                                       Operator op=operatorRepository.getOperatorByOperatorCode(ab.getOperatorCode());
                                                       if(op!=null && op.getId()>0 && op.getOperatorName()!=null)
                                                       {
                                                          brwo.setAssignorOperatorName(op.getOperatorName());
                                                       }
                                                    }
                                                    
                                                    if(ab.getDriverCode()!=null && ab.getDriverCode().length()>0)
                                                    {
                                                        brwo.setDriverCode(ab.getDriverCode());
                                                       Driver dr=driverRepository.getDriverByDriverCode(ab.getDriverCode());
                                                       if(dr!=null && dr.getId()>0 && dr.getName()!=null)
                                                       {
                                                          brwo.setDriverName(dr.getName());
                                                            brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                                       }
                                                    }
                                                }
                                         GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
							maplst.add(brwo);
						}

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllAcceptedUpcomingBookingByOperatorCodeByPage(String operatorCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
				Pageable pageableRequest = PageRequest.of(page, limit);

				Date curDT = new Date();

				List<Object> objlstCheck = bookingDao.getAllAcceptedUpcomingBookingByOperatorCode(curDT, GigflexConstants.assignedBookingAcceptedStatus, operatorCode);
				int count = objlstCheck.size();
				
			List<Object> objlst = bookingDao.getAllAcceptedUpcomingBookingByOperatorCode(curDT, GigflexConstants.assignedBookingAcceptedStatus, operatorCode, pageableRequest);
			List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                            Operator operator = operatorRepository.getOperatorByOperatorCode(operatorCode);
                            String organizationCode = operator.getOrganizationCode(); 
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TIMEFORMAT);
                            String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);

                           TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                            UserType ut=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOrganization);
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 6) {
						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[5];
						int configMinut = 30;
						if (ut != null && ut.getUserTypeCode() != null && ut.getUserTypeCode().length() > 0 && data.getOrganizationCode() != null && data.getOrganizationCode().length() > 0) {

                                                String configureminutesValue = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), data.getOrganizationCode(), configureminutesName);
                                                if (configureminutesValue != null && configureminutesValue.length() > 0) {
                                                    try {
                                                        configMinut = Integer.parseInt(configureminutesValue);
                                                    } catch (Exception ex) {
                                                        ex.printStackTrace();;
                                                    }
                                                }
                                                }
						Date curDt = new Date();
						Calendar cal = Calendar.getInstance();
						cal.setTime(curDt);
						cal.add(Calendar.MINUTE, configMinut);
						Date sdt = cal.getTime();
						Date pdt = data.getPickUpTime();
						if (pdt != null && pdt.after(curDt) && (pdt.before(sdt) || pdt.equals(sdt))) {

							BookingAllResponse brwo = new BookingAllResponse();
                                                        String conDt="";
                                                        
                                                       if (tzd != null && tzd.getId() > 0) {

                                                           String timezone = tzd.getTimeZoneName();
                                                           if(timezone!=null && timezone.length()>0 )
                                                           {
                                                                Date pDate = data.getPickUpTime();
                                                                pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                           }

                                                       }         


                                                        brwo.setDateFormat(dateformat);
                                                        brwo.setTimeFormat(timeformat); 
                                                        brwo.setBookingid(data.getBookingid());
							brwo.setId(data.getId());
							brwo.setRideCode(data.getRideCode());
                                                        
							brwo.setPassengerName(passengerData.getPassengerName());
                                                        brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                        brwo.setpCountryCode(passengerData.getpCountryCode());
                                                        brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                        brwo.setsCountryCode(passengerData.getsCountryCode());
                                                        brwo.setPassengerCode(passengerData.getPassengerCode());

							brwo.setPickUpTime(conDt);
							brwo.setPickLat(data.getPickLat());
							brwo.setPickLang(data.getPickLang());
							brwo.setPickUpAddress(data.getPickUpAddress());
							brwo.setDropLat(data.getDropLat());
							brwo.setDropLang(data.getDropLang());
							brwo.setDropOffAddress(data.getDropOffAddress());
							brwo.setAdditionalStopPage(data.getAdditionalStopPage());
							brwo.setVehicleCode(data.getVehicleCode());
							brwo.setNoOfPassengers(data.getNoOfPassengers());
							brwo.setNoOfBaggage(data.getNoOfBaggage());
							brwo.setAdditionalComment(data.getAdditionalComment());
							brwo.setCustomerFare(data.getCustomerFare());
                                                        brwo.setCurrencySymbol(currencySymbol);
							brwo.setBookingStatus(data.getBookingStatus());
							brwo.setPaymentOption(data.getPaymentOption());
							brwo.setOrganizationCode(data.getOrganizationCode());
							brwo.setOperatorCode(data.getOperatorCode());
							brwo.setIsPublished(data.getIsPublished());
                                                        brwo.setCancelationComment(data.getCancelationComment());
							brwo.setOrganizationName((String) arr[1]);
							brwo.setVehicleName((String) arr[2]);
							brwo.setOperatorName((String) arr[3]);
                                                        AssignBooking ab=(AssignBooking) arr[4];
                                                if(ab!=null && ab.getId()>0)
                                                {
                                                    if(ab.getOperatorCode()!=null && ab.getOperatorCode().length()>0)
                                                    {
                                                        brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                                       Operator op=operatorRepository.getOperatorByOperatorCode(ab.getOperatorCode());
                                                       if(op!=null && op.getId()>0 && op.getOperatorName()!=null)
                                                       {
                                                          brwo.setAssignorOperatorName(op.getOperatorName());
                                                       }
                                                    }
                                                    
                                                    if(ab.getDriverCode()!=null && ab.getDriverCode().length()>0)
                                                    {
                                                        brwo.setDriverCode(ab.getDriverCode());
                                                       Driver dr=driverRepository.getDriverByDriverCode(ab.getDriverCode());
                                                       if(dr!=null && dr.getId()>0 && dr.getName()!=null)
                                                       {
                                                          brwo.setDriverName(dr.getName());
                                                            brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                                       }
                                                    }
                                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
							maplst.add(brwo);
						}

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("count", count);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllAcceptedUpcomingBookingByOperatorCodeByDate(String operatorCode, Date fromDT, Date toDT) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Date curDT = new Date();
			List<Object> objlst = bookingDao.getAllAcceptedUpcomingBookingByOperatorCodeByDate(curDT, GigflexConstants.assignedBookingAcceptedStatus, operatorCode, fromDT, toDT);
					
			List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                            Operator operator = operatorRepository.getOperatorByOperatorCode(operatorCode);
                            String organizationCode = operator.getOrganizationCode(); 
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TIMEFORMAT);
                             String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);

                           TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                            UserType ut=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOrganization);
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 6) {
						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[5];
						int configMinut = 30;
						if (ut != null && ut.getUserTypeCode() != null && ut.getUserTypeCode().length() > 0 && data.getOrganizationCode() != null && data.getOrganizationCode().length() > 0) {

                                                String configureminutesValue = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), data.getOrganizationCode(), configureminutesName);
                                                if (configureminutesValue != null && configureminutesValue.length() > 0) {
                                                    try {
                                                        configMinut = Integer.parseInt(configureminutesValue);
                                                    } catch (Exception ex) {
                                                        ex.printStackTrace();;
                                                    }
                                                }
                                                }
						Date curDt = new Date();
						Calendar cal = Calendar.getInstance();
						cal.setTime(curDt);
						cal.add(Calendar.MINUTE, configMinut);
						Date sdt = cal.getTime();
						Date pdt = data.getPickUpTime();
						if (pdt != null && pdt.after(curDt) && (pdt.before(sdt) || pdt.equals(sdt))) {

							BookingAllResponse brwo = new BookingAllResponse();
						        String conDt="";
                                                        
                                                       if (tzd != null && tzd.getId() > 0) {

                                                           String timezone = tzd.getTimeZoneName();
                                                           if(timezone!=null && timezone.length()>0 )
                                                           {
                                                                Date pDate = data.getPickUpTime();
                                                                pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                           }

                                                       }         


                                                        brwo.setDateFormat(dateformat);
                                                        brwo.setTimeFormat(timeformat);
                                                        brwo.setBookingid(data.getBookingid());
							brwo.setId(data.getId());
							brwo.setRideCode(data.getRideCode());
                                                        
							brwo.setPassengerName(passengerData.getPassengerName());
                                                        brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                        brwo.setpCountryCode(passengerData.getpCountryCode());
                                                        brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                        brwo.setsCountryCode(passengerData.getsCountryCode());
                                                        brwo.setPassengerCode(passengerData.getPassengerCode());

							brwo.setPickUpTime(conDt);
							brwo.setPickLat(data.getPickLat());
							brwo.setPickLang(data.getPickLang());
							brwo.setPickUpAddress(data.getPickUpAddress());
							brwo.setDropLat(data.getDropLat());
							brwo.setDropLang(data.getDropLang());
							brwo.setDropOffAddress(data.getDropOffAddress());
							brwo.setAdditionalStopPage(data.getAdditionalStopPage());
							brwo.setVehicleCode(data.getVehicleCode());
							brwo.setNoOfPassengers(data.getNoOfPassengers());
							brwo.setNoOfBaggage(data.getNoOfBaggage());
							brwo.setAdditionalComment(data.getAdditionalComment());
							brwo.setCustomerFare(data.getCustomerFare());
                                                        brwo.setCurrencySymbol(currencySymbol);
							brwo.setBookingStatus(data.getBookingStatus());
							brwo.setPaymentOption(data.getPaymentOption());
							brwo.setOrganizationCode(data.getOrganizationCode());
							brwo.setOperatorCode(data.getOperatorCode());
							brwo.setIsPublished(data.getIsPublished());
                                                        brwo.setCancelationComment(data.getCancelationComment());
							brwo.setOrganizationName((String) arr[1]);
							brwo.setVehicleName((String) arr[2]);
							brwo.setOperatorName((String) arr[3]);
                                                        AssignBooking ab=(AssignBooking) arr[4];
                                                if(ab!=null && ab.getId()>0)
                                                {
                                                    if(ab.getOperatorCode()!=null && ab.getOperatorCode().length()>0)
                                                    {
                                                        brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                                       Operator op=operatorRepository.getOperatorByOperatorCode(ab.getOperatorCode());
                                                       if(op!=null && op.getId()>0 && op.getOperatorName()!=null)
                                                       {
                                                          brwo.setAssignorOperatorName(op.getOperatorName());
                                                       }
                                                    }
                                                    
                                                    if(ab.getDriverCode()!=null && ab.getDriverCode().length()>0)
                                                    {
                                                        brwo.setDriverCode(ab.getDriverCode());
                                                       Driver dr=driverRepository.getDriverByDriverCode(ab.getDriverCode());
                                                       if(dr!=null && dr.getId()>0 && dr.getName()!=null)
                                                       {
                                                          brwo.setDriverName(dr.getName());
                                                            brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                                       }
                                                    }
                                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
							maplst.add(brwo);
						}

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllAcceptedUpcomingBookingByOperatorCodeByDateByPage(String operatorCode, Date fromDT, Date toDT,
			int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
			Date curDT = new Date();
			List<Object> objlstCheck = bookingDao.getAllAcceptedUpcomingBookingByOperatorCodeByDate(curDT, GigflexConstants.assignedBookingAcceptedStatus, operatorCode, fromDT, toDT);
			int count = objlstCheck.size();	

			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = bookingDao.getAllAcceptedUpcomingBookingByOperatorCodeByDate(curDT, GigflexConstants.assignedBookingAcceptedStatus, operatorCode, fromDT, toDT, pageableRequest);
			List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
			if (objlst != null && objlst.size() > 0) {
                            Operator operator = operatorRepository.getOperatorByOperatorCode(operatorCode);
                            String organizationCode = operator.getOrganizationCode();
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TIMEFORMAT);
                            String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);

                           TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                            UserType ut=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOrganization);
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 6) {
						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[5];
						int configMinut = 30;
						if (ut != null && ut.getUserTypeCode() != null && ut.getUserTypeCode().length() > 0 && data.getOrganizationCode() != null && data.getOrganizationCode().length() > 0) {

                                                String configureminutesValue = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), data.getOrganizationCode(), configureminutesName);
                                                if (configureminutesValue != null && configureminutesValue.length() > 0) {
                                                    try {
                                                        configMinut = Integer.parseInt(configureminutesValue);
                                                    } catch (Exception ex) {
                                                        ex.printStackTrace();;
                                                    }
                                                }
                                                }
						Date curDt = new Date();
						Calendar cal = Calendar.getInstance();
						cal.setTime(curDt);
						cal.add(Calendar.MINUTE, configMinut);
						Date sdt = cal.getTime();
						Date pdt = data.getPickUpTime();
						if (pdt != null && pdt.after(curDt) && (pdt.before(sdt) || pdt.equals(sdt))) {

							BookingAllResponse brwo = new BookingAllResponse();
                                                        String conDt="";
                                                       
                                                       if (tzd != null && tzd.getId() > 0) {

                                                           String timezone = tzd.getTimeZoneName();
                                                           if(timezone!=null && timezone.length()>0 )
                                                           {
                                                                Date pDate = data.getPickUpTime();
                                                                pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                           }

                                                       }         


                                                        brwo.setDateFormat(dateformat);                                                        
                                                        brwo.setTimeFormat(timeformat);
                                                        brwo.setBookingid(data.getBookingid());
							brwo.setId(data.getId());
							brwo.setRideCode(data.getRideCode());
                                                        
							brwo.setPassengerName(passengerData.getPassengerName());
                                                        brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                        brwo.setpCountryCode(passengerData.getpCountryCode());
                                                        brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                        brwo.setsCountryCode(passengerData.getsCountryCode());
                                                        brwo.setPassengerCode(passengerData.getPassengerCode());

							brwo.setPickUpTime(conDt);
							brwo.setPickLat(data.getPickLat());
							brwo.setPickLang(data.getPickLang());
							brwo.setPickUpAddress(data.getPickUpAddress());
							brwo.setDropLat(data.getDropLat());
							brwo.setDropLang(data.getDropLang());
							brwo.setDropOffAddress(data.getDropOffAddress());
							brwo.setAdditionalStopPage(data.getAdditionalStopPage());
							brwo.setVehicleCode(data.getVehicleCode());
							brwo.setNoOfPassengers(data.getNoOfPassengers());
							brwo.setNoOfBaggage(data.getNoOfBaggage());
							brwo.setAdditionalComment(data.getAdditionalComment());
							brwo.setCustomerFare(data.getCustomerFare());
                                                        brwo.setCurrencySymbol(currencySymbol);
							brwo.setBookingStatus(data.getBookingStatus());
							brwo.setPaymentOption(data.getPaymentOption());
							brwo.setOrganizationCode(data.getOrganizationCode());
							brwo.setOperatorCode(data.getOperatorCode());
							brwo.setIsPublished(data.getIsPublished());
                                                        brwo.setCancelationComment(data.getCancelationComment());
							brwo.setOrganizationName((String) arr[1]);
							brwo.setVehicleName((String) arr[2]);
							brwo.setOperatorName((String) arr[3]);
                                                        AssignBooking ab=(AssignBooking) arr[4];
                                                if(ab!=null && ab.getId()>0)
                                                {
                                                    if(ab.getOperatorCode()!=null && ab.getOperatorCode().length()>0)
                                                    {
                                                        brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                                       Operator op=operatorRepository.getOperatorByOperatorCode(ab.getOperatorCode());
                                                       if(op!=null && op.getId()>0 && op.getOperatorName()!=null)
                                                       {
                                                          brwo.setAssignorOperatorName(op.getOperatorName());
                                                       }
                                                    }
                                                    
                                                    if(ab.getDriverCode()!=null && ab.getDriverCode().length()>0)
                                                    {
                                                        brwo.setDriverCode(ab.getDriverCode());
                                                       Driver dr=driverRepository.getDriverByDriverCode(ab.getDriverCode());
                                                       if(dr!=null && dr.getId()>0 && dr.getName()!=null)
                                                       {
                                                          brwo.setDriverName(dr.getName());
                                                            brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                                       }
                                                    }
                                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
							maplst.add(brwo);
						}

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("count", count);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

//	@Override
//	public String getAllAcceptedUpcomingBookingByDriverCode(String driverCode) {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//			Date curDT = new Date();
//			List<Object> objlst = bookingDao.getAllAcceptedUpcomingBookingByDriverCode(curDT, GigflexConstants.assignedBookingAcceptedStatus, driverCode);
//
//			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
//			if (objlst != null && objlst.size() > 0) {
//				for (int i = 0; i < objlst.size(); i++) {
//					Object[] arr = (Object[]) objlst.get(i);
//					if (arr.length >= 4) {
//						Booking data = (Booking) arr[0];
//						int configMinut = 30;
//						if (data.getOrganizationCode() != null && data.getOrganizationCode().length() > 0) {
//							Organization org = organizationDao.findByOrganizationCode(data.getOrganizationCode());
//							if (org != null && org.getId() > 0 && org.getConfigureMinutes() != null
//									&& org.getConfigureMinutes() > 0) {
//								configMinut = org.getConfigureMinutes();
//							}
//						}
//						Date curDt = new Date();
//						Calendar cal = Calendar.getInstance();
//						cal.setTime(curDt);
//						cal.add(Calendar.MINUTE, configMinut);
//						Date sdt = cal.getTime();
//						Date pdt = data.getPickUpTime();
//						if (pdt != null && pdt.after(curDt) && (pdt.before(sdt) || pdt.equals(sdt))) {
//
//							BookingResponse brwo = new BookingResponse();
//						    String conDt="";
//                            Organization org = organizationDao.findByOrganizationCode(data.getOrganizationCode());
//                            if (org != null && org.getId() > 0) {
//                                String timezoneCode = org.getTimezone();
//                                TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
//                                Date pDate = data.getPickUpTime();
//                                pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, tz.getTimeZoneName(), GigflexConstants.dateFormatterForView);
//                                conDt=GigflexDateUtil.converDateToString(pDate);
//                            }
//
//
//							brwo.setId(data.getId());
//							brwo.setRideCode(data.getRideCode());
//							brwo.setPassengerName(data.getPassengerName());
//							brwo.setPrimaryContactNumber(data.getPrimaryContactNumber());
//							brwo.setSecondaryContactNumber(data.getSecondaryContactNumber());
//							brwo.setPickUpTime(conDt);
//							brwo.setPickLat(data.getPickLat());
//							brwo.setPickLang(data.getPickLang());
//							brwo.setPickUpAddress(data.getPickUpAddress());
//							brwo.setDropLat(data.getDropLat());
//							brwo.setDropLang(data.getDropLang());
//							brwo.setDropOffAddress(data.getDropOffAddress());
//							brwo.setAdditionalStopPage(data.getAdditionalStopPage());
//							brwo.setVehicleCode(data.getVehicleCode());
//							brwo.setNoOfPassengers(data.getNoOfPassengers());
//							brwo.setNoOfBaggage(data.getNoOfBaggage());
//							brwo.setAdditionalComment(data.getAdditionalComment());
//							brwo.setCustomerFare(data.getCustomerFare());
//							brwo.setBookingStatus(data.getBookingStatus());
//							brwo.setPaymentOption(data.getPaymentOption());
//							brwo.setOrganizationCode(data.getOrganizationCode());
//							brwo.setOperatorCode(data.getOperatorCode());
//							brwo.setIsPublished(data.getIsPublished());
//
//							brwo.setOrganizationName((String) arr[1]);
//							brwo.setVehicleName((String) arr[2]);
//							brwo.setOperatorName((String) arr[3]);
//							maplst.add(brwo);
//						}
//
//					}
//				}
//				if (maplst.size() > 0) {
//					ObjectMapper mapperObj = new ObjectMapper();
//					String Detail = mapperObj.writeValueAsString(maplst);
//					jsonobj.put("responsecode", 200);
//					jsonobj.put("message", "Success");
//					jsonobj.put("timestamp", new Date());
//					jsonobj.put("data", new JSONArray(Detail));
//				} else {
//					jsonobj.put("responsecode", 404);
//					jsonobj.put("message", "Record Not Found");
//					jsonobj.put("timestamp", new Date());
//				}
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("message", "Record Not Found");
//				jsonobj.put("timestamp", new Date());
//			}
//
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		} catch (Exception ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		}
//		return res;
//	}

//	@Override
//	public String getAllAcceptedUpcomingBookingByDriverCodeByPage(String driverCode, int page, int limit) {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//			Pageable pageableRequest = PageRequest.of(page, limit);
//
//			Date curDT = new Date();
//			List<Object> objlst = bookingDao.getAllAcceptedUpcomingBookingByDriverCode(curDT, GigflexConstants.assignedBookingAcceptedStatus, driverCode, pageableRequest);
//
//			List<BookingResponse> maplst = new ArrayList<BookingResponse>();
//			if (objlst != null && objlst.size() > 0) {
//				for (int i = 0; i < objlst.size(); i++) {
//					Object[] arr = (Object[]) objlst.get(i);
//					if (arr.length >= 4) {
//						Booking data = (Booking) arr[0];
//						int configMinut = 30;
//						if (data.getOrganizationCode() != null && data.getOrganizationCode().length() > 0) {
//							Organization org = organizationDao.findByOrganizationCode(data.getOrganizationCode());
//							if (org != null && org.getId() > 0 && org.getConfigureMinutes() != null
//									&& org.getConfigureMinutes() > 0) {
//								configMinut = org.getConfigureMinutes();
//							}
//						}
//						Date curDt = new Date();
//						Calendar cal = Calendar.getInstance();
//						cal.setTime(curDt);
//						cal.add(Calendar.MINUTE, configMinut);
//						Date sdt = cal.getTime();
//						Date pdt = data.getPickUpTime();
//						if (pdt != null && pdt.after(curDt) && (pdt.before(sdt) || pdt.equals(sdt))) {
//
//							BookingResponse brwo = new BookingResponse();
//						    String conDt="";
//                            Organization org = organizationDao.findByOrganizationCode(data.getOrganizationCode());
//                            if (org != null && org.getId() > 0) {
//                                String timezoneCode = org.getTimezone();
//                                TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
//                                Date pDate = data.getPickUpTime();
//                                pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, tz.getTimeZoneName(), GigflexConstants.dateFormatterForView);
//                                conDt=GigflexDateUtil.converDateToString(pDate);
//                            }
//
//
//							brwo.setId(data.getId());
//							brwo.setRideCode(data.getRideCode());
//							brwo.setPassengerName(data.getPassengerName());
//							brwo.setPrimaryContactNumber(data.getPrimaryContactNumber());
//							brwo.setSecondaryContactNumber(data.getSecondaryContactNumber());
//							brwo.setPickUpTime(conDt);
//							brwo.setPickLat(data.getPickLat());
//							brwo.setPickLang(data.getPickLang());
//							brwo.setPickUpAddress(data.getPickUpAddress());
//							brwo.setDropLat(data.getDropLat());
//							brwo.setDropLang(data.getDropLang());
//							brwo.setDropOffAddress(data.getDropOffAddress());
//							brwo.setAdditionalStopPage(data.getAdditionalStopPage());
//							brwo.setVehicleCode(data.getVehicleCode());
//							brwo.setNoOfPassengers(data.getNoOfPassengers());
//							brwo.setNoOfBaggage(data.getNoOfBaggage());
//							brwo.setAdditionalComment(data.getAdditionalComment());
//							brwo.setCustomerFare(data.getCustomerFare());
//							brwo.setBookingStatus(data.getBookingStatus());
//							brwo.setPaymentOption(data.getPaymentOption());
//							brwo.setOrganizationCode(data.getOrganizationCode());
//							brwo.setOperatorCode(data.getOperatorCode());
//							brwo.setIsPublished(data.getIsPublished());
//
//							brwo.setOrganizationName((String) arr[1]);
//							brwo.setVehicleName((String) arr[2]);
//							brwo.setOperatorName((String) arr[3]);
//							maplst.add(brwo);
//						}
//
//					}
//				}
//				if (maplst.size() > 0) {
//					ObjectMapper mapperObj = new ObjectMapper();
//					String Detail = mapperObj.writeValueAsString(maplst);
//					jsonobj.put("responsecode", 200);
//					jsonobj.put("message", "Success");
//					jsonobj.put("timestamp", new Date());
//					jsonobj.put("data", new JSONArray(Detail));
//				} else {
//					jsonobj.put("responsecode", 404);
//					jsonobj.put("message", "Record Not Found");
//					jsonobj.put("timestamp", new Date());
//				}
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("message", "Record Not Found");
//				jsonobj.put("timestamp", new Date());
//			}
//
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		} catch (Exception ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		}
//		return res;
//	}

    @Override
    public String sendMessageForUsers(String appKey, String appSecret,String url,String phoneNumber,String message) {
        
         String messageToken=null;
      try{
         SendMessageAPI sendmessageapi=new SendMessageAPI();
         messageToken= sendmessageapi.sendMessageForUsers(appKey, appSecret, url, phoneNumber, message);
      }
      catch(Exception e){
          e.printStackTrace();
      }

       return messageToken;
    }

    @Override
    public String getAllAcceptedUpcomingBookingByOrganizationCodeByPage(String organizationCode, int page, int limit) {
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
				Pageable pageableRequest = PageRequest.of(page, limit);

				Date curDT = new Date();

				List<Object> objlstCheck = bookingDao.getAllAcceptedUpcomingBookingByOrganizationCode(curDT, GigflexConstants.assignedBookingAcceptedStatus, organizationCode);
				int count = objlstCheck.size();
				
			List<Object> objlst = bookingDao.getAllAcceptedUpcomingBookingByOrganizationCode(curDT, GigflexConstants.assignedBookingAcceptedStatus, organizationCode, pageableRequest);
			List<BookingAllResponse> maplst = new ArrayList<BookingAllResponse>();
			if (objlst != null && objlst.size() > 0) {
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;//currencySymbol
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TIMEFORMAT);
                             String currencySymbol =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.CURRENCYSYMBOL);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.userTypeOrganization, organizationCode, GigflexConstants.TimeZone);

                           TimeZoneDetail tzd = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                            UserType ut=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.userTypeOrganization);
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 6) {
						Booking data = (Booking) arr[0];
                                                Passenger passengerData = (Passenger) arr[5];
						int configMinut = 30;
						if (ut != null && ut.getUserTypeCode() != null && ut.getUserTypeCode().length() > 0 && data.getOrganizationCode() != null && data.getOrganizationCode().length() > 0) {

                                                String configureminutesValue = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), data.getOrganizationCode(), configureminutesName);
                                                if (configureminutesValue != null && configureminutesValue.length() > 0) {
                                                    try {
                                                        configMinut = Integer.parseInt(configureminutesValue);
                                                    } catch (Exception ex) {
                                                        ex.printStackTrace();;
                                                    }
                                                }
                                                }
						Date curDt = new Date();
						Calendar cal = Calendar.getInstance();
						cal.setTime(curDt);
						cal.add(Calendar.MINUTE, configMinut);
						Date sdt = cal.getTime();
						Date pdt = data.getPickUpTime();
						if (pdt != null && pdt.after(curDt) && (pdt.before(sdt) || pdt.equals(sdt))) {

							BookingAllResponse brwo = new BookingAllResponse();
                                                        String conDt="";
                                                        
                                                       if (tzd != null && tzd.getId() > 0) {

                                                           String timezone = tzd.getTimeZoneName();
                                                           if(timezone!=null && timezone.length()>0 )
                                                           {
                                                                Date pDate = data.getPickUpTime();
                                                                pDate = GigflexDateUtil.getGMTtoLocationDate(pDate, timezone, dtFormat);
                                                                conDt=GigflexDateUtil.convertDateToString(pDate, dtFormat);
                                                           }

                                                       }         


                                                        brwo.setDateFormat(dateformat);                                                        
                                                        brwo.setTimeFormat(timeformat);
                                                        brwo.setBookingid(data.getBookingid());
							brwo.setId(data.getId());
							brwo.setRideCode(data.getRideCode());
                                                        
							brwo.setPassengerName(passengerData.getPassengerName());
                                                        brwo.setPrimaryContactNumber(passengerData.getPrimaryContactNumber());
                                                        brwo.setpCountryCode(passengerData.getpCountryCode());
                                                        brwo.setSecondaryContactNumber(passengerData.getSecondaryContactNumber());
                                                        brwo.setsCountryCode(passengerData.getsCountryCode());
                                                        brwo.setPassengerCode(passengerData.getPassengerCode());

							brwo.setPickUpTime(conDt);
							brwo.setPickLat(data.getPickLat());
							brwo.setPickLang(data.getPickLang());
							brwo.setPickUpAddress(data.getPickUpAddress());
							brwo.setDropLat(data.getDropLat());
							brwo.setDropLang(data.getDropLang());
							brwo.setDropOffAddress(data.getDropOffAddress());
							brwo.setAdditionalStopPage(data.getAdditionalStopPage());
							brwo.setVehicleCode(data.getVehicleCode());
							brwo.setNoOfPassengers(data.getNoOfPassengers());
							brwo.setNoOfBaggage(data.getNoOfBaggage());
							brwo.setAdditionalComment(data.getAdditionalComment());
							brwo.setCustomerFare(data.getCustomerFare());
                                                        brwo.setCurrencySymbol(currencySymbol);
							brwo.setBookingStatus(data.getBookingStatus());
							brwo.setPaymentOption(data.getPaymentOption());
							brwo.setOrganizationCode(data.getOrganizationCode());
							brwo.setOperatorCode(data.getOperatorCode());
							brwo.setIsPublished(data.getIsPublished());
                                                        brwo.setCancelationComment(data.getCancelationComment());
							brwo.setOrganizationName((String) arr[1]);
							brwo.setVehicleName((String) arr[2]);
							brwo.setOperatorName((String) arr[3]);
                                                        AssignBooking ab=(AssignBooking) arr[4];
                                                if(ab!=null && ab.getId()>0)
                                                {
                                                    if(ab.getOperatorCode()!=null && ab.getOperatorCode().length()>0)
                                                    {
                                                        brwo.setAssignorOperatorCode(ab.getOperatorCode());
                                                       Operator op=operatorRepository.getOperatorByOperatorCode(ab.getOperatorCode());
                                                       if(op!=null && op.getId()>0 && op.getOperatorName()!=null)
                                                       {
                                                          brwo.setAssignorOperatorName(op.getOperatorName());
                                                       }
                                                    }
                                                    
                                                    if(ab.getDriverCode()!=null && ab.getDriverCode().length()>0)
                                                    {
                                                        brwo.setDriverCode(ab.getDriverCode());
                                                       Driver dr=driverRepository.getDriverByDriverCode(ab.getDriverCode());
                                                       if(dr!=null && dr.getId()>0 && dr.getName()!=null)
                                                       {
                                                          brwo.setDriverName(dr.getName());
                                                            brwo.setDriverVehicleCode(dr.getDefaultVehicleCode());
                                                       }
                                                    }
                                                }
                                                GlobalRideType grt=rideTypeRepository.getGlobalRideTypeByVehicleCode(data.getVehicleCode());
                                            if(grt!=null && grt.getId()>0 && grt.getGlobalRideCode()!=null && grt.getVehicleName()!=null)
                                            {
                                                brwo.setGlobalRideCode(grt.getGlobalRideCode());
                                                brwo.setGlobalRideName(grt.getVehicleName());
                                            }
							maplst.add(brwo);
						}

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("count", count);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	
    }

     
}
