/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.assignbooking.repository;

import com.gigflex.prototype.microservices.assignbooking.dtob.AssignBooking;
import com.gigflex.prototype.microservices.booking.dtob.Booking;
import java.util.Date;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface AssignBookingRepository
		extends JpaRepository<AssignBooking, Long>, JpaSpecificationExecutor<AssignBooking> {
//
//	@Query("SELECT b,o.organizationName,c.vehicleName FROM Booking b, AssignBooking ab, Organization o,RideType c WHERE ab.isDeleted != TRUE AND b.isPublished = TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.pickUpTime>:curDT AND (b.bookingStatus = :bookingStatusPending OR b.bookingStatus = :bookingStatusRejected) AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode")
//	public List<Object> getAllValidUnAssignedBooking(@Param("curDT") Date curDT,
//			@Param("bookingStatusPending") String bookingStatusPending,
//			@Param("bookingStatusRejected") String bookingStatusRejected);
	

	@Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND  b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.pickUpTime>:curDT AND ( b.bookingStatus = :bookingStatusPending OR b.bookingStatus = :assignedBookingPublishedStatus) AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode  AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY b.id DESC")
	public List<Object> getAllValidUnAssignedBooking(@Param("curDT") Date curDT,
			@Param("bookingStatusPending") String bookingStatusPending,@Param("assignedBookingPublishedStatus") String assignedBookingPublishedStatus);

	@Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND  b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.pickUpTime>:curDT AND ( b.bookingStatus = :bookingStatusPending OR b.bookingStatus = :assignedBookingPublishedStatus ) AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY b.id DESC")
	public List<Object> getAllValidUnAssignedBookingByPage(@Param("curDT") Date curDT,
			@Param("bookingStatusPending") String bookingStatusPending,@Param("assignedBookingPublishedStatus") String assignedBookingPublishedStatus,
			 Pageable pageableRequest);
        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isPublished = TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.pickUpTime>:curDT AND ( b.bookingStatus = :bookingStatusPending OR  b.bookingStatus = :assignedBookingPublishedStatus ) AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.operatorCode != :operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY b.id DESC")
	public List<Object> getAllValidUnAssignedBookingExceptCreator(@Param("curDT") Date curDT,
			@Param("bookingStatusPending") String bookingStatusPending,@Param("assignedBookingPublishedStatus") String assignedBookingPublishedStatus,@Param("operatorCode") String operatorCode);

        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isPublished = TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.pickUpTime>:curDT AND ( b.bookingStatus = :bookingStatusPending OR  b.bookingStatus = :assignedBookingPublishedStatus ) AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.operatorCode != :operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY b.id DESC")
	public List<Object> getAllValidUnAssignedBookingExceptCreatorByPage(@Param("curDT") Date curDT,
			@Param("bookingStatusPending") String bookingStatusPending,@Param("assignedBookingPublishedStatus") String assignedBookingPublishedStatus,@Param("operatorCode") String operatorCode,Pageable pageableRequest);

        
        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op WHERE ab.isDeleted != TRUE AND b.isPublished = TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.pickUpTime>:curDT AND ( b.bookingStatus = :bookingStatusPending OR  b.bookingStatus = :assignedBookingPublishedStatus ) AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.organizationCode != :organizationCode ORDER BY b.id DESC")
	public List<Object> getAllValidUnAssignedBookingExceptCreatorOrganization(@Param("curDT") Date curDT,
			@Param("bookingStatusPending") String bookingStatusPending,@Param("assignedBookingPublishedStatus") String assignedBookingPublishedStatus,@Param("organizationCode") String organizationCode);

        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName ,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op ,Passenger p WHERE ab.isDeleted != TRUE AND b.isPublished = TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.pickUpTime>:curDT AND ( b.bookingStatus = :bookingStatusPending OR  b.bookingStatus = :assignedBookingPublishedStatus ) AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.organizationCode != :organizationCode  AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY b.id DESC")
	public List<Object> getAllValidUnAssignedBookingExceptCreatorOrganizationByPage(@Param("curDT") Date curDT,
			@Param("bookingStatusPending") String bookingStatusPending,@Param("assignedBookingPublishedStatus") String assignedBookingPublishedStatus,@Param("organizationCode") String organizationCode,Pageable pageableRequest);

        
        
        
	@Query("SELECT a FROM AssignBooking a WHERE a.isDeleted != TRUE AND a.rideCode = :rideCode AND (a.driverCode=:driverCode OR a.driverCode IS NULL)")
	public AssignBooking getAssignBookingByRideCodeAndDriverCodeForAccepted(@Param("rideCode") String rideCode,
			@Param("driverCode") String driverCode);

	@Query("SELECT a FROM AssignBooking a WHERE a.isDeleted != TRUE AND a.rideCode = :rideCode")
	public AssignBooking getAssignBookingByRideCode(@Param("rideCode") String rideCode);

	@Query("SELECT a FROM AssignBooking a WHERE a.isDeleted != TRUE AND a.rideCode = :rideCode AND (a.driverCode=:driverCode OR a.driverCode IS NULL)")
	public AssignBooking getAssignBookingByRideCodeAndDriverCode(@Param("rideCode") String rideCode,
			@Param("driverCode") String driverCode);

	@Query("SELECT a FROM AssignBooking a WHERE a.isDeleted != TRUE AND a.assignBookingCode = :assignBookingCode")
	public AssignBooking getAssignBookingByCode(@Param("assignBookingCode") String assignBookingCode);

        @Query("SELECT a,b,c.name,o.operatorName,p  FROM AssignBooking a, Booking b, Driver c,Operator o,Passenger p WHERE a.isDeleted != TRUE AND a.driverCode = c.driverCode AND b.operatorCode = o.operatorCode AND a.rideCode = b.rideCode AND a.rideCode = :rideCode  AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE ")
	public Object getCurrentLocationByRideCode(@Param("rideCode") String rideCode);
        
        @Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName, ab,p  FROM Booking a, Organization b, RideType c,Operator o, AssignBooking ab,Passenger p  WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND ab.rideCode = a.rideCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND ab.driverCode = :driverCode AND a.bookingStatus = :bookingStatusAssigned  AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE ")
        public List<Object> getAssignedBookingByDriverCode(@Param("driverCode") String driverCode,@Param("bookingStatusAssigned") String bookingStatusAssigned);
        
        @Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName, ab,p FROM Booking a, Organization b, RideType c,Operator o, AssignBooking ab ,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND ab.rideCode = a.rideCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND ab.driverCode = :driverCode AND a.bookingStatus = :bookingStatusAssigned AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE ")
        public List<Object> getAssignedBookingByDriverCode(@Param("driverCode") String driverCode,@Param("bookingStatusAssigned") String bookingStatusAssigned, Pageable pageableRequest);
      
        
        @Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName, ab,p FROM Booking a, Organization b, RideType c,Operator o, AssignBooking ab ,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND ab.rideCode = a.rideCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND ab.driverCode = :driverCode AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND (a.bookingStatus = :bookingStatusAccepted OR a.bookingStatus = :bookingStatusInProgress OR a.bookingStatus = :bookingStatusCompleted)")
        public List<Object> getAllAcceptedBookingByDriverCode(@Param("driverCode") String driverCode,@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("bookingStatusInProgress") String bookingStatusInProgress,@Param("bookingStatusCompleted") String bookingStatusCompleted);
        
        @Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName, ab FROM Booking a, Organization b, RideType c,Operator o, AssignBooking ab WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND ab.rideCode = a.rideCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND ab.driverCode = :driverCode AND (a.bookingStatus = :bookingStatusAccepted OR a.bookingStatus = :bookingStatusInProgress OR a.bookingStatus = :bookingStatusCompleted)")
        public List<Object> getAllAcceptedBookingByDriverCode(@Param("driverCode") String driverCode,@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("bookingStatusInProgress") String bookingStatusInProgress,@Param("bookingStatusCompleted") String bookingStatusCompleted, Pageable pageableRequest);

        
    	@Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName ,p FROM Booking b, AssignBooking ab, Organization o,\n" + 
    			"RideType c,Operator op ,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode \n" + 
    			"AND b.pickUpTime>:curDT AND b.organizationCode = o.organizationCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode\n" + 
    			"AND (b.operatorCode=:operatorCode OR b.bookingStatus = :assignedBookingPublishedStatus OR (b.operatorCode !=:operatorCode AND b.isPublished = TRUE)) AND \n" + 
    			"(b.bookingStatus = :bookingStatusPending OR (b.bookingStatus = :bookingStatusRejected AND ab.driverCode!=:driverCode))")
    	public List<Object> getAllValidUnAssignedBookingByOperatorCodeByPage(@Param("curDT") Date curDT,
    			@Param("bookingStatusPending") String bookingStatusPending,
                        @Param("assignedBookingPublishedStatus") String assignedBookingPublishedStatus,
    			@Param("bookingStatusRejected") String bookingStatusRejected,
    			@Param("operatorCode") String operatorCode,
    			@Param("driverCode") String driverCode,
    			 Pageable pageableRequest);
    	
    	@Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName ,p FROM Booking b, AssignBooking ab, Organization o,\n" + 
    			"RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode \n" + 
    			"AND b.pickUpTime>:curDT AND b.organizationCode = o.organizationCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode\n" + 
    			"AND (b.operatorCode=:operatorCode OR (b.operatorCode !=:operatorCode AND b.isPublished = TRUE)) AND \n" + 
    			"(b.bookingStatus = :bookingStatusPending OR b.bookingStatus = :assignedBookingPublishedStatus OR (b.bookingStatus = :bookingStatusRejected AND ab.driverCode!=:driverCode))")
    	public List<Object> getAllValidUnAssignedBookingByOperatorCode(@Param("curDT") Date curDT,
    			@Param("bookingStatusPending") String bookingStatusPending,
                        @Param("assignedBookingPublishedStatus") String assignedBookingPublishedStatus,
    			@Param("bookingStatusRejected") String bookingStatusRejected,
    			@Param("operatorCode") String operatorCode,
    			@Param("driverCode") String driverCode);
        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab ,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op ,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND  ab.driverCode = :driverCode  AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE ")
	public List<Object> getAllBookingByDriverCodeWithFilter(@Param("driverCode") String driverCode,@Param("sDT") Date sDT,@Param("eDT") Date eDT,Pageable pageableRequest);

        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND  ab.driverCode = :driverCode")
	public List<Object> getAllBookingByDriverCodeWithFilter(@Param("driverCode") String driverCode,@Param("sDT") Date sDT,@Param("eDT") Date eDT);

        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND  ab.driverCode = :driverCode  AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE ")
	public List<Object> getAllBookingByDriverCodeWithFilter(@Param("driverCode") String driverCode,Pageable pageableRequest);
        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND  ab.driverCode = :driverCode")
	public List<Object> getAllBookingByDriverCodeWithFilter(@Param("driverCode") String driverCode);
        
        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op ,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus = :bookingStatus AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND  ab.driverCode = :driverCode  AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE " )
	public List<Object> getAllBookingByDriverCodeWithFilter(@Param("driverCode") String driverCode,@Param("bookingStatus") String bookingStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT,Pageable pageableRequest);
        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus = :bookingStatus AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND  ab.driverCode = :driverCode")
	public List<Object> getAllBookingByDriverCodeWithFilter(@Param("driverCode") String driverCode,@Param("bookingStatus") String bookingStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT);

        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab ,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op ,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus = :bookingStatus  AND  ab.driverCode = :driverCode  AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE ")
	public List<Object> getAllBookingByDriverCodeWithFilter(@Param("driverCode") String driverCode,@Param("bookingStatus") String bookingStatus,Pageable pageableRequest);

        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus = :bookingStatus  AND  ab.driverCode = :driverCode")
	public List<Object> getAllBookingByDriverCodeWithFilter(@Param("driverCode") String driverCode,@Param("bookingStatus") String bookingStatus);

        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus IN  (:bookingStatus) AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND  ab.driverCode = :driverCode  ORDER BY FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByDriverCodeWithFilterByPage(@Param("driverCode") String driverCode,@Param("bookingStatus") List<String> bookingStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT, @Param("orderLst") List<String> orderLst);
        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus IN  (:bookingStatus) AND ab.driverCode = :driverCode  ORDER BY FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByDriverCodeWithFilterByPage(@Param("driverCode") String driverCode,@Param("bookingStatus") List<String> bookingStatus, @Param("orderLst") List<String> orderLst);
        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab ,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op ,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus IN  (:bookingStatus) AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND  ab.driverCode = :driverCode   AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  ORDER BY FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByDriverCodeWithFilterByPage(@Param("driverCode") String driverCode,@Param("bookingStatus") List<String> bookingStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT, @Param("orderLst") List<String> orderLst, Pageable pageableRequest);
        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab ,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus IN  (:bookingStatus) AND ab.driverCode = :driverCode   AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  ORDER BY FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByDriverCodeWithFilterByPage(@Param("driverCode") String driverCode,@Param("bookingStatus") List<String> bookingStatus, @Param("orderLst") List<String> orderLst, Pageable pageableRequest);
        
       @Query("SELECT b  FROM Booking b, AssignBooking ab WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode  AND b.bookingStatus = :bookingStatus  AND  ab.driverCode = :driverCode")
	public List<Booking> getAllBookingByDriverCodeWithStaus(@Param("driverCode") String driverCode,@Param("bookingStatus") String bookingStatus);

        @Query("SELECT b ,p.passengerName FROM Booking b, AssignBooking ab,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND   b.bookingStatus IN  (:bookingStatus) AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND  ab.driverCode = :driverCode   AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  ORDER BY FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByDriverCodeWithFilterforMobile(@Param("driverCode") String driverCode,@Param("bookingStatus") List<String> bookingStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT, @Param("orderLst") List<String> orderLst);
       
        @Query("SELECT b ,p.passengerName FROM Booking b, AssignBooking ab,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND   b.bookingStatus IN  (:bookingStatus) AND   ab.driverCode = :driverCode   AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  ORDER BY FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByDriverCodeWithFilterforMobile(@Param("driverCode") String driverCode,@Param("bookingStatus") List<String> bookingStatus, @Param("orderLst") List<String> orderLst);
        
          @Query("SELECT b ,p.passengerName FROM Booking b, AssignBooking ab,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND   b.bookingStatus IN  (:bookingStatus) AND   ab.driverCode = :driverCode   AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  ORDER BY FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByDriverCodeWithFilterforMobile(@Param("driverCode") String driverCode,@Param("bookingStatus") List<String> bookingStatus, @Param("orderLst") List<String> orderLst,Pageable pageableRequest);
        
                @Query("SELECT b ,p.passengerName FROM Booking b, AssignBooking ab,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND   b.bookingStatus IN  (:bookingStatus) AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND  ab.driverCode = :driverCode   AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  ORDER BY FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByDriverCodeWithFilterforMobile(@Param("driverCode") String driverCode,@Param("bookingStatus") List<String> bookingStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT, @Param("orderLst") List<String> orderLst,Pageable pageableRequest);

        @Query("SELECT a FROM AssignBooking a WHERE a.isDeleted != TRUE AND a.rideCode = :rideCode AND a.driverCode = :driverCode AND a.status =:status ")
        public AssignBooking getAssignBookingByDriverCodeAndRideCode(@Param("driverCode") String driverCode, @Param("rideCode") String rideCode, @Param("status") String status);
       
}
