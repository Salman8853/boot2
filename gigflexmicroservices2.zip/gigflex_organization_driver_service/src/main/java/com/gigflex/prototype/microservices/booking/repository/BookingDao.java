package com.gigflex.prototype.microservices.booking.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetail;
import java.util.Date;


public interface BookingDao extends JpaRepository<Booking,Long>,JpaSpecificationExecutor<Booking> {
	
        @Query("SELECT b FROM Booking b WHERE  b.isDeleted != TRUE AND  b.pickUpTime>:curDT AND b.bookingStatus = :bookingStatusAccepted ORDER BY b.id DESC")
	public List<Booking> getAllUpcomingAcceptedBooking(@Param("curDT") Date curDT,@Param("bookingStatusAccepted") String bookingStatusAccepted);
      
        
        @Query("SELECT b FROM Booking b WHERE  b.isDeleted != TRUE AND  b.pickUpTime<:curDT AND b.bookingStatus NOT IN ( :assignedBookingStatusList)  ORDER BY b.organizationCode ASC ")
	public List<Booking> getAllBookingNearToExpire(@Param("curDT") Date curDT,@Param("assignedBookingStatusList") List<String> assignedBookingStatusList);
            
        @Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName, p FROM Booking a, Organization b, RideType c,Operator o,Passenger p  WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.isPublished = TRUE  AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND a.pickUpTime>:curDT AND a.bookingStatus = :bookingStatusAccepted ORDER BY a.id DESC")
   	public List<Object> getAllAcceptedUpcomingBooking(@Param("curDT") Date curDT,
   			@Param("bookingStatusAccepted") String bookingStatusAccepted);
    
        @Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName, p FROM Booking a, Organization b, RideType c,Operator o,Passenger p  WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.isPublished = TRUE AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND a.pickUpTime>:curDT AND a.bookingStatus = :bookingStatusAccepted ORDER BY a.id DESC")
   	public List<Object> getAllAcceptedUpcomingBooking(@Param("curDT") Date curDT,
   			@Param("bookingStatusAccepted") String bookingStatusAccepted,Pageable pageableRequest);
    
	@Query("SELECT a , p FROM Booking a,Passenger p WHERE a.isDeleted != TRUE AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND a.rideCode = :rideCode")
	public Object getBookingWithPassengerByRideCode(@Param("rideCode") String rideCode);
        
        @Query("SELECT a FROM Booking a WHERE a.isDeleted != TRUE AND a.rideCode = :rideCode")
	public Booking getBookingByRideCode(@Param("rideCode") String rideCode);       
        
        
        @Query("SELECT a FROM Booking a WHERE a.isDeleted != TRUE AND a.bookingid = :bookingid")
	public Booking getBookingByBookingid(@Param("bookingid") long bookingid);
	
        @Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName,p  FROM Booking a, Organization b, RideType c,Operator o,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.bookingid = :bookingid AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY a.id DESC")
	public List<Object> getBookingByBookingidWithName(@Param("bookingid") long bookingid);
        
	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName,ab,p FROM Booking a, Organization b, RideType c,Operator o,AssignBooking ab ,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.rideCode = ab.rideCode AND a.rideCode = :rideCode AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY a.id DESC")
	public List<Object> getBookingByRideCodeWithName(@Param("rideCode") String rideCode);
	
	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName,p FROM Booking a, Organization b, RideType c,Operator o,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.bookingStatus = :bookingStatus AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY a.id DESC")
	public List<Object> getBookingByBookingStatus(@Param("bookingStatus") String bookingStatus);
	
	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName,p FROM Booking a, Organization b, RideType c,Operator o,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.bookingStatus = :bookingStatus AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY a.id DESC")
	public List<Object> getBookingByBookingStatus(@Param("bookingStatus") String bookingStatus,Pageable pageableRequest);
//	@Query("SELECT a FROM Booking a WHERE a.isDeleted != TRUE")
//	public List<Booking> getAllBooking();
	
//	@Query("SELECT a FROM Booking a WHERE a.isDeleted != TRUE")
//	public List<Booking> getAllBooking(Pageable pageableRequest);
//	
//	@Query("SELECT a,b.organizationName,c.vehicleName FROM Booking a, Organization b,RideType c WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode")
//	public List<Object> getAllBookingWithReqTime();
//	
//	@Query("SELECT a,b.organizationName,c.vehicleName FROM Booking a, Organization b,RideType c WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode")
//	public List<Object> getAllBookingWithReqTime(Pageable pageableRequest);
	
	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName ,p FROM Booking a, Organization b, RideType c,Operator o,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY a.id DESC")
	public List<Object> getAllBooking(Pageable pageableRequest);

	@Query("SELECT a FROM Booking a WHERE a.isDeleted != TRUE AND a.id = :id")
	public Booking getBookingById(@Param("id") Long id);
	
	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName ,p FROM Booking a, Organization b, RideType c,Operator o,Passenger p  WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND  a.id = :id AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE")
	public List<Object> getBookingByIdWithName(@Param("id") Long id);
	
	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName ,p FROM Booking a, Organization b, RideType c,Operator o ,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.organizationCode = :organizationCode AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY a.id DESC")
	public List<Object> getBookingByOrgCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName ,p FROM Booking a, Organization b, RideType c,Operator o ,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.organizationCode = :organizationCode AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY a.id DESC")
	public List<Object> getBookingByOrgCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
	
	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName,p FROM Booking a, Organization b, RideType c,Operator o,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY a.id DESC")
	public List<Object> getAllBooking();

	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName,ab ,p FROM Booking a, Organization b, RideType c,Operator o, AssignBooking ab,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.rideCode=ab.rideCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.operatorCode = :operatorCode AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY a.id DESC")
	public List<Object> getBookingByOperatorCode(@Param("operatorCode") String operatorCode);
	
	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName,ab,p FROM Booking a, Organization b, RideType c,Operator o, AssignBooking ab,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.rideCode=ab.rideCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.operatorCode = :operatorCode AND a.passengerCode = p.passengerCode AND p.isDeleted != TRUE ORDER BY a.id DESC")
	public List<Object> getBookingByOperatorCode(@Param("operatorCode") String operatorCode,Pageable pageableRequest);

	@Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND b.pickUpTime>=:fromDT AND b.pickUpTime<:toDT  ORDER BY b.id DESC")
	public List<Object> getAllBookingByDate(@Param("fromDT") Date fromDT,@Param("toDT") Date toDT);
	
	@Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName ,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND b.pickUpTime>=:fromDT AND b.pickUpTime<:toDT ORDER BY b.id DESC")
	public List<Object> getAllBookingByDate(@Param("fromDT") Date fromDT,@Param("toDT") Date toDT,Pageable pageableRequest);
	
	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName,ab,p  FROM Booking a, Organization b, RideType c,Operator o,AssignBooking ab,Passenger p  WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND  a.rideCode=ab.rideCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND  a.pickUpTime>:curDT AND a.bookingStatus = :bookingStatusAccepted AND  a.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND (a.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY a.id DESC")
   	public List<Object> getAllAcceptedUpcomingBookingByOperatorCode(@Param("curDT") Date curDT,
   			@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("operatorCode") String operatorCode);
    
	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName,ab,p FROM Booking a, Organization b, RideType c,Operator o,AssignBooking ab,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND  a.rideCode=ab.rideCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND  a.pickUpTime>:curDT AND a.bookingStatus = :bookingStatusAccepted AND  a.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND (a.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY a.id DESC")
   	public List<Object> getAllAcceptedUpcomingBookingByOperatorCode(@Param("curDT") Date curDT,
   			@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("operatorCode") String operatorCode,Pageable pageableRequest);
    

        @Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName,ab FROM Booking a, Organization b, RideType c,Operator o,AssignBooking ab WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND  a.rideCode=ab.rideCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND  a.pickUpTime>:curDT AND a.bookingStatus = :bookingStatusAccepted AND (a.organizationCode = :organizationCode OR ab.organizationCode = :organizationCode) ORDER BY a.id DESC")
   	public List<Object> getAllAcceptedUpcomingBookingByOrganizationCode(@Param("curDT") Date curDT,
   			@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("organizationCode") String organizationCode);
    
	@Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName,ab ,p FROM Booking a, Organization b, RideType c,Operator o,AssignBooking ab,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND  a.rideCode=ab.rideCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND  a.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND  a.pickUpTime>:curDT AND a.bookingStatus = :bookingStatusAccepted AND (a.organizationCode = :organizationCode OR ab.organizationCode = :organizationCode) ORDER BY a.id DESC")
   	public List<Object> getAllAcceptedUpcomingBookingByOrganizationCode(@Param("curDT") Date curDT,
   			@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("organizationCode") String organizationCode,Pageable pageableRequest);
    
        @Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName,ab,p FROM Booking a, Organization b, RideType c,Operator o,AssignBooking ab,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND  a.rideCode=ab.rideCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND  a.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND  a.pickUpTime>:curDT AND a.bookingStatus = :bookingStatusAccepted AND (a.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) AND a.pickUpTime>=:fromDT AND a.pickUpTime<:toDT ORDER BY a.id DESC")
   	public List<Object> getAllAcceptedUpcomingBookingByOperatorCodeByDate(@Param("curDT") Date curDT,
   			@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("operatorCode") String operatorCode,@Param("fromDT") Date fromDT,@Param("toDT") Date toDT);
    
        @Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName, ab,p FROM Booking a, Organization b, RideType c,Operator o, AssignBooking ab,Passenger p WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND  a.rideCode=ab.rideCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND  a.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND  a.pickUpTime>:curDT AND a.bookingStatus = :bookingStatusAccepted AND (a.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) AND a.pickUpTime>=:fromDT AND a.pickUpTime<:toDT ORDER BY a.id DESC")
   	public List<Object> getAllAcceptedUpcomingBookingByOperatorCodeByDate(@Param("curDT") Date curDT,@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("operatorCode") String operatorCode,@Param("fromDT") Date fromDT,@Param("toDT") Date toDT,Pageable pageableRequest);

//    @Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName FROM Booking a, Organization b, RideType c,Operator o WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.isPublished = TRUE AND a.pickUpTime>:curDT AND a.bookingStatus = :bookingStatusAccepted AND a.driverCode = :driverCode")
//   	public List<Object> getAllAcceptedUpcomingBookingByDriverCode(@Param("curDT") Date curDT,
//   			@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("driverCode") String driverCode);
//    
//    @Query("SELECT a,b.organizationName,c.vehicleName,o.operatorName FROM Booking a, Organization b, RideType c,Operator o WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = c.vehicleCode AND a.operatorCode = o.operatorCode AND a.isPublished = TRUE AND a.pickUpTime>:curDT AND a.bookingStatus = :bookingStatusAccepted AND a.driverCode = :driverCode")
//   	public List<Object> getAllAcceptedUpcomingBookingByDriverCode(@Param("curDT") Date curDT,
//   			@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("driverCode") String driverCode,Pageable pageableRequest);

    
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus = :bookingStatusAccepted AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND b.pickUpTime>=:fromDT AND b.pickUpTime<:toDT ORDER BY b.id DESC")
	public List<Object> getAllAcceptedBookingByDate(@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("fromDT") Date fromDT,@Param("toDT") Date toDT);
	
	@Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE  AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus = :bookingStatusAccepted AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND b.pickUpTime>=:fromDT AND b.pickUpTime<:toDT ORDER BY b.id DESC")
	public List<Object> getAllAcceptedBookingByDate(@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("fromDT") Date fromDT,@Param("toDT") Date toDT,Pageable pageableRequest);

        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus = :bookingStatus AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY b.id DESC")
	public List<Object> getAllBookingByOperatorCodeWithFilter(@Param("operatorCode") String operatorCode,@Param("bookingStatus") String bookingStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT,Pageable pageableRequest);

        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus = :bookingStatus AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY b.id DESC")
	public List<Object> getAllBookingByOperatorCodeWithFilter(@Param("operatorCode") String operatorCode,@Param("bookingStatus") String bookingStatus,Pageable pageableRequest);

        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY b.id DESC")
	public List<Object> getAllBookingByOperatorCodeWithFilter(@Param("operatorCode") String operatorCode,@Param("sDT") Date sDT,@Param("eDT") Date eDT,Pageable pageableRequest);

        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND  (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY b.id DESC")
	public List<Object> getAllBookingByOperatorCodeWithFilter(@Param("operatorCode") String operatorCode,Pageable pageableRequest);
        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus = :bookingStatus AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY b.id DESC")
    	public List<Object> getAllBookingByOperatorCodeWithFilter(@Param("operatorCode") String operatorCode,@Param("bookingStatus") String bookingStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT);

            
            @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus = :bookingStatus AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY b.id DESC")
    	public List<Object> getAllBookingByOperatorCodeWithFilter(@Param("operatorCode") String operatorCode,@Param("bookingStatus") String bookingStatus);

            
            @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY b.id DESC")
    	public List<Object> getAllBookingByOperatorCodeWithFilter(@Param("operatorCode") String operatorCode,@Param("sDT") Date sDT,@Param("eDT") Date eDT);

            @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND  (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY b.id DESC")
    	public List<Object> getAllBookingByOperatorCodeWithFilter(@Param("operatorCode") String operatorCode);

        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op ,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND b.operatorCode = op.operatorCode AND b.bookingStatus IN (:bookingStatus) AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByOperatorCodeWithFilterByPage(@Param("operatorCode") String operatorCode,@Param("bookingStatus") List<String> bookingStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT, @Param("orderLst") List<String> orderLst,  Pageable pageableRequest);

        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op ,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND b.operatorCode = op.operatorCode AND b.bookingStatus IN (:bookingStatus) AND (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY  FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByOperatorCodeWithFilterByPage(@Param("operatorCode") String operatorCode,@Param("bookingStatus") List<String> bookingStatus,@Param("orderLst") List<String> orderLst,Pageable pageableRequest);

        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND b.operatorCode = op.operatorCode AND b.bookingStatus IN (:bookingStatus) AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY  FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByOperatorCodeWithFilterByPage(@Param("operatorCode") String operatorCode,@Param("bookingStatus") List<String> bookingStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT,@Param("orderLst") List<String> orderLst);

        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE AND b.operatorCode = op.operatorCode AND b.bookingStatus IN (:bookingStatus) AND (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY  FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByOperatorCodeWithFilterByPage(@Param("operatorCode") String operatorCode,@Param("bookingStatus") List<String> bookingStatus,@Param("orderLst") List<String> orderLst);

        
        
        
        
        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op ,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus IN (:bookingStatus) AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND (b.organizationCode = :organizationCode OR ab.organizationCode = :organizationCode) ORDER BY FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByOrganizationCodeWithFilterByPage(@Param("organizationCode") String organizationCode,@Param("bookingStatus") List<String> bookingStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT, @Param("orderLst") List<String> orderLst,  Pageable pageableRequest);

        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op ,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus IN (:bookingStatus) AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND (b.organizationCode = :organizationCode OR ab.organizationCode = :organizationCode) ORDER BY  FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByOrganizationCodeWithFilterByPage(@Param("organizationCode") String organizationCode,@Param("bookingStatus") List<String> bookingStatus,@Param("orderLst") List<String> orderLst,Pageable pageableRequest);

        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus IN (:bookingStatus)  AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND b.pickUpTime>=:sDT AND b.pickUpTime<:eDT AND (b.organizationCode = :organizationCode OR ab.organizationCode = :organizationCode) ORDER BY  FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByOrganizationCodeWithFilterByPage(@Param("organizationCode") String organizationCode,@Param("bookingStatus") List<String> bookingStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT,@Param("orderLst") List<String> orderLst);

        @Query("SELECT b,o.organizationName,c.vehicleName,op.operatorName,ab,p FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.bookingStatus IN (:bookingStatus) AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND (b.organizationCode = :organizationCode OR ab.organizationCode = :organizationCode) ORDER BY  FIELD(b.bookingStatus,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(b.pickUpTime))")
	public List<Object> getAllLatestBookingByOrganizationCodeWithFilterByPage(@Param("organizationCode") String organizationCode,@Param("bookingStatus") List<String> bookingStatus,@Param("orderLst") List<String> orderLst);

         @Query("SELECT b FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND (b.organizationCode = :organizationCode OR ab.organizationCode = :organizationCode) ORDER BY b.bookingStatus DESC")
    	public List<Booking> getAllDashboardBookingByOrganizationCode(@Param("organizationCode") String organizationCode);

        @Query("SELECT b FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND (b.organizationCode = :organizationCode OR ab.organizationCode = :organizationCode) AND b.bookingStatus = :bookingStatus ORDER BY b.bookingStatus DESC")
    	public List<Booking> getAllDashboardBookingByOrganizationCodeByStatus(@Param("organizationCode") String organizationCode,@Param("bookingStatus") String bookingStatus);

        
        
        
        @Query("SELECT b FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) ORDER BY b.bookingStatus DESC")
    	public List<Booking> getAllDashboardBookingByOperatorCode(@Param("operatorCode") String operatorCode);

        @Query("SELECT b FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND (b.operatorCode = :operatorCode OR ab.operatorCode = :operatorCode) AND b.bookingStatus = :bookingStatus ORDER BY b.bookingStatus DESC")
    	public List<Booking> getAllDashboardBookingByOperatorCodeByStatus(@Param("operatorCode") String operatorCode,@Param("bookingStatus") String bookingStatus);

        
        @Query("SELECT b FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND ab.driverCode = :driverCode ORDER BY b.bookingStatus DESC")
    	public List<Booking> getAllDashboardBookingByDriverCode(@Param("driverCode") String driverCode);

        @Query("SELECT b FROM Booking b, AssignBooking ab, Organization o,RideType c,Operator op,Passenger p  WHERE ab.isDeleted != TRUE AND b.isDeleted != TRUE AND b.rideCode=ab.rideCode AND b.organizationCode = o.organizationCode AND b.vehicleCode = c.vehicleCode AND b.operatorCode = op.operatorCode AND b.passengerCode = p.passengerCode AND p.isDeleted != TRUE  AND ab.driverCode = :driverCode AND b.bookingStatus = :bookingStatus ORDER BY b.bookingStatus DESC")
    	public List<Booking> getAllDashboardBookingByDriverCodeByStatus(@Param("driverCode") String driverCode,@Param("bookingStatus") String bookingStatus);

    
        @Query("SELECT vd FROM Driver d , VehicleDetail vd WHERE d.isDeleted != TRUE AND vd.isDeleted != TRUE AND d.defaultVehicleCode = vd.vehicleCode AND d.driverCode = :driverCode ")
        public VehicleDetail  getVehicleDetailDriverCode(@Param("driverCode") String driverCode);

        @Query("SELECT a FROM Booking a, AssignBooking ab WHERE a.isDeleted != TRUE AND ab.rideCode = a.rideCode AND ab.driverCode = :driverCode AND (a.bookingStatus = :bookingStatusAccepted OR a.bookingStatus = :bookingStatusInProgress OR a.bookingStatus = :bookingStatusAssigned) ORDER BY a.dropOffTime  ")
        public List<Booking> getAllAcceptedBookingByDriverCode(@Param("driverCode") String driverCode,@Param("bookingStatusAccepted") String bookingStatusAccepted,@Param("bookingStatusInProgress") String bookingStatusInProgress,@Param("bookingStatusAssigned") String bookingStatusAssigned);

//        @Query("SELECT a FROM Booking a, AssignBooking ab WHERE a.isDeleted != TRUE AND ab.rideCode = a.rideCode AND ab.driverCode = :driverCode AND (a.bookingStatus = :assignedBookingCompletedStatus ) ORDER BY a.dropOffTime DESC LIMIT 1")
//        @Query("SELECT a FROM Booking a, AssignBooking ab WHERE a.isDeleted != TRUE AND ab.rideCode = a.rideCode AND ab.driverCode = :driverCode AND (a.bookingStatus = :assignedBookingCompletedStatus ) ORDER BY a.dropOffTime DESC ")
//        public Booking getLastCompletedBookingByDriverCode(@Param("driverCode") String driverCode,@Param("assignedBookingCompletedStatus") String assignedBookingCompletedStatus,Pageable pageableRequest);
       
        @Query("SELECT d FROM Booking b,AssignBooking a,Driver d WHERE a.rideCode=b.rideCode AND (NOT ((b.pickUpTime >= :dropOffTime AND b.dropOffTime > :dropOffTime) OR (b.pickUpTime < :pickupTime AND b.dropOffTime <= :pickupTime))) AND a.driverCode IN (:drivercodeList) AND a.driverCode=d.driverCode AND  b.bookingStatus!=:cancedStatus AND b.bookingStatus!=:rejectedStatus AND b.bookingStatus!=:completedStatus AND b.bookingStatus!=:expiredStatus")
        public List<Driver> getAssignedBusyDriver(@Param("pickupTime") Date pickupTime,@Param("dropOffTime")  Date dropOffTime,@Param("drivercodeList") List<String> drivercodeList,@Param("cancedStatus")String cancedStatus,@Param("rejectedStatus")String rejectedStatus,@Param("completedStatus")String completedStatus,@Param("expiredStatus")String expiredStatus);

        
//        @Query("SELECT b FROM Booking b,AssignBooking a WHERE a.rideCode=b.rideCode AND a.driverCode=:driverCode AND b.bookingStatus NOT IN (:cancelledStatus,:expiredStatus,:rejectedStatus) AND  b.dropOffTime <= :pickupTime ORDER BY UNIX_TIMESTAMP(:pickupTime)-UNIX_TIMESTAMP(b.dropOffTime) LIMIT 1")
        @Query("SELECT b FROM Booking b,AssignBooking a WHERE a.rideCode=b.rideCode AND a.driverCode=:driverCode AND b.bookingStatus NOT IN (:cancelledStatus,:expiredStatus,:rejectedStatus) AND  b.dropOffTime <= :pickupTime ORDER BY UNIX_TIMESTAMP(:pickupTime)-UNIX_TIMESTAMP(b.dropOffTime)")
        public List<Booking> getNearestBookingByDriverCodeFromPickupTime(@Param("driverCode") String driverCode,@Param("pickupTime")  Date pickupTime, @Param("cancelledStatus") String cancelledStatus,@Param("expiredStatus") String expiredStatus, @Param("rejectedStatus") String rejectedStatus, Pageable pageableRequest);
        
        @Query("Select b.customerFare from Booking b where b.isDeleted != TRUE And b.rideCode=:rideCode")
        public Double getFareByRideCode(@Param("rideCode") String rideCode);

        @Query("SELECT b FROM Booking b,AssignBooking a WHERE a.rideCode=b.rideCode AND ((b.pickUpTime >= :fromTimeOffDate AND b.pickUpTime <= :toTimeOffDate) OR (b.dropOffTime >= :fromTimeOffDate AND b.dropOffTime <= :toTimeOffDate) OR (b.pickUpTime <= :fromTimeOffDate AND b.dropOffTime >= :toTimeOffDate)) AND a.driverCode =:driverCode AND  (b.bookingStatus =:assignedStatus OR b.bookingStatus =:acceptedStatus)")
        public List<Booking> getAssignedBookingListByDriverCodeAndBetweenTimeOffDates(@Param("driverCode") String driverCode, @Param("fromTimeOffDate") Date fromTimeOffDate,@Param("toTimeOffDate") Date toTimeOffDate,@Param("assignedStatus") String assignedStatus,@Param("acceptedStatus")  String acceptedStatus);
   
        @Query("SELECT b FROM Booking b,AssignBooking a WHERE a.rideCode=b.rideCode  AND a.driverCode =:driverCode AND  (b.bookingStatus =:assignedStatus OR b.bookingStatus =:acceptedStatus)")
        public List<Booking> getAssignedAndAcceptedBookingListByDriverCode(@Param("driverCode") String driverCode, @Param("assignedStatus") String assignedStatus, @Param("acceptedStatus")  String acceptedStatus);

        @Query("SELECT b FROM Booking b,AssignBooking a WHERE a.rideCode=b.rideCode AND (b.pickUpTime >= :curFromTime AND b.pickUpTime < :curToTime)  AND a.driverCode =:driverCode AND  (b.bookingStatus =:assignedStatus OR b.bookingStatus =:acceptedStatus OR b.bookingStatus = :inProgressStatus)")
        public List<Booking> getAssignedBookingListByDriverCodeAndBetweenCurrntTime(@Param("driverCode") String driverCode,@Param("curFromTime")  Date curFromTime,@Param("curToTime")  Date curToTime,@Param("assignedStatus") String assignedStatus, @Param("acceptedStatus")  String acceptedStatus, @Param("inProgressStatus")  String inProgressStatus);

}
