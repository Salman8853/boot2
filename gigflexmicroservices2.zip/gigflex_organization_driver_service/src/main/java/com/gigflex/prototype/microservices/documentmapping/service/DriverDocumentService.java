/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service;

import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocumentRequest;
import java.util.List;

/**
 *
 * @author nirbhay.p
 */
public interface DriverDocumentService {
	
    public String getAllDriverDocument();
    public String getAllDriverDocument(int page, int limit);
 
    public String  getAllDriverDocumentByDriverCode(String driverCode);
    public String  getAllDriverDocumentByDriverCode(String driverCode,int page, int limit);

    public String getDriverDocumentByDriverDocumentCode(String driverDocumentCode);
    public String softDeleteDriverDocumentByDriverDocumentCode(String driverDocumentCode);
    public String softMultipleDeleteDriverDocumentByDriverDocumentCode(List<String> driverDocumentCodeList);
    public String saveDriverDocument(DriverDocumentRequest driDetReq,String ip);
    public String updateDriverDocument(String driverDocumentCode,DriverDocumentRequest driDetReq,String ip);
    public String getDocumentExpirationByDriverCode(String driverCode);
}
