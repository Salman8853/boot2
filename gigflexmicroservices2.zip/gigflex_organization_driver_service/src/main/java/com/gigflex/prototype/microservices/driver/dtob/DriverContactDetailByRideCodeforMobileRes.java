/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.dtob;

/**
 *
 * @author m.salman
 */
public class DriverContactDetailByRideCodeforMobileRes {
    private String passangerno;
    private String operatorno;
    private String assignerno;
    private String ridecode;

    public String getPassangerno() {
        return passangerno;
    }

    public void setPassangerno(String passangerno) {
        this.passangerno = passangerno;
    }

    public String getOperatorno() {
        return operatorno;
    }

    public void setOperatorno(String operatorno) {
        this.operatorno = operatorno;
    }

    public String getAssignerno() {
        return assignerno;
    }

    public void setAssignerno(String assignerno) {
        this.assignerno = assignerno;
    }

    public String getRidecode() {
        return ridecode;
    }

    public void setRidecode(String ridecode) {
        this.ridecode = ridecode;
    }
    
}
