/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.hoursofoperation.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "hoursofoperation")
public class HoursOfOperation extends CommonAttributes implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "hoursofoperation_code", unique = true)
    private String hoursOfOperationCode;

    public HoursOfOperation() {
    }
    
            
    @PrePersist
    private void assignUUID() {
        if (this.getHoursOfOperationCode() == null || this.getHoursOfOperationCode().length() == 0) {
           this.setHoursOfOperationCode(UUID.randomUUID().toString());
        }
    }

    public HoursOfOperation(Long id,String hoursOfOperationCode,String vehicleCode, String driverCode,
            String fromTime,String toTime,int dayCode) {
            super();
            this.id = id;
            this.hoursOfOperationCode = hoursOfOperationCode;
            this.vehicleCode = vehicleCode;
            this.driverCode = driverCode;                  
            this.fromTime = fromTime;
            this.toTime = toTime;   
            this.dayCode = dayCode;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getHoursOfOperationCode() {
        return hoursOfOperationCode;
    }

    public void setHoursOfOperationCode(String hoursOfOperationCode) {
        this.hoursOfOperationCode = hoursOfOperationCode;
    }

    
    @Column(name = "vehicle_code")
    private String vehicleCode;
     
    @Column(name = "driver_code", nullable = false)
    private String driverCode;
    
    @Column(name = "fromtime")
    private String fromTime;
            
    @Column(name = "totime")
    private String toTime; 
    
    @Column(name = "day_code")
    private Integer dayCode;

    public String getVehicleCode() {
        return vehicleCode;
    }

    public void setVehicleCode(String vehicleCode) {
        this.vehicleCode = vehicleCode;
    }

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }
   
    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public Integer getDayCode() {
        return dayCode;
    }

    public void setDayCode(Integer dayCode) {
        this.dayCode = dayCode;
    }
    
    
    @Override
    public String toString() {
            return "HoursOfOperation [id=" + id + ", hoursOfOperationCode=" +hoursOfOperationCode+", vehicleCode=" + vehicleCode +", driverCode=" + driverCode +", fromTime=" + fromTime +", toTime=" + toTime+", dayCode=" + dayCode+"]";
    }
    
}
