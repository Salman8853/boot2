/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.vehicledetail.dtob;

/**
 *
 * @author m.salman
 */
public class VehicleDetailDriverResponseforMobile {
          private Long id;

	private String vehicleCode;

	private String vehicleTypeCode;
	
	private String vehicleTypeName;

	private Long vehicleYear;
        private String vehicleImage;
       private String licensePlate;
       private String insurance;

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }
      private String modelName;
     private boolean isdefaultvehicleCode;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getVehicleCode() {
        return vehicleCode;
    }

    public void setVehicleCode(String vehicleCode) {
        this.vehicleCode = vehicleCode;
    }

    public String getVehicleTypeCode() {
        return vehicleTypeCode;
    }

    public void setVehicleTypeCode(String vehicleTypeCode) {
        this.vehicleTypeCode = vehicleTypeCode;
    }

    public String getVehicleTypeName() {
        return vehicleTypeName;
    }

    public void setVehicleTypeName(String vehicleTypeName) {
        this.vehicleTypeName = vehicleTypeName;
    }

    public Long getVehicleYear() {
        return vehicleYear;
    }

    public void setVehicleYear(Long vehicleYear) {
        this.vehicleYear = vehicleYear;
    }

    public String getVehicleImage() {
        return vehicleImage;
    }

    public void setVehicleImage(String vehicleImage) {
        this.vehicleImage = vehicleImage;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public String getInsurance() {
        return insurance;
    }

    public void setInsurance(String insurance) {
        this.insurance = insurance;
    }

    public boolean isIsdefaultvehicleCode() {
        return isdefaultvehicleCode;
    }

    public void setIsdefaultvehicleCode(boolean isdefaultvehicleCode) {
        this.isdefaultvehicleCode = isdefaultvehicleCode;
    }
     
     
        
}
