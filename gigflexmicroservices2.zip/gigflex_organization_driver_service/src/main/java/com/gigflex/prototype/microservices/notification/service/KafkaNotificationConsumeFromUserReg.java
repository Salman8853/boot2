package com.gigflex.prototype.microservices.notification.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.notification.repository.NotificationDao;

public class KafkaNotificationConsumeFromUserReg {
	
 private Notification notification;
	 
	 @Autowired
	    private SimpMessagingTemplate template;

	    
	    @Autowired
	    NotificationDao notificationDao;
	    private static final Logger LOG = LoggerFactory.getLogger(KafkaNotificationConsumeFromUserReg.class);
	    
	     @KafkaListener(topics = "AddNotificationFromUserReg")
	     public void listen(@Payload String message) {
	           ObjectMapper objectMapper = new ObjectMapper();
	        LOG.info("received message='{}'", message);
	        try{
	        	Notification notify = objectMapper.readValue(message, Notification.class);
	            LOG.info("received message for AddNewNotificationFromUserReg='{}'", notify.getMessage());
	            LOG.info("received message for AddNewNotificationFromUserReg='{}'", notify.getNotificationCode());
	            LOG.info("received message for AddNewNotificationFromUserReg='{}'", notify.getUserCode());
	            LOG.info("received message for AddNewNotificationFromUserReg='{}'", notify.getUserType());
	      
	          
	            notification=new Notification();
	            
	            notification.setNotificationCode(notify.getNotificationCode());
	            notification.setMessage(notify.getMessage());
	            notification.setShortMessage(notify.getShortMessage());
	            notification.setUserCode(notify.getUserCode());
	            notification.setIsRead(notify.getIsRead());
	            notification.setIsDeleted(notify.getIsDeleted());
	            notification.setUserType(notify.getUserType());

	            
	            template.convertAndSend("/topic/notification", notify);
//	            notification.setIsRead(true);

	            notificationDao.save(notification);
	            
	        }
	         catch (JsonParseException e) {
				LOG.error("In  KafkaNotificationService for AddNewNotificationFromUserReg >>>>", e);
			} catch (JsonMappingException e) {
				LOG.error("In KafkaNotificationService for AddNewNotificationFromUserReg >>>>", e);
			} catch (IOException e) {
				LOG.error("In KafkaNotificationService for AddNewNotificationFromUserReg >>>>", e);
			}catch (Exception e) {
				LOG.error("In KafkaNotificationService for AddNewNotificationFromUserReg >>>>", e);
			}
	         
	     }

}
