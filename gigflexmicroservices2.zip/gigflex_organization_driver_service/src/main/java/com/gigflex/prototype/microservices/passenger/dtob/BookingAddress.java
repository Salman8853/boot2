/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.passenger.dtob;

/**
 *
 * @author amit.kumar
 */
public class BookingAddress {
    
    private String pickLat;
	    
    private String pickLang;

    private String pickUpAddress;

    private String dropLat;

    private String dropLang;
    
    private String dropOffAddress;

    public String getPickLat() {
        return pickLat;
    }

    public void setPickLat(String pickLat) {
        this.pickLat = pickLat;
    }

    public String getPickLang() {
        return pickLang;
    }

    public void setPickLang(String pickLang) {
        this.pickLang = pickLang;
    }

    public String getPickUpAddress() {
        return pickUpAddress;
    }

    public void setPickUpAddress(String pickUpAddress) {
        this.pickUpAddress = pickUpAddress;
    }

    public String getDropLat() {
        return dropLat;
    }

    public void setDropLat(String dropLat) {
        this.dropLat = dropLat;
    }

    public String getDropLang() {
        return dropLang;
    }

    public void setDropLang(String dropLang) {
        this.dropLang = dropLang;
    }

    public String getDropOffAddress() {
        return dropOffAddress;
    }

    public void setDropOffAddress(String dropOffAddress) {
        this.dropOffAddress = dropOffAddress;
    }
    
    
    
}
