package com.gigflex.prototype.microservices.vehicledetail.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.gigflex.prototype.microservices.vehicledetail.dtob.VehicleDetail;


public interface VehicleDetailRepository extends JpaRepository<VehicleDetail, Long>,JpaSpecificationExecutor<VehicleDetail>{
	
	@Query("SELECT a,vdm.driverCode,m.modelName,f.fuelTypeName FROM VehicleDetail a, MakeModelMapping m,Fuel f,VehicleDriverMapping vdm WHERE a.isDeleted != TRUE AND vdm.isDeleted != TRUE AND a.vehicleCode = vdm.vehicleCode AND a.modelCode = m.modelCode AND a.fuelTypeCode = f.fuelTypeCode")
	public List<Object> getAllVehicleDetail();
	
	@Query("SELECT a,vdm.driverCode,m.modelName,f.fuelTypeName FROM VehicleDetail a, MakeModelMapping m,Fuel f,VehicleDriverMapping vdm WHERE a.isDeleted != TRUE AND vdm.isDeleted != TRUE AND a.vehicleCode = vdm.vehicleCode AND a.modelCode = m.modelCode AND a.fuelTypeCode = f.fuelTypeCode")
	public List<Object> getAllVehicleDetail(Pageable pageableRequest);
	
	@Query("SELECT m FROM VehicleDetail m WHERE m.isDeleted != TRUE AND m.vehicleCode = :vehicleCode")
	public VehicleDetail getVehicleDetailByVehicleCode(@Param("vehicleCode") String vehicleCode);
        
	@Query("SELECT m FROM VehicleDetail m,VehicleDriverMapping vdm WHERE vdm.isDeleted != TRUE AND m.isDeleted != TRUE AND vdm.vehicleCode = m.vehicleCode AND vdm.driverCode=:driverCode")
	public List<VehicleDetail> getDriverVehicleDetailByVehicleCode(@Param("driverCode") String driverCode);
	
//	@Query("SELECT a,b.organizationName FROM VehicleDetail a, Organization b WHERE a.isDeleted != TRUE AND b.organizationCode = a.organizationCode AND a.vehicleCode = :vehicleCode")
//	public List<Object> getVehicleDetailByVehicleCodeWithName(@Param("vehicleCode") String vehicleCode);
	
	@Query("SELECT a,vdm.driverCode,m.modelName,f.fuelTypeName FROM VehicleDetail a, MakeModelMapping m,Fuel f,VehicleDriverMapping vdm WHERE a.isDeleted != TRUE AND vdm.isDeleted != TRUE AND a.vehicleCode = vdm.vehicleCode AND a.modelCode = m.modelCode AND a.fuelTypeCode = f.fuelTypeCode AND a.vehicleCode = :vehicleCode")
	public Object getVehicleDetailByVehicleCodeWithName(@Param("vehicleCode") String vehicleCode);
	
	@Query("SELECT m FROM VehicleDetail m WHERE m.isDeleted != TRUE AND m.id = :id")
	public VehicleDetail getVehicleDetailById(@Param("id") Long id);
	
	@Query("SELECT a,b.organizationName,m.modelName,f.fuelTypeName,vdm.driverCode FROM VehicleDetail a, Organization b, MakeModelMapping m,Fuel f,VehicleDriverMapping vdm WHERE a.isDeleted != TRUE AND vdm.isDeleted != TRUE AND a.vehicleCode = vdm.vehicleCode AND b.organizationCode = a.organizationCode AND a.modelCode = m.modelCode AND a.fuelTypeCode = f.fuelTypeCode AND a.organizationCode = :organizationCode")
	public List<Object> getVehicleDetailByOrgCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT a,b.organizationName,m.modelName,f.fuelTypeName,vdm.driverCode FROM VehicleDetail a, Organization b, MakeModelMapping m,Fuel f,VehicleDriverMapping vdm WHERE a.isDeleted != TRUE AND vdm.isDeleted != TRUE AND a.vehicleCode = vdm.vehicleCode AND b.organizationCode = a.organizationCode AND a.modelCode = m.modelCode AND a.fuelTypeCode = f.fuelTypeCode AND a.organizationCode = :organizationCode")
	public List<Object> getVehicleDetailByOrgCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
	
	@Query("SELECT a,vdm.driverCode,m.modelName,f.fuelTypeName FROM VehicleDetail a, MakeModelMapping m,Fuel f,VehicleDriverMapping vdm WHERE a.isDeleted != TRUE AND vdm.isDeleted != TRUE AND a.vehicleCode = vdm.vehicleCode AND a.modelCode = m.modelCode AND a.fuelTypeCode = f.fuelTypeCode AND a.modelCode = :modelCode")
	public List<Object> getVehicleDetailByModelCode(@Param("modelCode") String modelCode);
	
	@Query("SELECT a,vdm.driverCode,m.modelName,f.fuelTypeName FROM VehicleDetail a, MakeModelMapping m,Fuel f,VehicleDriverMapping vdm WHERE a.isDeleted != TRUE AND vdm.isDeleted != TRUE AND a.vehicleCode = vdm.vehicleCode AND a.modelCode = m.modelCode AND a.fuelTypeCode = f.fuelTypeCode AND a.modelCode = :modelCode")
	public List<Object> getVehicleDetailByModelCode(@Param("modelCode") String modelCode,Pageable pageableRequest);
	
//	@Query("SELECT vd FROM VehicleDetail vd WHERE vd.isDeleted != TRUE AND vd.organizationCode = :organizationCode AND vd.vehicleName = :vehicleName")
//	public VehicleDetail getVehicleDetailByOrgCodeAndVehicleName(@Param("organizationCode") String organizationCode, @Param("vehicleName") String vehicleName);
//	
//	@Query("SELECT vd FROM VehicleDetail vd WHERE vd.isDeleted != TRUE AND vd.id != :id AND vd.organizationCode = :organizationCode AND vd.vehicleName = :vehicleName")
//	public VehicleDetail getVehicleDetailByIdOrgCodeAndVehicleName(@Param("id") Long id,@Param("organizationCode") String organizationCode, @Param("vehicleName") String vehicleName);
//	
//	@Query("SELECT vd FROM VehicleDetail vd,VehicleDriverMapping vdm WHERE vd.isDeleted != TRUE AND vdm.isDeleted != TRUE AND vdm.vehicleCode = vd.vehicleCode AND vdm.driverCode = :driverCode AND vd.vehicleName = :vehicleName")
//	public VehicleDetail getVehicleDetailByDriverCodeAndVehicleName(@Param("driverCode") String driverCode, @Param("vehicleName") String vehicleName);
//	
//	@Query("SELECT vd FROM VehicleDetail vd,VehicleDriverMapping vdm WHERE vd.isDeleted != TRUE AND vd.id != :id AND vdm.isDeleted != TRUE AND vdm.vehicleCode = vd.vehicleCode AND vdm.driverCode = :driverCode AND vd.vehicleName = :vehicleName")
//	public VehicleDetail getVehicleDetailByIdDriverCodeAndVehicleName(@Param("id") Long id,@Param("driverCode") String driverCode, @Param("vehicleName") String vehicleName);

	
//	@Query("SELECT vd FROM VehicleDetail vd WHERE vd.isDeleted != TRUE AND vd.organizationCode = :organizationCode AND vd.vehicleName = :vehicleName AND vd.driverCode = :driverCode")
//	public VehicleDetail getVehicleDetailByOrgCodeVehicleNameAndDriverCode(@Param("organizationCode") String organizationCode, @Param("vehicleName") String vehicleName, @Param("driverCode") String driverCode);
//	
//	
//	
//	@Query("SELECT vd FROM VehicleDetail vd WHERE vd.isDeleted != TRUE AND vd.id != :id AND vd.organizationCode = :organizationCode AND vd.vehicleName = :vehicleName AND vd.driverCode = :driverCode")
//	public VehicleDetail getVehicleDetailByIdOrgCodeVehicleNameAndDriverCode(@Param("id") Long id,@Param("organizationCode") String organizationCode, @Param("vehicleName") String vehicleName, @Param("driverCode") String driverCode);
	
	@Query("SELECT a,vdm.driverCode,m.modelName,f.fuelTypeName FROM VehicleDetail a, MakeModelMapping m,Fuel f,VehicleDriverMapping vdm WHERE a.isDeleted != TRUE AND vdm.isDeleted != TRUE AND a.vehicleCode = vdm.vehicleCode AND a.modelCode = m.modelCode AND a.fuelTypeCode = f.fuelTypeCode AND vdm.driverCode = :driverCode")
	public List<Object> getVehicleDetailByDriverCode(@Param("driverCode") String driverCode);
        
        
	@Query("SELECT a,m.modelName FROM VehicleDetail a, MakeModelMapping m,VehicleDriverMapping vdm WHERE a.isDeleted != TRUE AND vdm.isDeleted != TRUE AND a.vehicleCode = vdm.vehicleCode AND a.modelCode = m.modelCode AND vdm.driverCode = :driverCode")
	public List<Object> getVehicleDetailByDriverCodeforMobile(@Param("driverCode") String driverCode);
	
	@Query("SELECT a,vdm.driverCode,m.modelName,f.fuelTypeName FROM VehicleDetail a, MakeModelMapping m,Fuel f,VehicleDriverMapping vdm WHERE a.isDeleted != TRUE AND vdm.isDeleted != TRUE AND a.vehicleCode = vdm.vehicleCode AND a.modelCode = m.modelCode AND a.fuelTypeCode = f.fuelTypeCode AND vdm.driverCode = :driverCode")
	public List<Object> getVehicleDetailByDriverCode(@Param("driverCode") String driverCode,Pageable pageableRequest);

        @Query("SELECT a FROM VehicleDetail a, VehicleDriverMapping vdm WHERE a.isDeleted != TRUE AND vdm.isDeleted != TRUE AND a.vehicleCode = vdm.vehicleCode AND vdm.driverCode = :driverCode")
	public List<VehicleDetail> getVehicleListByDriverCode(@Param("driverCode") String driverCode);
        
        @Query("SELECT vd FROM VehicleDetail vd WHERE vd.isDeleted != TRUE AND vd.vehicleType = :grtc AND  vd.vehicleCode IN(:defoultDriverCodeList)")
        public List<VehicleDetail>  getVehicledetailListByglobalrideTypeCodeAndVehicleCode(@Param("grtc")String grtc,@Param("defoultDriverCodeList") List<String> defoultDriverCodeList);

        @Query("SELECT vd.vehicleCode ,vd.vehicleType,grt.vehicleName FROM VehicleDetail vd,VehicleDriverMapping vdm,GlobalRideType grt WHERE vd.isDeleted != TRUE AND vdm.isDeleted != TRUE AND grt.isDeleted != TRUE AND vd.vehicleCode = vdm.vehicleCode AND vd.vehicleType = grt.globalRideCode AND vdm.driverCode = :driverCode")
        public List<Object> getVehicleTypeDetailByDriverCode(@Param("driverCode") String driverCode);
}  
