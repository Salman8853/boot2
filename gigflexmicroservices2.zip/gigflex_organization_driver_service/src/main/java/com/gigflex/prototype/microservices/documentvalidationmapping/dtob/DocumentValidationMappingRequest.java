package com.gigflex.prototype.microservices.documentvalidationmapping.dtob;


public class DocumentValidationMappingRequest {
	
	private String documentCode;

	private String validationCode;


	public String getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}

	public String getValidationCode() {
		return validationCode;
	}

	public void setValidationCode(String validationCode) {
		this.validationCode = validationCode;
	}

	
}
