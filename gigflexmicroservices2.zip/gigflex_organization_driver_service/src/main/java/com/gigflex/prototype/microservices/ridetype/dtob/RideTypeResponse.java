package com.gigflex.prototype.microservices.ridetype.dtob;


public class RideTypeResponse {

    private Long id;

    private String vehicleCode;

    private String vehicleName;
  // baserate should be Double Type   
    private double baseRate;
   // ratePerMile should be Double Type   
    private double ratePerMile;
    
    private String currencySymbol;
    private String organizationCode;
    
    private String organizationName;
    
    private String globalRidetypeCode;
    
    private String globalRidetypeName;

    public String getGlobalRidetypeCode() {
        return globalRidetypeCode;
    }

    public void setGlobalRidetypeCode(String globalRidetypeCode) {
        this.globalRidetypeCode = globalRidetypeCode;
    }

    public String getGlobalRidetypeName() {
        return globalRidetypeName;
    }

    public void setGlobalRidetypeName(String globalRidetypeName) {
        this.globalRidetypeName = globalRidetypeName;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVehicleCode() {
		return vehicleCode;
	}

	public void setVehicleCode(String vehicleCode) {
		this.vehicleCode = vehicleCode;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

    public double getBaseRate() {
        return baseRate;
    }

    public void setBaseRate(double baseRate) {
        this.baseRate = baseRate;
    }

    public double getRatePerMile() {
        return ratePerMile;
    }

    public void setRatePerMile(double ratePerMile) {
        this.ratePerMile = ratePerMile;
    }

   

    public String getCurrencySymbol() {
        return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }


	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
    
    

}
