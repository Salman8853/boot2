package com.gigflex.prototype.microservices.makemodelmapping.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.makemodelmapping.dtob.MakeModelMappingRequest;
import com.gigflex.prototype.microservices.makemodelmapping.service.MakeModelMappingService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class MakeModelMappingController {

	@Autowired
	public MakeModelMappingService makeModelMappService;

	@GetMapping("/MakeModelMapping/{search}")
	public String search(@PathVariable("search") String search) {
		return makeModelMappService.search(search);
	}

	@GetMapping("/getAllMakeModelMapping")
	public String getAllMakeModelMapping() {
		return makeModelMappService.getAllMakeModelMapping();
	}

	@GetMapping(path = "/getMakeModelMappingByPage")
	public String getMakeModelMappingByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String makeModeMapp = makeModelMappService
				.getAllMakeModelMappingByPage(page, limit);

		return makeModeMapp;

	}

	@GetMapping("/getMakeModelMapping/{id}")
	public String getMakeModelMappingById(@PathVariable Long id) {
		return makeModelMappService.getMakeModelMappingById(id);
	}
	
	@GetMapping("/getByModelCode/{modelCode}")
	public String getByModelCode(@PathVariable String modelCode) {
		return makeModelMappService.getByModelCode(modelCode);
	}
	
	@GetMapping("/getModelByMakeCode/{makeCode}")
	public String getModelByMakeCode(@PathVariable String makeCode) {
		return makeModelMappService.getModelByMakeCode(makeCode);
	}
	
	@GetMapping("/getModelByMakeCodeByPage/{makeCode}")
	public String getModelByMakeCodeByPage(@PathVariable String makeCode,@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String makeModeMapp = makeModelMappService.getModelByMakeCodeByPage(makeCode, page, limit);
		
		return makeModeMapp;

	}

	@PostMapping("/saveMakeModelMapping")
	public String saveMakeModelMapping(
			@RequestBody MakeModelMappingRequest makeModelMapReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return makeModelMappService
				.saveNewMakeModelMapping(makeModelMapReq, ip);

	}

	@PutMapping("/updateMakeModelMapping/{id}")
	public String updateMakeModelMapping(@PathVariable Long id,
			@RequestBody MakeModelMappingRequest makeModelMapReq,
			HttpServletRequest request) {

		if (id == null) {
			return "MakeModelMapping with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return makeModelMappService.updateMakeModelMappingById(id,
					makeModelMapReq, ip);

		}

	}

	@DeleteMapping("/softDeleteMakeModelMappingByModelCode/{modelCode}")
	public String softDeleteMakeModelMappingByModelCode(@PathVariable String modelCode) {
		return makeModelMappService.softDeleteMakeModelMappingByModelCode(modelCode);
	}

	@DeleteMapping("/softMultipleDeleteByModelCode/{modelCodeList}")
	public String softMultipleDeleteByModelCode(
			@PathVariable("modelCodeList") List<String> modelCodeList) {
		if (modelCodeList != null && modelCodeList.size() > 0) {
			return makeModelMappService.softMultipleDeleteByModelCode(modelCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}
	}

}
