/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.repository;

import com.gigflex.prototype.microservices.driver.dtob.DriverRegistrationOTPDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Abhishek
 */
@Repository
public interface DriverRegistrationOTPRepository extends JpaRepository<DriverRegistrationOTPDetail, Long>,JpaSpecificationExecutor<DriverRegistrationOTPDetail> {
   @Query("SELECT drvotpdetail FROM DriverRegistrationOTPDetail drvotpdetail WHERE drvotpdetail.emailID = :emailID  AND drvotpdetail.tokenID = :tokenID")
   public DriverRegistrationOTPDetail getDriverRegistrationOTPDetail(@Param("emailID") String emailID,@Param("tokenID") String tokenID);
}
