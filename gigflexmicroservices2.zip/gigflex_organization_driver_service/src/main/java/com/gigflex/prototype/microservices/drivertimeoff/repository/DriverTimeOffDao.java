/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.drivertimeoff.repository;

import com.gigflex.prototype.microservices.drivertimeoff.dtob.DriverTimeOff;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface DriverTimeOffDao extends JpaRepository<DriverTimeOff,Long>,JpaSpecificationExecutor<DriverTimeOff>{

    @Query("SELECT dt FROM DriverTimeOff dt WHERE dt.isDeleted != TRUE")
    public List<DriverTimeOff> getAllDriverTimeOff();

    @Query("SELECT dt FROM DriverTimeOff dt WHERE dt.isDeleted != TRUE AND dt.driverCode = :driverCode")
    public List<DriverTimeOff> getTimeOffByDriverCode(@Param("driverCode") String driverCode);

//    @Query("SELECT dt FROM DriverTimeOff dt WHERE dt.isDeleted != TRUE AND dt.driverCode = :driverCode AND ( ((:fromDate >= dt.fromTimeOffDate   AND :fromDate <= dt.toTimeOffDate )  OR (:toDate >= dt.fromTimeOffDate AND :toDate <= dt.toTimeOffDate)) OR (:fromDate < dt.fromTimeOffDate AND :toDate > dt.toTimeOffDate ))")
    @Query("SELECT dt FROM DriverTimeOff dt WHERE dt.isDeleted != TRUE AND dt.driverCode = :driverCode AND ( ((:fromDate >= dt.fromDate   AND :fromDate <= dt.toDate )  OR (:toDate >= dt.fromDate AND :toDate <= dt.toDate)) OR (:fromDate < dt.fromDate AND :toDate > dt.toDate ))")
    public List<DriverTimeOff> getTimeOffByDriverCodeAndBetweenDate(@Param("driverCode") String driverCode,@Param("fromDate") Date fromdate,@Param("toDate") Date toDate);

    @Query("SELECT dt FROM DriverTimeOff dt WHERE dt.isDeleted != TRUE AND dt.driverTimeoffCode = :driverTimeoffCode")
    public DriverTimeOff getDriverTimeOffByTimeOffCode(@Param("driverTimeoffCode") String driverTimeoffCode);

    @Query("SELECT dt FROM DriverTimeOff dt WHERE dt.isDeleted != TRUE AND dt.organizationCode = :organizationCode")
    public List<DriverTimeOff> getTimeOffByOrganizationCode(@Param("organizationCode") String organizationCode);

    
}
