package com.gigflex.prototype.microservices.organization.service;

import com.gigflex.prototype.microservices.organization.dtob.OrganizationRequest;

public interface OrganizationService {
	
	public String getOrganizationByOrgCode(String organizationCode);
    public String updateOrganization(String organizationCode,OrganizationRequest orgReq,String ip);


}
