package com.gigflex.prototype.microservices.driver.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.driver.dtob.VehicleDriverMapping;

public interface VehicleDriverMappingRepository extends JpaRepository<VehicleDriverMapping, Long>{
	
	@Query("SELECT m FROM VehicleDriverMapping m WHERE m.isDeleted != TRUE AND m.driverCode = :driverCode AND m.vehicleCode = :vehicleCode")
	public VehicleDriverMapping getVehicleDriverMappingByDriverCodeAndVehicleCode(@Param("driverCode") String driverCode,@Param("vehicleCode") String vehicleCode);
	
	@Query("SELECT m FROM VehicleDriverMapping m WHERE m.isDeleted != TRUE AND m.id != :id AND m.driverCode = :driverCode AND m.vehicleCode = :vehicleCode")
	public VehicleDriverMapping getVehicleDriverMappingByDriverCodeAndVehicleCodeById(@Param("id") Long id,@Param("driverCode") String driverCode,@Param("vehicleCode") String vehicleCode);

	@Query("SELECT m FROM VehicleDriverMapping m WHERE m.isDeleted != TRUE AND m.driverCode = :driverCode")
	public List<VehicleDriverMapping> getVehicleDriverMappingByDriverCode(@Param("driverCode") String driverCode);
	
	@Query("SELECT m FROM VehicleDriverMapping m WHERE m.isDeleted != TRUE AND m.vehicleCode = :vehicleCode")
	public VehicleDriverMapping getVehicleDriverMappingByVehicleCode(@Param("vehicleCode") String vehicleCode);
}
