/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentExpirationByDriver;
import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocResponse;
import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocument;
import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocumentRequest;
import com.gigflex.prototype.microservices.documentmapping.dtob.OperatorDocument;
import com.gigflex.prototype.microservices.documentmapping.dtob.OperatorDocumentRequest;
import com.gigflex.prototype.microservices.documentmapping.repository.DriverDocumentRepository;
import com.gigflex.prototype.microservices.documentmapping.service.DriverDocumentService;
import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetail;
import com.gigflex.prototype.microservices.documenttypedetail.repository.DocumentTypeDetailRepository;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.globalsetting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.notification.dtob.Notification;
import com.gigflex.prototype.microservices.notification.service.NotificationService;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.usertype.dtob.UserType;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.utility.GigflexDateUtil;

/**
 *
 * @author nirbhay.p
 */
@Service
public class DriverDocumentServiceImpl implements DriverDocumentService {

	@Autowired
	DriverDocumentRepository driverDocumentRepository;
	
	@Autowired
	UserTypeRepository userTypeRepository;

	@Autowired
	DriverRepository driverRepository;

	@Autowired
	DocumentTypeDetailRepository documentTypeDetailRepository;

	@Autowired
	private OrganizationRepository orgDao;
	@Autowired
	OperatorRepository operatorRepository;
	@Autowired
	KafkaService kafkaService;

	@Autowired
	NotificationService notificationService;
        
        @Autowired
        GlobalSettingRepository globalSettingRepository;
    
        @Autowired
        LocalSettingRepository localSettingRepository;
        
        @Autowired
	private TimeZoneRepository timeZoneRepository;
        
	
	String  shortMessage;

	@Override
	public String getAllDriverDocument() {
//        
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//			List<DriverDocument> docTypeLst = driverDocumentRepository.getAllDriverDocument();
//			if (docTypeLst != null && docTypeLst.size() > 0) {
//				jsonobj.put("responsecode", 200);
//				jsonobj.put("message", "Success");
//				jsonobj.put("timestamp", new Date());
//				ObjectMapper mapperObj = new ObjectMapper();
//				String Detail = mapperObj.writeValueAsString(docTypeLst);
//				jsonobj.put("data", new JSONArray(Detail));
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("message", "Record Not Found.");
//				jsonobj.put("timestamp", new Date());
//			}
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception occurred.");
//			res = derr.toString();
//		}
//                catch (Exception  ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"Exception occurred.");
//			res = derr.toString();
//		}
//		return res;

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = driverDocumentRepository.getAllDriverDocument();
			List<DriverDocResponse> maplst = new ArrayList<DriverDocResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						DriverDocResponse ddr = new DriverDocResponse();

						DriverDocument data = (DriverDocument) arr[0];

						String conDt = "";
                                                String dtFormat = "";
                                                String dateformat ="";
                                                String timeformat ="";

						if (data.getDocExpiration() != null) {
							
                                                    Driver driver = driverRepository.getDriverByDriverCode(data.getDriverCode());
                                                    String organizationCode = driver.getOrganizationCode();   

                                                    dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                    dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, organizationCode, GigflexConstants.DATEFORMAT);
                                                    timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, organizationCode, GigflexConstants.TIMEFORMAT);
                                                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                    {
                                                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                    }                

                                                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, organizationCode, GigflexConstants.TimeZone);
                                                    TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                                    String timezone = tz.getTimeZoneName(); 
                                                    
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        Date docExpDate = data.getDocExpiration();
                                                        docExpDate = GigflexDateUtil.getGMTtoLocationDate(docExpDate, timezone,dtFormat);
                                                        conDt = GigflexDateUtil.convertDateToString(docExpDate,dtFormat);
                                                    }
                                                    
						}

                                                ddr.setDateFormat(dateformat);
                                                ddr.setTimeFormat(timeformat);
						ddr.setId(data.getId());
						ddr.setDriverDocumentCode(data.getDriverDocumentCode());
						ddr.setDocumentCode(data.getDocumentCode());
						ddr.setDriverCode(data.getDriverCode());
						ddr.setDocValue(data.getDocValue());
						ddr.setDocExpiration(conDt);

						ddr.setDocumentName((String) arr[1]);
						ddr.setDriverName((String) arr[2]);

						maplst.add(ddr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	
        
        @Override
	public String getAllDriverDocumentByDriverCode(String driverCode) {
//      String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//			List<DriverDocument> docTypeLst = driverDocumentRepository.getAllDriverDocumentByDriverCode(driverCode);
//			if (docTypeLst != null && docTypeLst.size() > 0) {
//				jsonobj.put("responsecode", 200);
//				jsonobj.put("message", "Success");
//				jsonobj.put("timestamp", new Date());
//				ObjectMapper mapperObj = new ObjectMapper();
//				String Detail = mapperObj.writeValueAsString(docTypeLst);
//				jsonobj.put("data", new JSONArray(Detail));
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("message", "Record Not Found.");
//				jsonobj.put("timestamp", new Date());
//			}
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception occurred.");
//			res = derr.toString();
//		}
//                catch (Exception  ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"Exception occurred.");
//			res = derr.toString();
//		}
//		return res;

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = driverDocumentRepository.getAllDriverDocumentByDriverCode(driverCode);
			List<DriverDocResponse> maplst = new ArrayList<DriverDocResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                            String dateformat = "";
                            String timeformat = "";
                            String timezoneCode = "";
                            TimeZoneDetail tz = null;
                            String timezone = "";
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;

                            Driver driver = driverRepository.getDriverByDriverCode(driverCode);
                            String organizationCode = driver.getOrganizationCode();   


                            dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.DATEFORMAT);
                            timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TIMEFORMAT);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TimeZone);
                            tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            timezone = tz.getTimeZoneName();   
                            
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						DriverDocResponse ddr = new DriverDocResponse();

						DriverDocument data = (DriverDocument) arr[0];
						String conDt = "";

						if (data.getDocExpiration() != null) {
//							TimeZoneDetail tz = driverDocumentRepository.getTimeZoneByDriverCode(data.getDriverCode());
						    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        Date docExpDate = data.getDocExpiration();
							docExpDate = GigflexDateUtil.getGMTtoLocationDate(docExpDate, timezone,dtFormat);
							conDt = GigflexDateUtil.convertDateToString(docExpDate,dtFormat);
                                                    }
                                                        
						}

                                                ddr.setDateFormat(dateformat);
                                                ddr.setTimeFormat(timeformat);
						ddr.setId(data.getId());
						ddr.setDriverDocumentCode(data.getDriverDocumentCode());
						ddr.setDocumentCode(data.getDocumentCode());
						ddr.setDriverCode(data.getDriverCode());
						ddr.setDocValue(data.getDocValue());
						ddr.setDocExpiration(conDt);

						ddr.setDocumentName((String) arr[1]);
						ddr.setDriverName((String) arr[2]);

						maplst.add(ddr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDriverDocumentByDriverDocumentCode(String driverDocumentCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			DriverDocument docTypeLst = driverDocumentRepository
					.getDriverDocumentByDriverDocumentCode(driverDocumentCode);
                        
                        if(docTypeLst != null && docTypeLst.getId() > 0)
                        {
                            
                           DriverDocResponse ddr = new DriverDocResponse();
                        
                           String dateformat = "";
                           String timeformat = "";
                           String conDt = "";
                           if (docTypeLst.getDocExpiration() != null) {
					
                                
                                String timezoneCode = "";
                                TimeZoneDetail tz = null;
                                String timezone = "";
                                String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;

                                Driver driver = driverRepository.getDriverByDriverCode(docTypeLst.getDriverCode());
                                String organizationCode = driver.getOrganizationCode();   


                                dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.userTypeDriver, driver.getDriverCode(), GigflexConstants.DATEFORMAT);
                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.userTypeDriver, driver.getDriverCode(), GigflexConstants.TIMEFORMAT);
                                if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=dateformat.trim()+" "+timeformat.trim();
                                }                

                                timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.userTypeDriver, driver.getDriverCode(), GigflexConstants.TimeZone);
                                tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                timezone = tz.getTimeZoneName();  

                                if(timezone!=null && timezone.length()>0 )
                                {
                                    Date docExpDate = docTypeLst.getDocExpiration();
                                    docExpDate = GigflexDateUtil.getGMTtoLocationDate(docExpDate, timezone,dtFormat);
                                    conDt = GigflexDateUtil.convertDateToString(docExpDate,dtFormat);
                                }

                            }

                            ddr.setDateFormat(dateformat);
                            ddr.setTimeFormat(timeformat);
                            ddr.setId(docTypeLst.getId());
                            ddr.setDriverDocumentCode(docTypeLst.getDriverDocumentCode());
                            ddr.setDocumentCode(docTypeLst.getDocumentCode());
                            ddr.setDriverCode(docTypeLst.getDriverCode());
                            ddr.setDocValue(docTypeLst.getDocValue());
                            ddr.setDocExpiration(conDt);

                           
                            if (ddr != null && ddr.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(ddr);
				jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("message", "Record Not Found.");
                                jsonobj.put("timestamp", new Date());
                            }
                            
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Record Not Found.");
                            jsonobj.put("timestamp", new Date());
                        }                        
			
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softDeleteDriverDocumentByDriverDocumentCode(String driverDocumentCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			DriverDocument docTypeLst = driverDocumentRepository
					.getDriverDocumentByDriverDocumentCode(driverDocumentCode);

			if (docTypeLst != null && docTypeLst.getId() > 0) {
				docTypeLst.setIsDeleted(true);
				DriverDocument docTypeRes = driverDocumentRepository.save(docTypeLst);
				if (docTypeRes != null && docTypeRes.getId() > 0) {
					kafkaService.sendDriverDocumentForUpdate(docTypeRes);

				try {
 
					Driver driver = driverRepository.getDriverByDriverCode(docTypeRes.getDriverCode());
					if(driver != null && driver.getId() > 0){
						
					Notification notification = new Notification();

					String bodyContent = "Dear Operator"
							+ ",Driver Document has been deleted."
							+ "Driver Name : " + driver.getName();
					shortMessage = "Driver Document has been deleted.";

					notification.setUserCode(driver.getOperatorCode());
					
					notification.setMessage(bodyContent);
					notification.setShortMessage(shortMessage);
					notification.setIsRead(Boolean.FALSE);

					notificationService.saveNotification(notification);
					}
					
				}

				catch (Exception e) {
					e.printStackTrace();
				}
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Driver Document has been deleted successfully.");
					// kafkaService.sendRoleMasterUpdate(roleRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteDriverDocumentByDriverDocumentCode(List<String> driverDocumentCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String driverDocumentCode : driverDocumentCodeList) {
				if (driverDocumentCode != null && driverDocumentCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					driverDocumentCode = driverDocumentCode.trim();

					DriverDocument docTypeLst = driverDocumentRepository
							.getDriverDocumentByDriverDocumentCode(driverDocumentCode);

					if (docTypeLst != null && docTypeLst.getId() > 0) {

						docTypeLst.setIsDeleted(true);
						DriverDocument docTypeRes = driverDocumentRepository.save(docTypeLst);
						if (docTypeRes != null && docTypeRes.getId() > 0) {
							kafkaService.sendDriverDocumentForUpdate(docTypeRes);
							
							try {
								 
								Driver driver = driverRepository.getDriverByDriverCode(docTypeRes.getDriverCode());
								if(driver != null && driver.getId() > 0){
									
								Notification notification = new Notification();

								String bodyContent = "Dear Operator"
										+ ",Driver Document has been deleted."
										+ "Driver Name : " + driver.getName();
								shortMessage = "Driver Document has been deleted.";

								notification.setUserCode(driver.getOperatorCode());
								
								notification.setMessage(bodyContent);
								notification.setShortMessage(shortMessage);
								notification.setIsRead(Boolean.FALSE);

								notificationService.saveNotification(notification);
								}
								
							}

							catch (Exception e) {
								e.printStackTrace();
							}
							
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", driverDocumentCode);
							jsonobj.put("message", "Driver Document has been deleted successfully.");
							// kafkaService.se
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", driverDocumentCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", driverDocumentCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Multiple delete failed.");
				res = derr.toString();
			}
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveDriverDocument(DriverDocumentRequest driDetReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (driDetReq != null) {
				DocumentTypeDetail dtd = documentTypeDetailRepository
						.getDocumentTypeDetailByDocumentCode(driDetReq.getDocumentCode());
				if (dtd != null && dtd.getId() > 0) {
					Driver otr = driverRepository.getDriverByDriverCode(driDetReq.getDriverCode());
					if (otr != null && otr.getId() > 0) {
						DriverDocument dridoc = driverDocumentRepository.getDriverDocumentByDriverCodeDocumentCode(
								driDetReq.getDocumentCode(), driDetReq.getDriverCode());

						if (dridoc != null && dridoc.getId() > 0) {
							jsonobj.put("responsecode", 409);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Record already exist.");
						} else {

							DriverDocument dd = new DriverDocument();
//                    Date expdt=null;
//                    if(driDetReq.getDocExpiration()!=null && driDetReq.getDocExpiration().trim().length()>0)
//                    {
//                    try {
//				expdt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse( driDetReq.getDocExpiration().trim());
//                                if(expdt==null )
//                                {
//                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
//						"Plz send expiration date in correct format(yyyy-MM-dd HH:mm:ss) ");
//				return derr.toString();
//                                }
//			} catch (Exception ex) {
//				ex.printStackTrace();
//				GigflexResponse derr = new GigflexResponse(400, new Date(),
//						"Plz send expiration date in correct format(yyyy-MM-dd HH:mm:ss) ");
//				return derr.toString();
//			}
//                    }

							Date expdt = null;
							try {
								expdt = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
										.parse(driDetReq.getDocExpiration().trim());
								if (expdt == null) {
									GigflexResponse derr = new GigflexResponse(400, new Date(),
											"Plz send date in correct format(" + GigflexConstants.dateFormatterForSave
													+ ") ");
									return derr.toString();
								}

							} catch (Exception ex) {
								ex.printStackTrace();
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Plz send date in correct format(" + GigflexConstants.dateFormatterForSave
												+ ") ");
								return derr.toString();
							}
String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, otr.getOrganizationCode(), GigflexConstants.TimeZone);
TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
String timezone = tz.getTimeZoneName(); 
tz = driverDocumentRepository
.getTimeZoneByDriverCode(driDetReq.getDriverCode());
Date docExptime = GigflexDateUtil.convertStringDateToGMT(
driDetReq.getDocExpiration().trim(), timezone,
GigflexConstants.dateFormatterForSave);
							if (docExptime == null) {
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Date conversion has been failed.");
								return derr.toString();
							}
							dd.setDocExpiration(docExptime);
							dd.setDocValue(driDetReq.getDocValue());
							dd.setDocumentCode(driDetReq.getDocumentCode());
							dd.setDriverCode(driDetReq.getDriverCode());

							dd.setIpAddress(ip);

							DriverDocument ddRes = driverDocumentRepository.save(dd);

							if (ddRes != null && ddRes.getId() > 0) {
								kafkaService.sendDriverDocumentForSave(ddRes);
								
								try {
									 
									Driver driver = driverRepository.getDriverByDriverCode(driDetReq.getDriverCode());
									if(driver != null && driver.getId() > 0){
										
									Notification notification = new Notification();

									String bodyContent = "Dear Operator"
											+ ",Driver Document has been added."
											+ "Driver Name : " + driver.getName();
									shortMessage = "Driver Document has been added.";

									notification.setUserCode(driver.getOperatorCode());
									notification.setIpAddress(ip);
									notification.setMessage(bodyContent);
									notification.setShortMessage(shortMessage);
									notification.setIsRead(Boolean.FALSE);

									notificationService.saveNotification(notification);
									}
									
								}

								catch (Exception e) {
									e.printStackTrace();
								}
								
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Driver Document has been added successfully.");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(ddRes);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Failed");
							}
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Driver does not exist.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Document Code is not valid.");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateDriverDocument(String driverDocumentCode, DriverDocumentRequest driDetReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			DocumentTypeDetail dtd = documentTypeDetailRepository
					.getDocumentTypeDetailByDocumentCode(driDetReq.getDocumentCode());
			if (dtd != null && dtd.getId() > 0) {
				Driver otr = driverRepository.getDriverByDriverCode(driDetReq.getDriverCode());
				if (otr != null && otr.getId() > 0) {

					DriverDocument ddoc = driverDocumentRepository
							.getDriverDocumentByDriverDocumentCode(driverDocumentCode);
					if (ddoc != null && ddoc.getId() > 0) {

						DriverDocument dd = driverDocumentRepository.getDriverDocumentByDriverCodeDocumentCodeNotInCode(
								driverDocumentCode, driDetReq.getDocumentCode(), driDetReq.getDriverCode());

						if (dd != null && dd.getId() > 0) {
							jsonobj.put("responsecode", 409);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Record already exist.");
						} else {
//
//                    Date expdt=null;
//                    if(driDetReq.getDocExpiration()!=null && driDetReq.getDocExpiration().trim().length()>0)
//                    {
//                    try {
//				expdt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse( driDetReq.getDocExpiration().trim());
//                                if(expdt==null )
//                                {
//                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
//						"Plz send expiration date in correct format(yyyy-MM-dd HH:mm:ss) ");
//				return derr.toString();
//                                }
//			} catch (Exception ex) {
//				ex.printStackTrace();
//				GigflexResponse derr = new GigflexResponse(400, new Date(),
//						"Plz send expiration date in correct format(yyyy-MM-dd HH:mm:ss) ");
//				return derr.toString();
//			}
//                    }
							Date expdt = null;
							try {
								expdt = new SimpleDateFormat(GigflexConstants.dateFormatterForSave)
										.parse(driDetReq.getDocExpiration().trim());
								if (expdt == null) {
									GigflexResponse derr = new GigflexResponse(400, new Date(),
											"Plz send date in correct format(" + GigflexConstants.dateFormatterForSave
													+ ") ");
									return derr.toString();
								}

							} catch (Exception ex) {
								ex.printStackTrace();
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Plz send date in correct format(" + GigflexConstants.dateFormatterForSave
												+ ") ");
								return derr.toString();
							}
							String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, otr.getOrganizationCode(), GigflexConstants.TimeZone);
TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
String timezone = tz.getTimeZoneName(); 
tz = driverDocumentRepository
.getTimeZoneByDriverCode(driDetReq.getDriverCode());
Date docExptime = GigflexDateUtil.convertStringDateToGMT(
driDetReq.getDocExpiration().trim(), timezone,
GigflexConstants.dateFormatterForSave);
							if (docExptime == null) {
								GigflexResponse derr = new GigflexResponse(400, new Date(),
										"Date conversion has been failed.");
								return derr.toString();
							}
							ddoc.setDocExpiration(docExptime);
							ddoc.setDocValue(driDetReq.getDocValue());
							ddoc.setDocumentCode(driDetReq.getDocumentCode());
							ddoc.setDriverCode(driDetReq.getDriverCode());

							ddoc.setIpAddress(ip);

							DriverDocument ddRes = driverDocumentRepository.save(ddoc);
							if (ddRes != null && ddRes.getId() > 0) {
								kafkaService.sendDriverDocumentForUpdate(ddRes);
								
								try {
									 
									Driver driver = driverRepository.getDriverByDriverCode(driDetReq.getDriverCode());
									if(driver != null && driver.getId() > 0){
										
									Notification notification = new Notification();

									String bodyContent = "Dear Operator"
											+ ",Driver Document has been updated."
											+ "Driver Name : " + driver.getName();
									shortMessage = "Driver Document has been updated.";

									notification.setUserCode(driver.getOperatorCode());
									notification.setIpAddress(ip);
									notification.setMessage(bodyContent);
									notification.setShortMessage(shortMessage);
									notification.setIsRead(Boolean.FALSE);

									notificationService.saveNotification(notification);
									}
									
								}

								catch (Exception e) {
									e.printStackTrace();
								}
								
								jsonobj.put("responsecode", 200);
								jsonobj.put("message", "Driver Document has been updated");
								jsonobj.put("timestamp", new Date());
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(ddRes);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("message", "Driver Document updation has been failed.");
								jsonobj.put("timestamp", new Date());
							}
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Driver Document Code is not valid.");
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Driver does not exist.");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Document Code is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllDriverDocument(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<Object> objlst = driverDocumentRepository.getAllDriverDocument(pageableRequest);
			List<DriverDocResponse> maplst = new ArrayList<DriverDocResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						DriverDocResponse ddr = new DriverDocResponse();

						DriverDocument data = (DriverDocument) arr[0];
						String conDt = "";
                                                String dtFormat = "";
                                                String dateformat ="";
                                                String timeformat ="";
                                                
						if (data.getDocExpiration() != null) {
                                                    
                                                    
                                                    Driver driver = driverRepository.getDriverByDriverCode(data.getDriverCode());
                                                    String organizationCode = driver.getOrganizationCode();   

                                                    dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;
                                                    dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.userTypeDriver, data.getDriverCode(), GigflexConstants.DATEFORMAT);
                                                    timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.userTypeDriver, data.getDriverCode(), GigflexConstants.TIMEFORMAT);
                                                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                                    {
                                                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                                                    }                

                                                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.userTypeDriver, data.getDriverCode(), GigflexConstants.TimeZone);
                                                    TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                                    String timezone = tz.getTimeZoneName(); 
                                                    
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        Date docExpDate = data.getDocExpiration();
							docExpDate = GigflexDateUtil.getGMTtoLocationDate(docExpDate, timezone,dtFormat);
							conDt = GigflexDateUtil.convertDateToString(docExpDate,dtFormat);
                                                    }
						}
                                                
                                                ddr.setDateFormat(dateformat);
                                                ddr.setTimeFormat(timeformat);
						ddr.setId(data.getId());
						ddr.setDriverDocumentCode(data.getDriverDocumentCode());
						ddr.setDocumentCode(data.getDocumentCode());
						ddr.setDriverCode(data.getDriverCode());
						ddr.setDocValue(data.getDocValue());
						ddr.setDocExpiration(conDt);

						ddr.setDocumentName((String) arr[1]);
						ddr.setDriverName((String) arr[2]);

						maplst.add(ddr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllDriverDocumentByDriverCode(String driverCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<Object> objlst = driverDocumentRepository.getAllDriverDocumentByDriverCode(driverCode,
					pageableRequest);
			List<DriverDocResponse> maplst = new ArrayList<DriverDocResponse>();
			if (objlst != null && objlst.size() > 0) {
                            
                            
                            String dateformat = "";
                            String timeformat = "";
                            String timezoneCode = "";
                            TimeZoneDetail tz = null;
                            String timezone = "";
                            String dtFormat=GigflexConstants.YYYY_MM_DD_HH_MM_SS;

                            Driver driver = driverRepository.getDriverByDriverCode(driverCode);
                            String organizationCode = driver.getOrganizationCode();   


                            dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.DATEFORMAT);
                            timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TIMEFORMAT);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.userTypeDriver, driverCode, GigflexConstants.TimeZone);
                            tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            timezone = tz.getTimeZoneName();   
                            
                            
                            
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						DriverDocResponse ddr = new DriverDocResponse();

						DriverDocument data = (DriverDocument) arr[0];
						String conDt = "";

						if (data.getDocExpiration() != null) {
//							TimeZoneDetail tz = driverDocumentRepository.getTimeZoneByDriverCode(data.getDriverCode());
							
                                                    if(timezone!=null && timezone.length()>0 )
                                                    {
                                                        Date docExpDate = data.getDocExpiration();
							docExpDate = GigflexDateUtil.getGMTtoLocationDate(docExpDate, timezone,dtFormat);
							conDt = GigflexDateUtil.convertDateToString(docExpDate,dtFormat);
                                                    }
                                                        
						}

                                                ddr.setDateFormat(dateformat);
                                                ddr.setTimeFormat(timeformat);
						ddr.setId(data.getId());
						ddr.setDriverDocumentCode(data.getDriverDocumentCode());
						ddr.setDocumentCode(data.getDocumentCode());
						ddr.setDriverCode(data.getDriverCode());
						ddr.setDocValue(data.getDocValue());
						ddr.setDocExpiration(conDt);

						ddr.setDocumentName((String) arr[1]);
						ddr.setDriverName((String) arr[2]);

						maplst.add(ddr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDocumentExpirationByDriverCode(String driverCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Driver dr = driverRepository.getDriverByDriverCode(driverCode);
			if (dr != null && dr.getId() > 0) {
				Date curDT = new Date();
				DocumentExpirationByDriver dres = new DocumentExpirationByDriver();
				dres.setIsExpired(Boolean.FALSE);
				List<DriverDocument> ddlst = driverDocumentRepository.getExpiredDriverDocumentByDriverCode(driverCode,
						curDT);
				if (ddlst != null && ddlst.size() > 0) {
					dres.setIsExpired(Boolean.TRUE);
					dres.setDriver(dr);
				}
				List<OperatorDocument> odlst = driverDocumentRepository
						.getExpiredOperatorDocumentByOperatorCode(dr.getOperatorCode(), curDT);
                                
				if (odlst != null && odlst.size() > 0) {
					dres.setIsExpired(Boolean.TRUE);
					Operator or = operatorRepository.getOperatorByOperatorCode(dr.getOperatorCode());
					if (or != null && or.getId() > 0) {
						dres.setOperator(or);
					}
				}
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(dres);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Driver does not exist.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

}
