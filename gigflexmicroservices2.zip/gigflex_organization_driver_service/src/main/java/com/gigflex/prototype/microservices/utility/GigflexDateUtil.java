/**
 * 
 */
package com.gigflex.prototype.microservices.utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import com.gigflex.prototype.microservices.util.GigflexConstants;

public class GigflexDateUtil {
	public static String converDateToString(Date date) {
		DateFormat dateFormat = new SimpleDateFormat(GigflexConstants.dateFormatterForView);
		String strDate = dateFormat.format(date);
		return strDate;
		
	}
        
        public static Date convertStringToDate(String startDate, String format){ //throws Exception {

            Date date = null;
            try
            {
               date = new SimpleDateFormat(format).parse(startDate);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
		
	   return date;
	}
	
	public static Date convertStringToDate(String DateStr) {
	
    Date date = null;
	try {
		date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(DateStr);
	} catch (ParseException e) {
		
		e.printStackTrace();
	}  
    return date;
	}
	
	public static void main(String[] args) {
		
		Date date = GigflexDateUtil.getCurrentDate(new Date());
		System.out.println(date);
		
		
	}
	public static Date getCurrentDate(Date date) {

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		Date month = cal.getTime();

		return month;
		}
		
//	public static Date newDate(){
//		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss") ;
//		String x="2018-12-09 09:10:33";
//
//		Date date = new Date() ;
//		String format = dateFormat.format(date);
//		System.out.println(format);
//		
//	}
        
       
        
	public static Date convertStringDateToGMT(String dateInfo,String timezone,String dateFormate){
        Date utilDate=null;
        try{
            if(dateInfo!=null && timezone!=null){
            LocalDateTime ldt = LocalDateTime.parse(dateInfo,DateTimeFormatter.ofPattern(dateFormate)); 
            ZoneId z = ZoneId.of(timezone);
            ZonedDateTime zdt = ldt.atZone( z );
            utilDate=Date.from(zdt.toInstant());
            System.out.println("==utilDate==="+utilDate);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return utilDate;
    }
    
   public static Date getGMTtoLocationDate(Date d1,String timezone,String dateFormat) throws Exception{
       DateTimeFormatter format = null;
       ZonedDateTime zdt = null;
       try {
           format = DateTimeFormatter.ofPattern(dateFormat);
           // DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
           Instant instant = d1.toInstant();
           ZoneId z = ZoneId.of(timezone);
           LocalDateTime ldt = instant.atZone(z).toLocalDateTime();
           zdt = ldt.atZone(ZoneId.of(timezone));
           System.out.println("====formated date====" + format.format(zdt));
       } catch (Exception e) {
           e.printStackTrace();
       }

       return new SimpleDateFormat(dateFormat).parse(format.format(zdt));
   }
   
       public static String convertDateToString(Date date, String format) {//throws Exception {

		String strdate = null;
                try{
               strdate= new SimpleDateFormat(format).format(date);
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
		return strdate;
	}
       
        public static boolean isDate(String date, String dateformat) {
        if (date == null) {
            return false;
        }
        //set the format to use as a constructor argument
        SimpleDateFormat sdf = new SimpleDateFormat(dateformat);
        if (date.trim().length() != sdf.toPattern().length()) {
            return false;
        }

        sdf.setLenient(false);

        try {
            sdf.parse(date.trim());
        } catch (ParseException pe) {
            pe.printStackTrace();
            return false;
        }
        return true;
    }
}
