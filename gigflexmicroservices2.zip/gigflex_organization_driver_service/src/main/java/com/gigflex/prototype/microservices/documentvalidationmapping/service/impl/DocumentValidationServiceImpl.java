package com.gigflex.prototype.microservices.documentvalidationmapping.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetail;
import com.gigflex.prototype.microservices.documenttypedetail.repository.DocumentTypeDetailRepository;
import com.gigflex.prototype.microservices.documentvalidationmapping.dtob.DocmentValidationResponse;
import com.gigflex.prototype.microservices.documentvalidationmapping.dtob.DocumentValidationMapping;
import com.gigflex.prototype.microservices.documentvalidationmapping.dtob.DocumentValidationMappingRequest;
import com.gigflex.prototype.microservices.documentvalidationmapping.repository.DocumentValidationMappingRepository;
import com.gigflex.prototype.microservices.documentvalidationmapping.search.DocumentValidationMappingSpecificationsBuilder;
import com.gigflex.prototype.microservices.documentvalidationmapping.service.DocumentValidationService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.validation.dtob.Validation;
import com.gigflex.prototype.microservices.validation.repository.ValidationRepository;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

@Service
public class DocumentValidationServiceImpl implements DocumentValidationService {

	@Autowired
	DocumentValidationMappingRepository documentValidationMappingDao;

	@Autowired
	DocumentTypeDetailRepository dtdRep;

	@Autowired
	ValidationRepository validationRep;

	@Override
	public String getAllDocumentValidationMapping() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = documentValidationMappingDao.getAllDocumentValidationMapping();
			List<DocmentValidationResponse> maplst = new ArrayList<DocmentValidationResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						DocmentValidationResponse dvr = new DocmentValidationResponse();

						DocumentValidationMapping data = (DocumentValidationMapping) arr[0];

						dvr.setId(data.getId());
						dvr.setDocumentValidationCode(data.getDocumentValidationCode());
						dvr.setDocumentCode(data.getDocumentCode());
						dvr.setDocumentName((String) arr[1]);
						dvr.setValidationCode(data.getValidationCode());
						dvr.setValidationName((String) arr[2]);

						maplst.add(dvr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDocumentValidationMappingById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Object objlst = documentValidationMappingDao.getDocumentValidationMappingById(id);
			if (objlst != null) {
				Object[] arr = (Object[]) objlst;
				if (arr.length >= 3) {

					DocmentValidationResponse dvr = new DocmentValidationResponse();

					DocumentValidationMapping data = (DocumentValidationMapping) arr[0];

					dvr.setId(data.getId());
					dvr.setDocumentValidationCode(data.getDocumentValidationCode());
					dvr.setDocumentCode(data.getDocumentCode());
					dvr.setDocumentName((String) arr[1]);
					dvr.setValidationCode(data.getValidationCode());
					dvr.setValidationName((String) arr[2]);

					DocmentValidationResponse maplst = dvr;

					if (maplst != null) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(maplst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDocumentValidationMappingByDocumentValidationCode(String documentValidationCode) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Object objlst = documentValidationMappingDao
					.getDocumentValidationMappingByDocumentValidationCode(documentValidationCode);
			if (objlst != null) {

				Object[] arr = (Object[]) objlst;
				if (arr.length >= 3) {

					DocmentValidationResponse dvr = new DocmentValidationResponse();

					DocumentValidationMapping data = (DocumentValidationMapping) arr[0];

					dvr.setId(data.getId());
					dvr.setDocumentValidationCode(data.getDocumentValidationCode());
					dvr.setDocumentCode(data.getDocumentCode());
					dvr.setDocumentName((String) arr[1]);
					dvr.setValidationCode(data.getValidationCode());
					dvr.setValidationName((String) arr[2]);

					DocmentValidationResponse maplst = dvr;

					if (maplst != null) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(maplst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String saveNewDocumentValidationMapping(DocumentValidationMappingRequest documentValidationMappingReq,
			String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (documentValidationMappingReq != null) {

				if (documentValidationMappingReq.getDocumentCode() != null
						&& documentValidationMappingReq.getDocumentCode().trim().length() > 0
						&& documentValidationMappingReq.getValidationCode() != null
						&& documentValidationMappingReq.getValidationCode().trim().length() > 0) {

					DocumentTypeDetail dtd = dtdRep
							.getDocumentTypeDetailByDocumentCode(documentValidationMappingReq.getDocumentCode());
					if (dtd != null && dtd.getId() > 0) {

						Validation validation = validationRep
								.getValidationByValidationCode(documentValidationMappingReq.getValidationCode());
						if (validation != null && validation.getId() > 0) {

							DocumentValidationMapping mappingCheck = documentValidationMappingDao
									.getDocumentValidationMappingByDocumentCodeAndValidationCode(
											documentValidationMappingReq.getDocumentCode(),
											documentValidationMappingReq.getValidationCode());

							if (mappingCheck != null && mappingCheck.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record already exist.");
							} else {

								DocumentValidationMapping mappinglst = new DocumentValidationMapping();

								mappinglst.setDocumentCode(documentValidationMappingReq.getDocumentCode());
								mappinglst.setValidationCode(documentValidationMappingReq.getValidationCode());

								mappinglst.setIpAddress(ip);

								DocumentValidationMapping mappingRes = documentValidationMappingDao.save(mappinglst);

								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());

								if (mappingRes != null && mappingRes.getId() > 0) {

									jsonobj.put("message", "DocumentValidationMapping has been added successfully.");
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj.writeValueAsString(mappingRes);
									jsonobj.put("data", new JSONObject(Detail));
								} else {
									jsonobj.put("message", "Failed");
								}
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Validation Code not found.");
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Document Code not found.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateDocumentValidationMappingById(Long id,
			DocumentValidationMappingRequest documentValidationMappingReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && documentValidationMappingReq != null) {

				if (documentValidationMappingReq.getDocumentCode() != null
						&& documentValidationMappingReq.getDocumentCode().trim().length() > 0
						&& documentValidationMappingReq.getValidationCode() != null
						&& documentValidationMappingReq.getValidationCode().trim().length() > 0) {

					DocumentValidationMapping Mappinglst = documentValidationMappingDao
							.findDocumentValidationMappingById(id);

					if (Mappinglst != null && Mappinglst.getId() > 0) {

						DocumentTypeDetail dtd = dtdRep
								.getDocumentTypeDetailByDocumentCode(documentValidationMappingReq.getDocumentCode());
						if (dtd != null && dtd.getId() > 0) {

							Validation validation = validationRep
									.getValidationByValidationCode(documentValidationMappingReq.getValidationCode());
							if (validation != null && validation.getId() > 0) {

								DocumentValidationMapping mappingCheck = documentValidationMappingDao
										.getDocumentValidationMappingByDocumentCodeAndValidationCodeById(id,
												documentValidationMappingReq.getDocumentCode(),
												documentValidationMappingReq.getValidationCode());

								if (mappingCheck != null && mappingCheck.getId() > 0) {
									jsonobj.put("responsecode", 409);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message", "Record already exist.");
								} else {

									DocumentValidationMapping mapping = Mappinglst;

									mapping.setDocumentCode(documentValidationMappingReq.getDocumentCode());
									mapping.setValidationCode(documentValidationMappingReq.getValidationCode());

									mapping.setIpAddress(ip);

									DocumentValidationMapping mappingRes = documentValidationMappingDao.save(mapping);

									if (mappingRes != null && mappingRes.getId() > 0) {
										jsonobj.put("responsecode", 200);
										jsonobj.put("message", "DocumentValidationMapping updation has been done");
										jsonobj.put("timestamp", new Date());
										ObjectMapper mapperObj = new ObjectMapper();
										String Detail = mapperObj.writeValueAsString(mappingRes);
										jsonobj.put("data", new JSONObject(Detail));
									} else {
										jsonobj.put("responsecode", 400);
										jsonobj.put("message", "DocumentValidationMapping updation has been failed.");
										jsonobj.put("timestamp", new Date());
									}
								}
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Validation Code not found.");
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Document Code not found.");
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "DocumentValidationMapping ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByDocumentValidationCode(String documentValidationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			DocumentValidationMapping mappinglst = documentValidationMappingDao
					.findDocumentValidationMappingByDocumentValidationCode(documentValidationCode);
			if (mappinglst != null && mappinglst.getId() > 0) {
				mappinglst.setIsDeleted(true);
				DocumentValidationMapping mappingRes = documentValidationMappingDao.save(mappinglst);

				if (mappingRes != null && mappingRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "DocumentValidationMapping deleted successfully.");
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByDocumentValidationCode(List<String> documentValidationCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String documentValidationCode : documentValidationCodeList) {
				JSONObject jsonobj = new JSONObject();

				DocumentValidationMapping mappinglst = documentValidationMappingDao
						.findDocumentValidationMappingByDocumentValidationCode(documentValidationCode);
				if (mappinglst != null && mappinglst.getId() > 0) {

					mappinglst.setIsDeleted(true);
					DocumentValidationMapping mappingRes = documentValidationMappingDao.save(mappinglst);

					if (mappingRes != null && mappingRes.getId() > 0) {
						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", documentValidationCode);
						jsonobj.put("message", "DocumentValidationMapping deleted successfully.");
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", documentValidationCode);
						jsonobj.put("message", "Failed");
					}

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("code", documentValidationCode);
					jsonobj.put("message", "Record Not Found");
				}
				jarr.add(jsonobj);
			}

			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllDocumentValidationMappingByPgae(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<Object> objlst = documentValidationMappingDao.getAllDocumentValidationMapping(pageableRequest);
			List<DocmentValidationResponse> maplst = new ArrayList<DocmentValidationResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						DocmentValidationResponse dvr = new DocmentValidationResponse();

						DocumentValidationMapping data = (DocumentValidationMapping) arr[0];

						dvr.setId(data.getId());
						dvr.setDocumentValidationCode(data.getDocumentValidationCode());
						dvr.setDocumentCode(data.getDocumentCode());
						dvr.setDocumentName((String) arr[1]);
						dvr.setValidationCode(data.getValidationCode());
						dvr.setValidationName((String) arr[2]);

						maplst.add(dvr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				DocumentValidationMappingSpecificationsBuilder builder = new DocumentValidationMappingSpecificationsBuilder();
				Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
				}

				Specification<DocumentValidationMapping> spec = builder.build();
				if (spec != null) {
					List<DocumentValidationMapping> DocumentValidationMappinglst = documentValidationMappingDao
							.findAll(spec);
					if (DocumentValidationMappinglst != null && DocumentValidationMappinglst.size() > 0) {
						for (DocumentValidationMapping valdtn : DocumentValidationMappinglst) {
							if (valdtn.getIsDeleted() != null && valdtn.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(valdtn);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("DocumentValidationMapping", new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getDocumentValidationByDocumentCode(String documentCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = documentValidationMappingDao.getDocumentValidationMappingByDocumentCode(documentCode);
			List<DocmentValidationResponse> maplst = new ArrayList<DocmentValidationResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						DocmentValidationResponse dvr = new DocmentValidationResponse();

						DocumentValidationMapping data = (DocumentValidationMapping) arr[0];

						dvr.setId(data.getId());
						dvr.setDocumentValidationCode(data.getDocumentValidationCode());
						dvr.setDocumentCode(data.getDocumentCode());
						dvr.setDocumentName((String) arr[1]);
						dvr.setValidationCode(data.getValidationCode());
						dvr.setValidationName((String) arr[2]);

						maplst.add(dvr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDocumentValidationByDocumentCode(String documentCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<Object> objlst = documentValidationMappingDao.getDocumentValidationMappingByDocumentCode(documentCode,
					pageableRequest);
			List<DocmentValidationResponse> maplst = new ArrayList<DocmentValidationResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						DocmentValidationResponse dvr = new DocmentValidationResponse();

						DocumentValidationMapping data = (DocumentValidationMapping) arr[0];

						dvr.setId(data.getId());
						dvr.setDocumentValidationCode(data.getDocumentValidationCode());
						dvr.setDocumentCode(data.getDocumentCode());
						dvr.setDocumentName((String) arr[1]);
						dvr.setValidationCode(data.getValidationCode());
						dvr.setValidationName((String) arr[2]);

						maplst.add(dvr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDocumentValidationByValidationCode(String validationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = documentValidationMappingDao
					.getDocumentValidationMappingByValidationCode(validationCode);
			List<DocmentValidationResponse> maplst = new ArrayList<DocmentValidationResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						DocmentValidationResponse dvr = new DocmentValidationResponse();

						DocumentValidationMapping data = (DocumentValidationMapping) arr[0];

						dvr.setId(data.getId());
						dvr.setDocumentValidationCode(data.getDocumentValidationCode());
						dvr.setDocumentCode(data.getDocumentCode());
						dvr.setDocumentName((String) arr[1]);
						dvr.setValidationCode(data.getValidationCode());
						dvr.setValidationName((String) arr[2]);

						maplst.add(dvr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDocumentValidationByValidationCode(String validationCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<Object> objlst = documentValidationMappingDao
					.getDocumentValidationMappingByValidationCode(validationCode, pageableRequest);
			List<DocmentValidationResponse> maplst = new ArrayList<DocmentValidationResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {

						DocmentValidationResponse dvr = new DocmentValidationResponse();

						DocumentValidationMapping data = (DocumentValidationMapping) arr[0];

						dvr.setId(data.getId());
						dvr.setDocumentValidationCode(data.getDocumentValidationCode());
						dvr.setDocumentCode(data.getDocumentCode());
						dvr.setDocumentName((String) arr[1]);
						dvr.setValidationCode(data.getValidationCode());
						dvr.setValidationName((String) arr[2]);

						maplst.add(dvr);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

}
