package com.gigflex.prototype.microservices.driver.dtob;

import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocument;

public class DriverDocumentDetailResponse {
	
	public Driver driver;
	public DriverDocument driverDocument;
	public String organizationName;
	public String operatorName;
    private String documentType;
    
	public Driver getDriver() {
		return driver;
	}
	public void setDriver(Driver driver) {
		this.driver = driver;
	}
	public DriverDocument getDriverDocument() {
		return driverDocument;
	}
	public void setDriverDocument(DriverDocument driverDocument) {
		this.driverDocument = driverDocument;
	}
	public String getOrganizationName() {
		return organizationName;
	}
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	
	public String getOperatorName() {
		return operatorName;
	}
	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
    
    

	
	

}
