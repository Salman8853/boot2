/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.additionalfaretype.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "additional_faretype")
public class AdditionalFareType extends CommonAttributes{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "additional_faretype_code", unique = true)

    private String additionalFareTypeCode;
    
     @Column(name = "name")
     private String name;
     
    @Column(name = "ammount")
     private String ammount;
  
      @PrePersist
    private void assignUUID() {
        if(this.getAdditionalFareTypeCode()==null || this.getAdditionalFareTypeCode().length()==0)
        {
            this.setAdditionalFareTypeCode(UUID.randomUUID().toString());
        }
    }
     
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAdditionalFareTypeCode() {
        return additionalFareTypeCode;
    }

    public void setAdditionalFareTypeCode(String additionalFareTypeCode) {
        this.additionalFareTypeCode = additionalFareTypeCode;
    }

    public String getAmmount() {
        return ammount;
    }

    public void setAmmount(String ammount) {
        this.ammount = ammount;
    }

   

    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
