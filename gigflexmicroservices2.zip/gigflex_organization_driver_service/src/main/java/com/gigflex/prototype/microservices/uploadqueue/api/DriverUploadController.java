package com.gigflex.prototype.microservices.uploadqueue.api;

import java.io.IOException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.gigflex.prototype.microservices.uploadqueue.service.DriverStorageService;
import com.gigflex.prototype.microservices.util.GigflexResponse;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/organizationdriverservice/")
public class DriverUploadController {
	
	@Autowired
    private DriverStorageService fileStorageService;

    @PostMapping("/uploadDriverFile")
    public String uploadFile(@RequestParam("file") MultipartFile file,@RequestParam("operatorCode") String operatorCode,@RequestParam("organizationCode") String organizationCode) {
        String res = "";
        String respon = fileStorageService.storeFile(file,operatorCode,organizationCode);
        
        try {
            JSONObject jSONObject = new JSONObject(respon);
            if (jSONObject.has("responsecode") && jSONObject.getInt("responsecode") == 200) {

                String fileName = jSONObject.getString("filename");
                 String uploadFileCode = jSONObject.getString("uploadFileCode");
                String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                        .path("/organizationdriverservice/downloadFile/")
                        .path(fileName)
                        .toUriString();
                JSONObject jsonobj = new JSONObject();
                jsonobj.put("responsecode", 200);
                jsonobj.put("message", "success");
                jsonobj.put("filename", fileName);
                jsonobj.put("fileurl", fileDownloadUri);
                jsonobj.put("uploadFileCode", uploadFileCode);
                res = jsonobj.toString();
            } else {
                res = respon;
            }
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;
//        return new UploadFileResponse(fileName, fileDownloadUri,
//                file.getContentType(), file.getSize());
    }

    @GetMapping("/downloadDriverFile/{fileName}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String fileName, HttpServletRequest request) {
        // Load file as Resource
        Resource resource = fileStorageService.loadFileAsResource(fileName);

        // Try to determine file's content type
        String contentType = null;
        try {
            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        // Fallback to the default content type if type could not be determined
        if (contentType == null) {
            contentType = "application/octet-stream";
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }

}
