package com.gigflex.prototype.microservices.operator.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.driver.dtob.Users;
import com.gigflex.prototype.microservices.operator.repository.UserRepository;

@Service
public class KafkaWorkerupdateservice {

	
        @Autowired
	UserRepository userRepository;
	private static final Logger LOG = LoggerFactory.getLogger(KafkaWorkerupdateservice.class);

	@KafkaListener(topics = "UpdateUser")
	public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			Users user = objectMapper.readValue(message, Users.class);
                       Users u= userRepository.findByUserCode(user.getUserCode());
                          if(u!=null&& u.getId()>0) 
                          {
                       try
                        {
                            u.setIsActive(user.getIsActive());
                            u.setPassword(user.getPassword());
                            userRepository.save(u);
                        }
                        catch (Exception e) {
			LOG.error("In KafkaWorkerService >>>>", e);
                        }
                          }
			LOG.info("received message='{}'", user.getName());
			LOG.info("received message='{}'", user.getUserCode());
			LOG.info("received message='{}'", user.getIsActive());
			LOG.info("received message='{}'", user.getEmail());
			
			
		} catch (JsonParseException e) {
			LOG.error("In KafkaWorkerService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaWorkerService >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaWorkerService >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaWorkerService >>>>", e);
		}
	}


}