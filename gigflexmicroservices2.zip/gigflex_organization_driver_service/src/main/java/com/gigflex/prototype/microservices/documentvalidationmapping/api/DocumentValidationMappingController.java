package com.gigflex.prototype.microservices.documentvalidationmapping.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.documentvalidationmapping.dtob.DocumentValidationMappingRequest;
import com.gigflex.prototype.microservices.documentvalidationmapping.service.DocumentValidationService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/organizationdriverservice/")
public class DocumentValidationMappingController {

	@Autowired
	private DocumentValidationService docValService;

	@GetMapping("/DocumentValidationMapping/{search}")
	public String search(@PathVariable("search") String search) {
		return docValService.search(search);
	}

	@GetMapping("/getAllDocumentValidationMapping")
	public String getAllDocumentValidationMapping() {
		return docValService.getAllDocumentValidationMapping();
	}

	@GetMapping(path = "/getAllDocumentValidationMappingByPage")
	public String getAllDocumentValidationMappingByPage(@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String act = docValService.getAllDocumentValidationMappingByPgae(page, limit);

		return act;

	}

	@GetMapping("/getAllDocumentValidationMappingByDocumentCode/{documentCode}")
	public String getAllDocumentValidationMappingByDocumentCode(@PathVariable String documentCode) {
		return docValService.getDocumentValidationByDocumentCode(documentCode);
	}

	@GetMapping(path = "/getAllDocumentValidationMappingByDocumentCodeByPage/{documentCode}")
	public String getAllDocumentValidationMappingByDocumentCodeByPage(@PathVariable String documentCode,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String act = docValService.getDocumentValidationByDocumentCode(documentCode, page, limit);

		return act;

	}

	@GetMapping("/getAllDocumentValidationMappingByValidationCode/{validationCode}")
	public String getAllDocumentValidationMappingByValidationCode(@PathVariable String validationCode) {
		return docValService.getDocumentValidationByValidationCode(validationCode);
	}

	@GetMapping(path = "/getAllDocumentValidationMappingByValidationCodeByPage/{validationCode}")
	public String getAllDocumentValidationMappingByValidationCodeByPage(@PathVariable String validationCode,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String act = docValService.getDocumentValidationByValidationCode(validationCode, page, limit);

		return act;

	}

	@GetMapping("/getDocumentValidationMappingById/{id}")
	public String getDocumentValidationMappingById(@PathVariable Long id) {
		return docValService.getDocumentValidationMappingById(id);
	}

	@GetMapping("/getDocumentValidationMappingByDocumentValidationCode/{documentValidationCode}")
	public String getDocumentValidationMappingByDocumentValidationCode(@PathVariable String documentValidationCode) {
		return docValService.getDocumentValidationMappingByDocumentValidationCode(documentValidationCode);
	}

	@PostMapping("/saveNewDocumentValidationMapping")
	public String saveNewDocumentValidationMapping(
			@RequestBody DocumentValidationMappingRequest documentValidationMappingReq, HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return docValService.saveNewDocumentValidationMapping(documentValidationMappingReq, ip);

	}

	@DeleteMapping("/softDeleteDocumentValidationMappingByDocumentValidationCode/{documentValidationCode}")
	public String softDeleteDocumentValidationMappingByDocumentValidationCode(
			@PathVariable String documentValidationCode) {
		return docValService.softDeleteByDocumentValidationCode(documentValidationCode);
	}

	@DeleteMapping("/softMultipleDeleteByDocumentValidationCode/{documentValidationCodeList}")
	public String softMultipleDeleteByDocumentValidationCode(@PathVariable List<String> documentValidationCodeList) {
		if (documentValidationCodeList != null && documentValidationCodeList.size() > 0) {
			return docValService.softMultipleDeleteByDocumentValidationCode(documentValidationCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
			return derr.toString();
		}

	}

	@PutMapping("/updateDocumentValidationMapping/{id}")
	public String updateDocumentValidationMapping(@PathVariable Long id,
			@RequestBody DocumentValidationMappingRequest documentValidationMappingReq, HttpServletRequest request) {

		if (id == null) {
			return "DocumentValidationMapping with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return docValService.updateDocumentValidationMappingById(id, documentValidationMappingReq, ip);
		}

	}
}
