/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.uploadqueue.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Date;
import java.util.Iterator;
import java.util.stream.StreamSupport;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.gigflex.prototype.microservices.assignbooking.repository.AssignBookingRepository;
import com.gigflex.prototype.microservices.booking.dtob.Booking;
import com.gigflex.prototype.microservices.booking.repository.BookingDao;
import com.gigflex.prototype.microservices.uploadqueue.dtob.UploadQueue;
import com.gigflex.prototype.microservices.uploadqueue.repository.UploadQueueDao;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@Service
public class FileStorageService {

	@Autowired
	private UploadQueueDao uploadQueueDao;

	@Autowired
	private BookingDao bookingDao;
	
	@Autowired
	private AssignBookingRepository assignBookingDao;

	 @Value("${xlsfile.upload-dir}")
	 String uploadDir;

//	String uploadDir = "/home/esoft/Desktop/file_upload";
	private Path fileStorageLocation;

	// @Autowired
	// public FileStorageService() {
	// this.fileStorageLocation = Paths.get(uploadDir)
	// .toAbsolutePath().normalize();
	//
	// // try {
	// // Files.createDirectories(this.fileStorageLocation);
	// // } catch (Exception ex) {
	// // ex.printStackTrace();
	// // // throw new
	// FileStorageException("Could not create the directory where the uploaded files will be stored.",
	// ex);
	// // }
	// }

	public String storeFile(MultipartFile file) {
		// Normalize file name
		String res1 = "";
		this.fileStorageLocation = Paths.get(uploadDir).toAbsolutePath()
				.normalize();
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		try {
			String filenameStart = "";
			String filenameEnd = "";
			Date date = new Date();
			long time = date.getTime();
			int inx = fileName.lastIndexOf(".");
			filenameStart = fileName.substring(0, inx);
			filenameEnd = fileName.substring(inx);
			fileName = filenameStart + "-" + time + filenameEnd;

			 if(filenameEnd != null && filenameEnd.trim().length() > 0 && (
			 filenameEnd.equalsIgnoreCase(".xls") ||
			 filenameEnd.equalsIgnoreCase(".xlsx")) ){

			JSONObject jsonobj = new JSONObject();
			// Check if the file's name contains invalid characters
			if (fileName.contains("..") || fileName.contains("/") || fileName.contains("\\") || fileName.contains("<") || fileName.contains(">") || fileName.contains("'")) {
                //  throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
                jsonobj.put("responsecode", 500);
                jsonobj.put("message", "Sorry! Filename contains invalid path sequence or characters like(.. ' / \\ < >)");
                res1 = jsonobj.toString();
            } else {
				// Copy file to the target location (Replacing existing file
				// with the same name)
				Path targetLocation = this.fileStorageLocation
						.resolve(fileName);
				Files.copy(file.getInputStream(), targetLocation,
						StandardCopyOption.REPLACE_EXISTING);

				File myFile = new File(targetLocation.toUri());
				FileInputStream fis = new FileInputStream(myFile);

				Workbook myWorkBook;
				Sheet mySheet = null;

				if (filenameEnd.equalsIgnoreCase(".xls")) {
					myWorkBook = new HSSFWorkbook(fis);
					mySheet = myWorkBook.getSheetAt(0);
				} else if (filenameEnd.equalsIgnoreCase(".xlsx")) {
					myWorkBook = new XSSFWorkbook(fis);
					mySheet = myWorkBook.getSheetAt(0);
				}
				Iterator<Row> rowIterator = mySheet.iterator();
				Iterator<Row> rowIterator1 = mySheet.iterator();

				Iterable<Row> newIterable = () -> rowIterator1;
				long size = StreamSupport.stream(newIterable.spliterator(),
						false).count();
				// long size = 0;
				Boolean status = true;
				int rowCount = 0;
//				String emailList = "";
//				boolean isPwdValid = false;
//				boolean isEmailValid = false;

				while (rowIterator.hasNext()) {
					Row row = rowIterator.next();

					if (row != null) {
						if (rowCount == 0) {

							String cell1 = "";
							String cell2 = "";
							String cell3 = "";
							String cell4 = "";
							String cell5 = "";
							String cell6 = "";
							String cell7 = "";
							String cell8 = "";
							String cell9 = "";
							String cell10 = "";
							String cell11 = "";


							Iterator<Cell> cellIterator = row.cellIterator();
							int cellCount = 0;
							Booking booking = new Booking();

							while (cellIterator.hasNext()) {
								cellCount++;

								Cell cell = cellIterator.next();

								if (cell != null) {
									if (cellCount == 11) {
										cell11 = cell.getStringCellValue();
										break;
									} else if (cellCount == 10) {
										cell10 = cell.getStringCellValue();
									} else if (cellCount == 9) {
										cell9 = cell.getStringCellValue();
									} else if (cellCount == 8) {
										cell8 = cell.getStringCellValue();
									} else if (cellCount == 7) {
										cell7 = cell.getStringCellValue();
									} else if (cellCount == 6) {
										cell6 = cell.getStringCellValue();
									} else if (cellCount == 5) {
										cell5 = cell.getStringCellValue();
									} else if (cellCount == 4) {
										cell4 = cell.getStringCellValue();
									} else if (cellCount == 3) {
										cell3 = cell.getStringCellValue();
									} else if (cellCount == 2) {
										cell2 = cell.getStringCellValue();
									} else if (cellCount == 1) {
										cell1 = cell.getStringCellValue();
									}

								}
							}
							if (cell1.trim().equalsIgnoreCase("passengername")
									&& cell2.trim().equalsIgnoreCase(
											"primarycontactnumber")
									&& cell3.trim().equalsIgnoreCase(
											"secondarycontactnumber")
									&& cell4.trim().equalsIgnoreCase(
											"pickupaddress")
									&& cell5.trim().equalsIgnoreCase(
											"dropoffaddress")
									&& cell6.trim().equalsIgnoreCase(
											"additionalstoppage")
									&& cell7.trim().equalsIgnoreCase(
											"noofpassengers")
									&& cell8.trim().equalsIgnoreCase(
											"noofbaggage")
									&& cell9.trim().equalsIgnoreCase(
											"customfare")
									&& cell10.trim().equalsIgnoreCase(
											"paymentoption")
									&& cell11.trim()
											.equalsIgnoreCase("comment")) {
								status = true;
							} else {
								status = false;

								break;
							}

						} else {
							Iterator<Cell> cellIterator = row.cellIterator();
							int cellCount = 0;
							Booking booking = new Booking();

							while (cellIterator.hasNext()) {
								cellCount++;
								
								Double fare = null;

								Cell cell = cellIterator.next();

								if (cell != null) {
									String res = "";
									switch (cell.getCellType()) {
									case Cell.CELL_TYPE_STRING:
										res = cell.getStringCellValue();
										break;
									case Cell.CELL_TYPE_NUMERIC:
										double var = cell.getNumericCellValue();
										if(cellCount != 9){
										Long l = (long) var;
										res = l.toString();
										}
										else{
											fare = var;
										}
										break;
									case Cell.CELL_TYPE_BOOLEAN:
										if (cell.getBooleanCellValue()) {
											res = "true";
										} else {
											res = "false";
										}

										break;
									default:

									}

									if (cellCount == 11) {

										booking.setAdditionalComment(res);
										
										break;
								} else if (cellCount == 10) {
									
									booking.setPaymentOption(res);
									}  else if (cellCount == 9) {

										booking.setCustomerFare(fare);
										
									} else if (cellCount == 8) {
										
										booking.setNoOfBaggage(Integer
													.parseInt(res));

									} else if (cellCount == 7) {
										
										if (res.trim().length() > 0) {
											booking.setNoOfPassengers(Integer
													.parseInt(res));
											
										}

									} else if (cellCount == 6) {
										if (res.trim().length() > 0) {
											
											booking.setAdditionalStopPage(res);

										}

									} else if (cellCount == 5) {
										booking.setDropOffAddress(res);

									} else if (cellCount == 4) {

										booking.setPickUpAddress(res);

									} else if (cellCount == 3) {
										
										booking.setSecondaryContactNumber(res);

									} else if (cellCount == 2) {
										
										booking.setPrimaryContactNumber(res);

									} else if (cellCount == 1) {
										
										booking.setPassengerName(res);
									}

								}

							}
//							if (booking != null && booking.getPassengerName() != null) {
//
//								Worker worker1 = workerDao
//										.findByWorkerEmail(worker.getEmail());
//								if (worker1 != null && worker1.getId() > 0) {
//									if (emailList.length() > 0) {
//										emailList += "," + worker.getEmail();
//									} else {
//										emailList = worker.getEmail();
//
//									}
//								}
//
//							}
						}
						rowCount++;
					}
				}
				if (status) {
					if (size > 1) {
//						if (emailList.length() > 0) {
//							jsonobj.put("responsecode", 400);
//							jsonobj.put("message", "Emails are already Exist!("
//									+ emailList + ")");
//						} else {

							UploadQueue uq = new UploadQueue();

							uq.setFileName(fileName);
							uq.setTotalRecords((size - 1));
							uq.setProcessedRecords(0L);
							uq.setFaliedRecords(0L);

							UploadQueue uploadRes = uploadQueueDao.save(uq);

							startFileUploadThread(uploadDir + "/" + fileName,
									uploadRes.getUploadCode());

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "success");
							jsonobj.put("filename", fileName);
							jsonobj.put("uploadFileCode",
									uploadRes.getUploadCode());
//						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message",
								"Sorry! File have no data for booking");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message",
							"Sorry! File Should be in proper format.");
				}
				res1 = jsonobj.toString();

			}
			 }
			 else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(),
			 "File type should be xls or xlsx.");
			 res1 = derr.toString();
			 }

		} catch (IOException ex) {
			// throw new FileStorageException("Could not store file " + fileName
			// + ". Please try again!", ex);
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Could not store file " + fileName + ". Please try again!");
			res1 = derr.toString();
			ex.printStackTrace();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res1 = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res1 = derr.toString();
			ex.printStackTrace();
		}

		return res1;
	}

	// public static boolean passwordPattern(String pwd) {
	// if (pwd != null) {
	// try {
	// String pattern = "(?=.*[0-7])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{7,}";
	// isPwdValid = pwd.matches(pattern);
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }
	// return isPwdValid;
	// }
	//
	// public static boolean emailPatternValidation(String email) {
	// if (email != null && !email.equals("")) {
	// try {
	// String regex = "^(.+)@(.+)$";
	// Pattern pattern = Pattern.compile(regex);
	// Matcher matcher = pattern.matcher(email);
	// if (matcher.matches()) {
	// isEmailValid = true;
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	//
	// }
	// return isEmailValid;
	// }

	public Resource loadFileAsResource(String fileName) {
		Resource resource = null;
		try {
			Path filePath = this.fileStorageLocation.resolve(fileName)
					.normalize();
			resource = new UrlResource(filePath.toUri());

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return resource;
	}

	public void startFileUploadThread(String fileName, String uploadCode) {
		Thread t = new Thread(new FileUploadThread(fileName, uploadCode,
				bookingDao,uploadQueueDao,assignBookingDao));
		t.start();
	}
}
