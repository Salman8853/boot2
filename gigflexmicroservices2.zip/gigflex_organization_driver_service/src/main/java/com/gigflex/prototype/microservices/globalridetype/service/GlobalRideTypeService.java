package com.gigflex.prototype.microservices.globalridetype.service;

import com.gigflex.prototype.microservices.globalridetype.dtob.GlobalRideTypeRequest;

public interface GlobalRideTypeService {
	
	public String getAllGlobalRideType(int page, int limit);
	
	public String getAllGlobalRideType();

	public String saveNewGlobalRideType(GlobalRideTypeRequest globalRideTypeReq, String ip);
	
	public String getGlobalRideTypeByGlobalRideCode(String globalRideCode);
        
        public String getAllGlobalRideTypeByorganizationCode( String organizationCode,int page, int limit);
       public String getGlobalRideTypeByGlobalRideCodewithorgCode(String globalRideCode,String organizationCode);
        
       public String getAllGlobalRideTypeByorgCode( String organizationCode);
        

}
