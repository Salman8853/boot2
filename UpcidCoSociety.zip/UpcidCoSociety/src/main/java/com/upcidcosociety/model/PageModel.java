/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class PageModel {
    private Integer id;
    private String pagetitles;
    private String pageContent;
    private String url; 
    private Boolean active;
    private Integer pageId;

    public PageModel() {
    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPagetitles() {
        return pagetitles;
    }

    public void setPagetitles(String pagetitles) {
        this.pagetitles = pagetitles;
    }

    public String getPageContent() {
        return pageContent;
    }

    public void setPageContent(String pageContent) {
        this.pageContent = pageContent;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Integer getPageId() {
        return pageId;
    }

    public void setPageId(Integer pageId) {
        this.pageId = pageId;
    }
    
    
}
