/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class SectorModel {
    
 private Integer id;
 
 private String sector;
 
 private String InUse;

    public SectorModel() {
        
    }

 
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSector() {
        return sector;
    }

    public void setSector(String sector) {
        this.sector = sector;
    }

    public String getInUse() {
        return InUse;
    }

    public void setInUse(String InUse) {
        this.InUse = InUse;
    }

    @Override
    public String toString() {
        return "SectorModel{" + "id=" + id + ", sector=" + sector + ", InUse=" + InUse + '}';
    }
 
 
 
    
}
