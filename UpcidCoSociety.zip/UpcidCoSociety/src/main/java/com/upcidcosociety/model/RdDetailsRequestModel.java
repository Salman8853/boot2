/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class RdDetailsRequestModel {
    
  private String pnoNumber;
   
   
  private Integer rdSerialNo ;
   
  private Integer rdacc_no;
     
 private String rdOpenningDate; 
 
 private String rdDreakingDate; 
 
 private Double pmd;  
 
 private Integer pod;  

 private Double intdue; 
 
 private Double intPaid; 
 

 private Double intBal;
 
 private Double openningBalance; 
 
 private Double bal31March;
 

 private Double intOpenningBal; 
 
 private Double totalPayment; 
 
 private String finYear; 
 
 private String installmentSum; 

 private Double oldAmt; 

 private String result;  
 
 
private Double janValue;

private Double febValue;

private Double marchValue;

private Double aprilValue;

private Double mayValue;

private Double juneValue;

private Double julyValue;

private Double augustValue;

private Double septValue;

private Double octValue;

private Double novValue;

private Double decValue;

    public RdDetailsRequestModel() {
        
    }
    public String getPnoNumber() {
        return pnoNumber;
    }

    public void setPnoNumber(String pnoNumber) {
        this.pnoNumber = pnoNumber;
    }

    public Integer getRdacc_no() {
        return rdacc_no;
    }

    public void setRdacc_no(Integer rdacc_no) {
        this.rdacc_no = rdacc_no;
    }

    public String getRdOpenningDate() {
        return rdOpenningDate;
    }

    public void setRdOpenningDate(String rdOpenningDate) {
        this.rdOpenningDate = rdOpenningDate;
    }

    public String getRdDreakingDate() {
        return rdDreakingDate;
    }

    public void setRdDreakingDate(String rdDreakingDate) {
        this.rdDreakingDate = rdDreakingDate;
    }

    public Double getPmd() {
        return pmd;
    }

    public void setPmd(Double pmd) {
        this.pmd = pmd;
    }

    public Integer getPod() {
        return pod;
    }

    public void setPod(Integer pod) {
        this.pod = pod;
    }

   

   

    public Double getIntdue() {
        return intdue;
    }

    public void setIntdue(Double intdue) {
        this.intdue = intdue;
    }

    public Double getIntPaid() {
        return intPaid;
    }

    public void setIntPaid(Double intPaid) {
        this.intPaid = intPaid;
    }

    public Double getIntBal() {
        return intBal;
    }

    public void setIntBal(Double intBal) {
        this.intBal = intBal;
    }

    public Double getOpenningBalance() {
        return openningBalance;
    }

    public void setOpenningBalance(Double openningBalance) {
        this.openningBalance = openningBalance;
    }

    public Double getBal31March() {
        return bal31March;
    }

    public void setBal31March(Double bal31March) {
        this.bal31March = bal31March;
    }

    public Double getIntOpenningBal() {
        return intOpenningBal;
    }

    public void setIntOpenningBal(Double intOpenningBal) {
        this.intOpenningBal = intOpenningBal;
    }

    public Double getTotalPayment() {
        return totalPayment;
    }

    public void setTotalPayment(Double totalPayment) {
        this.totalPayment = totalPayment;
    }

    public String getFinYear() {
        return finYear;
    }

    public void setFinYear(String finYear) {
        this.finYear = finYear;
    }

    public String getInstallmentSum() {
        return installmentSum;
    }

    public void setInstallmentSum(String installmentSum) {
        this.installmentSum = installmentSum;
    }

    public Double getOldAmt() {
        return oldAmt;
    }

    public void setOldAmt(Double oldAmt) {
        this.oldAmt = oldAmt;
    }

  
    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Double getJanValue() {
        return janValue;
    }

    public void setJanValue(Double janValue) {
        this.janValue = janValue;
    }

    public Double getFebValue() {
        return febValue;
    }

    public void setFebValue(Double febValue) {
        this.febValue = febValue;
    }

    public Double getMarchValue() {
        return marchValue;
    }

    public void setMarchValue(Double marchValue) {
        this.marchValue = marchValue;
    }

    public Double getAprilValue() {
        return aprilValue;
    }

    public void setAprilValue(Double aprilValue) {
        this.aprilValue = aprilValue;
    }

    public Double getMayValue() {
        return mayValue;
    }

    public void setMayValue(Double mayValue) {
        this.mayValue = mayValue;
    }

    public Double getJuneValue() {
        return juneValue;
    }

    public void setJuneValue(Double juneValue) {
        this.juneValue = juneValue;
    }

    public Double getJulyValue() {
        return julyValue;
    }

    public void setJulyValue(Double julyValue) {
        this.julyValue = julyValue;
    }

    public Double getAugustValue() {
        return augustValue;
    }

    public void setAugustValue(Double augustValue) {
        this.augustValue = augustValue;
    }

    public Double getSeptValue() {
        return septValue;
    }

    public void setSeptValue(Double septValue) {
        this.septValue = septValue;
    }

    public Double getOctValue() {
        return octValue;
    }

    public void setOctValue(Double octValue) {
        this.octValue = octValue;
    }

    public Double getNovValue() {
        return novValue;
    }

    public void setNovValue(Double novValue) {
        this.novValue = novValue;
    }

    public Double getDecValue() {
        return decValue;
    }

    public void setDecValue(Double decValue) {
        this.decValue = decValue;
    }

    public Integer getRdSerialNo() {
        return rdSerialNo;
    }

    public void setRdSerialNo(Integer rdSerialNo) {
        this.rdSerialNo = rdSerialNo;
    }

  
 
}
