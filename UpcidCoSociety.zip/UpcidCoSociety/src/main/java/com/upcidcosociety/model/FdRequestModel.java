/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;


import java.util.List;


/**
 *
 * @author m.salman
 */
public class FdRequestModel {

private String pnoNumber;

 private String fdAccNo;

 private String openningDate; 
 
 private String partialDate; 
 
 private String closeDate; 
 
 private Integer fdPeriod;  

 private Double openningDeposite; 
 
 private String openningAmtinWords; 
 
 private String openningBalance; 
 
 private String certificateNo; 
 
 private String recieptNo; 
 
 private Double maturityAmount; 
 
 private String fdStatus;
 
 private String finYear;
 
 private String ageGroup;
 

 private Double interestdue; 
 

 private Double interestPaid;
 

 private Double interestBal; 
 
 private Double partialmaturityAmount;
 
 private Double partialinterestdue;
 
 private Double partialinterestBal;
 

 private Double fdPaid; 
 

 private Double fdBal; 
 

 private Double oldAmount;
 
 private String maturityDate;
 
 private String fdcreateandorUpdateStatus;
 
 
 private List<FdNomineeModel>nominee;

    public String getFdAccNo() {
        return fdAccNo;
    }

    public void setFdAccNo(String fdAccNo) {
        this.fdAccNo = fdAccNo;
    }

    public String getOpenningDate() {
        return openningDate;
    }

    public void setOpenningDate(String openningDate) {
        this.openningDate = openningDate;
    }

    public String getPartialDate() {
        return partialDate;
    }

    public void setPartialDate(String partialDate) {
        this.partialDate = partialDate;
    }

    public String getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(String closeDate) {
        this.closeDate = closeDate;
    }

    public Integer getFdPeriod() {
        return fdPeriod;
    }

    public void setFdPeriod(Integer fdPeriod) {
        this.fdPeriod = fdPeriod;
    }

    public Double getOpenningDeposite() {
        return openningDeposite;
    }

    public void setOpenningDeposite(Double openningDeposite) {
        this.openningDeposite = openningDeposite;
    }

    public String getOpenningAmtinWords() {
        return openningAmtinWords;
    }

    public void setOpenningAmtinWords(String openningAmtinWords) {
        this.openningAmtinWords = openningAmtinWords;
    }

    public String getOpenningBalance() {
        return openningBalance;
    }

    public void setOpenningBalance(String openningBalance) {
        this.openningBalance = openningBalance;
    }

    public String getCertificateNo() {
        return certificateNo;
    }

    public void setCertificateNo(String certificateNo) {
        this.certificateNo = certificateNo;
    }

    public String getRecieptNo() {
        return recieptNo;
    }

    public void setRecieptNo(String recieptNo) {
        this.recieptNo = recieptNo;
    }

    public Double getMaturityAmount() {
        return maturityAmount;
    }

    public void setMaturityAmount(Double maturityAmount) {
        this.maturityAmount = maturityAmount;
    }

 

    public String getFdStatus() {
        return fdStatus;
    }

    public void setFdStatus(String fdStatus) {
        this.fdStatus = fdStatus;
    }

    public String getFinYear() {
        return finYear;
    }

    public void setFinYear(String finYear) {
        this.finYear = finYear;
    }

    public String getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }

    public String getPnoNumber() {
        return pnoNumber;
    }

    public void setPnoNumber(String pnoNumber) {
        this.pnoNumber = pnoNumber;
    }

    public Double getInterestdue() {
        return interestdue;
    }

    public void setInterestdue(Double interestdue) {
        this.interestdue = interestdue;
    }

    public Double getInterestPaid() {
        return interestPaid;
    }

    public void setInterestPaid(Double interestPaid) {
        this.interestPaid = interestPaid;
    }

    public Double getInterestBal() {
        return interestBal;
    }

    public void setInterestBal(Double interestBal) {
        this.interestBal = interestBal;
    }

    public Double getFdPaid() {
        return fdPaid;
    }

    public void setFdPaid(Double fdPaid) {
        this.fdPaid = fdPaid;
    }

    public Double getFdBal() {
        return fdBal;
    }

    public void setFdBal(Double fdBal) {
        this.fdBal = fdBal;
    }

    public Double getOldAmount() {
        return oldAmount;
    }

    public void setOldAmount(Double oldAmount) {
        this.oldAmount = oldAmount;
    }

    public List<FdNomineeModel> getNominee() {
        return nominee;
    }

    public void setNominee(List<FdNomineeModel> nominee) {
        this.nominee = nominee;
    }

    public Double getPartialmaturityAmount() {
        return partialmaturityAmount;
    }

    public void setPartialmaturityAmount(Double partialmaturityAmount) {
        this.partialmaturityAmount = partialmaturityAmount;
    }

    public Double getPartialinterestdue() {
        return partialinterestdue;
    }

    public void setPartialinterestdue(Double partialinterestdue) {
        this.partialinterestdue = partialinterestdue;
    }

    public Double getPartialinterestBal() {
        return partialinterestBal;
    }

    public void setPartialinterestBal(Double partialinterestBal) {
        this.partialinterestBal = partialinterestBal;
    }

    public String getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getFdcreateandorUpdateStatus() {
        return fdcreateandorUpdateStatus;
    }

    public void setFdcreateandorUpdateStatus(String fdcreateandorUpdateStatus) {
        this.fdcreateandorUpdateStatus = fdcreateandorUpdateStatus;
    }

}
