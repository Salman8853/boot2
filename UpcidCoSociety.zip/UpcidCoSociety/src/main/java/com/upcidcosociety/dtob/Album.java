/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "album")
public class Album {
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "id")
 private Integer id;
 
 @Column(name="album_title")
 private String albumTitle;
 
 @Column(name="created_date",columnDefinition = "DATETIME")
 private Date createdDate;
 
 @JsonIgnore
 @OneToMany(mappedBy = "album",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
 private List<AlbumDetail> AlbumDetailList;

    public Album() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAlbumTitle() {
        return albumTitle;
    }

    public void setAlbumTitle(String albumTitle) {
        this.albumTitle = albumTitle;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public List<AlbumDetail> getAlbumDetailList() {
        return AlbumDetailList;
    }

    public void setAlbumDetailList(List<AlbumDetail> AlbumDetailList) {
        this.AlbumDetailList = AlbumDetailList;
    }
  
}
