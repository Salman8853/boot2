/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "rd_details")
public class RdDetails {
  @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "rdacc_no")
 private Integer rdAccNo;
 
 @Column(name="cerated_date",columnDefinition = "DATE")
 private Date ceratedDate; 
 
 @Column(name="active",nullable = false)
 private Boolean active; 
 
 @OneToOne
 @JoinColumn(name = "member_id",referencedColumnName ="member_id" )
 private MemberDetail memberDetail;

    public RdDetails() {
        
    }

    public Integer getRdAccNo() {
        return rdAccNo;
    }

    public void setRdAccNo(Integer rdAccNo) {
        this.rdAccNo = rdAccNo;
    }

    public Date getCeratedDate() {
        return ceratedDate;
    }

    public void setCeratedDate(Date ceratedDate) {
        this.ceratedDate = ceratedDate;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public MemberDetail getMemberDetail() {
        return memberDetail;
    }

    public void setMemberDetail(MemberDetail memberDetail) {
        this.memberDetail = memberDetail;
    }

  
 
}
