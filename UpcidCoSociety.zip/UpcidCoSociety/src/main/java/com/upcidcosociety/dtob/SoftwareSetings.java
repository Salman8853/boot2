/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name="software_setings")
public class SoftwareSetings {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    
    @Column(name = "loan_rate")
    private double loanRate;
    
    @Column(name = "dividend_day")
    private String dividendDay;
   
    @Column(name = "dividend_month")
    private String dividendMonth;
   
    @Column(name = "pky_enabled")
    private String pkyEnabled;
   
    @Column(name = "month_adj_done")
    private String monthAdjDone;
   
    @Column(name = "basic_pay_multiplier")
    private long basicPayMultiplier;
   
    @Column(name = "share_pay_multiplier")
    private long sharePayMultiplier;
    
    @Column(name = "dividentrate")
    private long dividentrate;
    
    @JsonIgnore
    @OneToMany(mappedBy = "ssid", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<SwRateSetting> swRtsettingList;
    
//    @JsonIgnore
//    @OneToMany(mappedBy = "ssid", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    private List<SwMonthlyCal> swMonthlyCalList;
//     
    public SoftwareSetings() {
        
    }
     
    
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public double getLoanRate() {
        return loanRate;
    }

    public void setLoanRate(double loanRate) {
        this.loanRate = loanRate;
    }

    public String getDividendDay() {
        return dividendDay;
    }

    public void setDividendDay(String dividendDay) {
        this.dividendDay = dividendDay;
    }

    public String getDividendMonth() {
        return dividendMonth;
    }

    public void setDividendMonth(String dividendMonth) {
        this.dividendMonth = dividendMonth;
    }

    public String getPkyEnabled() {
        return pkyEnabled;
    }

    public void setPkyEnabled(String pkyEnabled) {
        this.pkyEnabled = pkyEnabled;
    }

    public String getMonthAdjDone() {
        return monthAdjDone;
    }

    public void setMonthAdjDone(String monthAdjDone) {
        this.monthAdjDone = monthAdjDone;
    }

    public long getBasicPayMultiplier() {
        return basicPayMultiplier;
    }

    public void setBasicPayMultiplier(long basicPayMultiplier) {
        this.basicPayMultiplier = basicPayMultiplier;
    }

    public long getSharePayMultiplier() {
        return sharePayMultiplier;
    }

    public void setSharePayMultiplier(long sharePayMultiplier) {
        this.sharePayMultiplier = sharePayMultiplier;
    }

    public long getDividentrate() {
        return dividentrate;
    }

    public void setDividentrate(long dividentrate) {
        this.dividentrate = dividentrate;
    }

    public List<SwRateSetting> getSwRtsettingList() {
        return swRtsettingList;
    }

    public void setSwRtsettingList(List<SwRateSetting> swRtsettingList) {
        this.swRtsettingList = swRtsettingList;
    }

//    public List<SwMonthlyCal> getSwMonthlyCalList() {
//        return swMonthlyCalList;
//    }
//
//    public void setSwMonthlyCalList(List<SwMonthlyCal> swMonthlyCalList) {
//        this.swMonthlyCalList = swMonthlyCalList;
//    }

  
}
