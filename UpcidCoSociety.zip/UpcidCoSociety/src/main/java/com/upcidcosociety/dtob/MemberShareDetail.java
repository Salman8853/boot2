/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "member_share_detail")
public class MemberShareDetail {
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "msd_id")
 private Integer msdId; 

 @Column(name="share_opening_balance")
 private Double shareOpeningBalance;

 @Column(name="srdamount")
 private Double srdAmount;

 @Column(name="share_paid")
 private Double sharePaid;
 
 @Column(name="total_share")
 private Double totalShare;

 @Column(name="finyear")
 private Integer finyear;
 
@Column(name="share_paid_date",columnDefinition = "DATE")
private Date sharePaidDate;

 @OneToOne
 @JoinColumn(name = "mem_id", referencedColumnName = "member_id")
 private MemberDetail memberDetail;

  @JsonIgnore
  @OneToMany(mappedBy = "memberShareDetail", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<MemberShareDetailMonthWise> memberShareDetailMonthWiseList;
 
    public Integer getMsdId() {
        return msdId;
    }

    public void setMsdId(Integer msdId) {
        this.msdId = msdId;
    }

    public Double getShareOpeningBalance() {
        return shareOpeningBalance;
    }

    public void setShareOpeningBalance(Double shareOpeningBalance) {
        this.shareOpeningBalance = shareOpeningBalance;
    }

    public Double getSrdAmount() {
        return srdAmount;
    }

    public void setSrdAmount(Double srdAmount) {
        this.srdAmount = srdAmount;
    }

    public Double getSharePaid() {
        return sharePaid;
    }

    public void setSharePaid(Double sharePaid) {
        this.sharePaid = sharePaid;
    }

    public Double getTotalShare() {
        return totalShare;
    }

    public void setTotalShare(Double totalShare) {
        this.totalShare = totalShare;
    }

    public Date getSharePaidDate() {
        return sharePaidDate;
    }

    public void setSharePaidDate(Date sharePaidDate) {
        this.sharePaidDate = sharePaidDate;
    }

    public MemberDetail getMemberDetail() {
        return memberDetail;
    }

    public void setMemberDetail(MemberDetail memberDetail) {
        this.memberDetail = memberDetail;
    }

  

    public List<MemberShareDetailMonthWise> getMemberShareDetailMonthWiseList() {
        return memberShareDetailMonthWiseList;
    }

    public void setMemberShareDetailMonthWiseList(List<MemberShareDetailMonthWise> memberShareDetailMonthWiseList) {
        this.memberShareDetailMonthWiseList = memberShareDetailMonthWiseList;
    }

    public Integer getFinyear() {
        return finyear;
    }

    public void setFinyear(Integer finyear) {
        this.finyear = finyear;
    }
  
}
