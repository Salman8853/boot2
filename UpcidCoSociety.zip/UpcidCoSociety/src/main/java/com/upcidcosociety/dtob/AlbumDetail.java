/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;


import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "album_detail")
public class AlbumDetail {
    
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "album_detail_id")
 private Integer albumDetailId;
 
 @Column(name="image_url")
 private String imageUrl;
 
 @Column(name="created_date",columnDefinition = "DATETIME")
 private Date createdDate;
 
 @ManyToOne
 @JoinColumn(name = "album_id", referencedColumnName = "id")
 private Album album;

    public AlbumDetail() {
    }

    public Integer getAlbumDetailId() {
        return albumDetailId;
    }

    public void setAlbumDetailId(Integer albumDetailId) {
        this.albumDetailId = albumDetailId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Album getAlbum() {
        return album;
    }

    public void setAlbum(Album album) {
        this.album = album;
    }
 
 
}
