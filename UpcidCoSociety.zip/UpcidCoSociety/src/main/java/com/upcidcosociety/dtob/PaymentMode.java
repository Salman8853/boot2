/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import com.upcidcosociety.util.CommonAttributes;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name="paymentmode")
public class PaymentMode extends  CommonAttributes implements Serializable{
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "payment_id")
 private Integer paymentId;
 
 @Column(name="payment_type")
 private String paymentType;

    public Integer getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Integer paymentId) {
        this.paymentId = paymentId;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }
 
 
}
