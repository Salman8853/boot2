/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import com.upcidcosociety.util.CommonAttributes;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name="category")
public class Category extends  CommonAttributes implements Serializable{
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "cat_id")
 private Integer catId;
 
 @Column(name="category_name")
 private String categoryName;

    public Category() {
    }

    public Integer getCatId() {
        return catId;
    }

    public void setCatId(Integer catId) {
        this.catId = catId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

}
