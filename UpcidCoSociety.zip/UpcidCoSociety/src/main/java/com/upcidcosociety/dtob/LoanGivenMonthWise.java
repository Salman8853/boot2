/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "loan_given_monthwise")
public class LoanGivenMonthWise {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "month")
    private String month;

    @Column(name = "amount")
    private Double amount;
    
    @Column(name = "date", columnDefinition = "DATE")
    private  Date date;
    
    @Column(name = "finyear")
    private Integer finyear;
    
     @ManyToOne
     @JoinColumn(name = "loan_id", referencedColumnName = "loan_id")
     private LoanDetails loandetails;

    public LoanGivenMonthWise() {
        
    }

    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getFinyear() {
        return finyear;
    }

    public void setFinyear(Integer finyear) {
        this.finyear = finyear;
    }

    public LoanDetails getLoandetails() {
        return loandetails;
    }

    public void setLoandetails(LoanDetails loandetails) {
        this.loandetails = loandetails;
    }
      
}
