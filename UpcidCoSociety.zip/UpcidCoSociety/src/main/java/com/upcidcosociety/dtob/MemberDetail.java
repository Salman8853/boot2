/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.upcidcosociety.util.CommonAttributes;
import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "member_detail")
public class MemberDetail extends CommonAttributes implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "member_id")
    private Integer memberId;

    @Column(name = "member_name")
    private String memberName;

    @Column(name = "date_of_birth", columnDefinition = "DATETIME")
    private Date dateOfBirth;

    @Column(name = "date_of_appointment", columnDefinition = "DATETIME")
    private Date dateofappoint;

    @Column(name = "date_of_retirement", columnDefinition = "DATETIME")
    private Date dateOfRetirement;
    
    @Column(name="account_opening_date",columnDefinition = "DATETIME")
    private Date accountOpeningDate; 
    
    @Column(name = "pno_number")
    private String pnoNumber;

    @Column(name = "father_name")
    private String fatherName;

    @Column(name = "mobileNumber")
    private String mobileNumber;

    @Column(name = "email")
    private String email;

    @Column(name = "present_address")
    private String presentAddress;

    @Column(name = "permanent_address")
    private String permanentAddress;

    @Column(name = "profileulr")
    private String profileulr;

    @Column(name = "signurl")
    private String signurl;

    @Column(name = "account_open_formurl")
    private String accountOpenFormurl;

    @Column(name = "gpfornpanumber")
    private String gpfornpanumber;

    @Column(name = "aadharnumber")
    private String aadharnumber;

    @Column(name = "pannumber")
    private String pannumber;
    
    @Column(name = "accountstart_date",columnDefinition = "DATETIME")
    private Date accountstartDate ;

    @Column(name = "memberaccount_number")
    private String memberaccountNumber;
    
    @Column(name = "desclaimer")
    private Boolean desclaimer;
    
    @Column(name = "status")
    private String status;
    
    

//    @JsonIgnore
//    @OneToMany(mappedBy = "memberDetail", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    private Set<MemberAddress> memberAddress;
    @JsonIgnore
    @OneToMany(mappedBy = "memberDetail", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Nominee> nominee;
    
//    @JsonIgnore
//    @OneToMany(mappedBy = "memberDetail", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    private Set<MemberWitness> mwitnessSet;
   
    
    
    
    @OneToOne
    @JoinColumn(name = "memberaccount_id")
    private MemberAccount memberAccount;

    @OneToOne
    @JoinColumn(name = "user_id")
    private Users users;

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Date getDateOfRetirement() {
        return dateOfRetirement;
    }

    public void setDateOfRetirement(Date dateOfRetirement) {
        this.dateOfRetirement = dateOfRetirement;
    }

    public Date getAccountOpeningDate() {
        return accountOpeningDate;
    }

    public void setAccountOpeningDate(Date accountOpeningDate) {
        this.accountOpeningDate = accountOpeningDate;
    }

    public String getPnoNumber() {
        return pnoNumber;
    }

    public void setPnoNumber(String pnoNumber) {
        this.pnoNumber = pnoNumber;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPresentAddress() {
        return presentAddress;
    }

    public void setPresentAddress(String presentAddress) {
        this.presentAddress = presentAddress;
    }

    public String getPermanentAddress() {
        return permanentAddress;
    }

    public void setPermanentAddress(String permanentAddress) {
        this.permanentAddress = permanentAddress;
    }

    public String getProfileulr() {
        return profileulr;
    }

    public void setProfileulr(String profileulr) {
        this.profileulr = profileulr;
    }

    public String getSignurl() {
        return signurl;
    }

    public void setSignurl(String signurl) {
        this.signurl = signurl;
    }

    public String getAccountOpenFormurl() {
        return accountOpenFormurl;
    }

    public Date getDateofappoint() {
        return dateofappoint;
    }

    public void setDateofappoint(Date dateofappoint) {
        this.dateofappoint = dateofappoint;
    }

    public String getGpfornpanumber() {
        return gpfornpanumber;
    }

    public void setGpfornpanumber(String gpfornpanumber) {
        this.gpfornpanumber = gpfornpanumber;
    }

    public String getAadharnumber() {
        return aadharnumber;
    }

    public void setAadharnumber(String aadharnumber) {
        this.aadharnumber = aadharnumber;
    }

    public String getPannumber() {
        return pannumber;
    }

    public void setPannumber(String pannumber) {
        this.pannumber = pannumber;
    }

    public Date getAccountstartDate() {
        return accountstartDate;
    }

    public void setAccountstartDate(Date accountstartDate) {
        this.accountstartDate = accountstartDate;
    }

    public String getMemberaccountNumber() {
        return memberaccountNumber;
    }

    public void setMemberaccountNumber(String memberaccountNumber) {
        this.memberaccountNumber = memberaccountNumber;
    }

    public Boolean getDesclaimer() {
        return desclaimer;
    }

    public void setDesclaimer(Boolean desclaimer) {
        this.desclaimer = desclaimer;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    
    
    public void setAccountOpenFormurl(String accountOpenFormurl) {
        this.accountOpenFormurl = accountOpenFormurl;
    }

    public Set<Nominee> getNominee() {
        return nominee;
    }

    public void setNominee(Set<Nominee> nominee) {
        this.nominee = nominee;
    }

//    public Set<MemberWitness> getMwitnessSet() {
//        return mwitnessSet;
//    }
//
//    public void setMwitnessSet(Set<MemberWitness> mwitnessSet) {
//        this.mwitnessSet = mwitnessSet;
//    }
    public MemberAccount getMemberAccount() {
        return memberAccount;
    }

    public void setMemberAccount(MemberAccount memberAccount) {
        this.memberAccount = memberAccount;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }
    
}
