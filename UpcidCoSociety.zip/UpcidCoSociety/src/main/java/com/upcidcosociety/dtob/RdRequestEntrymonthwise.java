/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "rdrequestentry_monthwise")
public class RdRequestEntrymonthwise {
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "rdrequest_id")
 private Integer rdrequestId;
 
 @Column(name = "member_id")
 private Integer memberId;
 
 
 @Column(name = "rdaccountno" )
 private Integer rdaccountno;
 
 @JoinColumn(name = "rdserial_no")
 private Integer rdserialno;
 
 @Column(name="financial_year")
 private String financialYear;
 
 @Column(name="month_name")
 private String monthName;
 
 @Column(name="amount")
 private Double amount;
 
 @Column(name="request_by")
 private String requestBy;
 
 @Column(name="status")
 private Boolean status;
 
 @Column(name="created_date",columnDefinition = "DATE")
 private Date createdDate;

    public Integer getRdrequestId() {
        return rdrequestId;
    }

    public void setRdrequestId(Integer rdrequestId) {
        this.rdrequestId = rdrequestId;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public Integer getRdaccountno() {
        return rdaccountno;
    }

    public void setRdaccountno(Integer rdaccountno) {
        this.rdaccountno = rdaccountno;
    }

    public Integer getRdserialno() {
        return rdserialno;
    }

    public void setRdserialno(Integer rdserialno) {
        this.rdserialno = rdserialno;
    }

    public String getFinancialYear() {
        return financialYear;
    }

    public void setFinancialYear(String financialYear) {
        this.financialYear = financialYear;
    }

    public String getMonthName() {
        return monthName;
    }

    public void setMonthName(String monthName) {
        this.monthName = monthName;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

   

    public String getRequestBy() {
        return requestBy;
    }

    public void setRequestBy(String requestBy) {
        this.requestBy = requestBy;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
 
 
}
