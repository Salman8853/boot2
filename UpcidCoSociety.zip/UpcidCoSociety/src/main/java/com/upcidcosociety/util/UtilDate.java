/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 *
 * @author m.salman
 */
public class UtilDate {
     private static final Logger logger  = LoggerFactory.getLogger(UtilDate.class);
    public static final SimpleDateFormat dd_MM_yyyy = new SimpleDateFormat("dd-MM-yyyy");
    public static final SimpleDateFormat MM_dd_yyyy = new SimpleDateFormat("MM-dd-yyyy");
    public static final SimpleDateFormat MMsddsyyyy = new SimpleDateFormat("MM/dd/yyyy");
//    public static SimpleDateFormat CLIENT_SDF = new SimpleDateFormat("MMM dd, yyyy hh:mm:ss");
    public static final SimpleDateFormat dd_MM_yyyy_hh_mm_ss = new SimpleDateFormat("ddMMyyyyhhmmss");
    public static final SimpleDateFormat MM_dd_yyyy_HH_mm_ss = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
    public static final SimpleDateFormat YYYY_MM_dd_HH_mm_ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public static final SimpleDateFormat MM_dd_yyyy_hh_mm = new SimpleDateFormat("MM-dd-yyyy hh:mm");
    public static SimpleDateFormat dbDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    public static SimpleDateFormat dbDateTimeFormat = new SimpleDateFormat("yyyy-MM-dd  hh:mm:ss");
    public static SimpleDateFormat D_MMM_YYYY_H_MM_A = new SimpleDateFormat("d MMM yyyy (h:mm a)");
    public static SimpleDateFormat D_MMM_YYYY = new SimpleDateFormat("d MMM yyyy");
    
     public static String formateDateToStringddMMyyyyhhmmss(Date date) {
       try {
            if (date != null) {
                return dd_MM_yyyy_hh_mm_ss.format(date);
            }
        } catch (Exception e) {
            logger.error("Error", e);
        }
        return dd_MM_yyyy_hh_mm_ss.format(new Date());

    }
 
     public static String formatetdateToString_dd_MM_yyyy(Date date) {
        try {
            if (date != null) {
                return dd_MM_yyyy.format(date);
            }
        } catch (Exception e) {
            logger.error("Error", e);
        }
        return dd_MM_yyyy.format(new Date());
    }
      public static String formatedateTostring_MM_dd_yyyy_HH_mm_ss(Date date) {
        try {
            if (date != null) {
                return MM_dd_yyyy_HH_mm_ss.format(date);
            }
        } catch (Exception e) {
            logger.error("Error", e);
        }
        return MM_dd_yyyy_HH_mm_ss.format(new Date());
    }
      
       public static Timestamp convertDatetoTimestamp(Date dateStr) {
        Timestamp timestamp = new Timestamp(dateStr.getTime());
        return timestamp;
    }
     public static Date formattedDate(Date crtDate) {
         try {
             return dd_MM_yyyy.parse(dd_MM_yyyy.format(crtDate));
         } catch (Exception e) {
             return new Date();
         }
    }
     public static String formattedDate_D_MMM_YYYY(Date crtDate) {
         try {
             return D_MMM_YYYY.format(crtDate);
         } catch (Exception e) {
             return D_MMM_YYYY.format(new Date());
         }
    }
       
        public static Date convertStringToDate(String DateStr) {

        Date date = null;
        try {
            date = new SimpleDateFormat("dd-MM-yyyy").parse(DateStr);
        } catch (ParseException e) {

            e.printStackTrace();
        }
        return date;
    }
    
       public static Date convertStringToDate(String startDate, String format){ //throws Exception {

            Date date = null;
            try
            {
               date = new SimpleDateFormat(format).parse(startDate);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
		
	   return date;
	}
     
       
 
}   
 
