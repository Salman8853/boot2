/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.util;

import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author m.salman
 */
public class MailBodyContentUtil {
     private static final Logger logger = LoggerFactory.getLogger(MailBodyContentUtil.class);
    
     public static String mailbodyformemberComplaint(String logoPath, String memebername,String remark,String answer) {
         StringBuilder sb = new StringBuilder(); 
        String bodyContent = "";
        try {
                    sb.append("<!doctype html>\n");
                    sb.append("<html>\n") ;
                    sb.append("\n") ;
                    sb.append("<head>\n");
                    sb.append("<title>Untitled Document</title>\n");
                    sb.append("</head>\n");
                    sb.append("\n");
                    sb.append("<body bgcolor=\"#f0f0f0\">\n");
                    sb.append("<table width=\"100%\" bgcolor=\"#f0f0f0\" style=\"background-color:#f0f0f0; font-family: roboto\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n");
                    sb.append("<tbody>\n");
                    sb.append("<tr>\n");
                    sb.append("<td>&nbsp; </td>\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append("<td> <table class=\"m_3215276118864477536full-width\" align=\"center\"  width=\"600\" border=\"0\" cellpadding=\"0\"\n");
                    sb.append("cellspacing=\"0\" bgcolor=\"#ffffff\" style=\"background-color:#ffffff; border-radius: 3px; width:600px\">\n");
                    sb.append("<tbody>\n");
                    sb.append("<tr>\n");
                    sb.append("<td valign=\"middle\" style=\"padding-top:30px;padding-bottom:26px;width:52px; text-align: center\"><img alt=\"\"\n");
                    sb.append("src=" + logoPath + " border=\"0\" hspace=\"0\" vspace=\"0\">\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append("</tbody>\n");
                    sb.append("</table></td>\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append("<td>&nbsp; </td>\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append("<td>\n");
                    sb.append("\n");
                    sb.append("<table class=\"m_3215276118864477536email-width\" align=\"center\" width=\"600\" border=\"0\" cellpadding=\"0\"\n");
                    sb.append("cellspacing=\"0\" style=\"width:600px; \">\n");
                    sb.append("<tbody>\n");
                    sb.append("  <tr>\n");
                    sb.append("<td bgcolor=\"#ffffff\" style=\"background-color:#ffffff\">\n");
                    sb.append("  <table class=\"m_3215276118864477536full-width\" align=\"center\" width=\"600\" border=\"0\" cellpadding=\"0\"\n");
                    sb.append("cellspacing=\"0\" bgcolor=\"#ffffff\" style=\"background-color:#ffffff;width:600px;border-radius: 3px;\">\n");
                    sb.append("<tbody>\n");
                    sb.append("  <tr>\n");
                    sb.append("   \n");
                    sb.append("<td align=\"left\" class=\"m_3215276118864477536mobile-text\"\n");
                    sb.append("style=\"color:#000000;font-family:Roboto;font-size:15px;line-height:20px;padding:20px;\">\n");
                    sb.append("<p>Hello <b>" + memebername + "</b>,<br/> \n");
                    sb.append("You logged a complaints againts U.P C.I.D credit Cooperative Society Limited.<br/>");
                    sb.append("<b>Your complaint is :</b><br/>");
                    sb.append(remark).append(".<br/>");
                    sb.append("<b>reply to your complaint is:</b><br/>");
                    sb.append(answer).append("<br/>");
                    sb.append("\n");
                    sb.append("</td>\n");
                    sb.append("\n");
                    sb.append("</tr>\n");
                    sb.append("\n");
                    sb.append("<tr>\n");
                    sb.append("\n");
                    sb.append("<td align=\"center\" style=\"height: 50px\">\n");
                    sb.append("\n");
                    sb.append("</td>\n");
                    sb.append("\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append("<td style=\"background: #061770; text-align: center; color: #ffffff; padding: 15px; border-radius: 0 0 3px 3px;\">Thank You!!\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append("</tbody>\n");
                    sb.append("</table>\n");
                    sb.append( "\n");
                    sb.append( "\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append("</tbody>\n");
                    sb.append("  </table>\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append(" <tr>\n");
                    sb.append("<td>\n");
                    sb.append(" \n");
                    sb.append("\n");
                    sb.append("\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append("</tbody>\n");
                    sb.append("</table>\n");
                    sb.append("</body>\n");
                    sb.append("\n");
                    sb.append("</html>");
            
                 
        } catch (Exception e) {
            logger.error("Exception While generateBodyContentForActivateCustomerMailLink " + e);
        }
      return sb.toString();
    }
 public static String mailBodyformemberAccountCreation(String logoPath,String loginLink, String memebername,String pnoNumber,String password) {
        StringBuilder sb = new StringBuilder(); 
             try{
                    sb.append("<!doctype html>\n");
                    sb.append("<html>\n") ;
                    sb.append("\n") ;
                    sb.append("<head>\n");
                    sb.append("<title>Untitled Document</title>\n");
                    sb.append("</head>\n");
                    sb.append("\n");
                    sb.append("<body bgcolor=\"#f0f0f0\">\n");
                    sb.append("<table width=\"100%\" bgcolor=\"#f0f0f0\" style=\"background-color:#f0f0f0; font-family: roboto\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n");
                    sb.append("<tbody>\n");
                    sb.append("<tr>\n");
                    sb.append("<td>&nbsp; </td>\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append("<td> <table class=\"m_3215276118864477536full-width\" align=\"center\"  width=\"600\" border=\"0\" cellpadding=\"0\"\n");
                    sb.append("cellspacing=\"0\" bgcolor=\"#ffffff\" style=\"background-color:#ffffff; border-radius: 3px; width:600px\">\n");
                    sb.append("<tbody>\n");
                    sb.append("<tr>\n");
                    sb.append("<td valign=\"middle\" style=\"padding-top:30px;padding-bottom:26px;width:52px; text-align: center\"><img alt=\"\"\n");
                    sb.append("src=" + logoPath + " border=\"0\" hspace=\"0\" vspace=\"0\">\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append("</tbody>\n");
                    sb.append("</table></td>\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append("<td>&nbsp; </td>\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append("<td>\n");
                    sb.append("\n");
                    sb.append("<table class=\"m_3215276118864477536email-width\" align=\"center\" width=\"600\" border=\"0\" cellpadding=\"0\"\n");
                    sb.append("cellspacing=\"0\" style=\"width:600px; \">\n");
                    sb.append("<tbody>\n");
                    sb.append("<tr>\n");
                    sb.append("<td bgcolor=\"#ffffff\" style=\"background-color:#ffffff\">\n");
                    sb.append("<table class=\"m_3215276118864477536full-width\" align=\"center\" width=\"600\" border=\"0\" cellpadding=\"0\"\n");
                    sb.append("cellspacing=\"0\" bgcolor=\"#ffffff\" style=\"background-color:#ffffff;width:600px;border-radius: 3px;\">\n");
                    sb.append("<tbody>\n");
                    sb.append("<tr>\n");
                    sb.append("\n");
                    sb.append("<td align=\"left\"\n");
                    sb.append("style=\"color:#69ba3a;font-size:30px;line-height:35px;font-weight:normal;padding:20px 20px 0px\">\n");
                    sb.append("Congratulations!! </td>\n");
                    sb.append("\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append(" \n");
                    sb.append("<td align=\"left\" class=\"m_3215276118864477536mobile-text\"\n");
                    sb.append("style=\"color:#2E2E2E;font-family:Roboto;font-size:15px;line-height:20px;padding:20px;\">\n");
                    sb.append("<p>Hello " + memebername + ", \n");
                    sb.append("you are successfully registered with U.P C.I.D  credit Cooperative Society Limited.");
                    sb.append(" Your account detail is:<br><b>Username:</b> ").append(pnoNumber).append("<br>");
                    sb.append("<b>Password:</b> " ).append(password).append("<br/>");
                    sb.append("please click here:" );
                    sb.append("<a href=" ).append(loginLink).append(">");
                    sb.append(loginLink ).append("</a>");
                    sb.append("<br>and do login.");
                    sb.append("</p> <br>\n");
//                    sb.append("<p>We look forward to doing business together. </p> \n");
//                    sb.append("\n");
                    sb.append("</td>\n");
                    sb.append("\n");
                    sb.append("</tr>\n");
                    sb.append(" \n");
                    sb.append("<tr>\n");
                    sb.append("\n");
                    sb.append("<td align=\"center\" style=\"height: 50px\">\n");
                    sb.append(" \n");
                    sb.append("</td>\n");
                    sb.append("\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append("<td style=\"background: #061770; text-align: center; color: #ffffff; padding: 15px; border-radius: 0 0 3px 3px;\">Thank You!!\n");
                    sb.append("</td>\n");
                    sb.append("  </tr>\n");
                    sb.append("</tbody>\n");
                    sb.append("</table>\n");
                    sb.append("\n");
                    sb.append("\n");
                    sb.append("\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append("</tbody>\n");
                    sb.append("</table>\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append( " <tr>\n");
                    sb.append("<td>\n");
                    sb.append( " \n");
                    sb.append("\n");
                    sb.append("\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append("</tbody>\n");
                    sb.append("</table>\n");
                    sb.append("</body>\n");
                    sb.append("\n");
                    sb.append("</html>");
        } catch (Exception e) {
            logger.error("Exception While generateBodyContentForActivateCustomerMailLink " + e);
        }
        return sb.toString();
    }
 
 public static String mailBodyformemberAccountCreationfromMemberSide(String logoPath, String memebername) {
        StringBuilder sb = new StringBuilder(); 
             try{
                    sb.append("<!doctype html>\n");
                    sb.append("<html>\n") ;
                    sb.append("\n") ;
                    sb.append("<head>\n");
                    sb.append("<title>Untitled Document</title>\n");
                    sb.append("</head>\n");
                    sb.append("\n");
                    sb.append("<body bgcolor=\"#f0f0f0\">\n");
                    sb.append("<table width=\"100%\" bgcolor=\"#f0f0f0\" style=\"background-color:#f0f0f0; font-family: roboto\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n");
                    sb.append("<tbody>\n");
                    sb.append("<tr>\n");
                    sb.append("<td>&nbsp; </td>\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append("<td> <table class=\"m_3215276118864477536full-width\" align=\"center\"  width=\"600\" border=\"0\" cellpadding=\"0\"\n");
                    sb.append("cellspacing=\"0\" bgcolor=\"#ffffff\" style=\"background-color:#ffffff; border-radius: 3px; width:600px\">\n");
                    sb.append("<tbody>\n");
                    sb.append("<tr>\n");
                    sb.append("<td valign=\"middle\" style=\"padding-top:30px;padding-bottom:26px;width:52px; text-align: center\"><img alt=\"\"\n");
                    sb.append("src=" + logoPath + " border=\"0\" hspace=\"0\" vspace=\"0\">\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append("</tbody>\n");
                    sb.append("</table></td>\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append("<td>&nbsp; </td>\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append("<td>\n");
                    sb.append("\n");
                    sb.append("<table class=\"m_3215276118864477536email-width\" align=\"center\" width=\"600\" border=\"0\" cellpadding=\"0\"\n");
                    sb.append("cellspacing=\"0\" style=\"width:600px; \">\n");
                    sb.append("<tbody>\n");
                    sb.append("<tr>\n");
                    sb.append("<td bgcolor=\"#ffffff\" style=\"background-color:#ffffff\">\n");
                    sb.append("<table class=\"m_3215276118864477536full-width\" align=\"center\" width=\"600\" border=\"0\" cellpadding=\"0\"\n");
                    sb.append("cellspacing=\"0\" bgcolor=\"#ffffff\" style=\"background-color:#ffffff;width:600px;border-radius: 3px;\">\n");
                    sb.append("<tbody>\n");
                    sb.append("<tr>\n");
                    sb.append("\n");
                    sb.append("<td align=\"left\"\n");
                    sb.append("style=\"color:#69ba3a;font-size:30px;line-height:35px;font-weight:normal;padding:20px 20px 0px\">\n");
                    sb.append("Congratulations!! </td>\n");
                    sb.append("\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append(" \n");
                    sb.append("<td align=\"left\" class=\"m_3215276118864477536mobile-text\"\n");
                    sb.append("style=\"color:#2E2E2E;font-family:Roboto;font-size:15px;line-height:20px;padding:20px;\">\n");
                    sb.append("<p>Hello " + memebername + ", \n");
                    sb.append("congratulation! you are successfully registered with U.P C.I.D  credit Cooperative Society Limited.");
                    sb.append(" Your detail will be verify by admin,then you will get credential for Sign in").append("<br>");
                    sb.append("</p> <br>\n");
//                    sb.append("<p>We look forward to doing business together. </p> \n");
//                    sb.append("\n");
                    sb.append("</td>\n");
                    sb.append("\n");
                    sb.append("</tr>\n");
                    sb.append(" \n");
                    sb.append("<tr>\n");
                    sb.append("\n");
                    sb.append("<td align=\"center\" style=\"height: 50px\">\n");
                    sb.append(" \n");
                    sb.append("</td>\n");
                    sb.append("\n");
                    sb.append("</tr>\n");
                    sb.append("<tr>\n");
                    sb.append("<td style=\"background: #061770; text-align: center; color: #ffffff; padding: 15px; border-radius: 0 0 3px 3px;\">Thank You!!\n");
                    sb.append("</td>\n");
                    sb.append("  </tr>\n");
                    sb.append("</tbody>\n");
                    sb.append("</table>\n");
                    sb.append("\n");
                    sb.append("\n");
                    sb.append("\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append("</tbody>\n");
                    sb.append("</table>\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append( " <tr>\n");
                    sb.append("<td>\n");
                    sb.append( " \n");
                    sb.append("\n");
                    sb.append("\n");
                    sb.append("</td>\n");
                    sb.append("</tr>\n");
                    sb.append("</tbody>\n");
                    sb.append("</table>\n");
                    sb.append("</body>\n");
                    sb.append("\n");
                    sb.append("</html>");
        } catch (Exception e) {
            logger.error("Exception While generateBodyContentForActivateCustomerMailLink " + e);
        }
        return sb.toString();
    }

}
