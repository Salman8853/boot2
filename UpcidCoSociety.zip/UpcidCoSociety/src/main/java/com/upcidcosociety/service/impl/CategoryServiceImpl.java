/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.CategoryDao;
import com.upcidcosociety.dao.MemberAccountDao;
import com.upcidcosociety.dtob.Category;
import com.upcidcosociety.model.CategoryModel;
import com.upcidcosociety.service.CategoryService;
import com.upcidcosociety.util.UpcidConstants;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class CategoryServiceImpl implements CategoryService {

    private static final Logger logger = LoggerFactory.getLogger(CategoryServiceImpl.class);
    @Autowired
    private CategoryDao categoryDao;

    @Autowired
    private MemberAccountDao memberAccountDao;

    @Override
    public UpcidResponse addCategory(Category category, String remoteaddress, String username) {
        UpcidResponse response = new UpcidResponse();
        try {
            Category cat = null;
            if (category != null && category.getCategoryName() != null && category.getCategoryName().trim().length() > 0) {
                cat = categoryDao.checkCategoryByName(category.getCategoryName());
                if (cat != null && cat.getCatId() > 0) {
                    response.setStatus(HttpStatus.CONFLICT);
                    response.setMessage("Category already exist");
                    response.setData(category);
                    return response;
                }
                cat = new Category();
                cat.setCategoryName(category.getCategoryName());
                cat.setCreatedDate(UtilDate.convertDatetoTimestamp(new Date()));
                cat.setIpAddress(remoteaddress);
                cat.setCreatedBy(username);
                cat.setModifiedBy(username);
                cat.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                Category ctegory = categoryDao.addCategory(cat);
                if (ctegory != null && ctegory.getCatId() != null && ctegory.getCatId() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record saved!");
                    response.setData(ctegory);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not saved!");
                    response.setData(ctegory);
                }

            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Plaese enter mandatory fields!");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving category");
            logger.info("Exception while saving category:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse updateCategory(Category category, String remoteaddress, String username) {
        UpcidResponse response = new UpcidResponse();
        Category ctegory = null;
        try {
            if (category != null && category.getCatId() != null && category.getCatId() > 0 && category.getCategoryName() != null && category.getCategoryName().trim().length() > 0) {
                ctegory = categoryDao.checkCategoryByidAndName(category.getCatId(), category.getCategoryName());
                if (ctegory != null) {
                    response.setStatus(HttpStatus.CONFLICT);
                    response.setMessage("record already exist");
                    response.setData(category);
                    return response;
                }
                ctegory = categoryDao.getCategoryByid(category.getCatId());

                ctegory.setCategoryName(category.getCategoryName());
                ctegory.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                ctegory.setIpAddress(remoteaddress);
                ctegory.setModifiedBy(username);
                Category ct = categoryDao.updateCategory(ctegory);
                if (ct != null && ct.getCatId() > 0) {
                    response.setStatus(HttpStatus.OK);;
                    response.setMessage("Record update!");
                    response.setData(ctegory);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record updation failed!");
                    response.setData(ctegory);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Plaese enter mandatory fields!");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving update category");
            logger.info("Exception while update category:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getAllCategory(String userName) {
        UpcidResponse<List<CategoryModel>> response = new UpcidResponse();
        try {
            CategoryModel categoryModel = null;
            List<CategoryModel> CategoryModelList = new ArrayList<>();
            List<Integer> categoryIdList = new ArrayList<>();
            List<Category> categoryList = memberAccountDao.getallDistinctCategoryListByCriteria();
            if (categoryList != null && categoryList.size() > 0) {
                for (Category category : categoryList) {

                    categoryIdList.add(category.getCatId());
                }
            }
            List<Category> ctglst = categoryDao.getAllCategory();
            if (ctglst != null && ctglst.size() > 0) {
                for (Category category : ctglst) {
                    categoryModel = new CategoryModel();
                    categoryModel.setCatId(category.getCatId());
                    categoryModel.setCategoryName(category.getCategoryName());

                    if (categoryIdList != null && categoryIdList.contains(category.getCatId())) {

                        categoryModel.setInUse(UpcidConstants.IN_USE);

                    } else {

                        categoryModel.setInUse(UpcidConstants.IS_Delete);
                    }
                    CategoryModelList.add(categoryModel);
                }
                response.setStatus(HttpStatus.OK);
                response.setMessage("");
                response.setData(CategoryModelList);
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Not Found");
                response.setData(CategoryModelList);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured whengetAll rank");
            logger.info("Exception occured while getAll Category:" + e);
            e.printStackTrace();
        }
        return response;
    }
    
    
    @Override
     public UpcidResponse getAllCategoryforMember(String userName){
        UpcidResponse<List<Category>> response=new UpcidResponse();
         try {
             
             List<Category>ctglst=categoryDao.getAllCategory();
            if(ctglst!=null && ctglst.size()>0){
                response.setStatus(HttpStatus.OK);
                response.setMessage("");
                response.setData(ctglst);
            }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Not Found");
                response.setData(ctglst);
             } 
         } catch (Exception e) {
              response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured whengetAll rank");
             logger.info("Exception occured while getAll Category:" + e);
              e.printStackTrace();
         }
         return response;
     }

    @Override
    public UpcidResponse getCategoryById(Integer id, String userName) {
        UpcidResponse<Category> response = new UpcidResponse();
        try {
            if (id != null && id > 0) {
                Category category = categoryDao.getCategoryByid(id);
                if (category != null && category.getCatId() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("");
                    response.setData(category);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found");
                    response.setData(category);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("category id not found");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when get category by id");
            logger.info("Exception occured when get category by id:" + e);
            e.printStackTrace();
        }
        return response;
    }

    @Override
    public UpcidResponse softDeleteCategoryById(Integer id, String userName) {
        UpcidResponse<Category> response = new UpcidResponse();
        try {
            if (id != null && id > 0) {
                Category category = categoryDao.getCategoryByid(id);
                if (category != null && category.getCatId() != null && category.getCatId() > 0) {

                    category.setIsDeleted(Boolean.TRUE);
                    category.setModifiedBy(userName);
                    category.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                    Category cat = categoryDao.updateCategory(category);
                    if (cat != null && cat.getCatId() != null && cat.getCatId() > 0) {
                        response.setStatus(HttpStatus.OK);
                        response.setMessage("record deleted");
                        response.setData(cat);
                    } else {
                        response.setStatus(HttpStatus.NOT_FOUND);
                        response.setMessage("record deletion failed");
                        response.setData(cat);
                    }
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("record not found");
                    response.setData(category);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("category id not found");
                response.setData(null);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when delete category by id");
            logger.info("Exception occured when delete category by id:" + e);
            e.printStackTrace();
        }
        return response;
    }
}
