/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.ComplaintsCategoryMasterDao;
import com.upcidcosociety.dao.ComplaintsDao;
import com.upcidcosociety.dao.ComplaintsRequestMasterDao;
import com.upcidcosociety.dtob.ComplaintsCategoryMaster;
import com.upcidcosociety.service.ComplaintsCategoryMasterService;
import com.upcidcosociety.util.UpcidResponse;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class ComplaintsCategoryMasterServiceImpl  implements ComplaintsCategoryMasterService{
   
      private static final Logger logger = LoggerFactory.getLogger(ComplaintsCategoryMasterServiceImpl.class);

    @Autowired
    private ComplaintsCategoryMasterDao complaintsCategoryMasterDao;
    
    
      public UpcidResponse getAllComplaintsCategoryMaster(){
      UpcidResponse<List<ComplaintsCategoryMaster>> response=new UpcidResponse();
         try { 
            List<ComplaintsCategoryMaster>ccMasterlst=complaintsCategoryMasterDao.getAllComplaintsCategoryMaster();
            if(ccMasterlst!=null && ccMasterlst.size()>0){
                response.setStatus(HttpStatus.OK);
                response.setMessage("");
                response.setData(ccMasterlst);
            }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Not Found");
                response.setData(ccMasterlst);
             } 
         } catch (Exception e) {
              response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getAll ComplaintsCategoryMaster");
             logger.info("Exception occured while getAll ComplaintsCategoryMaster:" + e);
              e.printStackTrace();
         }
         return response;
      }

}
