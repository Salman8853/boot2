/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.ComplaintsCategoryMasterDao;
import com.upcidcosociety.dao.ComplaintsDao;
import com.upcidcosociety.dao.ComplaintsRequestMasterDao;
import com.upcidcosociety.dtob.Complaints;
import com.upcidcosociety.dtob.ComplaintsCategoryMaster;
import com.upcidcosociety.dtob.ComplaintsRequestMaster;
import com.upcidcosociety.model.ComplaintsModel;
import com.upcidcosociety.model.ComplaintsReplyModel;
import com.upcidcosociety.service.ComplaintsService;
import com.upcidcosociety.service.EmailService;
import com.upcidcosociety.util.UpcidResponse;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class ComplaintsServiceImpl implements ComplaintsService {

    private static final Logger logger = LoggerFactory.getLogger(ComplaintsServiceImpl.class);

    @Autowired
    private ComplaintsDao complaintsDao;

    @Autowired
    private ComplaintsCategoryMasterDao complaintsCategoryMasterDao;

    @Autowired
    private ComplaintsRequestMasterDao complaintsRequestMasterDao;

    @Autowired
    private EmailService emailService;
    
     @Value("${logopath}")
     private String logopath;
     
     
    @Override
    public UpcidResponse saveNewComplaints(ComplaintsModel complaintsModel) {
        UpcidResponse<Complaints> response = new UpcidResponse();
        try {
            Complaints compl = null;
            if (complaintsModel != null && complaintsModel.getCustomerName() != null && complaintsModel.getCustomerName().trim().length() > 0 && complaintsModel.getPnotNumber() != null && complaintsModel.getPnotNumber().trim().length() > 0) {
                compl = new Complaints();
                ComplaintsRequestMaster cRMaster = null;
                cRMaster = complaintsRequestMasterDao.getComplaintsRequestMasterByid(complaintsModel.getCompRequest());
                if (cRMaster != null) {
                    compl.setCompRequest(cRMaster);
                }
                ComplaintsCategoryMaster complCategoryMaster = null;
                complCategoryMaster = complaintsCategoryMasterDao.getComplaintsCategoryMasterByid(complaintsModel.getCompCategory());
                if (complCategoryMaster != null) {
                    compl.setCompCategory(complCategoryMaster);
                }
                compl.setPnotNumber(complaintsModel.getPnotNumber());
                compl.setMobileNumber(complaintsModel.getMobileNumber());
                compl.setCustomerName(complaintsModel.getCustomerName());
                compl.setEmailId(complaintsModel.getEmailId());
                compl.setPinCode(complaintsModel.getPinCode());
                compl.setRemark(complaintsModel.getRemark());
                Complaints complaint = complaintsDao.saveComplaints(compl);
                if (complaint != null && complaint.getCompId() != null && complaint.getCompId() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Your complaint has been successfully saved!");
                    response.setData(complaint);

                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Your complaint sending failed!");
                    response.setData(complaint);

                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Please fill all mendatory fields!");
                response.setData(null);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving complaint");
            logger.info("Exception while saving complaint:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getAllComplaints(String username) {
        UpcidResponse<List<Complaints>> response = new UpcidResponse();
        try {

            List<Complaints> cpmlist = complaintsDao.getAllComplaints();
            if (cpmlist != null && cpmlist.size() > 0) {
                response.setStatus(HttpStatus.OK);
                response.setMessage("Ok");
                response.setData(cpmlist);

            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record not found!");
                response.setData(cpmlist);

            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while getting all complaint");
            logger.info("Exception while getting all complaint:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getComplaintById(Integer id) {
        UpcidResponse<Complaints> response = new UpcidResponse();
        try {
            Complaints complaints = complaintsDao.getComplaintbyId(id);
            if (complaints != null && complaints.getCompId() != null && complaints.getCompId() > 0) {
                response.setStatus(HttpStatus.OK);
                response.setMessage("Ok");
                response.setData(complaints);
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("not found!");
                response.setData(complaints);

            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while getting complaint by id");
            logger.info("Exception while getting complaint by id:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse sentcomplaintReplytoMember(ComplaintsReplyModel complaintsReplyModel) {
        UpcidResponse response = new UpcidResponse();
        try {
            if (complaintsReplyModel != null && complaintsReplyModel.getId() != null && complaintsReplyModel.getId() > 0
                    && complaintsReplyModel.getName() != null && complaintsReplyModel.getName().trim().length() > 0
                    && complaintsReplyModel.getEmail() != null && complaintsReplyModel.getEmail().trim().length() > 0
                    && complaintsReplyModel.getRemark() != null && complaintsReplyModel.getRemark().trim().length() > 0
                    && complaintsReplyModel.getResponse() != null && complaintsReplyModel.getResponse().trim().length() > 0) {
                response = emailService.sendMailToMemeberForComplaint(logopath,complaintsReplyModel.getName(), complaintsReplyModel.getEmail(), complaintsReplyModel.getRemark(), complaintsReplyModel.getResponse());
            }
          

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while sending complaint reply");
            logger.info("Exception occured while sending complaint reply:" + e);

        }
  return response;
    }

}
