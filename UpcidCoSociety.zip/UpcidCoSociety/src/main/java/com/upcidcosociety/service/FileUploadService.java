/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.util.UpcidResponse;
import java.io.File;
import java.io.IOException;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author m.salman
 */
public interface FileUploadService {
    
     public UpcidResponse UploadFile(MultipartFile files, File location,String fileName)throws  IOException;
    
}
