/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.util.UpcidResponse;
import org.springframework.mail.MailException;

/**
 *
 * @author m.salman
 */
public interface EmailService {
    
 public UpcidResponse sendMailToMemeberForAccountOpenning( String logopath,String loginlink,String memeberName,String memberEmail, String PNONumber,String password);
    
 public UpcidResponse sendMailToMemeberForAccountOpenningFromMemberSide( String logopath,String memeberName,String memberEmail);
    
 public UpcidResponse sendMailToMemeberForComplaint(String logopath,String memberName,String memberEmail,String remark,String remarkAnswer);
}
