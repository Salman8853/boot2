/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.PageMasterDao;
import com.upcidcosociety.dao.PagesDao;
import com.upcidcosociety.dtob.PageMaster;
import com.upcidcosociety.dtob.Pages;
import com.upcidcosociety.model.PageModel;
import com.upcidcosociety.service.PageMasterService;
import com.upcidcosociety.util.UpcidResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class PageMasterServiceImpl implements PageMasterService {
    
 private static final Logger logger = LoggerFactory.getLogger(PageMasterServiceImpl.class);
 @Autowired
 private PageMasterDao pageMasterDao; 

 @Autowired 
  private PagesDao pagesDao;
    
   
    @Override
    @Transactional
     public UpcidResponse getPageMasterBypageName(String pageName,String userName){
        UpcidResponse<PageMaster> response=new UpcidResponse();
        try {
            
            if (pageName != null && pageName.trim().length() > 0) {
                PageMaster pageMaster = pageMasterDao.getPageMasterBypageName(pageName);
                if (pageMaster != null && pageMaster.getPid()> 0) {
                     response.setStatus(HttpStatus.OK);
                    response.setMessage("ok");
                    response.setData(pageMaster);
                } else {
                      response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found");
                    response.setData(pageMaster);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("pageName not found");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when get PageMaster by pageName");
            logger.info("Exception occured when getPageMaster by pageName:" + e);
            e.printStackTrace();
        }
        return response;  
     
     }
     
     @Override
      public UpcidResponse getPageByPageName(String pageName){
        UpcidResponse<Pages> response=new UpcidResponse();
        try {
            if (pageName != null && pageName.trim().length() > 0) {
                PageMaster pageMaster = pageMasterDao.getPageMasterBypageName(pageName);
                if (pageMaster != null && pageMaster.getPid()> 0) {
                    Pages pages=pagesDao.getpageBypid(pageMaster.getPid());
                    if(pages!=null && pages.getId()>0){
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("ok");
                    response.setData(pages);
                    }else{
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found");
                    response.setData(pages);
                    }
                } else {
                     response.setStatus(HttpStatus.NOT_FOUND);
                     response.setMessage("Record not found");
                     response.setData(null);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("pageName not found");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when get PageMaster by pageName");
            logger.info("Exception occured when getPageMaster by pageName:" + e);
            e.printStackTrace();
        }
        return response;  
      
      }
        
}
