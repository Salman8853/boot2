/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.ComplaintsRequestMasterDao;
import com.upcidcosociety.dtob.ComplaintsRequestMaster;
import com.upcidcosociety.service.ComplaintsRequestMasterService;
import com.upcidcosociety.util.UpcidResponse;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class ComplaintsRequestMasterServiceImpl implements ComplaintsRequestMasterService{
     private static final Logger logger = LoggerFactory.getLogger(ComplaintsRequestMasterServiceImpl.class);

    @Autowired
    private ComplaintsRequestMasterDao complaintsRequestMasterDao; 
    
    @Override
    public UpcidResponse getAllComplaintsRequestMaster(){
       UpcidResponse<List<ComplaintsRequestMaster>> response=new UpcidResponse();
         try { 
            List<ComplaintsRequestMaster>crMasterlst=complaintsRequestMasterDao.getAllComplaintsRequestMaster();
            if(crMasterlst!=null && crMasterlst.size()>0){
                response.setStatus(HttpStatus.OK);
                response.setMessage("");
                response.setData(crMasterlst);
            }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Not Found");
                response.setData(crMasterlst);
             } 
         } catch (Exception e) {
              response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getAll ComplaintsRequestMaster");
             logger.info("Exception occured while getAll ComplaintsRequestMaster:" + e);
              e.printStackTrace();
           }
          return response;
        }
    
}
