/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.PageMasterDao;
import com.upcidcosociety.dao.PagesDao;
import com.upcidcosociety.dtob.PageMaster;
import com.upcidcosociety.dtob.Pages;
import com.upcidcosociety.model.PageModel;
import com.upcidcosociety.service.PagesService;
import com.upcidcosociety.util.UpcidConstants;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.Date;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class PagesServiceImpl  implements PagesService {
  private static final Logger logger = LoggerFactory.getLogger(PagesServiceImpl.class);
   @Autowired
   private PagesDao pagesDao;
   
   @Autowired
   private PageMasterDao pageMasterDao;
   
     @Override
     public UpcidResponse addPages(PageModel pages,String remoteaddress,String username){
          UpcidResponse<Pages> response=new UpcidResponse();
         try {
             if(pages!=null && pages.getPagetitles()!=null && pages.getPagetitles().trim().length()>0 && pages.getPageContent()!=null &&pages.getPageContent().trim().length()>0){
                 
                    // check duplicate pages first
                    
                    Pages page=new Pages();
                    page.setPagetitles(pages.getPagetitles());
                    page.setPageContent(pages.getPageContent());
                    page.setCreatedBy(username);
                    page.setCreatedDate(UtilDate.convertDatetoTimestamp(new Date()));
                    page.setModifiedBy(username);
                    page.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                    page.setIpAddress(remoteaddress);
                    page.setUrl(pages.getUrl());
                    page.setActive(pages.getActive());
                    PageMaster pm=pageMasterDao.getPageMasterBypageId(pages.getPageId());
                    if(pm==null){
                    response.setStatus(HttpStatus.NOT_FOUND);;
                    response.setMessage("Failed");
                    response.setData(null);
                    return response;
                     }
                    page.setPageid(pm);
                    Pages pg=  pagesDao.addPages(page);
                   if(pg!=null && pg.getId()!=null && pg.getId()>0){
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record saved");
                    response.setData(pg); 
                   }else{
                    response.setStatus(HttpStatus.NOT_FOUND);;
                    response.setMessage("Failed");
                    response.setData(pg);
                   }
                  
             }else{
                 response.setStatus(HttpStatus.NOT_FOUND);
                 response.setMessage("Please fill mandatory fields");
                 response.setData(null);
             }
         } catch (Exception e) {
              response= new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured");
              logger.info("Exception:"+e);
              e.printStackTrace();
         }
      return response;
     }
     
     @Override
     public UpcidResponse updatePages(PageModel page,String remoteaddress,String username){
        UpcidResponse<Pages> response=new UpcidResponse();
         Pages pages=null;
       try{
           if(page!=null && page.getId()!=null && page.getId()>0){
//               ctegory = categoryDao.checkCategoryByidAndName(category.getCatId(), category.getCategoryName());
//               if (ctegory != null) {
//                   response.setStatus(HttpStatus.CONFLICT);
//                   response.setMessage("Category already exist");
//                   response.setData(category);
//                   return response;
//               }
               pages = pagesDao.getpageByid(page.getId());
               pages.setPagetitles(page.getPagetitles());
               pages.setUrl(page.getUrl());
               pages.setPageContent(page.getPageContent());
               pages.setActive(page.getActive());
               pages.setModifiedBy(username);
               pages.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
               pages.setIpAddress(remoteaddress);
               Pages pg = pagesDao.updatePages(pages);
               if (pg != null && pg.getId()> 0) {
                   response.setStatus(HttpStatus.OK);;
                   response.setMessage("Record update!");
                   response.setData(pg);
               } else {
                   response.setStatus(HttpStatus.NOT_FOUND);
                   response.setMessage("Record updation failed!");
                   response.setData(pg);
               }
           }else{
               response.setStatus(HttpStatus.NOT_FOUND);
               response.setMessage("Plaese enter mandatory fields!");
               response.setData(null);
           }
           
        }catch(Exception e){
         response= new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving update page");
         logger.info("Exception while update page:"+e);
        }
       return response; 
     }
     @Override
     public UpcidResponse getAllPages(String username){
         
         UpcidResponse<List<Pages>> response=new UpcidResponse();
         try {
             List<Pages>pglst=pagesDao.getAllpage();
            if(pglst!=null && pglst.size()>0){
                response.setStatus(HttpStatus.OK);
                response.setMessage("ok");
                response.setData(pglst);
            }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Not Found");
                response.setData(pglst);
             } 
         } catch (Exception e) {
              response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getAll Pages");
             logger.info("Exception occured while getAll Pages:" + e);
              e.printStackTrace();
         }
         return response;
     } 
     
     @Override
     public UpcidResponse getpageBypid(Integer pid,String username){
         UpcidResponse<PageModel> response=new UpcidResponse();
          try {
              PageModel pm =null;
              if(pid!=null && pid>0){
              Pages pages=pagesDao.getpageBypid(pid);
             if(pages!=null && pages.getId()>0){
                 pm=new PageModel();
                 pm.setId(pages.getId());
                 pm.setPagetitles(pages.getPagetitles());
                 pm.setUrl(pages.getUrl());
                 pm.setPageContent(pages.getPageContent());
                 pm.setActive(pages.getActive()); 
                 pm.setPageId(pages.getPageid().getPid());
                response.setStatus(HttpStatus.OK);
                response.setMessage("ok");
                response.setData(pm);
            }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage(" Record Not Found");
                response.setData(pm);
             } 
           }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("PageId Not Found");
                response.setData(pm);
          }
           } catch (Exception e) {
             response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getpageBypid");
             logger.info("Exception occured while getpageBypid:" + e);
              e.printStackTrace();
           }
          return response;
     }
     
      @Override
      public UpcidResponse deletePageById(Integer id,String username){
         UpcidResponse<Pages> response=new UpcidResponse();
          try {
             
                if(id!=null && id>0){
                  Pages page=pagesDao.getpageByid(id);
                 if(page!=null && page.getId()!=null && page.getId()>0) {
                    page.setIsDeleted(Boolean.TRUE);
                    page.setModifiedBy(username);
                    page.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                    Pages pg=  pagesDao.updatePages(page);
                  if(pg!=null && pg.getId()>0){
                     response.setStatus(HttpStatus.OK);
                     response.setMessage("Record deleted successfully!");
                     response.setData(pg);
                  }else{
                     response.setStatus(HttpStatus.NOT_FOUND);
                     response.setMessage("Record not deleted ");
                     response.setData(pg);
                   }
                 }else{
                     response.setStatus(HttpStatus.NOT_FOUND);
                     response.setMessage("Record not found ");
                     response.setData(page);
                 }    
                }else{
                     response.setStatus(HttpStatus.NOT_FOUND);
                     response.setMessage("PageId not found");
                     response.setData(null);
                 }
               
          } catch (Exception e) {
              response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when deletepageBypid");
              logger.info("Exception occured while deletpageBypid:" + e);
              e.printStackTrace();
          }
          return response;
       }
}
