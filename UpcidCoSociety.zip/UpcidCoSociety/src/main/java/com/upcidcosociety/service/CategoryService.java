/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.dtob.Category;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface CategoryService {
    public UpcidResponse addCategory(Category category,String remoteaddress,String username);

    public UpcidResponse updateCategory(Category category,String remoteaddress,String username);

    public UpcidResponse getAllCategory(String userName);
    
    public UpcidResponse getAllCategoryforMember(String userName);
    
    public UpcidResponse getCategoryById(Integer id,String userName);
    
    public UpcidResponse softDeleteCategoryById(Integer id,String userName);
}
