/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.dtob.Posting;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface PostingService {
   public UpcidResponse addPosting(Posting posting,String remoteaddress,String username);

   public UpcidResponse updatePosting(Posting posting,String remoteaddress,String username);
   
   public UpcidResponse getAllPosting(String userName);
    
   public UpcidResponse getAllPostingforMember(String userName);
           
   public UpcidResponse getPostingById(Integer id,String userName);
    
   public UpcidResponse softDeletePostingById(Integer id,String userName);
    
}
