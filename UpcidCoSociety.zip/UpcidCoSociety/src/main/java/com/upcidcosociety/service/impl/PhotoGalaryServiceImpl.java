/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.AlbumDao;
import com.upcidcosociety.dao.AlbumDetailDao;
import com.upcidcosociety.dtob.Album;
import com.upcidcosociety.dtob.AlbumDetail;
import com.upcidcosociety.model.AlbumModel;
import com.upcidcosociety.service.PhotoGalaryService;
import com.upcidcosociety.util.UpcidResponse;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class PhotoGalaryServiceImpl implements PhotoGalaryService {
  private static final Logger logger = LoggerFactory.getLogger(PhotoGalaryServiceImpl.class);
    @Autowired
    private AlbumDao albumDao;
    
    @Autowired
    private AlbumDetailDao albumDetailDao; 

    @Override
    public UpcidResponse addPhotoGalary(AlbumModel albumModel, String remoteaddress, String username) {
        UpcidResponse<Album> response = new UpcidResponse();
        try {
              Album album=null;
              AlbumDetail albumDetail=null;
              
        if(albumModel!=null && albumModel.getAlbumTitle()!=null){
          album= albumDao.getAlbumByTitleName( albumModel.getAlbumTitle().toUpperCase());
         if(album!=null){
               List<String>urlList=albumModel.getUrlList();
               if(urlList!=null && urlList.size()>0){
                for(String url:urlList){
                 albumDetail=new AlbumDetail();
                 albumDetail.setImageUrl(url);
                 albumDetail.setCreatedDate(new Date());
                 albumDetail.setAlbum(album);
                 albumDetailDao.addAlbumDetail(albumDetail);
                 }
                }else{
//                   addede new imagesurl failed
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not saved!");
                    response.setData(null);
                   
               
                  }
//              addede new imagesurl success
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record saved!");
                    response.setData(null);
               

            } else{
           album=new Album();
           album.setAlbumTitle(albumModel.getAlbumTitle().toUpperCase());
           album.setCreatedDate(new Date());        
           Album albm=albumDao.addAlbum(album);
           if(albm!=null && albm.getId()!=null && albm.getId()>0){
               
               List<String>urlList=albumModel.getUrlList();
               if(urlList!=null && urlList.size()>0){
                for(String url:urlList){
                  albumDetail=new AlbumDetail();
                  albumDetail.setImageUrl(url);
                  albumDetail.setCreatedDate(new Date());
                  albumDetail.setAlbum(album);
                  albumDetailDao.addAlbumDetail(albumDetail);
                 }
                }
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record saved succesfully!");
                    response.setData(null);
            }else{
//             error massege
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not saved!");
                    response.setData(null);
              }
      
            }
        }else{
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Please fill all mendatory fields!");
                    response.setData(null);
        
            }
                
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured saving photo galary");
            logger.info("Exception when saving photo galary:" + e);
        }
        return response;
    }
    
    @Override
    public UpcidResponse getallAlbumList(String username){
        UpcidResponse<List<Album>> response = new UpcidResponse();
        try {
           List<Album>albumList=albumDao.getAlbumList();
           if(albumList!=null && albumList.size()>0){
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("get All album List!");
                    response.setData(albumList);
           
           }else{
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setMessage("Record not found!");
            response.setData(albumList);
            }
            
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting all album list");
            logger.info("Exception when getting all album list:" + e); 
            
        }
        return response;
    }
    
    @Override
    public UpcidResponse getgalaryListByalbumTitle(String albumTitle,String username){
      UpcidResponse<Album> response = new UpcidResponse();
        try {
          Album album=albumDao.getAlbumByTitleName(albumTitle);
           if(album!=null && album.getId()!=null && album.getId()>0){
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record found");
                    response.setData(album);
           
           }else{
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setMessage("Record not found!");
            response.setData(album);
            }
            
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting album by albumTitle");
            logger.info("Exception when getting album by albumTitle:" + e); 
            
        }
        return response;
    
    }
    
     @Override
     public UpcidResponse deteteGalaryimage(Integer albumdetailId,String username){
       UpcidResponse<Album> response = new UpcidResponse();
        try {
          int deletedindex=albumDetailDao.deteteimageUrlfromAlbumDetailbyalbumdetailId(albumdetailId);
           if(deletedindex!=0 && deletedindex>0){
               
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record deleted!");
                    response.setData(null);
           
           }else{
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setMessage("Record not deleted!");
            response.setData(null);
            }
            
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when deleting albumdetail by albumdetailId");
            logger.info("Exception when deleting albumdetail by albumdetailId:" + e); 
            
        }
        return response;
     }

}
