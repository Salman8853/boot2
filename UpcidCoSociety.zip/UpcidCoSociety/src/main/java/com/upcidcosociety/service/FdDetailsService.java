/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.model.FdNomineeModel;
import com.upcidcosociety.model.FdRenueModel;
import com.upcidcosociety.model.FdRequestModel;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface FdDetailsService {
   public UpcidResponse generateNewaccountNumberforNewFd(String pnoNumber,String username); 
                         
   public UpcidResponse getfdmaturityvalueforajax(String pnoNumber,String openningdate,int fdPeriod,int oppeningFdAmount,String username);
   
   public UpcidResponse createnewfd(FdRequestModel fdrequestmodel,String username);  
   
   public UpcidResponse getfddetailsByfpnoNumber(String pnonumber,String username); 
   
   public UpcidResponse getfddetailsByfdaccountNumber(String pnonumber,String fdaccountnumber,String username);  
   
   public UpcidResponse generatecertificate(String pnonumber,String fdaccountnumber,String username);  
   
   public UpcidResponse getresponseforfdRenueal(String pnonumber,String fdaccountnumber,Integer period,Double amount,String renuedate,String username);  
   
   public UpcidResponse updateFDforRenueal(FdRenueModel fdrenuemodel,String username);  
}
