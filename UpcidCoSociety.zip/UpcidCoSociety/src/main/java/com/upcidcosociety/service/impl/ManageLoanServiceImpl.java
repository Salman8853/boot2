/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.LoanAdjustmenetDao;
import com.upcidcosociety.dao.LoanGivenMonthWiseDao;
import com.upcidcosociety.dao.LoanInterestDueMonthWiseDao;
import com.upcidcosociety.dao.LoanInterestRecoveredMonthWiseDao;
import com.upcidcosociety.dao.LoanRecoverdMonthWiseDao;
import com.upcidcosociety.dao.ManageLoanDao;
import com.upcidcosociety.dao.MemberDetailDao;
import com.upcidcosociety.dao.MemberShareDetailDao;
import com.upcidcosociety.dao.SoftwareSetingsDao;
import com.upcidcosociety.dao.SwMonthlyCalDao;
import com.upcidcosociety.dao.SwRateSettingDao;
import com.upcidcosociety.dtob.LoanAdjustmenet;
import com.upcidcosociety.dtob.LoanDetails;
import com.upcidcosociety.dtob.LoanGivenMonthWise;
import com.upcidcosociety.dtob.LoanInterestDueMonthWise;
import com.upcidcosociety.dtob.LoanInterestRecoveredMonthWise;
import com.upcidcosociety.dtob.LoanRecoverdMonthWise;
import com.upcidcosociety.dtob.MemberDetail;
import com.upcidcosociety.dtob.MemberShareDetail;
import com.upcidcosociety.dtob.SoftwareSetings;
import com.upcidcosociety.model.LoanAdjRequestModel;
import com.upcidcosociety.model.LoanGivenRequestModel;
import com.upcidcosociety.model.LoanInterestRecoveredRequestModel;
import com.upcidcosociety.model.LoanIntrestDueRequestModel;
import com.upcidcosociety.model.LoanRecoveredRequestModel;
import com.upcidcosociety.model.LoanRequestModel;
import com.upcidcosociety.service.ManageLoanService;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class ManageLoanServiceImpl implements ManageLoanService {

    private static final Logger logger = LoggerFactory.getLogger(ManageLoanServiceImpl.class);

    @Autowired
    private MemberDetailDao memberDetailDao;

    @Autowired
    private MemberShareDetailDao membersharedetaildao;

    @Autowired
    private ManageLoanDao manageloandao;

    @Autowired
    private LoanGivenMonthWiseDao loangivenmonthwisedao;

    @Autowired
    private LoanRecoverdMonthWiseDao loanrecoverdmonthwisedao;

    @Autowired
    private LoanInterestDueMonthWiseDao loaninterestduemonthwisedao;

    @Autowired
    private LoanInterestRecoveredMonthWiseDao loaninterestrecoveredmonthwisedao;

    @Autowired
    private LoanAdjustmenetDao loanadjustmenetdao;

    @Autowired
    private SoftwareSetingsDao softwareSetingsDao;

    @Autowired
    private SwRateSettingDao swRateSettingDao;

    @Autowired
    private SwMonthlyCalDao swMonthlyCalDao;

    @Override
    public UpcidResponse saveloandetail(LoanRequestModel loanrequestmodel, String username) {
        UpcidResponse<LoanDetails> response = new UpcidResponse();
        try {
            MemberDetail memberdetail = null;
            LoanDetails loandetails = null;
            if (loanrequestmodel != null && loanrequestmodel.getPnoNumber() != null && loanrequestmodel.getPnoNumber().trim().length() > 0) {
                Double final_loanbal = 0.0;
                Double balonmarch = 0.0;
                Double princ = loanrequestmodel.getPrincipal() != null ? loanrequestmodel.getPrincipal() : 0;
//                Double openbal = loanrequestmodel.getOpenningBalace() != null ? loanrequestmodel.getOpenningBalace() : 0;
//                String loanstartDate = loanrequestmodel.getLoanstartDate();
                loandetails = new LoanDetails();
                loandetails.setPrincipal(loanrequestmodel.getPrincipal() != null ? loanrequestmodel.getPrincipal() : 0);
                loandetails.setOpenningBalace(loanrequestmodel.getOpenningBalace() != null ? loanrequestmodel.getOpenningBalace() : 0.0);
                Date startDate = UtilDate.convertStringToDate(loanrequestmodel.getLoanstartDate());
                loandetails.setLoanstartDate(startDate);

                Calendar calendar = Calendar.getInstance();
                calendar.setTime(startDate);
                int dd = calendar.get(Calendar.DAY_OF_MONTH);
                String loangivenmonthname = null;
                Double loanbal = 0.0;
                Map<String, Double> map = ManageLoanServiceImpl.getgivinMonthdetails(loanrequestmodel.getLoangivenrequestmodel());
                for (Map.Entry<String, Double> entry : map.entrySet()) {
                    loangivenmonthname = entry.getKey();
                    loanbal = entry.getValue();
                }

                if (dd <= 15) {
                    final_loanbal = loanbal - princ;
                } else {
                    final_loanbal = loanbal;
                }
                Double loan_limit = loanrequestmodel.getLoanLimit() - final_loanbal;
                if ((DateTime.now().getDayOfMonth() == 31) && (DateTime.now().getMonthOfYear() == 3)) {
                    balonmarch = final_loanbal;
                } else {
                    balonmarch = 0.0;
                }
                loandetails.setBalaceOn31March(balonmarch);
                loandetails.setLoanLimit(loan_limit);
                loandetails.setLastBalance(final_loanbal);
                memberdetail = memberDetailDao.getmemberDetailByPnoNumber(loanrequestmodel.getPnoNumber());
                loandetails.setMemberDetail(memberdetail);
                LoanDetails loandtls = manageloandao.saveloandetails(loandetails);
                if (loandtls != null && loandtls.getLoanId() > 0) {
                    LoanGivenMonthWise loangivenmonthwise = new LoanGivenMonthWise();
                    loangivenmonthwise.setAmount(final_loanbal);
                    loangivenmonthwise.setMonth(loangivenmonthname);
                    DateTime date = new DateTime();
                    Integer year = null;
                    if (loangivenmonthname.equalsIgnoreCase("January") || loangivenmonthname.equalsIgnoreCase("February") || loangivenmonthname.equalsIgnoreCase("March")) {
                        year = date.getYear() - 1;
                    } else {
                        year = date.getYear();
                    }
                    loangivenmonthwise.setFinyear(year);
                    loangivenmonthwise.setDate(startDate);
                    loangivenmonthwise.setLoandetails(loandtls);
                    loangivenmonthwisedao.save(loangivenmonthwise);
                    LoanRecoverdMonthWise loanrecoverdmonthwise = null;
                    String loanrecoveryMonth = null;
                    Double loanRecoverd = 0.0;
                    if (dd <= 15) {
                        Map<String, Double> map2 = ManageLoanServiceImpl.getloanRecoveryMonthdetails(princ, loangivenmonthname);
                        for (Map.Entry<String, Double> entry : map2.entrySet()) {
                            loanrecoveryMonth = entry.getKey();
                            loanRecoverd = entry.getValue();
                        }
                    } else {
                        Map<String, Double> map2 = ManageLoanServiceImpl.getloanRecoveryMonthdetails(0.0, loangivenmonthname);
                        for (Map.Entry<String, Double> entry : map2.entrySet()) {
                            loanrecoveryMonth = entry.getKey();
                            loanRecoverd = entry.getValue();
                        }
                    }
                    loanrecoverdmonthwise = new LoanRecoverdMonthWise();
                    loanrecoverdmonthwise.setAmount(loanRecoverd);
                    loanrecoverdmonthwise.setMonth(loanrecoveryMonth);
                    loanrecoverdmonthwise.setFinyear(year);
                    loanrecoverdmonthwise.setDate(startDate);
                    loanrecoverdmonthwise.setLoandetails(loandtls);
                    loanrecoverdmonthwisedao.save(loanrecoverdmonthwise);
                    
                    double loanrate = 0;
                    SoftwareSetings softwaresetings = softwareSetingsDao.getSoftwareSetings();
                    if(softwaresetings!=null && softwaresetings.getId()>0){
                          loanrate=softwaresetings.getLoanRate();
                    }
                    Double interestdue = 0.0;
                    LoanInterestDueMonthWise loaninterestduemonthwise = null;
                    LoanInterestRecoveredMonthWise loaninterestrecoveredmonthwise = null;
                    if (dd <= 15) {
                        Map<String, Double> map3 = ManageLoanServiceImpl.getInterestDueAndIntRecoveryMonthWisedetails(loanbal, loanrate, loangivenmonthname);
                        for (Map.Entry<String, Double> entry : map3.entrySet()) {
                            loanrecoveryMonth = entry.getKey();
                            interestdue = entry.getValue();
                        }
                    } else {
                        Map<String, Double> map3 = ManageLoanServiceImpl.getInterestDueAndIntRecoveryMonthWisedetails(0.0, 0.0, loangivenmonthname);
                        for (Map.Entry<String, Double> entry : map3.entrySet()) {
                            loanrecoveryMonth = entry.getKey();
                            interestdue = entry.getValue();
                        }
                    }
                    loaninterestduemonthwise = new LoanInterestDueMonthWise();
                    loaninterestduemonthwise.setAmount(interestdue);
                    loaninterestduemonthwise.setMonth(loanrecoveryMonth);
                    loaninterestduemonthwise.setFinyear(year);
                    loaninterestduemonthwise.setDate(startDate);
                    loaninterestduemonthwise.setLoandetails(loandtls);
                    loaninterestduemonthwisedao.save(loaninterestduemonthwise);
                    ///save data for interest recovery same as above
                    loaninterestrecoveredmonthwise = new LoanInterestRecoveredMonthWise();
                    loaninterestrecoveredmonthwise.setAmount(interestdue);
                    loaninterestrecoveredmonthwise.setMonth(loanrecoveryMonth);
                    loaninterestrecoveredmonthwise.setDate(startDate);
                    loaninterestrecoveredmonthwise.setFinyear(year);
                    loaninterestrecoveredmonthwise.setLoandetails(loandtls);
                    loaninterestrecoveredmonthwisedao.save(loaninterestrecoveredmonthwise);
                    
                    
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record Saved!");
                    response.setData(loandtls);

                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not saved!");
                    response.setData(null);
                }

            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Please fill all mendtory fields!");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when saving loan detail!");
            logger.info("Exception when saving loan detail!:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse updateloandetail(LoanRequestModel loanrequestmodel, String username) {
        UpcidResponse<LoanDetails> response = new UpcidResponse();
        try {
            MemberDetail memberdetail = null;
            LoanDetails loandetails = null;
            if (loanrequestmodel != null && loanrequestmodel.getPnoNumber() != null && loanrequestmodel.getPnoNumber().trim().length() > 0 && loanrequestmodel.getLoanId() != null && loanrequestmodel.getLoanId() > 0) {
                memberdetail = memberDetailDao.getmemberDetailByPnoNumber(loanrequestmodel.getPnoNumber());
                if (memberdetail != null && memberdetail.getMemberId() != null && memberdetail.getMemberId() > 0) {
                    Double basicpay = memberdetail.getMemberAccount().getBasicPay();
                    Double totalshare = 0.0;
                    MemberShareDetail memberShareDetail = membersharedetaildao.getmeberShareDetailBymemberId(memberdetail.getMemberId());
                    if (memberShareDetail != null && memberShareDetail.getMsdId() != null && memberShareDetail.getMsdId() > 0) {
                        totalshare = totalshare + memberShareDetail.getTotalShare();
                    }
                    Double principal = loanrequestmodel.getPrincipal();
                    Double Openbalance = loanrequestmodel.getOpenningBalace();
//                    Double lastBalance = loanrequestmodel.getLoanBalaceafterCurrentMonthDeduction();

                    Double totalloangiven = 0.0;
                    Map<String, Double> map = ManageLoanServiceImpl.getgivinMonthdetails(loanrequestmodel.getLoangivenrequestmodel());
                     for (Map.Entry<String, Double> entry : map.entrySet()) {
                        totalloangiven = totalloangiven + entry.getValue();
                    }
                    Double totalloanrec = 0.0;
                    Map<String, Double> map2 = ManageLoanServiceImpl.getloanRecoverMonthwisedetailsforUpdate(loanrequestmodel.getLoanrecoveredrequestmodel());
                    for (Map.Entry<String, Double> entry : map2.entrySet()) {
                        totalloanrec = totalloanrec + entry.getValue();
                    }
                    double basic_pay_multipier = 0.0;
                    double total_share_multipier = 0.0;

                    SoftwareSetings softwaresetings = softwareSetingsDao.getSoftwareSetings();
                    if (softwaresetings != null && softwaresetings.getId() != null && softwaresetings.getId() > 0) {
                        long basicpayMultiplair = softwaresetings.getBasicPayMultiplier();
                        long totalShareMultiplair = softwaresetings.getSharePayMultiplier();
                        if (basicpayMultiplair > 0) {
                            basic_pay_multipier = (double) basicpayMultiplair;
                        }
                        if (totalShareMultiplair > 0) {
                            total_share_multipier = (double) totalShareMultiplair;
                        }
                    }
                    DateTime date = new DateTime();
                    String crntmonth = date.monthOfYear().getAsText();
                 
                    Double ajdustBalance = 0.0;
                    Map<String, Double> map5 = ManageLoanServiceImpl.getloanAjdustMonthwisedetailsforUpdate(crntmonth, loanrequestmodel.getLoanadjrequestmodel());
                    for (Map.Entry<String, Double> entry : map5.entrySet()) {
                        ajdustBalance = entry.getValue();
                    }
                    Double loanbalance = 0.0;
                    Double balonmarch = 0.0;
                    if (ajdustBalance > 0.0) {
                        loanbalance = (totalloangiven - totalloanrec);
                        loanbalance = loanbalance - ajdustBalance;
                    } else {
                        loanbalance = Openbalance + (totalloangiven - totalloanrec);
                    }

                    double loanlimit = ManageLoanServiceImpl.calculateLoanLimitForMememberOnUpdate(basicpay.longValue(), totalshare.longValue(), loanbalance.longValue(), basic_pay_multipier, total_share_multipier);

                    if ((DateTime.now().getDayOfMonth() == 31) && (DateTime.now().getMonthOfYear() == 3)) {
                        balonmarch = loanbalance;
                    } else {
                        balonmarch = 0.0;
                    }

//                     double lbal = loanbalance + principal;
                    LoanDetails loandetail = manageloandao.getloandetailsBymemberId(memberdetail.getMemberId());

                    if (loandetail != null && loandetail.getLoanId() != null && loandetail.getLoanId() > 0) {
                        loandetail.setLoanLimit(loanlimit);
                        loandetail.setLastBalance(loanbalance);
                        loandetail.setPrincipal(principal);
                        loandetail.setOpenningBalace(Openbalance);
                        loandetail.setBalaceOn31March(balonmarch);
                        loandetail.setLoancloseDate(UtilDate.convertStringToDate(loanrequestmodel.getLoancloseDate()));
                        LoanDetails loandtls = manageloandao.updateloandetail(loandetail);
                        if (loandtls != null && loandtls.getLoanId() != null && loandtls.getLoanId() > 0) {
                            LoanGivenMonthWise loangivenmonthwise=null;
                            LoanAdjustmenet  loanadjustmenet=null;
                            String monthName="";
                            Double amount = 0.0;
                            Map<String, Double> mapgiven = ManageLoanServiceImpl.getcurrentMonthgivendetails(crntmonth, loanrequestmodel.getLoangivenrequestmodel());
                            for (Map.Entry<String, Double> entry : mapgiven.entrySet()) {
                                monthName = entry.getKey();
                                amount = entry.getValue();
                            }
                            int crntyear =0;
                            if (crntmonth.equalsIgnoreCase("January") || crntmonth.equalsIgnoreCase("February") || crntmonth.equalsIgnoreCase("March")) {
                                crntyear = date.getYear() - 1;
                            } else {
                                crntyear = date.getYear();
                            }
                            if(amount>0.0){
                            loangivenmonthwise = new LoanGivenMonthWise();
                            loangivenmonthwise.setAmount(amount);
                            loangivenmonthwise.setMonth(monthName);
                            loangivenmonthwise.setFinyear(crntyear);
                            loangivenmonthwise.setDate(date.toDate());
                            loangivenmonthwise.setLoandetails(loandtls);
                            loangivenmonthwisedao.save(loangivenmonthwise);
                            }
                            String adjmonthName="";
                            Double adjamount = 0.0;
                           Map<String, Double> loanadjmonthwise = ManageLoanServiceImpl.getloanAjdustMonthwisedetailsforUpdate(crntmonth, loanrequestmodel.getLoanadjrequestmodel());
                           for (Map.Entry<String, Double> entry : loanadjmonthwise.entrySet()) {
                                   adjmonthName= entry.getKey();
                                   adjamount = entry.getValue();  
                            }
                           if(adjamount>0.0){
                             loanadjustmenet = new LoanAdjustmenet();
                             loanadjustmenet.setAmount(adjamount);
                             loanadjustmenet.setMonth(adjmonthName);
                             loanadjustmenet.setFinyear(crntyear);
                             loanadjustmenet.setDate(date.toDate());
                             loanadjustmenetdao.save(loanadjustmenet);
                             }
                             response.setStatus(HttpStatus.OK);
                             response.setMessage("Record Saved!");
                             response.setData(loandtls);
                            
                        } else {
                             response.setStatus(HttpStatus.NOT_MODIFIED);
                             response.setMessage("Record not Saved!");
                             response.setData(loandtls);
                        }
                    }else{
                             response.setStatus(HttpStatus.NOT_FOUND);
                             response.setMessage("Record not found!");
                             response.setData(null);
                    
                    }
                    
                } else {
                             response.setStatus(HttpStatus.NOT_FOUND);
                             response.setMessage("Member is not Registered!");
                             response.setData(null);
                }

            }else{
                             response.setStatus(HttpStatus.NOT_FOUND);
                             response.setMessage("Please fill all mendatory details!");
                             response.setData(null);
              }

        } catch (Exception e) {
             response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when update loan detail!");
            logger.info("Exception when update loan detail!:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getloandetailbymemberId(String pnoNumber, String username) {
        UpcidResponse<LoanRequestModel> response = new UpcidResponse();
        try {
            LoanRequestModel loanrequestmodel = null;
            MemberDetail memberdetail = null;
            LoanDetails loandetails = null;
             LoanGivenRequestModel loangivenrequestmodel = null;
            LoanRecoveredRequestModel loanrecoveredrequestmodel = null;
            LoanIntrestDueRequestModel loanintrestduerequestmodel = null;
            LoanAdjRequestModel loanadjrequestmodel = null;
            LoanInterestRecoveredRequestModel loaninterestrecoveredrequestmodel = null;
            memberdetail = memberDetailDao.getmemberDetailByPnoNumber(pnoNumber);

            if (memberdetail != null && memberdetail.getMemberId() != null && memberdetail.getMemberId() > 0) {
                loandetails = manageloandao.getloandetailsBymemberId(memberdetail.getMemberId());
                if (loandetails != null && loandetails.getLoanId() != null && loandetails.getLoanId() > 0) {
                    loanrequestmodel = new LoanRequestModel();
                    loanrequestmodel.setLoanId(loandetails.getLoanId());
                    loanrequestmodel.setOpenningBalace(loandetails.getOpenningBalace());
                    loanrequestmodel.setPrincipal(loandetails.getPrincipal() != null ? loandetails.getPrincipal() : 0);
                    loanrequestmodel.setBalaceOn31March(loandetails.getBalaceOn31March() != null ? loandetails.getBalaceOn31March() : 0);
                    loanrequestmodel.setLoanstartDate(UtilDate.formatetdateToString_dd_MM_yyyy(loandetails.getLoanstartDate()));
                    loanrequestmodel.setLoancloseDate(UtilDate.formatetdateToString_dd_MM_yyyy(loandetails.getLoancloseDate()));
                    loanrequestmodel.setPnoNumber(pnoNumber);
                    DateTime date = new DateTime();
                    String crntmonth = date.monthOfYear().getAsText();
                    loanrequestmodel.setLoanBalaceafterCurrentMonthDeduction(loandetails.getLastBalance());
                    
                    Integer year = 0;
                    if(crntmonth.equalsIgnoreCase("January")||crntmonth.equalsIgnoreCase("February")||crntmonth.equalsIgnoreCase("March")){
                          year=date.getYear()-1;
                    }else{
                    
                          year=date.getYear();
                    }
                    List<LoanGivenMonthWise> loangivenmonthwiselst = loangivenmonthwisedao.getAll(loandetails.getLoanId(), year);
                    if (loangivenmonthwiselst != null && !loangivenmonthwiselst.isEmpty()) {
                        loangivenrequestmodel = new LoanGivenRequestModel();
                        for (LoanGivenMonthWise loangivenmonthdtls : loangivenmonthwiselst) {
                            String month = loangivenmonthdtls.getMonth();
                            switch (month) {
                                case "January":
                                    loangivenrequestmodel.setJanValue(loangivenmonthdtls.getAmount());
                                    break;
                                case "February":
                                    loangivenrequestmodel.setFebValue(loangivenmonthdtls.getAmount());
                                    break;
                                case "March":
                                    loangivenrequestmodel.setMarchValue(loangivenmonthdtls.getAmount());
                                    break;
                                case "April":
                                    loangivenrequestmodel.setAprilValue(loangivenmonthdtls.getAmount());
                                    break;
                                case "May":
                                    loangivenrequestmodel.setMayValue(loangivenmonthdtls.getAmount());
                                    break;
                                case "June":
                                    loangivenrequestmodel.setJuneValue(loangivenmonthdtls.getAmount());
                                    break;
                                case "July":
                                    loangivenrequestmodel.setJulyValue(loangivenmonthdtls.getAmount());
                                    break;
                                case "August":
                                    loangivenrequestmodel.setAugustValue(loangivenmonthdtls.getAmount());
                                    break;
                                case "September":
                                    loangivenrequestmodel.setSeptValue(loangivenmonthdtls.getAmount());
                                    break;
                                case "October":
                                    loangivenrequestmodel.setOctValue(loangivenmonthdtls.getAmount());
                                    break;
                                case "November":
                                    loangivenrequestmodel.setNovValue(loangivenmonthdtls.getAmount());
                                    break;
                                case "December":
                                    loangivenrequestmodel.setDecValue(loangivenmonthdtls.getAmount());                                  
                                    break;
                            }
                        }
                    }
                          String currentmonth = date.monthOfYear().getAsText();
                             switch (currentmonth) {
                                case "January":
                                     loangivenrequestmodel.setIscrnjantMonth(!currentmonth.equalsIgnoreCase("January")?"True":"False");
                                    break;
                                case "February":
                                     loangivenrequestmodel.setIscrntfebMonth(!currentmonth.equalsIgnoreCase("February")?"True":"False");
                                    break;
                                case "March":    
                                     loangivenrequestmodel.setIscrntmarMonth(!currentmonth.equalsIgnoreCase("March")?"True":"False");
                                    break;
                                case "April":
                                     loangivenrequestmodel.setIscrntaprMonth(!currentmonth.equalsIgnoreCase("April")?"True":"False");
                                    break;
                                case "May":
                                     loangivenrequestmodel.setIscrntmayMonth(!currentmonth.equalsIgnoreCase("May")?"True":"False");
                                    break;
                                case "June":
                                     loangivenrequestmodel.setIscrntjuneMonth(!currentmonth.equalsIgnoreCase("June")?"True":"False");
                        
                                    break;
                                case "July":
                                     loangivenrequestmodel.setIscrntjulyMonth(!currentmonth.equalsIgnoreCase("July")?"True":"False");
                                    
                                    break;
                                case "August":
                                     loangivenrequestmodel.setIscrntaugMonth(!currentmonth.equalsIgnoreCase("August")?"True":"False");

                                    break;
                                case "September":
                                     loangivenrequestmodel.setIscrntseptMonth(!currentmonth.equalsIgnoreCase("September")?"True":"False");
                                    break;
                                case "October":
                                     loangivenrequestmodel.setIscrntoctMonth(!currentmonth.equalsIgnoreCase("October")?"True":"False");
                                    break;
                                case "November":
                                     loangivenrequestmodel.setIscrntnovMonth(!currentmonth.equalsIgnoreCase("November")?"True":"False");   
                                    break;
                                case "December":                                
                                     loangivenrequestmodel.setIscrntdecMonth(!currentmonth.equalsIgnoreCase("December")?"True":"False");
                                    break;
                            }
                             
                    loanrequestmodel.setLoangivenrequestmodel(loangivenrequestmodel);
                    List<LoanRecoverdMonthWise> loanrecoverdmonthwiselst = loanrecoverdmonthwisedao.getAll(loandetails.getLoanId(), year);
                    if (loanrecoverdmonthwiselst != null && !loanrecoverdmonthwiselst.isEmpty()) {
                        loanrecoveredrequestmodel = new LoanRecoveredRequestModel();
                        for (LoanRecoverdMonthWise loanrecoverded : loanrecoverdmonthwiselst) {
                            String month = loanrecoverded.getMonth();
                            switch (month) {
                                case "January":
                                    loanrecoveredrequestmodel.setJanValue(loanrecoverded.getAmount());
                                    
                                    break;
                                case "February":
                                    loanrecoveredrequestmodel.setFebValue(loanrecoverded.getAmount());
                                    
                                    break;
                                case "March":
                                    loanrecoveredrequestmodel.setMarchValue(loanrecoverded.getAmount());
                                    
                                    break;
                                case "April":
                                    loanrecoveredrequestmodel.setAprilValue(loanrecoverded.getAmount());
                                    
                                    break;
                                case "May":
                                    loanrecoveredrequestmodel.setMayValue(loanrecoverded.getAmount());
                                     
                                    break;
                                case "June":
                                    loanrecoveredrequestmodel.setJuneValue(loanrecoverded.getAmount());
                                     
                                    break;
                                case "July":
                                    loanrecoveredrequestmodel.setJulyValue(loanrecoverded.getAmount());
                                     
                                    break;
                                case "August":
                                    loanrecoveredrequestmodel.setAugustValue(loanrecoverded.getAmount());
                                     
                                    break;
                                case "September":
                                    loanrecoveredrequestmodel.setSeptValue(loanrecoverded.getAmount());
                                     
                                    break;
                                case "October":
                                    loanrecoveredrequestmodel.setOctValue(loanrecoverded.getAmount());
                                     
                                    break;
                                case "November":
                                    loanrecoveredrequestmodel.setNovValue(loanrecoverded.getAmount());
                                     
                                    break;
                                case "December":
                                    loanrecoveredrequestmodel.setDecValue(loanrecoverded.getAmount());
                                     
                                    break;
                            }
                        }
                    }
                    loanrequestmodel.setLoanrecoveredrequestmodel(loanrecoveredrequestmodel);
                    List<LoanInterestDueMonthWise> loaninterestduemonthwiselst = loaninterestduemonthwisedao.getAll(loandetails.getLoanId(), year);
                    if (loaninterestduemonthwiselst != null && !loaninterestduemonthwiselst.isEmpty()) {
                        loanintrestduerequestmodel = new LoanIntrestDueRequestModel();
                        for (LoanInterestDueMonthWise loaninterestduemonthwise : loaninterestduemonthwiselst) {
                            String month = loaninterestduemonthwise.getMonth();
                            switch (month) {
                                case "January":
                                    loanintrestduerequestmodel.setJanValue(loaninterestduemonthwise.getAmount());
                                 
                                    break;
                                case "February":
                                    loanintrestduerequestmodel.setFebValue(loaninterestduemonthwise.getAmount());
                                     
                                    break;
                                case "March":
                                    loanintrestduerequestmodel.setMarchValue(loaninterestduemonthwise.getAmount());
                                  
                                    break;
                                case "April":
                                    loanintrestduerequestmodel.setAprilValue(loaninterestduemonthwise.getAmount());
                                    
                                    break;
                                case "May":
                                    loanintrestduerequestmodel.setMayValue(loaninterestduemonthwise.getAmount());
                                    
                                    break;
                                case "June":
                                    loanintrestduerequestmodel.setJuneValue(loaninterestduemonthwise.getAmount());
                                     
                                    break;
                                case "July":
                                    loanintrestduerequestmodel.setJulyValue(loaninterestduemonthwise.getAmount());
                                    
                                    break;
                                case "August":
                                    loanintrestduerequestmodel.setAugustValue(loaninterestduemonthwise.getAmount());
                                     
                                    break;
                                case "September":
                                    loanintrestduerequestmodel.setSeptValue(loaninterestduemonthwise.getAmount());
                                     
                                    break;
                                case "October":
                                    loanintrestduerequestmodel.setOctValue(loaninterestduemonthwise.getAmount());
                                  
                                    break;
                                case "November":
                                    loanintrestduerequestmodel.setNovValue(loaninterestduemonthwise.getAmount());
                                     
                                    break;
                                case "December":
                                    loanintrestduerequestmodel.setDecValue(loaninterestduemonthwise.getAmount());
                                    
                                    break;
                            }
                        }
                    }
//                     loanrecoveredrequestmodel.setIscrntMonth(crntmonth.equalsIgnoreCase("December")?Boolean.TRUE:Boolean.FALSE);
                    loanrequestmodel.setLoanintrestduerequestmodel(loanintrestduerequestmodel);
                    List<LoanInterestRecoveredMonthWise> loaninterestrecovermonthwiselst = loaninterestrecoveredmonthwisedao.getAll(loandetails.getLoanId(), year);
                    if (loaninterestrecovermonthwiselst != null && !loaninterestrecovermonthwiselst.isEmpty()) {
                        loaninterestrecoveredrequestmodel = new LoanInterestRecoveredRequestModel();
                        for (LoanInterestRecoveredMonthWise loaninterestrecoveredmonthwise : loaninterestrecovermonthwiselst) {
                            String month = loaninterestrecoveredmonthwise.getMonth();
                            switch (month) {
                                case "January":
                                    loaninterestrecoveredrequestmodel.setJanValue(loaninterestrecoveredmonthwise.getAmount());
                                    
                                    break;
                                case "February":
                                    loaninterestrecoveredrequestmodel.setFebValue(loaninterestrecoveredmonthwise.getAmount());
                                    
                                    break;
                                case "March":
                                    loaninterestrecoveredrequestmodel.setMarchValue(loaninterestrecoveredmonthwise.getAmount());
                                    
                                    break;
                                case "April":
                                    loaninterestrecoveredrequestmodel.setAprilValue(loaninterestrecoveredmonthwise.getAmount());
                                    
                                    break;
                                case "May":
                                    loaninterestrecoveredrequestmodel.setMayValue(loaninterestrecoveredmonthwise.getAmount());
                                   
                                    break;
                                case "June":
                                    loaninterestrecoveredrequestmodel.setJuneValue(loaninterestrecoveredmonthwise.getAmount());
                                   
                                    break;
                                case "July":
                                    loaninterestrecoveredrequestmodel.setJulyValue(loaninterestrecoveredmonthwise.getAmount());
                                   
                                    break;
                                case "August":
                                    loaninterestrecoveredrequestmodel.setAugustValue(loaninterestrecoveredmonthwise.getAmount());
                                     
                                    break;
                                case "September":
                                    loaninterestrecoveredrequestmodel.setSeptValue(loaninterestrecoveredmonthwise.getAmount());
                                   
                                    break;
                                case "October":
                                    loaninterestrecoveredrequestmodel.setOctValue(loaninterestrecoveredmonthwise.getAmount());
                                    
                                    break;
                                case "November":
                                    loaninterestrecoveredrequestmodel.setNovValue(loaninterestrecoveredmonthwise.getAmount());
                                   
                                    break;
                                case "December":
                                    loaninterestrecoveredrequestmodel.setDecValue(loaninterestrecoveredmonthwise.getAmount());
                                   
                                    break;
                            }
                        }
                    }
                    loanrequestmodel.setLoaninterestrecoveredrequestmodel(loaninterestrecoveredrequestmodel);
                    List<LoanAdjustmenet> loanadjustmenetlst = loanadjustmenetdao.getAll(loandetails.getLoanId(), year);
                    if (loanadjustmenetlst != null && !loanadjustmenetlst.isEmpty()) {
                        loanadjrequestmodel = new LoanAdjRequestModel();
                        for (LoanAdjustmenet loanadjustmenet : loanadjustmenetlst) {
                            String month = loanadjustmenet.getMonth();
                            switch (month) {
                                case "January":
                                    loanadjrequestmodel.setJanValue(loanadjustmenet.getAmount());
                                    
                                    break;
                                case "February":
                                    loanadjrequestmodel.setFebValue(loanadjustmenet.getAmount());
                                      
                                    break;
                                case "March":
                                    loanadjrequestmodel.setMarchValue(loanadjustmenet.getAmount());
                                  
                                    break;
                                case "April":
                                    loanadjrequestmodel.setAprilValue(loanadjustmenet.getAmount());
                                     
                                    break;
                                case "May":
                                    loanadjrequestmodel.setMayValue(loanadjustmenet.getAmount());
                                    
                                    break;
                                case "June":
                                    loanadjrequestmodel.setJuneValue(loanadjustmenet.getAmount());
                                     
                                    break;
                                case "July":
                                    loanadjrequestmodel.setJulyValue(loanadjustmenet.getAmount());
                                      
                                    break;
                                case "August":
                                    loanadjrequestmodel.setAugustValue(loanadjustmenet.getAmount());
                                  
                                    break;
                                case "September":
                                    loanadjrequestmodel.setSeptValue(loanadjustmenet.getAmount());
                                    
                                    break;
                                case "October":
                                    loanadjrequestmodel.setOctValue(loanadjustmenet.getAmount());
                                      
                                    break;
                                case "November":
                                    loanadjrequestmodel.setNovValue(loanadjustmenet.getAmount());
                                    
                                    break;
                                case "December":
                                    loanadjrequestmodel.setDecValue(loanadjustmenet.getAmount());
                                    
                                    break;
                            }
                        }
                    }

                    loanrequestmodel.setLoanadjrequestmodel(loanadjrequestmodel);
                    response.setStatus(HttpStatus.OK);
                    response.setMessage(" ");
                    response.setData(loanrequestmodel);
                } else {
                    loanrequestmodel = new LoanRequestModel();
                      DateTime dd= new DateTime();
                      String crntmonth = dd.monthOfYear().getAsText();
                               loangivenrequestmodel = new LoanGivenRequestModel();
                               switch (crntmonth) {
                                case "January":
                                   
                                     loangivenrequestmodel.setIscrnjantMonth(!crntmonth.equalsIgnoreCase("January")?"True":"False");
                                    break;
                                case "February":
                                     loangivenrequestmodel.setIscrntfebMonth(!crntmonth.equalsIgnoreCase("February")?"True":"False");
                                    break;
                                case "March": 
                                     loangivenrequestmodel.setIscrntmarMonth(!crntmonth.equalsIgnoreCase("March")?"True":"False");
                                    break;
                                case "April":
                                     loangivenrequestmodel.setIscrntaprMonth(!crntmonth.equalsIgnoreCase("April")?"True":"False");
                                    break;
                                case "May":
                                     loangivenrequestmodel.setIscrntmayMonth(!crntmonth.equalsIgnoreCase("May")?"True":"False");
                                    break;
                                case "June": 
                                     loangivenrequestmodel.setIscrntjuneMonth(!crntmonth.equalsIgnoreCase("June")?"True":"False");
                                    break;
                                case "July":
                                     loangivenrequestmodel.setIscrntjulyMonth(!crntmonth.equalsIgnoreCase("July")?"True":"False");
                                    break;
                                case "August":
                                     loangivenrequestmodel.setIscrntaugMonth(!crntmonth.equalsIgnoreCase("August")?"True":"False");
                                    break;
                                case "September":
                                     loangivenrequestmodel.setIscrntseptMonth(!crntmonth.equalsIgnoreCase("September")?"True":"False");
                                    break;
                                case "October":
                                     loangivenrequestmodel.setIscrntoctMonth(!crntmonth.equalsIgnoreCase("October")?"True":"False");
                                    break;
                                case "November":
                                     loangivenrequestmodel.setIscrntnovMonth(!crntmonth.equalsIgnoreCase("November")?"True":"False");   
                                    break;
                                case "December":                                 
                                     loangivenrequestmodel.setIscrntdecMonth(!crntmonth.equalsIgnoreCase("December")?"True":"False");
                                    break;
                            }
                    loanrequestmodel.setPnoNumber(pnoNumber);
                    loanrequestmodel.setLoangivenrequestmodel(loangivenrequestmodel);
                    response.setStatus(HttpStatus.OK);
                    response.setMessage(" ");
                    response.setData(loanrequestmodel);

                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("PNO Number not found!");
                response.setData(null);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting loan detail!");
            logger.info("Exception when getting loan detail!:" + e);
        }
        return response;
    }

    public static Map<String, Double> getgivinMonthdetails(LoanGivenRequestModel loangivenrequestmodel) {
        Map<String, Double> map = new HashMap<>();
        
        if (loangivenrequestmodel.getAprilValue() != null && loangivenrequestmodel.getAprilValue() > 0) {
            map.put("April", loangivenrequestmodel.getAprilValue());
        } 
            if (loangivenrequestmodel.getMayValue() != null && loangivenrequestmodel.getMayValue() > 0) {
            map.put("May", loangivenrequestmodel.getMayValue());
        } 
            if (loangivenrequestmodel.getJuneValue() != null && loangivenrequestmodel.getJuneValue() > 0) {
            map.put("June", loangivenrequestmodel.getJuneValue());
        } 
            if (loangivenrequestmodel.getJulyValue() != null && loangivenrequestmodel.getJulyValue() > 0) {
            map.put("July", loangivenrequestmodel.getJuneValue());
        } 
            if (loangivenrequestmodel.getAugustValue() != null && loangivenrequestmodel.getAugustValue() > 0) {
            map.put("August", loangivenrequestmodel.getAugustValue());
        } 
            if (loangivenrequestmodel.getSeptValue() != null && loangivenrequestmodel.getSeptValue() > 0) {
            map.put("September", loangivenrequestmodel.getSeptValue());
        } 
            if (loangivenrequestmodel.getOctValue() != null && loangivenrequestmodel.getOctValue() > 0) {
            map.put("October", loangivenrequestmodel.getOctValue());
        } 
            if (loangivenrequestmodel.getNovValue() != null && loangivenrequestmodel.getNovValue() > 0) {
            map.put("November", loangivenrequestmodel.getNovValue());
        } 
            if (loangivenrequestmodel.getDecValue() != null && loangivenrequestmodel.getDecValue() > 0) {
            map.put("December", loangivenrequestmodel.getDecValue());
        }  if (loangivenrequestmodel.getJanValue() != null && loangivenrequestmodel.getJanValue() > 0) {
            map.put("January", loangivenrequestmodel.getJanValue());
        } 
        if (loangivenrequestmodel.getFebValue() != null && loangivenrequestmodel.getFebValue() > 0) {
            map.put("February", loangivenrequestmodel.getFebValue());
        } 
        if (loangivenrequestmodel.getMarchValue() != null && loangivenrequestmodel.getMarchValue() > 0) {
            map.put("March", loangivenrequestmodel.getMarchValue());
        }

        return map;
    }

    public static Map<String, Double> getcurrentMonthgivendetails(String monthname, LoanGivenRequestModel loangivenrequestmodel) {
        Map<String, Double> map = new HashMap<>();
        switch (monthname) {
            case "April":
                map.put("April", loangivenrequestmodel.getAprilValue());
                break;
            case "May":
                map.put("May", loangivenrequestmodel.getMayValue());
                break;
            case "June":
                map.put("June", loangivenrequestmodel.getJuneValue());
                break;
            case "July":
                map.put("July", loangivenrequestmodel.getJulyValue());
                break;
            case "August":
                map.put("August", loangivenrequestmodel.getAugustValue());
                break;
            case "September":
                map.put("September", loangivenrequestmodel.getSeptValue());
                break;
            case "October":
                map.put("October", loangivenrequestmodel.getOctValue());
                break;
            case "November":
                map.put("November", loangivenrequestmodel.getNovValue());
                break;
            case "December":
                map.put("December", loangivenrequestmodel.getDecValue());
                break;
            case "January":
                map.put("January", loangivenrequestmodel.getJanValue());
                break;
            case "February":
                map.put("February", loangivenrequestmodel.getFebValue());
                break;
            case "March":
                map.put("March", loangivenrequestmodel.getMarchValue());
                break;
        }
        return map;
    }

    public static Map<String, Double> getloanRecoveryMonthdetails(Double princ, String monthname) {
        Map<String, Double> map = new HashMap<>();
        switch (monthname) {
            case "April":
                map.put(monthname, princ);
                break;
            case "May":
                map.put(monthname, princ);
                break;
            case "June":
                map.put(monthname, princ);
                break;
            case "July":
                map.put(monthname, princ);
                break;
            case "August":
                map.put(monthname, princ);
                break;
            case "September":
                map.put(monthname, princ);
                break;
            case "October":
                map.put(monthname, princ);
                break;
            case "November":
                map.put(monthname, princ);
                break;
            case "December":
                map.put(monthname, princ);
                break;
            case "January":
                map.put(monthname, princ);
                break;
            case "February":
                map.put(monthname, princ);
                break;
            case "March":
                map.put(monthname, princ);
                break;
        }
        return map;
    }

    public static Map<String, Double> getInterestDueAndIntRecoveryMonthWisedetails(Double loanBalance, Double loanrate, String monthname) {
        Map<String, Double> map = new HashMap<>();
        Long intdue = 0l;
        switch (monthname) {
            case "April":
                intdue = Math.round(loanBalance * loanrate / 100 / 12);
                map.put(monthname, intdue.doubleValue());
                break;
            case "May":
                intdue = Math.round(loanBalance * loanrate / 100 / 12);
                map.put(monthname, intdue.doubleValue());
                break;
            case "June":
                intdue = Math.round(loanBalance * loanrate / 100 / 12);
                map.put(monthname, intdue.doubleValue());
                break;
            case "July":
                intdue = Math.round(loanBalance * loanrate / 100 / 12);
                map.put(monthname, intdue.doubleValue());
                break;
            case "August":
                intdue = Math.round(loanBalance * loanrate / 100 / 12);
                map.put(monthname, intdue.doubleValue());
                break;
            case "September":
                intdue = Math.round(loanBalance * loanrate / 100 / 12);
                map.put(monthname, intdue.doubleValue());
                break;
            case "October":
                intdue = Math.round(loanBalance * loanrate / 100 / 12);
                map.put(monthname, intdue.doubleValue());
                break;
            case "November":
                intdue = Math.round(loanBalance * loanrate / 100 / 12);
                map.put(monthname, intdue.doubleValue());
                break;
            case "December":
                intdue = Math.round(loanBalance * loanrate / 100 / 12);
                map.put(monthname, intdue.doubleValue());
                break;
            case "January":
                intdue = Math.round(loanBalance * loanrate / 100 / 12);
                map.put(monthname, intdue.doubleValue());
                break;
            case "February":
                intdue = Math.round(loanBalance * loanrate / 100 / 12);
                map.put(monthname, intdue.doubleValue());
                break;
            case "March":
                intdue = Math.round(loanBalance * loanrate / 100 / 12);
                map.put(monthname, intdue.doubleValue());
                break;
        }
        return map;
    }
    ///for Loan detail update

    public static Map<String, Double> getloanRecoverMonthwisedetailsforUpdate(LoanRecoveredRequestModel loanrecoveredrequestmodel) {

        Map<String, Double> map = new HashMap<>();
        if (loanrecoveredrequestmodel.getAprilValue() != null && loanrecoveredrequestmodel.getAprilValue() > 0) {
            map.put("April", loanrecoveredrequestmodel.getAprilValue());
        } 
        if (loanrecoveredrequestmodel.getMayValue() != null && loanrecoveredrequestmodel.getMayValue() > 0) {
            map.put("May", loanrecoveredrequestmodel.getMayValue());
        } 
        if (loanrecoveredrequestmodel.getJuneValue() != null && loanrecoveredrequestmodel.getJuneValue() > 0) {
            map.put("June", loanrecoveredrequestmodel.getJuneValue());
        }  
        if (loanrecoveredrequestmodel.getJulyValue() != null && loanrecoveredrequestmodel.getJulyValue() > 0) {
            map.put("July", loanrecoveredrequestmodel.getJuneValue());
        } 
        if (loanrecoveredrequestmodel.getAugustValue() != null && loanrecoveredrequestmodel.getAugustValue() > 0) {
            map.put("August", loanrecoveredrequestmodel.getAugustValue());
        }  
        if (loanrecoveredrequestmodel.getSeptValue() != null && loanrecoveredrequestmodel.getSeptValue() > 0) {
            map.put("September", loanrecoveredrequestmodel.getSeptValue());
        } 
        if (loanrecoveredrequestmodel.getOctValue() != null && loanrecoveredrequestmodel.getOctValue() > 0) {
            map.put("October", loanrecoveredrequestmodel.getOctValue());
        } 
        if (loanrecoveredrequestmodel.getNovValue() != null && loanrecoveredrequestmodel.getNovValue() > 0) {
            map.put("November", loanrecoveredrequestmodel.getNovValue());
        } 
        if (loanrecoveredrequestmodel.getDecValue() != null && loanrecoveredrequestmodel.getDecValue() > 0) {
            map.put("December", loanrecoveredrequestmodel.getDecValue());
        } 
        if (loanrecoveredrequestmodel.getJanValue() != null && loanrecoveredrequestmodel.getJanValue() > 0) {
            map.put("January", loanrecoveredrequestmodel.getJanValue());
        } 
        if (loanrecoveredrequestmodel.getFebValue() != null && loanrecoveredrequestmodel.getFebValue() > 0) {
            map.put("February", loanrecoveredrequestmodel.getFebValue());
        }  
        if (loanrecoveredrequestmodel.getMarchValue() != null && loanrecoveredrequestmodel.getMarchValue() > 0) {
            map.put("March", loanrecoveredrequestmodel.getMarchValue());
        }
        return map;

    }

    public static Map<String, Double> getloanIntDueMonthwisedetailsforUpdate(LoanIntrestDueRequestModel loanintrestduerequestmodel) {
        Map<String, Double> map = new HashMap<>();

        if (loanintrestduerequestmodel.getAprilValue() != null && loanintrestduerequestmodel.getAprilValue() > 0) {
            map.put("April", loanintrestduerequestmodel.getAprilValue());
        } 
        if (loanintrestduerequestmodel.getMayValue() != null && loanintrestduerequestmodel.getMayValue() > 0) {
            map.put("May", loanintrestduerequestmodel.getMayValue());
        } 
        if (loanintrestduerequestmodel.getJuneValue() != null && loanintrestduerequestmodel.getJuneValue() > 0) {
            map.put("June", loanintrestduerequestmodel.getJuneValue());
        } 
        if (loanintrestduerequestmodel.getJulyValue() != null && loanintrestduerequestmodel.getJulyValue() > 0) {
            map.put("July", loanintrestduerequestmodel.getJuneValue());
        }
        if (loanintrestduerequestmodel.getAugustValue() != null && loanintrestduerequestmodel.getAugustValue() > 0) {
            map.put("August", loanintrestduerequestmodel.getAugustValue());
        } 
        if (loanintrestduerequestmodel.getSeptValue() != null && loanintrestduerequestmodel.getSeptValue() > 0) {
            map.put("September", loanintrestduerequestmodel.getSeptValue());
        }
        if (loanintrestduerequestmodel.getOctValue() != null && loanintrestduerequestmodel.getOctValue() > 0) {
            map.put("October", loanintrestduerequestmodel.getOctValue());
        }  
        if (loanintrestduerequestmodel.getNovValue() != null && loanintrestduerequestmodel.getNovValue() > 0) {
            map.put("November", loanintrestduerequestmodel.getNovValue());
        } 
        if (loanintrestduerequestmodel.getDecValue() != null && loanintrestduerequestmodel.getDecValue() > 0) {
            map.put("December", loanintrestduerequestmodel.getDecValue());
        } 
        if (loanintrestduerequestmodel.getJanValue() != null && loanintrestduerequestmodel.getJanValue() > 0) {
            map.put("January", loanintrestduerequestmodel.getJanValue());
        }  
        if (loanintrestduerequestmodel.getFebValue() != null && loanintrestduerequestmodel.getFebValue() > 0) {
            map.put("February", loanintrestduerequestmodel.getFebValue());
        } 
        if (loanintrestduerequestmodel.getMarchValue() != null && loanintrestduerequestmodel.getMarchValue() > 0) {
            map.put("March", loanintrestduerequestmodel.getMarchValue());
        }
        return map;
    }

    public static Map<String, Double> getloanIntRecMonthwisedetailsforUpdate(LoanInterestRecoveredRequestModel loaninterestrecoveredrequestmodel) {
        Map<String, Double> map = new HashMap<>();

        if (loaninterestrecoveredrequestmodel.getAprilValue() != null && loaninterestrecoveredrequestmodel.getAprilValue() > 0) {
            map.put("April", loaninterestrecoveredrequestmodel.getAprilValue());
        } 
        if (loaninterestrecoveredrequestmodel.getMayValue() != null && loaninterestrecoveredrequestmodel.getMayValue() > 0) {
            map.put("May", loaninterestrecoveredrequestmodel.getMayValue());
        } 
        if (loaninterestrecoveredrequestmodel.getJuneValue() != null && loaninterestrecoveredrequestmodel.getJuneValue() > 0) {
            map.put("June", loaninterestrecoveredrequestmodel.getJuneValue());
        } 
        if (loaninterestrecoveredrequestmodel.getJulyValue() != null && loaninterestrecoveredrequestmodel.getJulyValue() > 0) {
            map.put("July", loaninterestrecoveredrequestmodel.getJuneValue());
        } 
        if (loaninterestrecoveredrequestmodel.getAugustValue() != null && loaninterestrecoveredrequestmodel.getAugustValue() > 0) {
            map.put("August", loaninterestrecoveredrequestmodel.getAugustValue());
        } 
        if (loaninterestrecoveredrequestmodel.getSeptValue() != null && loaninterestrecoveredrequestmodel.getSeptValue() > 0) {
            map.put("September", loaninterestrecoveredrequestmodel.getSeptValue());
        } 
        if (loaninterestrecoveredrequestmodel.getOctValue() != null && loaninterestrecoveredrequestmodel.getOctValue() > 0) {
            map.put("October", loaninterestrecoveredrequestmodel.getOctValue());
        } 
        if (loaninterestrecoveredrequestmodel.getNovValue() != null && loaninterestrecoveredrequestmodel.getNovValue() > 0) {
            map.put("November", loaninterestrecoveredrequestmodel.getNovValue());
        } 
        if (loaninterestrecoveredrequestmodel.getDecValue() != null && loaninterestrecoveredrequestmodel.getDecValue() > 0) {
            map.put("December", loaninterestrecoveredrequestmodel.getDecValue());
        } 
        if (loaninterestrecoveredrequestmodel.getJanValue() != null && loaninterestrecoveredrequestmodel.getJanValue() > 0) {
            map.put("January", loaninterestrecoveredrequestmodel.getJanValue());
        } 
        if (loaninterestrecoveredrequestmodel.getFebValue() != null && loaninterestrecoveredrequestmodel.getFebValue() > 0) {
            map.put("February", loaninterestrecoveredrequestmodel.getFebValue());
        }
        if (loaninterestrecoveredrequestmodel.getMarchValue() != null && loaninterestrecoveredrequestmodel.getMarchValue() > 0) {
            map.put("March", loaninterestrecoveredrequestmodel.getMarchValue());
        }
        return map;

    }

    public static Map<String, Double> getloanAjdustMonthwisedetailsforUpdate(String monthname, LoanAdjRequestModel loanadjrequestmodel) {
        Map<String, Double> map = new HashMap<>();
        switch (monthname) {
            case "April":
                map.put("April", loanadjrequestmodel.getAprilValue()!=null?loanadjrequestmodel.getAprilValue():0);
                break;
            case "May":
                map.put("May", loanadjrequestmodel.getMayValue()!=null?loanadjrequestmodel.getMayValue():0);
                break;
            case "June":
                map.put("June", loanadjrequestmodel.getJuneValue()!=null?loanadjrequestmodel.getJuneValue():0);
                break;
            case "July":
                map.put("July", loanadjrequestmodel.getJulyValue()!=null?loanadjrequestmodel.getJulyValue():0);
                break;
            case "August":
                map.put("August", loanadjrequestmodel.getAugustValue()!=null?loanadjrequestmodel.getAugustValue():0);
                break;
            case "September":
                map.put("September", loanadjrequestmodel.getSeptValue()!=null?loanadjrequestmodel.getSeptValue():0);
                break;
            case "October":
                map.put("October", loanadjrequestmodel.getOctValue()!=null?loanadjrequestmodel.getOctValue():0);
                break;
            case "November":
                map.put("November", loanadjrequestmodel.getNovValue()!=null?loanadjrequestmodel.getNovValue():0);
                break;
            case "December":
                map.put("December", loanadjrequestmodel.getDecValue()!=null?loanadjrequestmodel.getDecValue():0);
                break;
            case "January":
                map.put("January", loanadjrequestmodel.getJanValue()!=null?loanadjrequestmodel.getJanValue():0);
                break;
            case "February":
                map.put("February", loanadjrequestmodel.getFebValue()!=null?loanadjrequestmodel.getFebValue():0);
                break;
            case "March":
                map.put("March", loanadjrequestmodel.getMarchValue()!=null?loanadjrequestmodel.getMarchValue():0);
                break;
        }
        return map;
    }

    public static double calculateLoanLimitForMememberOnUpdate(long basicpay, long sharetot, long loanbal, Double basic_pay_multiplier, Double share_pay_multiplier) {
        double loanlimit = 0L;
        
        double basicpayCal = basicpay * basic_pay_multiplier;
        double shareTotalCal = sharetot * share_pay_multiplier;
        if (basicpayCal < shareTotalCal) {
            loanlimit = basicpayCal - loanbal;
        } else {
                loanlimit = shareTotalCal - loanbal;
            
        }
        return loanlimit;
    }

}
