/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.MemberAccountDao;
import com.upcidcosociety.dao.SectorDao;
import com.upcidcosociety.dtob.Sector;
import com.upcidcosociety.model.SectorModel;
import com.upcidcosociety.service.SectorService;
import com.upcidcosociety.util.UpcidConstants;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class SectorServiceImpl implements SectorService{
   private static final Logger logger = LoggerFactory.getLogger(SectorServiceImpl.class);  
    @Autowired 
    private SectorDao sectorDao;
     @Autowired
    private MemberAccountDao memberAccountDao;
  
   
   @Override
    public UpcidResponse addSector(Sector sector,String remoteaddress,String username){
          UpcidResponse response=new UpcidResponse();
          
          try {
              Sector sctr=null;
             if(sector!=null && sector.getSector()!=null && sector.getSector().trim().length()>0){
                  sctr=sectorDao.checkSectorBysector(sector.getSector());
                  if(sctr!=null){
                    response.setStatus(HttpStatus.CONFLICT);
                    response.setMessage("Sectror already exist!");
                    response.setData(null);
                    return response; 
                  }
                  sctr=new Sector();
//                  sctr.setSectorCode(sector.getSectorCode());
                  sctr.setSector(sector.getSector());
                  sctr.setIpAddress(remoteaddress);
                  sctr.setIsDeleted(Boolean.FALSE);
                  sctr.setCreatedBy(username);
                  sctr.setCreatedDate(UtilDate.convertDatetoTimestamp(new Date()));
                  sctr.setModifiedBy(username);
                  sctr.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                  Sector sect=sectorDao.addSector(sctr);
                  if(sect!=null && sect.getId()!=null && sect.getId()>0){
                   response.setStatus(HttpStatus.OK);
                   response.setMessage("Record Saved successfully!");
                   response.setData(sect);
                   }else{
                   response.setStatus(HttpStatus.NOT_FOUND);
                   response.setMessage("Record not saved!");
                   response.setData(sect);
                   }
             }else{
              response.setStatus(HttpStatus.NOT_FOUND);
              response.setMessage("Plaese enter mandatory fields!");
              response.setData(sector);
             }
              
       } catch (Exception e) {
          response= new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving newsector");
           logger.info("Exception while saving newsector:"+e); 
       }
        return response; 
    }
    
    @Override
    public UpcidResponse updateSector(Sector sector,String remoteaddress,String username){
            UpcidResponse response=new UpcidResponse();
            Sector sectr=null;
       try{
           if(sector!=null && sector.getId()!=null && sector.getId()>0 && sector.getSector()!=null && sector.getSector().trim().length()>0){
               sectr = sectorDao.checkSectorByidAndSector(sector.getId(), sector.getSector());
               if (sectr != null) {
                   response.setStatus(HttpStatus.CONFLICT);
                   response.setMessage("Record already exist");
                   response.setData(sectr);
                   return response;
               }
                sectr = sectorDao.getSectorByid(sector.getId());

//               sectr.setSectorCode(sector.getSectorCode());
               sectr.setSector(sector.getSector());
               sectr.setModifiedBy(username);
               sectr.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
               sectr.setIpAddress(sector.getIpAddress());
               sectr.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
               sectr.setIpAddress(remoteaddress);
               Sector st=sectorDao.updateSector(sectr);
               if (st != null && st.getId()> 0) {
                   response.setStatus(HttpStatus.OK);;
                   response.setMessage("Record updated successfully!");
                   response.setData(st);
               } else {
                   response.setStatus(HttpStatus.NOT_FOUND);
                   response.setMessage("Record updation failed!");
                   response.setData(st);
               }

           }else{
               response.setStatus(HttpStatus.NOT_FOUND);
               response.setMessage("Plaese enter mandatory fields!");
               response.setData(sector);
           }
           
        }catch(Exception e){
         response= new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving update sector");
         logger.info("Exception while update sector:"+e);
        }
       return response; 
    }
    
     @Override
     public UpcidResponse getAllSector(String userName){
         
         UpcidResponse<List<SectorModel>> response = new UpcidResponse();
        try {
            SectorModel sectorModel = null;
            List<SectorModel> sectorModelList = new ArrayList<>();
            List<Integer> sectorIdList = new ArrayList<>();
            List<Sector> sectorList = memberAccountDao.getallDistinctSectorListByCriteria();
            if (sectorList != null && sectorList.size() > 0) {
                for (Sector sect : sectorList) {
                    sectorIdList.add(sect.getId());
                }
            }
             List<Sector>secglst=sectorDao.getAllSector();
            if (secglst != null && secglst.size() > 0) {
                for (Sector sector :secglst) {
                    sectorModel = new SectorModel();
                    sectorModel.setId(sector.getId());
                    sectorModel.setSector(sector.getSector());
                    if (sectorIdList != null && sectorIdList.contains(sector.getId())) {
                        sectorModel.setInUse(UpcidConstants.IN_USE);

                    } else {
                        sectorModel.setInUse(UpcidConstants.IS_Delete);
                    }
                    sectorModelList.add(sectorModel);
                }
                response.setStatus(HttpStatus.OK);
                response.setMessage("");
                response.setData(sectorModelList);
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Not Found");
                response.setData(sectorModelList);
            }
        } catch (Exception e) {
             response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getAll Sector");
             logger.info("Exception occured while getAll Sector:" + e);
              e.printStackTrace();
        }
        return response;  
     }
  
       @Override
     public UpcidResponse getAllSectorforMember(String userName){
       UpcidResponse response=new UpcidResponse();
         try {
             List<Sector>ctglst=sectorDao.getAllSector();
            if(ctglst!=null && ctglst.size()>0){
                response.setStatus(HttpStatus.OK);
                response.setMessage("");
                response.setData(ctglst);
            }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage(" Record not found");
                response.setData(ctglst);
             } 
         } catch (Exception e) {
              response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getAll Sector");
             logger.info("Exception occured while getAll Sector:" + e);
              e.printStackTrace();
         }
         return response; 
     }
     
     @Override
     public UpcidResponse geSectorById(Integer id,String userName){
       UpcidResponse<Sector> response=new UpcidResponse();
        try {
            if (id != null && id > 0) {
                Sector sector = sectorDao.getSectorByid(id);
                if (sector != null && sector.getId()> 0) {
                     response.setStatus(HttpStatus.OK);
                    response.setMessage("");
                    response.setData(sector);
                } else {
                      response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found");
                    response.setData(sector);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("sector id not found");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when get sector by id");
            logger.info("Exception occured when get sector by id:" + e);
            e.printStackTrace();
        }
        return response; 
     
     }
     @Override
      public UpcidResponse deleteSectorById(Integer id,String userName){
           UpcidResponse<Sector> response=new UpcidResponse();
          try {
              if (id != null && id > 0){
               Sector sector = sectorDao.getSectorByid(id);
               if(sector!=null && sector.getId()!=null && sector.getId()>0){
                   
                 sector.setIsDeleted(Boolean.TRUE);
                 sector.setModifiedBy(userName);
                 sector.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                 Sector cat= sectorDao.updateSector(sector);
                 if(cat!=null && cat.getId()!=null && cat.getId()>0){
                   response.setStatus(HttpStatus.OK);
                   response.setMessage("record deleted");
                   response.setData(cat);
                 }else{
                   response.setStatus(HttpStatus.NOT_FOUND);
                   response.setMessage("record deletion failed");
                   response.setData(cat);
                  }
               }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("record not found");
                response.setData(sector);
                }
              }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("  sector id not found");
                response.setData(null);
              }
             
         } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when delete sector by id");
            logger.info("Exception occured when delete sector by id:" + e);
            e.printStackTrace(); 
         }
         return response; 
      
      }
}
