/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.RdDetailMonthWiseHistoryDao;
import com.upcidcosociety.dao.RdDetailsDao;
import com.upcidcosociety.dao.RdEntryDetailMonthWiseDao;
import com.upcidcosociety.dao.RdentryDetailDao;
import com.upcidcosociety.dtob.RdDetailMonthWiseHistory;
import com.upcidcosociety.dtob.RdDetails;
import com.upcidcosociety.dtob.RdEntryDetailMonthWise;
import com.upcidcosociety.dtob.RdentryDetail;
import com.upcidcosociety.service.RdYearlyJobSchedular;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class RdYearlyJobSchedularImpl implements RdYearlyJobSchedular {

    private static final Logger logger = LoggerFactory.getLogger(RdYearlyJobSchedularImpl.class);

    @Autowired
    private RdDetailsDao rddetailsdao;

    @Autowired
    private RdentryDetailDao rdentrydetaildao;
   
    @Autowired
    private RdEntryDetailMonthWiseDao rdentrydetailmonthwisedao;

    @Autowired
    private RdDetailMonthWiseHistoryDao rddetailmonthwisehistorydao;
    
    @Override
    public void yearyjobforrd() {
        try {
       List<RdDetails> rddetailsList = null;
//            List<RdentryDetail> rdentrydetail = null;
//            List<RdEntryDetailMonthWise> rdentrymonthwiselst = null;
         
            rddetailsList = rddetailsdao.getAllRdDetails();
            if (rddetailsList != null && rddetailsList.size() > 0) {
                for (RdDetails rddetails : rddetailsList) {
                    
                    List<RdentryDetail> rdentrydetail = rdentrydetaildao.getAllRdentryDetailsofMember(rddetails.getRdAccNo());
                    if (rdentrydetail != null && rdentrydetail.size() > 0) {
                        for (RdentryDetail rdentrydtls : rdentrydetail) {
                             List<RdEntryDetailMonthWise> rdentrymonthwiselst=rdentrydetailmonthwisedao.getAllRdEntryDetailMonthWiseByRdSerialNo(rdentrydtls.getRdSerialNo());
//                            RdDetailMonthWiseHistory rddetailmonthwisehistory=null;
                            Double sumofmonths = 0.0;
                            if (rdentrymonthwiselst != null && rdentrymonthwiselst.size() > 0) {
                                for (RdEntryDetailMonthWise rdentrydetailmonthwise : rdentrymonthwiselst) {
                                    sumofmonths = sumofmonths + rdentrydetailmonthwise.getAmount();
                                    RdDetailMonthWiseHistory rddetailmonthwisehistory = new RdDetailMonthWiseHistory();
                                    rddetailmonthwisehistory.setAmount(rdentrydetailmonthwise.getAmount());
                                    rddetailmonthwisehistory.setEntryDate(rdentrydetailmonthwise.getEntryDate());
                                    rddetailmonthwisehistory.setMonth(rdentrydetailmonthwise.getMonth());
                                    Date date = rdentrydetailmonthwise.getEntryDate();
                                    Calendar calendar = Calendar.getInstance();
                                    calendar.setTime(date);
                                    int finyear = calendar.get(Calendar.YEAR);
                                    rddetailmonthwisehistory.setFinYear(finyear + "");
                                    rddetailmonthwisehistory.setRdserialnumber(rdentrydtls.getRdSerialNo());
                                    rddetailmonthwisehistory.setRdaccountnumber(rddetails.getRdAccNo());
                                    rddetailmonthwisehistorydao.saveRddetailhistory(rddetailmonthwisehistory);
//                                    delete details from Monthwise table after store in history table
                                    rdentrydetailmonthwisedao.deleteRdEntryDetailMonthWise(rdentrydetailmonthwise.getRdemwId());
                                      
                                    
                                }
                            }
                            sumofmonths=sumofmonths+rdentrydtls.getOldAmt();
                            rdentrydtls.setOldAmt(sumofmonths);
                            rdentrydetaildao.updatenewrdentrydetails(rdentrydtls);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
