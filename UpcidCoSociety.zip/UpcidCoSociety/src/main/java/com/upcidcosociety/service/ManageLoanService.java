/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.model.LoanRequestModel;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface ManageLoanService {
  public UpcidResponse saveloandetail(LoanRequestModel loanrequestmodel,String username);
  
  public UpcidResponse updateloandetail(LoanRequestModel loanrequestmodel,String username);
  
  public UpcidResponse getloandetailbymemberId(String pnoNumber,String username);
}
