/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.PaymentModeDao;
import com.upcidcosociety.dtob.PaymentMode;
import com.upcidcosociety.service.PaymentModeService;
import com.upcidcosociety.util.UpcidResponse;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class PaymentModeServiceImpl  implements PaymentModeService{
 private static final Logger logger = LoggerFactory.getLogger(PaymentModeServiceImpl.class); 
    
@Autowired
 private PaymentModeDao paymentModeDao;
    
  
    @Override
    public UpcidResponse getAllPaymentMode(String userName){
     UpcidResponse<List<PaymentMode>> response=new UpcidResponse();
         try {
             List<PaymentMode>pmlst=paymentModeDao.getAllPaymentMode();
            if(pmlst!=null && pmlst.size()>0){
                response.setStatus(HttpStatus.OK);
                response.setMessage("");
                response.setData(pmlst);
            }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Not Found");
                response.setData(pmlst);
             } 
         } catch (Exception e) {
              response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured whengetAll rank");
             logger.info("Exception occured while getAll Category:" + e);
              e.printStackTrace();
         }
         return response;
    }
    
}
