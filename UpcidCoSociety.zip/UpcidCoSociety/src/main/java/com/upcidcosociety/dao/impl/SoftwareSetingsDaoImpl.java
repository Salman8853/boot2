/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.SoftwareSetingsDao;
import com.upcidcosociety.dtob.FdDetails;
import com.upcidcosociety.dtob.SoftwareSetings;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class SoftwareSetingsDaoImpl implements SoftwareSetingsDao{
  @Autowired
  private SessionFactory sessionFactory;

  @Override
  public SoftwareSetings saveSoftwareSetings(SoftwareSetings softwareSetings){
         
        Session session=sessionFactory.getCurrentSession();
        session.save(softwareSetings);
        session.flush();
        return softwareSetings;
  
   }
  
   @Override
   public SoftwareSetings getSoftwareSetings(){
      try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM SoftwareSetings ss order by id DESC ";
            Query query = session.createQuery(hql);
            query.setMaxResults(1);
            SoftwareSetings ss = (SoftwareSetings) query.uniqueResult();
            if (ss != null && ss.getId()!= null && ss.getId() > 0) {
                return ss;
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
   }
}
