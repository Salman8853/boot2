/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.Pages;
import java.util.List;

/**
 *
 * @author m.salman
 */
public interface PagesDao {
     public Pages addPages(Pages pages);

    public List<Pages> getAllpage();
    
    public Pages getpageBypid(Integer pid);
    
     public Pages getpageByid(Integer pid);
     
     public Pages updatePages(Pages pages);
}
