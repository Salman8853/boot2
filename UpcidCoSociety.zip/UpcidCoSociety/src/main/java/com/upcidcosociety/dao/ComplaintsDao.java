/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.Complaints;
import java.util.List;

/**
 *
 * @author m.salman
 */
public interface ComplaintsDao {
    public Complaints saveComplaints(Complaints complaints);
     
    public List<Complaints> getAllComplaints();
    
 public Complaints getComplaintbyId(Integer compId);
}
