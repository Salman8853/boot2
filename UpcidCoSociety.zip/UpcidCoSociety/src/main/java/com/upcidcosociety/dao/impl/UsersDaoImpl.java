/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.UsersDao;
import com.upcidcosociety.dtob.Users;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class UsersDaoImpl implements UsersDao{

  @Autowired
  private SessionFactory sessionFactory;

    @Override
    public Users SaveUsers(Users users){
        Session session=sessionFactory.getCurrentSession();
        session.save(users);
        session.flush();
        return users;
    }
    @Override
    public Users updateUsers(Users users){
       try {
           Session session=sessionFactory.getCurrentSession();
           session.update(users);
           session.flush();
            return users;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    } 
    
    @Override
    public Users getUsersById(Integer userid) {
      try {
         Session session=sessionFactory.getCurrentSession();
//          return (Category)session.get(Category.class, catId);
         String hql = "FROM Users users WHERE users.isDeleted!=TRUE AND users.userid=:userid";
          Query query = session.createQuery(hql);
         query.setParameter("userid",userid);
          List<Users> results =query.list();
          if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
    }
    
    @Override
    public Users getAdminByUserName(String username){
         try {
         Session session=sessionFactory.getCurrentSession();
//          return (Category)session.get(Category.class, catId);
         String hql = "FROM Users users WHERE users.isDeleted!=TRUE AND users.username=:username";
          Query query = session.createQuery(hql);
         query.setParameter("username",username);
          List<Users> results =query.list();
          if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         } 
    
    }
//      @Override
//      public Users getAdminByUserNameandPassword( String currentpassword,String username){
//             try {
//               String hql = "FROM Users users WHERE users.isDeleted!=TRUE AND users.username=:username AND users.password=:currentpassword";
//          } catch (Exception e) {
//          }
//      }
    
}
