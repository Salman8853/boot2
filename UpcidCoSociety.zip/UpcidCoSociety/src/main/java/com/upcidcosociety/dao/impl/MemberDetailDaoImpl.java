/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.MemberDetailDao;
import com.upcidcosociety.dtob.MemberDetail;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class MemberDetailDaoImpl implements MemberDetailDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public MemberDetail saveMemberDetail(MemberDetail memberDetail) {
        Session session = sessionFactory.getCurrentSession();
        session.save(memberDetail);
        session.flush();
        return memberDetail;
    }

    @Override
    public List<Object[]> getMemberDetailByAccountNo(String accountNo) {
        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM MemberDetail md , MemberAccount ma WHERE md.memberAccount.accId=ma.accId and  md.isDeleted!=TRUE AND ma.bankAccountNumber=:accountNo";
            Query query = session.createQuery(hql);
            query.setParameter("accountNo", accountNo);
            List<Object[]> results = query.list();
            if (results != null && results.size() > 0) {
                return results;
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<MemberDetail> getAllMemberDetail() {

        List<MemberDetail> list = sessionFactory.getCurrentSession()
                .createCriteria(MemberDetail.class)
                .add(Restrictions.eq("isDeleted", Boolean.FALSE))
                .add(Restrictions.eq("status", "Accepted"))
                .list();
        if (!list.isEmpty()) {
            return list;
        }
        return null;
    }
    
     @Override
     public List<MemberDetail> getAllNewAccountRequestlist(String status){
      List<MemberDetail> list = sessionFactory.getCurrentSession()
                .createCriteria(MemberDetail.class)
                .add(Restrictions.eq("isDeleted", Boolean.FALSE))
                .add(Restrictions.eq("status", status))
                .list();
        if (!list.isEmpty()) {
            return list;
        }
        return null;
     }

    @Override
    public MemberDetail checkmemberDetail(String pnoNumber,String aadharNumber,String panNumber) {

        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM MemberDetail md WHERE md.isDeleted!=TRUE AND md.pnoNumber=:pnoNumber AND md.aadharnumber=:aadharNumber AND md.pannumber=:panNumber AND md.status!=:'Rejected'";
            Query query = session.createQuery(hql);
            query.setParameter("pnoNumber", pnoNumber);
            query.setParameter("aadharNumber", aadharNumber);
            query.setParameter("panNumber", panNumber);
            List<MemberDetail> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public MemberDetail checkmemberDetailBymemberIdAndpnonumber(Integer memeberId, String pnoNumber) {

        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM MemberDetail md WHERE md.isDeleted!=TRUE AND md.memeberId!=memeberId AND md.pnoNumber=:pnoNumber";
            Query query = session.createQuery(hql);
            query.setParameter("memeberId", memeberId);
            query.setParameter("pnoNumber", pnoNumber);
            List<MemberDetail> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public MemberDetail getmemberDetailBymemeberId(Integer memberId) {

        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM MemberDetail md WHERE md.isDeleted!=TRUE AND md.memberId=:memberId";
            Query query = session.createQuery(hql);
            query.setParameter("memberId", memberId);
            List<MemberDetail> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    @Override
    public MemberDetail getmemberDetailByPnoNumber(String pnoNumber) {
        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM MemberDetail md WHERE md.isDeleted!=TRUE AND md.pnoNumber=:pnoNumber";
            Query query = session.createQuery(hql);
            query.setParameter("pnoNumber", pnoNumber);
            List<MemberDetail> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}
