/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.RdDetailMonthWiseHistoryDao;
import com.upcidcosociety.dtob.RdDetailMonthWiseHistory;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class RdDetailMonthWiseHistoryDaoImpl implements RdDetailMonthWiseHistoryDao {

    @Autowired
    private SessionFactory sessionfactory;

    @Override
    public RdDetailMonthWiseHistory saveRddetailhistory(RdDetailMonthWiseHistory history) {
        try {
            Session session = sessionfactory.getCurrentSession();
            session.save(history);
            session.flush();
            return history;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<RdDetailMonthWiseHistory> getRddetailhistorybyrdaccnoAndrdserialno(Integer rdaccno, Integer rdserialno) {
        try {
            Session session = sessionfactory.getCurrentSession();
            String hql = "FROM RdDetailMonthWiseHistory history WHERE history.rdaccountnumber=:rdaccno AND history.rdserialnumber=:rdserialno";
            Query query = session.createQuery(hql);
            query.setParameter("rdaccno", rdaccno);
            query.setParameter("rdserialno", rdserialno);
            List<RdDetailMonthWiseHistory> results = query.list();
            if (results != null && results.size() > 0) {
                return results;
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }
}
