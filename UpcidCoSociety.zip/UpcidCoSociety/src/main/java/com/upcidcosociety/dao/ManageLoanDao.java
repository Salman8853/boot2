/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.LoanDetails;

/**
 *
 * @author m.salman
 */
public interface ManageLoanDao {
     public LoanDetails saveloandetails(LoanDetails loandetails);
     
     public LoanDetails updateloandetail(LoanDetails loandetails);

     public LoanDetails getloandetailsBymemberId(Integer memberId);
     
     public LoanDetails getloandetailsByloanId(Integer loanId);
}
