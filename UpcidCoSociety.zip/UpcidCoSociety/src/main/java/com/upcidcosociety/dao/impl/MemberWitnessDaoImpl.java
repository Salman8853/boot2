/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.MemberWitnessDao;
import com.upcidcosociety.dtob.MemberWitness;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class MemberWitnessDaoImpl implements MemberWitnessDao{
    
     @Autowired
     private SessionFactory sessionFactory; 
     
     @Override
     public MemberWitness addWitness(MemberWitness memberwitness){
         Session session=sessionFactory.getCurrentSession();
         session.save(memberwitness);
         session.flush();
         return memberwitness;
     
     }
     
     @Override
     public MemberWitness updateWitness(MemberWitness memberwitness){
        try {
           Session session=sessionFactory.getCurrentSession();
           session.update(memberwitness);
           session.flush();
            return memberwitness;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
       
     }
     
     
     @Override
      public List<MemberWitness> getWitnessbymemberID(Integer memberid){
       try {
         Session session=sessionFactory.getCurrentSession();
         String hql = "FROM MemberWitness wt WHERE  wt.memberDetail.memberId=:memberid";
         Query query = session.createQuery(hql);
         query.setParameter("memberid",memberid);
         List<MemberWitness> results =query.list();
         if(results!=null && results.size()>0){
           return results;
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
      
      }
      
       @Override
       public MemberWitness getWitnessbyId(Integer wid){
       try {
         Session session=sessionFactory.getCurrentSession();
         String hql = "FROM MemberWitness wt WHERE  wt.wId=:wid";
         Query query = session.createQuery(hql);
         query.setParameter("wid",wid);
         List<MemberWitness> results =query.list();
         if(results!=null && results.size()>0){
          return results.get(0);
         }else{
          return null;
          }
         } catch (Exception e) {
           e.printStackTrace();
           return null;  
         }
       }
}
