/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.MemberShareDetailDao;
import com.upcidcosociety.dtob.MemberShareDetail;
import com.upcidcosociety.dtob.RdDetails;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class MemberShareDetailDaoImpl implements MemberShareDetailDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public MemberShareDetail savemeberShareDetail(MemberShareDetail memberShareDetail) {
        Session session = sessionFactory.getCurrentSession();
        session.save(memberShareDetail);
        session.flush();
        return memberShareDetail;
    }
    
     @Override
     public MemberShareDetail updatemeberShareDetail(MemberShareDetail memberShareDetail){
     try {
           Session session=sessionFactory.getCurrentSession();
           session.update(memberShareDetail);
           session.flush();
            return memberShareDetail;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
     
      }
  

    @Override
    public MemberShareDetail getmeberShareDetailBymemberId(Integer memberId) {
        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM MemberShareDetail msd WHERE  msd.memberDetail.memberId=:memberId";
            Query query = session.createQuery(hql);
            query.setParameter("memberId", memberId);
            List<MemberShareDetail> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public MemberShareDetail getmeberShareDetailBymsdId(Integer msdId) {
        try{
        Session session = sessionFactory.getCurrentSession();
        String hql = "FROM MemberShareDetail msd WHERE  msd.msdId=:msdId";
        Query query = session.createQuery(hql);
        query.setParameter("msdId", msdId);
        List<MemberShareDetail> results = query.list();
        if (results != null && results.size() > 0) {
            return results.get(0);
        } else {
            return null;
        }
    }catch (Exception e){
           e.printStackTrace();
            return null;
     }
}  
    
    @Override
    public List<MemberShareDetail> getAllmeberShareDetail(){
        List<MemberShareDetail> list = sessionFactory.getCurrentSession()
                .createCriteria(MemberShareDetail.class)
                .list();
        if (!list.isEmpty()) {
            return list;
        }
        return null;

    }
}
