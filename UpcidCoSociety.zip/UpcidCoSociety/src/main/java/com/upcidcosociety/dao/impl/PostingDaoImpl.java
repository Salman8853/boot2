/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.PostingDao;
import com.upcidcosociety.dtob.Posting;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class PostingDaoImpl implements PostingDao{
  @Autowired
  private SessionFactory sessionFactory;
  
  
     @Override
     public Posting addPosting(Posting posting){
      Session session =sessionFactory.getCurrentSession();
      session.save(posting);
      session.flush();
      return posting;
     }
     
      @Override
      public Posting updatePosting(Posting posting){
           try {
            Session session = sessionFactory.getCurrentSession();
            session.update(posting);
            session.flush();
            return posting;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
      }
      
      @Override
      public Posting getPostingByid(Integer id){
         try {
         Session session=sessionFactory.getCurrentSession();
//          return (Category)session.get(Category.class, catId);
         String hql = "FROM Posting po WHERE po.isDeleted != TRUE AND po.id = :id";
         Query query = session.createQuery(hql);
         query.setParameter("id",id);
         List<Posting> results =query.list();
         if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
      
      }
      
      @Override
       public List<Posting> getAllPosting(){
        List<Posting> list =sessionFactory.getCurrentSession()
				.createCriteria(Posting.class)
				.add(Restrictions.eq("isDeleted", Boolean.FALSE))
				.list();
		if(!list.isEmpty() ) {
		return list;
		}
		return null;
       }
       
       @Override
       public Posting checkPostingByName(String posting){
            try {
               Session session=sessionFactory.getCurrentSession();  
               String hql = "FROM Posting po WHERE po.isDeleted!=TRUE AND po.posting=:posting";
               Query query = session.createQuery(hql);
               query.setParameter("posting",posting);
               List<Posting>results = query.list();
                if(results!=null && results.size()>0){
                  return results.get(0);
                  }else{
                   return null;
                  }
             } catch (Exception e) {
                e.printStackTrace();
                return null; 
           }
           
       }
     
   @Override
   public Posting checkPostingByidAndPostingName(Integer id,String posting){
        
       try {
               Session session=sessionFactory.getCurrentSession();  
               String hql = "FROM Posting po WHERE po.isDeleted!=TRUE AND po.id!=:id AND po.posting=:posting";
               Query query = session.createQuery(hql);
               query.setParameter("id",id);
               query.setParameter("posting",posting);
               List<Posting>results = query.list();
                if(results!=null && results.size()>0){
                  return results.get(0);
                  }else{
                   return null;
                  }
             } catch (Exception e) {
                e.printStackTrace();
                return null; 
           }
   }
}
