/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.MemberDetail;
import java.util.List;

/**
 *
 * @author m.salman
 */
public interface MemberDetailDao {
    
  public MemberDetail saveMemberDetail(MemberDetail memberDetail);
  
   public List<Object[]> getMemberDetailByAccountNo(String accountNo);
   
   public MemberDetail checkmemberDetail(String PonNumber,String aadharNumber,String panNumber);
   
   public MemberDetail checkmemberDetailBymemberIdAndpnonumber(Integer memeberId,String pnoNumber);
   
   public MemberDetail getmemberDetailBymemeberId(Integer memberId);
   
   public MemberDetail getmemberDetailByPnoNumber(String pnoNumber);
   
   public List<MemberDetail> getAllMemberDetail();
   
   public List<MemberDetail> getAllNewAccountRequestlist(String status);

}
