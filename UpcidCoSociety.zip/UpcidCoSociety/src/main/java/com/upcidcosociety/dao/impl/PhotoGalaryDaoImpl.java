/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.PhotoGalaryDao;
import com.upcidcosociety.dtob.PhotoGalary;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class PhotoGalaryDaoImpl  implements PhotoGalaryDao{
  @Autowired
  private SessionFactory sessionFactory; 
  
     @Override
     public PhotoGalary addPhotoGalary(PhotoGalary photoGalary){ 
        
        Session session=sessionFactory.getCurrentSession();
        session.save(photoGalary);
        session.flush();
        return photoGalary;
     }
}
