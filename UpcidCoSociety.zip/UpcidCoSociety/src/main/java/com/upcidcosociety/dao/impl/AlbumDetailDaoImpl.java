/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.AlbumDetailDao;
import com.upcidcosociety.dtob.AlbumDetail;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class AlbumDetailDaoImpl implements AlbumDetailDao{
    
 @Autowired
  private SessionFactory sessionFactory; 
 
 @Override
      public AlbumDetail addAlbumDetail(AlbumDetail albumDetail){
        Session session=sessionFactory.getCurrentSession();
        session.save(albumDetail);
        session.flush();
        return albumDetail;
      
      }
      
  @Override  
   public int deteteimageUrlfromAlbumDetailbyalbumdetailId(Integer albumdetailId){
           try {
               Session session=sessionFactory.getCurrentSession();  
               String hql = "delete from AlbumDetail ad WHERE ad.albumDetailId=:albumdetailId";
               Query query = session.createQuery(hql);
               query.setParameter("albumdetailId",albumdetailId);
               int index = query.executeUpdate();
               return index;
             } catch (Exception e) {
                e.printStackTrace();
                return 0; 
           }
   
    }
 
}
