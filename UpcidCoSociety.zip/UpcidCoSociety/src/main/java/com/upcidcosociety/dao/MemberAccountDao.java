/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.Category;
import com.upcidcosociety.dtob.MemberAccount;
import com.upcidcosociety.dtob.Posting;
import com.upcidcosociety.dtob.Rank;
import com.upcidcosociety.dtob.Sector;
import java.util.List;

/**
 *
 * @author m.salman
 */
public interface MemberAccountDao {

    public MemberAccount saveMemberAccount(MemberAccount memberAccount);

    public MemberAccount updateMemberAccount(MemberAccount memberAccount);

    public MemberAccount checkMemberAccountByaccIdAndBankAccountNumber(Integer accId, String bankAccountNumber);

    public MemberAccount getMemberAccountByid(Integer accId);

    public List<Category> getallDistinctCategoryListByCriteria();

    public List<Rank> getallDistinctRankListListByCriteria();

    public  List<Sector> getallDistinctSectorListByCriteria();
    
   public  List<Posting> getallDistinctPostingListByCriteria();

}
