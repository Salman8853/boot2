/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.CategoryDao;
import com.upcidcosociety.dtob.Category;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


/**
 *
 * @author m.salman
 */
@Repository
public class CategoryDaoImpl implements CategoryDao{
  @Autowired
  private SessionFactory sessionFactory;
  
  
     @Override
     public Category addCategory(Category category){ 
        Session session=sessionFactory.getCurrentSession();
        session.save(category);
        session.flush();
        return category;
     }
     
     @Override
     public Category getCategoryByid(Integer catId){
         try {
         Session session=sessionFactory.getCurrentSession();
//          return (Category)session.get(Category.class, catId);
         String hql = "FROM Category cat WHERE cat.isDeleted!=TRUE AND cat.catId=:catId";
         Query query = session.createQuery(hql);
         query.setParameter("catId",catId);
         List<Category> results =query.list();
         if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
     }

      @Override
      public Category updateCategory(Category category){
       try {
           Session session=sessionFactory.getCurrentSession();
           session.update(category);
           session.flush();
            return category;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
      }
       @Override
       public Category checkCategoryByName(String categoryName){
           try {
               Session session=sessionFactory.getCurrentSession();  
               String hql = "FROM Category cat WHERE cat.isDeleted!=TRUE AND cat.categoryName=:categoryName";
               Query query = session.createQuery(hql);
               query.setParameter("categoryName",categoryName);
               List<Category>results = query.list();
                if(results!=null && results.size()>0){
                  return results.get(0);
                  }else{
                   return null;
                  }
             } catch (Exception e) {
                e.printStackTrace();
                return null; 
           }
          
       }
       @Override
       public Category  checkCategoryByidAndName(Integer catId,String categoryName){
           try {
          Session session=sessionFactory.getCurrentSession();  
          String hql = "FROM Category cat WHERE cat.isDeleted!=TRUE AND cat.catId!=:catId AND cat.categoryName=:categoryName";
          Query query = session.createQuery(hql);
          query.setParameter("catId",catId);
          query.setParameter("categoryName",categoryName);
          List<Category>results = query.list();
          if(results!=null && results.size()>0){
               return results.get(0);
           }else{
              return null;
             }
           } catch (Exception e) {
               e.printStackTrace();
               return null;
           }
       }
        @Override
       public List<Category> getAllCategory(){
        List<Category> list = sessionFactory.getCurrentSession()
                .createCriteria(Category.class)
                .add(Restrictions.eq("isDeleted", Boolean.FALSE))
                .list();
        if (!list.isEmpty()) {
            return list;
        }
        return null;
    }
         
}
