/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.dtob.MemberShareDetail;
import com.upcidcosociety.dtob.MemberShareRequest;
import com.upcidcosociety.model.MemberDetailModel;
import com.upcidcosociety.model.MemberShareDetailModel;
import com.upcidcosociety.model.MemberWitnessModel;
import com.upcidcosociety.model.NomineeModel;
import com.upcidcosociety.service.CategoryService;
import com.upcidcosociety.service.FileUploadService;
import com.upcidcosociety.service.MemberDetailService;
import com.upcidcosociety.service.MemberShareDetailService;

import com.upcidcosociety.service.PaymentModeService;
import com.upcidcosociety.service.PostingService;
import com.upcidcosociety.service.RankService;
import com.upcidcosociety.service.SectorService;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
//import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/upcid")
public class MemberController {

    @Autowired
    private MemberDetailService memberDetailService;
    @Autowired
    private RankService rankService;
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private PostingService postingService;
    @Autowired
    private SectorService sectorService;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private PaymentModeService paymentModeService;

    @Autowired
    private MemberShareDetailService membersharedetailservice;

//    @Autowired
//    private MemberShareDetailService memberShareDetailService;
    @Value("${file.upload-dir}")
    private String uploadDir;
    private Path fileStorageLocation;

    @RequestMapping(value = "/newmember", method = RequestMethod.GET)
    public String newMember(ModelMap map, HttpServletRequest request, Principal principal) {
        MemberDetailModel obj = new MemberDetailModel();
        List<NomineeModel> lst = new ArrayList();
        NomineeModel modee = new NomineeModel();
        modee.setId(-1);
        lst.add(modee);
        obj.setNomineemodel(lst);
        List<MemberWitnessModel> witnesslst = new ArrayList<>();
        MemberWitnessModel memberwitnessmodel1= new MemberWitnessModel();
        memberwitnessmodel1.setwId(-1);
        MemberWitnessModel memberwitnessmodel2= new MemberWitnessModel();
        memberwitnessmodel2.setwId(-1);
        witnesslst.add(memberwitnessmodel1);
        witnesslst.add(memberwitnessmodel2);
        obj.setMemberwitnessmodel(witnesslst);
        
        map.addAttribute("member_form", obj);
        map.addAttribute("rankList", rankService.getAllrankformember(principal.getName()));
        map.addAttribute("categoryList", categoryService.getAllCategoryforMember(principal.getName()));
        map.addAttribute("sectorlist", sectorService.getAllSectorforMember(principal.getName()));
        map.addAttribute("postingList", postingService.getAllPostingforMember(principal.getName()));
        map.addAttribute("paymentList", paymentModeService.getAllPaymentMode(principal.getName()));
        return "addnewmember";
    }

    @RequestMapping(value = "/addmember", method = RequestMethod.POST)
    public String addnewMember(@ModelAttribute("member_form") MemberDetailModel memberDetailModel, ModelMap map, BindingResult result, HttpServletRequest request, Principal principal) throws IOException {
        UpcidResponse upcidResponse = null;
        if (result.hasErrors()) {
            map.addAttribute("member_form", memberDetailModel);
            map.addAttribute("rankList", rankService.getAllrankformember(principal.getName()));
            map.addAttribute("categoryList", categoryService.getAllCategoryforMember(principal.getName()));
            map.addAttribute("sectorlist", sectorService.getAllSectorforMember(principal.getName()));
            map.addAttribute("postingList", postingService.getAllPostingforMember(principal.getName()));
            map.addAttribute("paymentList", paymentModeService.getAllPaymentMode(principal.getName()));
            return "addnewmember";
        } else {
            String filename = null;
            String firstName = null;
            String flocation = null;
            String filelocationfordb = null;
            MultipartFile fl = null;
            flocation = uploadDir + "/fileUpload/" + memberDetailModel.getPnoNumber();
            fileStorageLocation = Paths.get(flocation).toAbsolutePath().normalize();
            File location = fileStorageLocation.toFile();
            if (!location.exists()) {
                location.mkdirs();
            }

            if (memberDetailModel!= null && memberDetailModel.getMemberId()!= null && memberDetailModel.getMemberId()> 0) {
                fl = memberDetailModel.getMemberphoto();
                if (fl != null && (int) fl.getSize() > 0) {
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "profile_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
//                filelocationfordb =location.getPath()+"/"+firstName+filename.substring(i);
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.setProfileulr(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberDetailModel.getMemberphoto(), location, firstName + filename.substring(i));
                }
                fl = memberDetailModel.getMembersignature();
                if (fl != null && (int) fl.getSize() > 0) {
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "sign_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
//                filelocationfordb =location.getPath()+"\\"+firstName+filename.substring(i);
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.setSignurl(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberDetailModel.getMembersignature(), location, firstName + filename.substring(i));
                }
                fl = memberDetailModel.getMemberAccountOpenningform();
                if (fl != null && (int) fl.getSize() > 0) {
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "reg_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
//                 filelocationfordb =location.getPath()+"\\"+firstName+filename.substring(i);
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.setAccountOpenFormurl(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberDetailModel.getMemberAccountOpenningform(), location, firstName + filename.substring(i));
                }
                
                List<NomineeModel>Nomineemodellst= memberDetailModel.getNomineemodel();
                if(Nomineemodellst!=null && !Nomineemodellst.isEmpty()){
                    int index=0;
                 for(NomineeModel nomineemodel:Nomineemodellst){
                  fl = nomineemodel.getNomineesign();
                    if(fl!=null && (int) fl.getSize() > 0){
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "nomineesign_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.getNomineemodel().get(index++).setSign(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(nomineemodel.getNomineesign(), location, firstName + filename.substring(i));
                   }
                 }
               }
                 List<MemberWitnessModel>memberWitnesmodel=memberDetailModel.getMemberwitnessmodel();
                 if(memberWitnesmodel!=null && !memberWitnesmodel.isEmpty()){
                       int index=0;
                    for(MemberWitnessModel memberwitnessmodel:memberWitnesmodel){
                    fl = memberwitnessmodel.getwSign();
                    if(fl!=null && (int) fl.getSize() > 0){
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "witnesssign_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                     memberDetailModel.getMemberwitnessmodel().get(index++).setwSignUrl(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberwitnessmodel.getwSign(), location, firstName + filename.substring(i));
                   }
                 }
              }
             upcidResponse = memberDetailService.updatenewMemberDetail(memberDetailModel, request.getRemoteAddr(), principal.getName());

            } else {
                
                fl = memberDetailModel.getMemberphoto();
                if (fl != null) {
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "profile_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
//                filelocationfordb =location.getPath()+"\\"+firstName+filename.substring(i);
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.setProfileulr(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberDetailModel.getMemberphoto(), location, firstName + filename.substring(i));
                }
                fl = memberDetailModel.getMembersignature();
                if (fl != null) {
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "sign_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.setSignurl(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberDetailModel.getMembersignature(), location, firstName + filename.substring(i));
                }
                fl = memberDetailModel.getMemberAccountOpenningform();
                if (fl != null) {
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "reg_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
//                 filelocationfordb =location.getPath()+"\\"+firstName+filename.substring(i);
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.setAccountOpenFormurl(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberDetailModel.getMemberAccountOpenningform(), location, firstName + filename.substring(i));
                }
                
                List<NomineeModel>Nomineemodellst= memberDetailModel.getNomineemodel();
                if(Nomineemodellst!=null && !Nomineemodellst.isEmpty()){
                    int index=0;
                 for(NomineeModel nomineemodel:Nomineemodellst){
                  fl = nomineemodel.getNomineesign();
                    if(fl!=null && (int) fl.getSize() > 0){
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "nomineesign_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.getNomineemodel().get(index++).setSign(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(nomineemodel.getNomineesign(), location, firstName + filename.substring(i));
                   }
                 }
                
                 }
                 List<MemberWitnessModel>memberWitnesmodel=memberDetailModel.getMemberwitnessmodel();
                 if(memberWitnesmodel!=null && !memberWitnesmodel.isEmpty()){
                       int index=0;
                    for(MemberWitnessModel memberwitnessmodel:memberWitnesmodel){
                    fl = memberwitnessmodel.getwSign();
                    if(fl!=null && (int) fl.getSize() > 0){
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "witnesssign_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                     memberDetailModel.getMemberwitnessmodel().get(index++).setwSignUrl(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberwitnessmodel.getwSign(), location, firstName + filename.substring(i));
                   }
                 }
              }
 
                upcidResponse = memberDetailService.addnewMemberDetail(memberDetailModel, request.getRemoteAddr(), principal.getName());
            }
            request.getSession().setAttribute("msg", upcidResponse.getMessage());

            if (upcidResponse.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
            } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");
            } else {
                request.getSession().setAttribute("msgType", "warning");
            }
            return "redirect:/upcid/newmember";
        }

    }
    
    
    
   
    
    @RequestMapping(value = "/getmemberdetail/{pnonumber}", method = RequestMethod.GET)
    public String GetMemberDetaillByAccountNo(@PathVariable String pnonumber, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse upcidResponse = null;
        upcidResponse = memberDetailService.getMemberDetailBypnoNumber(pnonumber, principal.getName());
        if (upcidResponse.getStatus() == HttpStatus.OK) {
            map.addAttribute("member_form", (MemberDetailModel) upcidResponse.getData());
            map.addAttribute("rankList", rankService.getAllrankformember(principal.getName()));
            map.addAttribute("categoryList", categoryService.getAllCategoryforMember(principal.getName()));
            map.addAttribute("sectorlist", sectorService.getAllSectorforMember(principal.getName()));
            map.addAttribute("postingList", postingService.getAllPostingforMember(principal.getName()));
            map.addAttribute("paymentList", paymentModeService.getAllPaymentMode(principal.getName()));
            return "addnewmember";
        }
        return "redirect:/upcid/newmember";
    }

    @RequestMapping(value = "/deletememberdetailById/{memeberId}", method = RequestMethod.GET)
    public String DeleteMemberDetaillBymemeberId(@PathVariable Integer memeberId, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse upcidResponse = null;
        upcidResponse = memberDetailService.deleteMemberDetailByMemeberId(memeberId, principal.getName());
        // map.addAttribute("paymentform", apiResponse.getResult());
        request.getSession().setAttribute("msg", upcidResponse.getMessage());
        if (upcidResponse.getStatus() == HttpStatus.OK) {
            request.getSession().setAttribute("msgType", "success");
        } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");

        } else {
            request.getSession().setAttribute("msgType", "warning");
        }
        return "redirect:/upcid/getAllmemberdetail";
    }

    @RequestMapping(value = "/getAllmemberdetail", method = RequestMethod.GET)
    public String GetAllMemberDetaill(ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<List<MemberDetailModel>> upcidResponse = null;
        upcidResponse = memberDetailService.getAllMemberDetail(principal.getName());
        map.addAttribute("mdlist", upcidResponse);
        return "showmember";
    }
    
    
   /**
    * this method will get All those new member account list who wants to create our account
    * @param map
    * @param request
    * @param principal
    * @return 
    */
      @RequestMapping(value = "/newaccountreq", method = RequestMethod.GET)
      public String getAllNewAccountRequestedList(ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse upcidResponse = null;
        upcidResponse = memberDetailService.getAllnewMemberAccountRequestedList(principal.getName());
         map.addAttribute("newaccountReqLst",upcidResponse);
       return "newaccountreq";
      
    }
      
      @RequestMapping(value = "/viewnewaccountreq", method = RequestMethod.GET)
      public String viewNewAccountRequestedMember(ModelMap map, HttpServletRequest request, Principal principal) {
       return "viewnewaccountreq"; 
    }
    
    
    // it will show member detail into view page 
    @RequestMapping(value = "/viewmemberdetail/{pnonumber}", method = RequestMethod.GET)
    public String viewmemberDetaill(@PathVariable String pnonumber, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse upcidResponse = null;
        upcidResponse = memberDetailService.getMemberDetailBypnoNumber(pnonumber, principal.getName());
        map.addAttribute("mdlist", upcidResponse);
        return "viewmember";
    }
    
    // disable member account 
    @RequestMapping(value = "/disable/{memeberId}", method = RequestMethod.GET)
    public String disablemember(@PathVariable Integer memeberId, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse upcidResponse = null;
        upcidResponse = memberDetailService.disableMemberDetailByMemeberId(memeberId, principal.getName());
        request.getSession().setAttribute("msg", upcidResponse.getMessage());

        if (upcidResponse.getStatus() == HttpStatus.OK) {
            request.getSession().setAttribute("msgType", "success");
        } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
        } else {
            request.getSession().setAttribute("msgType", "warning");
        }
        return "redirect:/upcid/getAllmemberdetail";
    }

    @RequestMapping(value = "/enable/{memeberId}", method = RequestMethod.GET)
    public String inablemember(@PathVariable Integer memeberId, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse upcidResponse = null;
        upcidResponse = memberDetailService.InableMemberDetailByMemeberId(memeberId, principal.getName());
        request.getSession().setAttribute("msg", upcidResponse.getMessage());

        if (upcidResponse.getStatus() == HttpStatus.OK) {
            request.getSession().setAttribute("msgType", "success");
        } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
        } else {
            request.getSession().setAttribute("msgType", "warning");
        }
        return "redirect:/upcid/getAllmemberdetail";
    }

    @RequestMapping(value = "/membershare", method = RequestMethod.GET)
    public String managemembershare(ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
        map.addAttribute("memberSharedetail_form", new MemberShareDetailModel());
        DateTime date = new DateTime();
        date = date.plusMonths(1);
        String monthname = date.monthOfYear().getAsText();
        map.addAttribute("monthNameforsharerequest", monthname);
        return "managemembershare";
    }

    @RequestMapping(value = "/membershare/{pnonumber}", method = RequestMethod.GET)
    public String managemembershare(@PathVariable String pnonumber, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<MemberShareDetailModel> response = null;
        response = membersharedetailservice.getMemberShareDetailBymemberId(pnonumber);
        if (response.getStatus() == HttpStatus.OK) {
            map.addAttribute("memberSharedetail_form", response.getData());
            DateTime date = new DateTime();
            date = date.plusMonths(1);
            String monthname = date.monthOfYear().getAsText();
            map.addAttribute("monthNameforsharerequest", monthname);
            map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
            return "managemembershare";
        } else {
            return "redirect:/upcid/membershare";
        }
    }

    @RequestMapping(value = "/membersharerequest", method = RequestMethod.POST)
    public String managemembershare(HttpServletRequest request, Principal principal) {
        UpcidResponse<MemberShareDetailModel> upcidResponse = null;
        MemberShareRequest membersharerequest = null;
        String monthName = request.getParameter("month");
        String amount = request.getParameter("amount");
        String memberId = request.getParameter("memberid");
        membersharerequest = new MemberShareRequest();
        Double amountVal = Double.parseDouble(amount);
        Integer memberIdVal = Integer.parseInt(memberId);
        membersharerequest.setMonth(monthName);
        membersharerequest.setAmount(amountVal);
        membersharerequest.setMemberId(memberIdVal);

        upcidResponse = membersharedetailservice.savemembershareRequest(membersharerequest);
        if (upcidResponse.getStatus() == HttpStatus.OK) {
            request.getSession().setAttribute("msgType", "success");
        } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
        } else {
            request.getSession().setAttribute("msgType", "warning");
        }
        return "redirect:/upcid/membershare";
    }

    @RequestMapping(value = "/updateshare", method = RequestMethod.POST)
    public String updatemembershare(@ModelAttribute("memberSharedetail_form") MemberShareDetailModel memberShareDetailModel, BindingResult result, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse upcidResponse = null;
        MemberShareDetail msd = null;
        if (result.hasErrors()) {
            map.addAttribute("memberSharedetail_form", new MemberShareDetailModel());
            return "managemembershare";
        } else {
            if (memberShareDetailModel != null && memberShareDetailModel.getMsdId() != null && memberShareDetailModel.getMsdId() > 0) {
                upcidResponse = membersharedetailservice.updateMemberShareDetail(memberShareDetailModel);
            }
            request.getSession().setAttribute("msg", upcidResponse.getMessage());

            if (upcidResponse.getStatus() == HttpStatus.OK) {
                msd=(MemberShareDetail)upcidResponse.getData();
                request.getSession().setAttribute("msgType", "success");
            } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");
            } else {
                request.getSession().setAttribute("msgType", "warning");
            }

            return "redirect:/upcid/membershare/" + msd.getMemberDetail().getMemberId();
        }
    }
    

  
    

}
//    }

