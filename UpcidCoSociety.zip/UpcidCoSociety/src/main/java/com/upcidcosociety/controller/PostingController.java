/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.dtob.Posting;
import com.upcidcosociety.service.PostingService;
import com.upcidcosociety.util.UpcidResponse;
import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/upcid")
public class PostingController {
    
     @Autowired
     private PostingService postingService;
    
     @RequestMapping(value = "/posting", method = RequestMethod.GET)  
     public String Postion(ModelMap map, HttpServletRequest request, Principal principal) {  
        map.addAttribute("posting_form", new Posting());
        map.addAttribute("postingListRes", postingService.getAllPosting(principal.getName()));
        return "posting"; 
    }
    
     @RequestMapping(value = "/addposting", method = RequestMethod.POST)  
     public String addPostion(@ModelAttribute("posting_form")Posting posting,ModelMap map, BindingResult result,HttpServletRequest request, Principal principal) {  
         UpcidResponse upcidResponse=null;
         if(result.hasErrors())
       {
         map.addAttribute("postingListRes", postingService.getAllPosting(principal.getName()));
         return "posting";
       }else{
            if (posting != null && posting.getId()!= null && posting.getId()> 0) {
                upcidResponse = postingService.updatePosting(posting,request.getRemoteAddr(),principal.getName());
            } else {
                 upcidResponse = postingService.addPosting(posting,request.getRemoteAddr(),principal.getName());
            } 
          }
         request.getSession().setAttribute("msg", upcidResponse.getMessage());
         if(upcidResponse.getStatus()== HttpStatus.OK){
           request.getSession().setAttribute("msgType", "success");
          }else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
         } else {
            request.getSession().setAttribute("msgType", "warning");
        }
         return "redirect:/upcid/posting";
    }
     
     @RequestMapping(value = "/editposting/{id}", method = RequestMethod.GET)  
     public String editPosting(@PathVariable Integer id, ModelMap map, HttpServletRequest request, Principal principal){
       
      UpcidResponse<Posting> response= postingService.getPostingById(id, principal.getName());
        if (response.getStatus() == HttpStatus.OK) {
             map.addAttribute("posting_form", response.getData());
             map.addAttribute("postingListRes", postingService.getAllPosting(principal.getName()));
            return "posting";
        } else {
            return "redirect:/upcid/posting";
        }
     }
     @RequestMapping(value = "/deletePosting/{id}", method = RequestMethod.GET)
    public String deletePosting(@PathVariable Integer id, ModelMap map, HttpServletRequest request, Principal principal) {
         UpcidResponse<Posting> response = postingService.softDeletePostingById(id, principal.getName());
         
            request.getSession().setAttribute("msg", response.getMessage());
            if (response.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
            } else if (response.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");

            } else {
                request.getSession().setAttribute("msgType", "warning");
            }

        return "redirect:/upcid/posting";
    }
     
}
