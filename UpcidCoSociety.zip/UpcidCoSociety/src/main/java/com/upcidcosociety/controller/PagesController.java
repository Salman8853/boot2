/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.dtob.News;
import com.upcidcosociety.dtob.PageMaster;
import com.upcidcosociety.dtob.Pages;
import com.upcidcosociety.model.AlbumDetailModel;
import com.upcidcosociety.model.AlbumModel;
import com.upcidcosociety.model.ComplaintsReplyModel;
import com.upcidcosociety.model.PageModel;
import com.upcidcosociety.service.ComplaintsService;
import com.upcidcosociety.service.FeedBackService;
import com.upcidcosociety.service.FileUploadService;
import com.upcidcosociety.service.NewsService;
import com.upcidcosociety.service.PageMasterService;
import com.upcidcosociety.service.PagesService;
import com.upcidcosociety.service.PhotoGalaryService;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/upcid")
public class PagesController {

    @Autowired
    private PagesService pagesService;
    @Autowired
    private PageMasterService pageMasterService;

    @Autowired
    private FileUploadService fileUploadService;

    @Autowired
    private PhotoGalaryService PhotoGalaryService;

    @Autowired
    private ComplaintsService complaintsService;

    @Autowired
    private FeedBackService feedBackService;

    @Autowired
    private NewsService newService;
    

    
    

    @Value("${file.upload-dir}")
    private String uploadDir;
    private Path fileStorageLocation;

    @RequestMapping(value = "/dashboard", method = RequestMethod.GET)
    public String goDashboard(ModelMap map, HttpServletRequest request, Principal principal) throws Exception {
        if (principal != null) {
            map.addAttribute("pagesRes", pagesService.getAllPages(principal.getName()));
            return "dashboard";
        } else {
            return "redirect:/upcid";
        }
    }

    @RequestMapping(value = "/cms/{pagename}", method = RequestMethod.GET)
    public String newckEditor(@PathVariable String pagename, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse response = null;
        response = pageMasterService.getPageMasterBypageName(pagename, principal.getName());
        if (response.getStatus() == HttpStatus.OK) {
            PageMaster pageMaster = (PageMaster) response.getData();

            response = pagesService.getpageBypid(pageMaster.getPid(), principal.getName());
            if (response.getStatus() == HttpStatus.OK) {
                map.addAttribute("pagestatus", "edit");
                map.addAttribute("ckeditor_form", (PageModel) response.getData());
                return "editPage";
            } else {
                map.addAttribute("pagestatus", "add");
                PageModel pm = new PageModel();
                pm.setPageId(pageMaster.getPid());
                map.addAttribute("ckeditor_form", pm);
                return "editPage";
            }

        }
        //redirect to error page 
        map.addAttribute("ckeditor_form", new Pages());
        return "editPage";
    }

    @RequestMapping(value = "/addpages", method = RequestMethod.POST)
    public String savepages(@ModelAttribute("ckeditor_form") PageModel pages, ModelMap map, BindingResult result, HttpServletRequest request, Principal principal) {
        UpcidResponse upcidResponse = null;
        if (result.hasErrors()) {
            map.addAttribute("ckeditor_form", pages);
            return "editPage";
        } else {
            if (pages != null && pages.getId() != null && pages.getId() > 0) {
                upcidResponse = pagesService.updatePages(pages, request.getRemoteAddr(), principal.getName());
            } else {
                upcidResponse = pagesService.addPages(pages, request.getRemoteAddr(), principal.getName());
            }

            request.getSession().setAttribute("msg", upcidResponse.getMessage());
            if (upcidResponse.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
                return "redirect:/upcid/dashboard";
            } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");
            } else {
                request.getSession().setAttribute("msgType", "warning");
            }

            map.addAttribute("ckeditor_form", pages);
            return "editPage";
        }
    }

    @RequestMapping(value = "/cms/edit/{pid}", method = RequestMethod.GET)
    public String editckCMS(@PathVariable Integer pid, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse response = pagesService.getpageBypid(pid, principal.getName());
        if (response.getStatus() == HttpStatus.OK) {
            map.addAttribute("ckeditor_form", response.getData());
            map.addAttribute("pagestatus", "edit");
            return "editPage";
        } else {
            return "redirect:/upcid/dashboard";
        }
    }

    @RequestMapping(value = "/cms/delete/{pid}", method = RequestMethod.GET)
    public String deleteCMS(@PathVariable Integer pid, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse response = pagesService.deletePageById(pid, principal.getName());

        request.getSession().setAttribute("msg", response.getMessage());
        if (response.getStatus() == HttpStatus.OK) {
            request.getSession().setAttribute("msgType", "success");
        } else if (response.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");

        } else {
            request.getSession().setAttribute("msgType", "warning");
        }
        return "redirect:/upcid/dashboard";
    }

//    photo Galary Controller
    @RequestMapping(value = "/galary", method = RequestMethod.GET)
    public String photogalary(ModelMap map, HttpServletRequest request, Principal principal) {
        AlbumModel albumModel = new AlbumModel();
        List<AlbumDetailModel> albumdetailmodellist = null;
        AlbumDetailModel albumDetailModel = new AlbumDetailModel();
        albumDetailModel.setAlbumdetailId(-1);
        albumdetailmodellist = new ArrayList<>();
        albumdetailmodellist.add(albumDetailModel);
        albumModel.setAlbumDetailList(albumdetailmodellist);
        map.addAttribute("photogalary_Form", albumModel);
        map.addAttribute("albumlist", PhotoGalaryService.getallAlbumList(principal.getName()));
        return "photogalary";
    }

    //add images from admin side
    @RequestMapping(value = "/saveImage", method = RequestMethod.POST)
    public String photogalary(@ModelAttribute("photogalary_Form") AlbumModel albumModel, BindingResult result, HttpServletRequest request, Principal principal) throws IOException {
        UpcidResponse upcidResponse = null;
        if (result.hasErrors()) {
            return "photogalary";
        } else {
            MultipartFile image = null;
            String flocation = null;
            int counter = 1;
            List<String> urlList = new ArrayList();
            flocation = uploadDir + "/galary/" + albumModel.getAlbumTitle();
            fileStorageLocation = Paths.get(flocation).toAbsolutePath().normalize();
            File location = fileStorageLocation.toFile();
            if (!location.exists()) {
                location.mkdirs();
            }
            for (AlbumDetailModel albumdetailModel : albumModel.getAlbumDetailList()) {
                if (albumdetailModel != null && albumdetailModel.getImage() != null) {
                    String url = null;
                    String firstName = null;
                    String fileName = null;
                    image = albumdetailModel.getImage();
                    fileName = image.getOriginalFilename();
                    int i = fileName.indexOf(".");
                    firstName = fileName.substring(0, i);
                    firstName = "image_" + counter + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
                    url = "/galary/" + albumModel.getAlbumTitle() + "/" + firstName + fileName.substring(i);
                    urlList.add(url);
                    upcidResponse = upcidResponse = fileUploadService.UploadFile(image, location, firstName + fileName.substring(i));
                }
                counter++;
            }
            if (urlList != null && urlList.size() > 0) {
                albumModel.setUrlList(urlList);
            }
            upcidResponse = PhotoGalaryService.addPhotoGalary(albumModel, request.getRemoteAddr(), principal.getName());
        }
        request.getSession().setAttribute("msg", upcidResponse.getMessage());

        if (upcidResponse.getStatus() == HttpStatus.OK) {
            request.getSession().setAttribute("msgType", "success");
        } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
        } else {
            request.getSession().setAttribute("msgType", "warning");
        }
        return "redirect:/upcid/galary";
    }

    @RequestMapping(value = "/albumgalary/{albumTitle}", method = RequestMethod.GET)
    public String photogalary(@PathVariable("albumTitle") String albumTitle, ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("photoGalarylistByalbumTitle", PhotoGalaryService.getgalaryListByalbumTitle(albumTitle, principal.getName()));
        return "insidegalary";

    }
    @RequestMapping(value = "/deleteimage/{albumdetailid}/{albumTitle}", method = RequestMethod.GET)
    public String photogalary(@PathVariable("albumdetailid") Integer albumdetailid,@PathVariable("albumTitle") String albumTitle, ModelMap map, HttpServletRequest request, Principal principal) {
       UpcidResponse upcidResponse = null;
        upcidResponse= PhotoGalaryService.deteteGalaryimage(albumdetailid, principal.getName());
       
        request.getSession().setAttribute("msg", upcidResponse.getMessage());

        if (upcidResponse.getStatus() == HttpStatus.OK) {
            request.getSession().setAttribute("msgType", "success");
        } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
        } else {
            request.getSession().setAttribute("msgType", "warning");
        }
       return "redirect:/upcid/albumgalary/"+albumTitle;
    }


    //upcid view complaints section
    @RequestMapping(value = "/viewall", method = RequestMethod.GET)
    public String viewallComplaints(ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("viewAllComplaintslist", complaintsService.getAllComplaints(principal.getName()));
        return "viewall";
    }

    @RequestMapping(value = "/complaint/{id}", method = RequestMethod.GET)
    public String viewlComplaints(@PathVariable Integer id, ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("viewComplaint", complaintsService.getComplaintById(id));
        return "viewcomplaint";
    }

    @RequestMapping(value = "/complaintreply/{id}", method = RequestMethod.GET)
    public String ComplaintsReply(@PathVariable Integer id, ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("reply_form", new ComplaintsReplyModel());
        map.addAttribute("viewComplaint", complaintsService.getComplaintById(id));
        return "replyoncomplaint";
    }
    @RequestMapping(value = "/reply", method = RequestMethod.POST)
    public String ComplaintsResponse(@ModelAttribute("reply_form")ComplaintsReplyModel complaintsReplyModel,BindingResult result, ModelMap map, HttpServletRequest request, Principal principal) {
     UpcidResponse upcidResponse = null;
     if(result.hasErrors()){
       map.addAttribute("viewComplaint", complaintsService.getComplaintById(complaintsReplyModel.getId()));
       return "replyoncomplaint";
     }else{
           upcidResponse=complaintsService.sentcomplaintReplytoMember(complaintsReplyModel);
       }
        request.getSession().setAttribute("msg", upcidResponse.getMessage());
        if (upcidResponse.getStatus() == HttpStatus.OK) {
            request.getSession().setAttribute("msgType", "success");
        } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
        } else {
            request.getSession().setAttribute("msgType", "warning");
        }
      return "redirect:/upcid/complaintreply/"+complaintsReplyModel.getId();
    }
   
           
    @RequestMapping(value = "/viewallfeedback", method = RequestMethod.GET)
    public String viewallFeedBack(ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("viewAllFeedBacklist", feedBackService.getAllFeedBack(principal.getName()));
        return "viewallfeedback";
    }

    @RequestMapping(value = "/viewafeedback/{id}", method = RequestMethod.GET)
    public String viewFeedBack(@PathVariable Integer id, ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("feedbackResponse", feedBackService.getFeedBackById(id, principal.getName()));
        return "viewfeedback";
    }

//     save news from admin side
    @RequestMapping(value = "/news")
    public String news(ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("news_form", new News());
        return "news";
    }

    @RequestMapping(value = "/addnews")
    public String news(@ModelAttribute("news_form") News news, BindingResult result, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse upcidResponse = null;
        if (result.hasErrors()) {
            return "news";
        } else {
//         save nerw news 
              upcidResponse=newService.saveNews(news, principal.getName());
        }
        
        request.getSession().setAttribute("msg", upcidResponse.getMessage());
     
         if(upcidResponse.getStatus()== HttpStatus.OK){
           request.getSession().setAttribute("msgType", "success");
          }else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
         } else {
            request.getSession().setAttribute("msgType", "warning");
        }
         return "redirect:/upcid/news";
    }
    
   @RequestMapping(value = "/upload", method = RequestMethod.GET)
    public String uploaddocs(ModelMap map, HttpServletRequest request, Principal principal) {
        return "upload";
    } 

}
