/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.util.Roles;
import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author m.salman
 */
@Controller
public class IndexController {

    @RequestMapping("/index")
    public String Index(ModelMap map) {
        return "index";
    }

    /**
     *
     * @param map
     * @return
     */
    @RequestMapping("/403")
    public String errorPage(ModelMap map) {
        return "redirect:/index";
    }

    /**
     *
     * send to member login
     *
     */
    @RequestMapping("/member/mdashboard")
    public String goDashboard(ModelMap map, Principal principal) {

        return "mdashboard";
    }

    /**
     *
     * send to admin login
     *
     */
//    @RequestMapping("/upcid")
//    public String adminPage(ModelMap map) {
//
//        return "upcid";
//    }

    /**
     *
     * check and redirect according to role
     */
    @RequestMapping(value = "/getLogedIn", method = RequestMethod.GET)
    public String showDashboard(ModelMap map, HttpServletRequest request, Principal principal) {

        if (request.isUserInRole(Roles.Admin_role)) {
            request.getSession().setAttribute("username", principal.getName());
            return "redirect:/upcid/dashboard";
        } else {
            return "redirect:/index";
        }

    }

    @RequestMapping(value = "/getMLogedIn", method = RequestMethod.GET)
    public @ResponseBody
    String showmDashboard(ModelMap map, HttpServletRequest request, Principal principal) {
        if (request.isUserInRole(Roles.Member_role)) {
            principal.getName();

            //get detail of memeber from db and set in session  
            request.getSession().setAttribute("username", principal.getName());
            return "{\"result\":\"success\"}";
        } else {
            return "{\"result\":\"Incorrect username or password\"}";
        }

    }

    @RequestMapping(value = "/failtologin", method = RequestMethod.GET)
    public String failtologin(ModelMap map, HttpServletRequest request, Principal principal) {
        System.out.println("from failtologin page of index controller");
        String error = "true";
        map.addAttribute("error", "true");
        return "redirect:/upcid";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout(ModelMap map, HttpServletRequest request, Principal principal) {

        if (request.isUserInRole(Roles.Admin_role)) {
            HttpSession httpSession = request.getSession();
            httpSession.invalidate();
            
            return "redirect:/upcid";
        } else if (request.isUserInRole(Roles.Member_role)) {
//            HttpSession httpSession = request.getSession();
//            httpSession.invalidate();
            return "redirect:/index";
        } else {
            HttpSession httpSession = request.getSession();
            httpSession.invalidate();
            return "redirect:/index";
        }

    }

    @RequestMapping(value = "/failtomemberlogin", method = RequestMethod.GET)
    public @ResponseBody
    String failtomemberlogin(ModelMap map, HttpServletRequest request, Principal principal) {
        System.out.println("from failtologin page of index controller");
        String error = "true";
        map.addAttribute("error", "true");
        return "{\"result\":\"Incorrect username or password\"}";
    }

    @RequestMapping(value = "/upcid", method = {RequestMethod.GET, RequestMethod.POST})
    public String adminLoginPage(HttpServletRequest request, ModelMap modelMap) {
        return "upcid";
    }

    @RequestMapping(value = "/member-login", method = RequestMethod.GET)
    public String memberLoginPage(HttpServletRequest request, ModelMap modelMap) {

        return "redirect:/index";
    }

}
