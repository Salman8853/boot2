/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.dtob.Sector;
import com.upcidcosociety.service.SectorService;
import com.upcidcosociety.util.UpcidResponse;
import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/upcid")
public class SectorController {
    
     @Autowired
     private SectorService sectorService;
     
     @RequestMapping(value = "/sector",method = RequestMethod.GET)  
     public String Sector(ModelMap map, HttpServletRequest request, Principal principal) { 
          map.addAttribute("sector_form", new Sector());
          map.addAttribute("sectorListRes", sectorService.getAllSector(principal.getName()));
          return "sector";  
    }
    
     @RequestMapping(value = "/addsector",method = RequestMethod.POST)  
     public String AddSector(@ModelAttribute("sector_form") Sector sector, ModelMap map, BindingResult result, HttpServletRequest request, Principal principal) { 
        UpcidResponse upcidResponse = null; 
        if(result.hasErrors()){
           map.addAttribute("sectorListRes", sectorService.getAllSector(principal.getName()));
           return "sector";
         }else{
            if (sector != null && sector.getId() != null && sector.getId() > 0) {
                upcidResponse = sectorService.updateSector(sector, request.getRemoteAddr(), principal.getName());
            } else {
                 upcidResponse = sectorService.addSector(sector, request.getRemoteAddr(), principal.getName());
            }
        } 
          request.getSession().setAttribute("msg", upcidResponse.getMessage());
     
         if(upcidResponse.getStatus()== HttpStatus.OK){
           request.getSession().setAttribute("msgType", "success");
          }else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
         } else {
            request.getSession().setAttribute("msgType", "warning");
         }
         return "redirect:/upcid/sector";
    }
    
     @RequestMapping(value = "/editsector/{id}", method = RequestMethod.GET)
     public String editSector(@PathVariable Integer id, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<Sector> response= sectorService.geSectorById(id, principal.getName());
        if (response.getStatus() == HttpStatus.OK) {
             map.addAttribute("sector_form", response.getData());
             map.addAttribute("sectorListRes", sectorService.getAllSector(principal.getName()));
            return "sector";
        } else {
            return "redirect:/upcid/sector";
        }
    }
    @RequestMapping(value = "/deleteSector/{id}", method = RequestMethod.GET)
    public String deleteCategory(@PathVariable Integer id, ModelMap map, HttpServletRequest request, Principal principal) {
         UpcidResponse<Sector> response = sectorService.deleteSectorById(id, principal.getName());
            request.getSession().setAttribute("msg", response.getMessage());
            if (response.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
            } else if (response.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");
            } else {
                request.getSession().setAttribute("msgType", "warning");
            }
            return "redirect:/upcid/sector";
    } 
     
}
