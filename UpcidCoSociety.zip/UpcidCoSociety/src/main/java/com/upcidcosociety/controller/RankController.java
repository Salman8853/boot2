/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;
import com.upcidcosociety.dtob.Rank;
import com.upcidcosociety.service.RankService;
import com.upcidcosociety.util.UpcidResponse;
import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/upcid")
public class RankController {
     @Autowired
     private RankService rankService;
      
    @RequestMapping(value = "/rank", method = RequestMethod.GET)
    public String rank(ModelMap map, HttpServletRequest request, Principal principal) {
    map.addAttribute("rank_form", new Rank()); 
    map.addAttribute("rankRes", rankService.getAll(principal.getName())); 
    return "rank";
    }
   @RequestMapping(value = "/addrank", method = RequestMethod.POST)
   public  String saveRank( @ModelAttribute("rank_form")Rank rank,ModelMap map, BindingResult result,HttpServletRequest request, Principal principal) {
       UpcidResponse upcidResponse=null;
       if(result.hasErrors()){
         map.addAttribute("rankRes", rankService.getAll(principal.getName())); 
         return "rank";
       }else{
            if (rank != null && rank.getId()!= null && rank.getId()> 0) {
                upcidResponse = rankService.updaterank(rank,request.getRemoteAddr(),principal.getName());
            } else {
                 upcidResponse = rankService.addranks(rank,request.getRemoteAddr(),principal.getName());
            } 
       }
           request.getSession().setAttribute("msg", upcidResponse.getMessage());
     
         if(upcidResponse.getStatus()== HttpStatus.OK){
           request.getSession().setAttribute("msgType", "success");
          }else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
         } else {
            request.getSession().setAttribute("msgType", "warning");
        }
         return "redirect:/upcid/rank";
 } 
    @RequestMapping(value = "/editrank/{id}", method = RequestMethod.GET)
     public String editrank(@PathVariable Integer id, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<Rank> response= rankService.getRankById(id, principal.getName());
        if (response.getStatus() == HttpStatus.OK) {
             map.addAttribute("rank_form", response.getData());
            map.addAttribute("rankRes", rankService.getAll(principal.getName()));
            return "rank";
        } else {
            return "redirect:/upcid/rank";
        }
    }
     @RequestMapping(value = "/deleterank/{id}", method = RequestMethod.GET)
    public String deleterank(@PathVariable Integer id, ModelMap map, HttpServletRequest request, Principal principal) {
         UpcidResponse<Rank> response = rankService.deleteRankById(id, principal.getName());
            request.getSession().setAttribute("msg", response.getMessage());
            if (response.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
            } else if (response.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");

            } else {
                request.getSession().setAttribute("msgType", "warning");
            }
            return "redirect:/upcid/rank";
    }
}
