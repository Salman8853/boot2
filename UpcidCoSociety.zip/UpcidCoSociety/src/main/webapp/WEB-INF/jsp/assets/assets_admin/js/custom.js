$(document).ready(function () {


    $('#home_slider').owlCarousel({
        loop: true,
        dots: false,
        autoplay: true,
        margin: 0,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            },
        }





    })

    $('#peopel_slider').owlCarousel({
        loop: true,
        dots: false,
        autoplay: true,
        margin: 0,
        nav: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 4
            },
        }





    })


    $(".collapse_nav").click(function () {
        $(this).parent().parent('.dash_left_section').toggleClass('hide_menu');
        $('.dash_right_section').toggleClass('srink_area');
    });

    $('.drop_menu .plus').click(function () {
        $(this).parent(".drop_menu").toggleClass('open');
    });
    $('.dash_left_section .collapse_nav').click(function () {
        $(this).parent(".dash_left_section").toggleClass('hide');
    });

});
$(document).ready(function () {
    $("a").tooltip();
});

$(document).ready(function () {
    $('#sort-tbl').DataTable();

});

//add dynamic Nominee for fd
$(document).ready(function () {
    var counter = 2;

    $("#addmore").on("click", function () {
//        var path=$(this).closest("td").find("#pathurl").val();
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td><div class="form-group"><input type="text" name="nominee[' + (counter - 1) + '].nomineeName" class="form-control " placeholder="Enter Nominee" id="nomineeId' + counter + '"  required="required"/> <p style="color: red" id="nomineeId' + counter + '_error" class="error"></p></div></td>';
        cols += '<td><div class="form-group"><input type="text" name="nominee[' + (counter - 1) + '].address" class="form-control " placeholder="Enter address" id="address' + counter + '"  required="required"/> <p style="color: red" id="address' + counter + '_error" class="error"></p></div></td>';
        cols += '<td><div class="form-group"><input type="text" name="nominee[' + (counter - 1) + '].relation" class="form-control " placeholder="Enter Relation" id="relation' + counter + '" required="required"/><p style="color: red" id="relation' + counter + '_error" class="error"></p></div></td>';
        cols += '<td><div class="form-group"><input type="text" name="nominee[' + (counter - 1) + '].share" class="form-control  " placeholder="Enter Share" id="share' + counter + '" required="required"/><p style="color: red" id="share' + counter + '_error" class="error"></p></div></td>';

        cols += '<td><div class="form-group"><input type="button" class="ibtnDel btn btn-xs btn-danger "  value="-" style="width:100%; font-size:19px; font-weight:600;"/></div></td>';
        newRow.append(cols);
        $("table.order-list").append(newRow);
        counter++;
    });



    $("table.order-list").on("click", ".ibtnDel", function (event) {
        $(this).closest("tr").remove();
        counter -= 1
    });


});



//add dynamic Nominee for member

$(document).ready(function () {
    var counter = 2;

    $("#addrow").on("click", function () {
        var path = $(this).closest("td").find("#pathurl").val();
        // alert(path);
        var newRow = $("<tr>");
        var cols = "";
        if(counter<=3){   
        cols += '<td><div class="form-group"><input type="text" name="nomineemodel[' + (counter - 1) + '].nomineeName" class="form-control membernominee" placeholder=" Nominee ' + counter + '" id="nomineeId' + counter + '"  required="required" onchange="nomineeNameValidator(this)" /> <p style="color: red" id="nomineeId' + counter + '_error" class="error"></p></div></td>';
        cols += '<td><div class="form-group"><input type="text" name="nomineemodel[' + (counter - 1) + '].relation" class="form-control nomineerelation" placeholder="Relation" id="relation' + counter + '" required="required" onchange="relationValidator(this)" /><p style="color: red" id="relation' + counter + '_error" class="error"></p></div></td>';
        cols += '<td><div class="form-group"><input type="text" name="nomineemodel[' + (counter - 1) + '].dob" class="form-control dob" placeholder="Date of Birth" id="dob' + counter + '"  required="required" onchange="nomineeadobValidator(this)" /> <p style="color: red" id="dob' + counter + '_error" class="error"></p></div></td>';
        cols += '<td><div class="form-group"><input type="text" name="nomineemodel[' + (counter - 1) + '].address" class="form-control address" placeholder="address" id="address' + counter + '"  required="required" onchange="nomineeaddressValidator(this)" /> <p style="color: red" id="address' + counter + '_error" class="error"></p></div></td>';
        cols += '<td><div class="form-group"><input type="file" name="nomineemodel[' + (counter - 1) + '].nomineesign" class="form-control nomineesign"  id="nomineesign' + counter + '" required="required"  /><p style="color: red" id="nomineesign' + counter + '_error" class="error"></p></div></td>';
        cols += '<td><div class="form-group"><input type="text" name="nomineemodel[' + (counter - 1) + '].percentage" class="form-control  nomineeparcentage" placeholder="Percentage" id="percentage' + counter + '" required="required" onchange="parcentageValidator(this)" /><p style="color: red" id="percentage' + counter + '_error" class="error"></p></div></td>';
        cols += '<td><div class="form-group"><input type="button" class="ibtnDel btn btn-xs btn-danger "  value="-" style="width:100%; font-size:19px; font-weight:600;"/></div></td>';
        newRow.append(cols);
        $("table.order-list").append(newRow);
        counter++;
        }

    });



    $("table.order-list").on("click", ".ibtnDel", function (event) {
        $(this).closest("tr").remove();
        counter -= 1
    });


});
//add dynamic images
$(document).ready(function () {
    var counter = 2;

    $("#addimage").on("click", function () {
        var newRow = "";
        newRow += '<div><div class="col-md-7"><div class="form-group" ><div class="form-control" style=" padding: 5px; height:34px;"><input type="file" name="albumDetailList[' + (counter - 1) + '].image" id="uploadphoto' + counter + '" class="uploadphoto" style=" margin-bottom:10px" required="required" value=""/></div>'
                + '<p style="color: red" id="uploadphoto' + counter + '_error" class="error"><form:errors path="image"/></p></div></div> '
                + '<div class="col-md-5"><a href="#" class="delete_btn"><i class="fa fa-minus" title="Delete Images"></i></a></div></div>';
        $("#image-group").append(newRow);
        counter++;
    });



    $("#image-group").on("click", ".delete_btn", function (event) {
        $(this).parent().parent().remove();

        counter -= 1
    });


});



$(".toggle-password").click(function () {

    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
//   alert(input.attr("type"));
    if (input.attr("type") == "password") {

        input.attr("type", "text");
    } else {
        input.attr("type", "password");
    }
});


//autoCompelete jquery Code

function autocomplete(inp, arr) {
    /*the autocomplete function takes two arguments,
     the text field element and an array of possible autocompleted values:*/
    var currentFocus;
    /*execute a function when someone writes in the text field:*/
    inp.addEventListener("input", function (e) {
        var a, b, i, val = this.value;
        /*close any already open lists of autocompleted values*/
        closeAllLists();
        if (!val) {
            return false;
        }
        currentFocus = -1;
        /*create a DIV element that will contain the items (values):*/
        a = document.createElement("DIV");
        a.setAttribute("id", this.id + "autocomplete-list");
        a.setAttribute("class", "autocomplete-items");
        /*append the DIV element as a child of the autocomplete container:*/
        this.parentNode.appendChild(a);
        /*for each item in the array...*/

        for (var key in arr) {
            /*check if the item starts with the same letters as the text field value:*/
            if (arr[key].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                /*create a DIV element for each matching element:*/
                b = document.createElement("DIV");
                /*make the matching letters bold:*/
                b.innerHTML = "<strong>" + arr[key].substr(0, val.length) + "</strong>";
                b.innerHTML += arr[key].substr(val.length);
                /*insert a input field that will hold the current array item's value:*/

//          alert(arr[key]);
//          alert(key);
                b.innerHTML += "<input type='hidden' value='" + key + "'>";
                /*execute a function when someone clicks on the item value (DIV element):*/
                b.addEventListener("click", function (e) {
                    /*insert the value for the autocomplete text field:*/
                    inp.value = this.getElementsByTagName("input")[0].value;
                    /*close the list of autocompleted values,
                     (or any other open lists of autocompleted values:*/
                    closeAllLists();
                });
                a.appendChild(b);
            }
        }
    });
    /*execute a function presses a key on the keyboard:*/
    inp.addEventListener("keydown", function (e) {
        var x = document.getElementById(this.id + "autocomplete-list");
        if (x)
            x = x.getElementsByTagName("div");
        if (e.keyCode == 40) {
            /*If the arrow DOWN key is pressed,
             increase the currentFocus variable:*/
            currentFocus++;
            /*and and make the current item more visible:*/
            addActive(x);
        } else if (e.keyCode == 38) { //up
            /*If the arrow UP key is pressed,
             decrease the currentFocus variable:*/
            currentFocus--;
            /*and and make the current item more visible:*/
            addActive(x);
        } else if (e.keyCode == 13) {
            /*If the ENTER key is pressed, prevent the form from being submitted,*/
            e.preventDefault();
            if (currentFocus > -1) {
                /*and simulate a click on the "active" item:*/
                if (x)
                    x[currentFocus].click();
            }
        }
    });
    inp.addEventListener("select", function (e) {});

    function addActive(x) {
        /*a function to classify an item as "active":*/
        if (!x)
            return false;
        /*start by removing the "active" class on all items:*/
        removeActive(x);
        if (currentFocus >= x.length)
            currentFocus = 0;
        if (currentFocus < 0)
            currentFocus = (x.length - 1);
        /*add class "autocomplete-active":*/
        x[currentFocus].classList.add("autocomplete-active");
    }
    function removeActive(x) {
        /*a function to remove the "active" class from all autocomplete items:*/
        for (var i = 0; i < x.length; i++) {
            x[i].classList.remove("autocomplete-active");
        }
    }
    function closeAllLists(elmnt) {
        /*close all autocomplete lists in the document,
         except the one passed as an argument:*/
        var x = document.getElementsByClassName("autocomplete-items");
        for (var i = 0; i < x.length; i++) {
            if (elmnt != x[i] && elmnt != inp) {
                x[i].parentNode.removeChild(x[i]);
            }
        }
    }
    /*execute a function when someone clicks in the document:*/
    document.addEventListener("click", function (e) {
        closeAllLists(e.target);
    });



}

function copyURL(obj) {
    /* Get the text field */
    var copyText = $(obj).siblings("input");
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val(copyText.val()).select();
    document.execCommand("copy");
    $temp.remove();
//    alert("Copied the text: " + copyText.val());

}
